import 'package:chat/admin_identity.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('administrator recognition is based only on the stable user ID', () {
    expect(isWaslaAdmin('92262d97-f604-423e-bac7-8573eafffa65'), isTrue);
    expect(isWaslaAdmin('92262D97-F604-423E-BAC7-8573EAFFFA65'), isTrue);
    expect(isWaslaAdmin('ordinary-user-id'), isFalse);
    expect(isWaslaAdmin(null), isFalse);
  });

  testWidgets('administrator label gets the accent and verification badge', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: AdminIdentityText(
            userId: '92262d97-f604-423e-bac7-8573eafffa65',
            label: 'درويش',
          ),
        ),
      ),
    );

    expect(find.byIcon(Icons.verified_rounded), findsOneWidget);
    final text = tester.widget<Text>(find.byType(Text));
    expect(text.style?.color, const Color(0xFF1769AA));
  });

  testWidgets('ordinary accounts stay unbadged even if their name matches', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: AdminIdentityText(
            userId: 'ordinary-user-id',
            label: 'darwish71',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
    );

    expect(find.byIcon(Icons.verified_rounded), findsNothing);
    final text = tester.widget<Text>(find.byType(Text));
    expect(text.data, 'darwish71');
    expect(text.style?.color, Colors.black);
  });
}
