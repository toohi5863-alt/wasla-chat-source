import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Device-local appearance preferences scoped to an account and conversation.
class ChatConversationSettingsStore {
  static const _fileName = 'wasla_chat_conversation_settings.json';

  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}/$_fileName');
  }

  Future<int?> backgroundColor(String userId, String conversationId) async {
    try {
      final file = await _file();
      if (!await file.exists()) return null;
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return null;
      final users = decoded['users'];
      if (users is! Map) return null;
      final userSettings = users[userId];
      if (userSettings is! Map) return null;
      final conversationSettings = userSettings[conversationId];
      if (conversationSettings is! Map) return null;
      final value = conversationSettings['background_color'];
      if (value is num) return value.toInt();
      return int.tryParse(value?.toString() ?? '');
    } on FormatException {
      return null;
    } on FileSystemException {
      return null;
    }
  }

  Future<void> setBackgroundColor(
    String userId,
    String conversationId,
    int? colorValue,
  ) async {
    final file = await _file();
    Map<String, dynamic> root = <String, dynamic>{'users': <String, dynamic>{}};
    if (await file.exists()) {
      try {
        final decoded = jsonDecode(await file.readAsString());
        if (decoded is Map) root = Map<String, dynamic>.from(decoded);
      } on FormatException {
        // Recover gracefully from a damaged local preference file.
      }
    }

    final usersValue = root['users'];
    final users = usersValue is Map
        ? Map<String, dynamic>.from(usersValue)
        : <String, dynamic>{};
    final accountValue = users[userId];
    final account = accountValue is Map
        ? Map<String, dynamic>.from(accountValue)
        : <String, dynamic>{};
    final conversationValue = account[conversationId];
    final conversation = conversationValue is Map
        ? Map<String, dynamic>.from(conversationValue)
        : <String, dynamic>{};
    if (colorValue == null) {
      conversation.remove('background_color');
    } else {
      conversation['background_color'] = colorValue;
    }
    account[conversationId] = conversation;
    users[userId] = account;
    root['users'] = users;

    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(jsonEncode(root), flush: true);
    await temporary.rename(file.path);
  }
}
