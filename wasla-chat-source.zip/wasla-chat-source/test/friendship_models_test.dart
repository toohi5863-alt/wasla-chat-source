import 'package:flutter_test/flutter_test.dart';
import 'package:chat/friendship_models.dart';

void main() {
  test('parses a pending incoming friendship request', () {
    final status = FriendshipStatus.fromMap({
      'status': 'pending',
      'requester_id': 'user-a',
      'addressee_id': 'user-b',
      'created_at': '2026-10-08T02:00:00Z',
    });

    expect(status.isPending, isTrue);
    expect(status.isIncomingFor('user-b'), isTrue);
    expect(status.isOutgoingFor('user-a'), isTrue);
    expect(status.isAccepted, isFalse);
    expect(status.createdAt, DateTime.parse('2026-10-08T02:00:00Z'));
  });

  test('parses empty and accepted friendship states', () {
    expect(FriendshipStatus.fromMap(null).status, 'none');
    expect(FriendshipStatus.fromMap({'status': 'accepted'}).isAccepted, isTrue);
  });

  test('parses accepted friend profile details', () {
    final friend = Friend.fromMap({
      'friend_id': 'user-b',
      'username': 'sara',
      'display_name': '',
      'avatar_path': 'user-b/avatar.jpg',
    });

    expect(friend.userId, 'user-b');
    expect(friend.label, '@sara');
    expect(friend.avatarPath, 'user-b/avatar.jpg');
  });

  test('uses username when a friend request has no display name', () {
    final request = FriendRequest.fromMap({
      'requester_id': 'user-a',
      'username': 'darwish_1',
      'display_name': '',
      'avatar_path': 'user-a/avatar.jpg',
    });

    expect(request.label, '@darwish_1');
    expect(request.avatarPath, 'user-a/avatar.jpg');
  });
}
