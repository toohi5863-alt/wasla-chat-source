class PushNotificationPreferences {
  const PushNotificationPreferences({
    this.messagesEnabled = true,
    this.groupsEnabled = true,
    this.channelsEnabled = true,
    this.statusesEnabled = false,
    this.callsEnabled = true,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.showMessagePreview = true,
    this.doNotDisturb = false,
  });

  final bool messagesEnabled;
  final bool groupsEnabled;
  final bool channelsEnabled;
  final bool statusesEnabled;
  final bool callsEnabled;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final bool showMessagePreview;
  final bool doNotDisturb;

  factory PushNotificationPreferences.fromMap(Map<String, dynamic>? map) {
    bool value(String key, bool fallback) =>
        map?[key] is bool ? map![key] as bool : fallback;

    return PushNotificationPreferences(
      messagesEnabled: value('messages_enabled', true),
      groupsEnabled: value('groups_enabled', true),
      channelsEnabled: value('channels_enabled', true),
      statusesEnabled: value('statuses_enabled', false),
      callsEnabled: value('calls_enabled', true),
      soundEnabled: value('sound_enabled', true),
      vibrationEnabled: value('vibration_enabled', true),
      showMessagePreview: value('show_message_preview', true),
      doNotDisturb: value('do_not_disturb', false),
    );
  }

  Map<String, dynamic> toMap() => {
    'messages_enabled': messagesEnabled,
    'groups_enabled': groupsEnabled,
    'channels_enabled': channelsEnabled,
    'statuses_enabled': statusesEnabled,
    'calls_enabled': callsEnabled,
    'sound_enabled': soundEnabled,
    'vibration_enabled': vibrationEnabled,
    'show_message_preview': showMessagePreview,
    'do_not_disturb': doNotDisturb,
  };

  bool enabledFor(String category) => switch (category) {
    'groups' => groupsEnabled,
    'channels' => channelsEnabled,
    'statuses' => statusesEnabled,
    'calls' => callsEnabled,
    _ => messagesEnabled,
  };

  bool allowsChatSoundFor(String category) =>
      soundEnabled && !doNotDisturb && enabledFor(category);

  PushNotificationPreferences copyWith({
    bool? messagesEnabled,
    bool? groupsEnabled,
    bool? channelsEnabled,
    bool? statusesEnabled,
    bool? callsEnabled,
    bool? soundEnabled,
    bool? vibrationEnabled,
    bool? showMessagePreview,
    bool? doNotDisturb,
  }) => PushNotificationPreferences(
    messagesEnabled: messagesEnabled ?? this.messagesEnabled,
    groupsEnabled: groupsEnabled ?? this.groupsEnabled,
    channelsEnabled: channelsEnabled ?? this.channelsEnabled,
    statusesEnabled: statusesEnabled ?? this.statusesEnabled,
    callsEnabled: callsEnabled ?? this.callsEnabled,
    soundEnabled: soundEnabled ?? this.soundEnabled,
    vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
    showMessagePreview: showMessagePreview ?? this.showMessagePreview,
    doNotDisturb: doNotDisturb ?? this.doNotDisturb,
  );
}

class ConversationNotificationPreference {
  const ConversationNotificationPreference({
    this.notificationsEnabled = true,
    this.mutedUntil,
  });

  final bool notificationsEnabled;
  final DateTime? mutedUntil;

  factory ConversationNotificationPreference.fromMap(
    Map<String, dynamic>? map,
  ) => ConversationNotificationPreference(
    notificationsEnabled: map?['notifications_enabled'] is bool
        ? map!['notifications_enabled'] as bool
        : true,
    mutedUntil: DateTime.tryParse(map?['muted_until']?.toString() ?? ''),
  );

  bool get isMuted =>
      !notificationsEnabled ||
      (mutedUntil != null && mutedUntil!.isAfter(DateTime.now().toUtc()));
}
