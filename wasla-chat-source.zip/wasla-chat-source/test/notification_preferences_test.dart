import 'package:flutter_test/flutter_test.dart';
import 'package:chat/notification_preferences.dart';

void main() {
  group('PushNotificationPreferences', () {
    test('uses safe defaults with status alerts opt-in', () {
      const preferences = PushNotificationPreferences();
      expect(preferences.messagesEnabled, isTrue);
      expect(preferences.groupsEnabled, isTrue);
      expect(preferences.channelsEnabled, isTrue);
      expect(preferences.statusesEnabled, isFalse);
      expect(preferences.callsEnabled, isTrue);
      expect(preferences.doNotDisturb, isFalse);
    });

    test('round-trips all account notification controls', () {
      const preferences = PushNotificationPreferences(
        messagesEnabled: false,
        groupsEnabled: false,
        channelsEnabled: true,
        statusesEnabled: true,
        callsEnabled: false,
        soundEnabled: false,
        vibrationEnabled: true,
        showMessagePreview: false,
        doNotDisturb: true,
      );
      final restored = PushNotificationPreferences.fromMap(preferences.toMap());
      expect(restored.toMap(), preferences.toMap());
      expect(restored.enabledFor('messages'), isFalse);
      expect(restored.enabledFor('groups'), isFalse);
      expect(restored.enabledFor('channels'), isTrue);
      expect(restored.enabledFor('statuses'), isTrue);
      expect(restored.enabledFor('calls'), isFalse);
      expect(restored.allowsChatSoundFor('messages'), isFalse);
      expect(restored.allowsChatSoundFor('groups'), isFalse);
    });

    test('chat sound follows sound, do-not-disturb and category controls', () {
      expect(
        const PushNotificationPreferences().allowsChatSoundFor('messages'),
        isTrue,
      );
      expect(
        const PushNotificationPreferences(soundEnabled: false)
            .allowsChatSoundFor('messages'),
        isFalse,
      );
      expect(
        const PushNotificationPreferences(doNotDisturb: true)
            .allowsChatSoundFor('messages'),
        isFalse,
      );
      expect(
        const PushNotificationPreferences(groupsEnabled: false)
            .allowsChatSoundFor('groups'),
        isFalse,
      );
    });
  });

  group('ConversationNotificationPreference', () {
    test('treats missing rows as enabled', () {
      const preference = ConversationNotificationPreference();
      expect(preference.isMuted, isFalse);
    });

    test('treats disabled and future-snoozed rows as muted', () {
      final disabled = ConversationNotificationPreference.fromMap({
        'notifications_enabled': false,
      });
      final snoozed = ConversationNotificationPreference.fromMap({
        'notifications_enabled': true,
        'muted_until': DateTime.now()
            .toUtc()
            .add(const Duration(hours: 1))
            .toIso8601String(),
      });
      expect(disabled.isMuted, isTrue);
      expect(snoozed.isMuted, isTrue);
    });

    test('ignores expired snooze time', () {
      final preference = ConversationNotificationPreference.fromMap({
        'notifications_enabled': true,
        'muted_until': DateTime.utc(2000).toIso8601String(),
      });
      expect(preference.isMuted, isFalse);
    });
  });
}
