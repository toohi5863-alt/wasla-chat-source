import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

enum AppTextSize {
  compact(scaleFactor: 0.9, label: 'أصغر'),
  standard(scaleFactor: 1.0, label: 'قياسي'),
  large(scaleFactor: 1.15, label: 'كبير'),
  extraLarge(scaleFactor: 1.3, label: 'كبير جدًا');

  const AppTextSize({required this.scaleFactor, required this.label});

  final double scaleFactor;
  final String label;

  static AppTextSize fromValue(Object? value) => switch (value?.toString()) {
    'compact' => AppTextSize.compact,
    'large' => AppTextSize.large,
    'extra_large' => AppTextSize.extraLarge,
    _ => AppTextSize.standard,
  };

  String get value => switch (this) {
    AppTextSize.compact => 'compact',
    AppTextSize.standard => 'standard',
    AppTextSize.large => 'large',
    AppTextSize.extraLarge => 'extra_large',
  };
}

enum MessageBubbleStyle {
  classic(
    value: 'classic',
    label: 'كلاسيكي',
    description: 'زوايا ناعمة مع طرف مميز',
  ),
  rounded(
    value: 'rounded',
    label: 'مستدير',
    description: 'حواف مستديرة بالكامل',
  ),
  compact(
    value: 'compact',
    label: 'مربع ناعم',
    description: 'زوايا أقصر ومظهر هادئ',
  );

  const MessageBubbleStyle({
    required this.value,
    required this.label,
    required this.description,
  });

  final String value;
  final String label;
  final String description;

  static MessageBubbleStyle fromValue(Object? value) =>
      switch (value?.toString()) {
        'rounded' => MessageBubbleStyle.rounded,
        'compact' => MessageBubbleStyle.compact,
        _ => MessageBubbleStyle.classic,
      };

  BorderRadius borderRadiusFor({required bool mine}) => switch (this) {
    MessageBubbleStyle.classic => BorderRadius.only(
      topLeft: const Radius.circular(20),
      topRight: const Radius.circular(20),
      bottomLeft: Radius.circular(mine ? 20 : 6),
      bottomRight: Radius.circular(mine ? 6 : 20),
    ),
    MessageBubbleStyle.rounded => BorderRadius.circular(22),
    MessageBubbleStyle.compact => BorderRadius.circular(12),
  };
}

class AppThemeOption {
  const AppThemeOption({
    required this.id,
    required this.name,
    required this.seedColor,
  });

  final String id;
  final String name;
  final int seedColor;

  Color get color => Color(seedColor);
  bool get isCustom => id.startsWith('custom_');

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'seed_color': seedColor,
  };

  static AppThemeOption? fromMap(Object? value) {
    if (value is! Map) return null;
    final map = Map<String, dynamic>.from(value);
    final id = map['id']?.toString().trim() ?? '';
    final name = map['name']?.toString().trim() ?? '';
    final rawColor = map['seed_color'];
    final color = rawColor is num
        ? rawColor.toInt()
        : int.tryParse(rawColor?.toString() ?? '');
    if (id.isEmpty || name.isEmpty || color == null) return null;
    return AppThemeOption(id: id, name: name, seedColor: color);
  }
}

const appThemePresets = <AppThemeOption>[
  AppThemeOption(id: 'wasla', name: 'وصال', seedColor: 0xFF087F72),
  AppThemeOption(id: 'ocean', name: 'المحيط', seedColor: 0xFF1769AA),
  AppThemeOption(id: 'violet', name: 'لافندر', seedColor: 0xFF6750A4),
  AppThemeOption(id: 'rose', name: 'وردي', seedColor: 0xFFB33C68),
  AppThemeOption(id: 'sunset', name: 'غروب', seedColor: 0xFFC45A28),
  AppThemeOption(id: 'forest', name: 'غابة', seedColor: 0xFF55723B),
  AppThemeOption(id: 'slate', name: 'رمادي', seedColor: 0xFF52616B),
];

AppThemeOption appThemeById(String id, List<AppThemeOption> customThemes) {
  for (final theme in customThemes) {
    if (theme.id == id) return theme;
  }
  for (final theme in appThemePresets) {
    if (theme.id == id) return theme;
  }
  return appThemePresets.first;
}

class AppSettings {
  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.themeId = 'wasla',
    this.customThemes = const [],
    this.textSize = AppTextSize.standard,
    this.bubbleStyle = MessageBubbleStyle.classic,
    this.reduceMotion = false,
    this.highContrast = false,
    this.compactLayout = false,
    this.showChatStatusHighlights = true,
  });

  final ThemeMode themeMode;
  final String themeId;
  final List<AppThemeOption> customThemes;
  final AppTextSize textSize;
  final MessageBubbleStyle bubbleStyle;
  final bool reduceMotion;
  final bool highContrast;
  final bool compactLayout;
  final bool showChatStatusHighlights;

  AppSettings copyWith({
    ThemeMode? themeMode,
    String? themeId,
    List<AppThemeOption>? customThemes,
    AppTextSize? textSize,
    MessageBubbleStyle? bubbleStyle,
    bool? reduceMotion,
    bool? highContrast,
    bool? compactLayout,
    bool? showChatStatusHighlights,
  }) => AppSettings(
    themeMode: themeMode ?? this.themeMode,
    themeId: themeId ?? this.themeId,
    customThemes: customThemes ?? this.customThemes,
    textSize: textSize ?? this.textSize,
    bubbleStyle: bubbleStyle ?? this.bubbleStyle,
    reduceMotion: reduceMotion ?? this.reduceMotion,
    highContrast: highContrast ?? this.highContrast,
    compactLayout: compactLayout ?? this.compactLayout,
    showChatStatusHighlights:
        showChatStatusHighlights ?? this.showChatStatusHighlights,
  );

  factory AppSettings.fromMap(Map<String, dynamic> map) {
    final value = map['theme_mode']?.toString();
    final rawThemes = map['custom_themes'];
    final customThemes = rawThemes is List
        ? rawThemes
              .map(AppThemeOption.fromMap)
              .whereType<AppThemeOption>()
              .toList()
        : <AppThemeOption>[];
    final requestedThemeId = map['theme_id']?.toString() ?? 'wasla';
    final validThemeIds = {
      ...appThemePresets.map((theme) => theme.id),
      ...customThemes.map((theme) => theme.id),
    };
    return AppSettings(
      themeMode: switch (value) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      },
      themeId: validThemeIds.contains(requestedThemeId)
          ? requestedThemeId
          : 'wasla',
      customThemes: customThemes,
      textSize: AppTextSize.fromValue(map['text_size']),
      bubbleStyle: MessageBubbleStyle.fromValue(map['bubble_style']),
      reduceMotion: map['reduce_motion'] == true,
      highContrast: map['high_contrast'] == true,
      compactLayout: map['compact_layout'] == true,
      showChatStatusHighlights: map['show_chat_status_highlights'] != false,
    );
  }

  Map<String, dynamic> toMap() => {
    'theme_mode': switch (themeMode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    },
    'theme_id': themeId,
    'custom_themes': customThemes.map((theme) => theme.toMap()).toList(),
    'text_size': textSize.value,
    'bubble_style': bubbleStyle.value,
    'reduce_motion': reduceMotion,
    'high_contrast': highContrast,
    'compact_layout': compactLayout,
    'show_chat_status_highlights': showChatStatusHighlights,
  };
}

/// Device-local preferences partitioned by authenticated account.
class AppSettingsStore {
  static const _fileName = 'wasla_app_settings.json';

  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}/$_fileName');
  }

  Future<AppSettings> load(String userId) async {
    if (userId.isEmpty) return const AppSettings();
    final file = await _file();
    if (!await file.exists()) return const AppSettings();

    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return const AppSettings();
      final users = decoded['users'];
      if (users is! Map) return const AppSettings();
      final value = users[userId];
      if (value is! Map) return const AppSettings();
      return AppSettings.fromMap(Map<String, dynamic>.from(value));
    } on FormatException {
      return const AppSettings();
    }
  }

  Future<void> save(String userId, AppSettings settings) async {
    if (userId.isEmpty) return;
    final file = await _file();
    Map<String, dynamic> root = <String, dynamic>{'users': <String, dynamic>{}};
    if (await file.exists()) {
      try {
        final decoded = jsonDecode(await file.readAsString());
        if (decoded is Map) root = Map<String, dynamic>.from(decoded);
      } on FormatException {
        // Keep the application usable if an old local settings file is damaged.
      }
    }

    final usersValue = root['users'];
    final users = usersValue is Map
        ? Map<String, dynamic>.from(usersValue)
        : <String, dynamic>{};
    users[userId] = settings.toMap();
    root['users'] = users;

    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(jsonEncode(root), flush: true);
    await temporary.rename(file.path);
  }
}
