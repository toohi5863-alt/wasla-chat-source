import 'package:chat/wasla_runtime_settings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  setUp(() {
    WaslaRuntimeSettings.announcementEnabled = false;
    WaslaRuntimeSettings.announcementText = '';
    WaslaRuntimeSettings.messagesEnabled = true;
    WaslaRuntimeSettings.mediaUploadsEnabled = true;
    WaslaRuntimeSettings.maxMediaUploadMb = 15;
  });

  group('WaslaRuntimeSettings', () {
    test('uses permissive defaults when no public settings are available', () {
      expect(WaslaRuntimeSettings.announcementEnabled, isFalse);
      expect(WaslaRuntimeSettings.announcementText, isEmpty);
      expect(WaslaRuntimeSettings.messagesEnabled, isTrue);
      expect(WaslaRuntimeSettings.mediaUploadsEnabled, isTrue);
      expect(WaslaRuntimeSettings.maxMediaUploadMb, 15);
      expect(WaslaRuntimeSettings.maxMediaUploadBytes, 15 * 1024 * 1024);
    });

    test('applies all supported public message and media settings', () {
      final changed = WaslaRuntimeSettings.applyPublicSettings({
        'announcement_enabled': true,
        'announcement_text': 'تحديث وصال',
        'messages_enabled': false,
        'media_uploads_enabled': false,
        'max_media_upload_mb': '8',
      });

      expect(changed, isTrue);
      expect(WaslaRuntimeSettings.announcementEnabled, isTrue);
      expect(WaslaRuntimeSettings.announcementText, 'تحديث وصال');
      expect(WaslaRuntimeSettings.messagesEnabled, isFalse);
      expect(WaslaRuntimeSettings.mediaUploadsEnabled, isFalse);
      expect(WaslaRuntimeSettings.maxMediaUploadMb, 8);
      expect(WaslaRuntimeSettings.maxMediaUploadBytes, 8 * 1024 * 1024);
    });

    test('returns false when applying the same settings a second time', () {
      const values = {
        'messages_enabled': true,
        'media_uploads_enabled': true,
        'max_media_upload_mb': 15,
      };

      expect(WaslaRuntimeSettings.applyPublicSettings(values), isFalse);
      expect(WaslaRuntimeSettings.applyPublicSettings(values), isFalse);
    });

    test('ignores malformed or out-of-range upload limits', () {
      WaslaRuntimeSettings.maxMediaUploadMb = 7;

      for (final value in [0, -1, 16, 'invalid', null]) {
        WaslaRuntimeSettings.applyPublicSettings({
          'max_media_upload_mb': value,
        });
        expect(WaslaRuntimeSettings.maxMediaUploadMb, 7);
      }
    });

    test('ignores unknown settings and values with unsupported types', () {
      final changed = WaslaRuntimeSettings.applyPublicSettings({
        'messages_enabled': 'false',
        'media_uploads_enabled': 0,
        'announcement_text': false,
        'max_video_upload_mb': 2,
      });

      expect(changed, isFalse);
      expect(WaslaRuntimeSettings.messagesEnabled, isTrue);
      expect(WaslaRuntimeSettings.mediaUploadsEnabled, isTrue);
      expect(WaslaRuntimeSettings.announcementText, isEmpty);
      expect(WaslaRuntimeSettings.maxMediaUploadMb, 15);
    });
  });
}
