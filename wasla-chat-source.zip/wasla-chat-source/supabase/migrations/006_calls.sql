-- Wasla 1.6: secure one-to-one audio/video call history and WebRTC signaling.
-- Call media itself is peer-to-peer; these tables carry only call state and SDP/ICE signaling.
create table if not exists public.calls (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null,
  caller_id uuid not null,
  callee_id uuid not null,
  media_type text not null check (media_type in ('audio', 'video')),
  status text not null default 'ringing'
    check (status in ('ringing', 'accepted', 'rejected', 'missed', 'ended', 'cancelled')),
  created_at timestamptz not null default now(),
  answered_at timestamptz,
  ended_at timestamptz,
  constraint calls_distinct_participants check (caller_id <> callee_id),
  constraint calls_caller_member_fkey
    foreign key (conversation_id, caller_id)
    references public.conversation_members(conversation_id, user_id) on delete cascade,
  constraint calls_callee_member_fkey
    foreign key (conversation_id, callee_id)
    references public.conversation_members(conversation_id, user_id) on delete cascade
);

create index if not exists calls_caller_created_idx
  on public.calls(caller_id, created_at desc);
create index if not exists calls_callee_created_idx
  on public.calls(callee_id, created_at desc);
create index if not exists calls_callee_ringing_idx
  on public.calls(callee_id, created_at desc) where status = 'ringing';

create table if not exists public.call_signals (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null references public.calls(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  signal_type text not null check (signal_type in ('offer', 'answer', 'ice')),
  data jsonb not null,
  created_at timestamptz not null default now(),
  constraint call_signals_distinct_participants check (sender_id <> receiver_id),
  constraint call_signals_payload_limit check (pg_column_size(data) <= 65536)
);

create index if not exists call_signals_call_created_idx
  on public.call_signals(call_id, created_at);
create index if not exists call_signals_receiver_call_idx
  on public.call_signals(receiver_id, call_id, created_at);

alter table public.calls enable row level security;
alter table public.call_signals enable row level security;

revoke all on public.calls, public.call_signals from anon, authenticated;
grant select, insert on public.calls to authenticated;
grant update (status, answered_at, ended_at) on public.calls to authenticated;
grant select, insert on public.call_signals to authenticated;

drop policy if exists calls_select_participant on public.calls;
create policy calls_select_participant on public.calls
  for select to authenticated
  using (
    (caller_id = (select auth.uid()) or callee_id = (select auth.uid()))
    and private.is_conversation_member(conversation_id)
  );

drop policy if exists calls_insert_direct_member on public.calls;
create policy calls_insert_direct_member on public.calls
  for insert to authenticated
  with check (
    caller_id = (select auth.uid())
    and caller_id <> callee_id
    and status = 'ringing'
    and answered_at is null
    and ended_at is null
    and private.is_conversation_member(conversation_id)
    and exists (
      select 1
      from public.conversation_members peer
      where peer.conversation_id = calls.conversation_id
        and peer.user_id = calls.callee_id
    )
    and not exists (
      select 1 from public.groups group_row
      where group_row.conversation_id = calls.conversation_id
    )
    and (select count(*) from public.conversation_members members
         where members.conversation_id = calls.conversation_id) = 2
  );

-- Keep these UPDATE policies separate: each actor may perform only its allowed status transition.
drop policy if exists calls_answer_or_decline on public.calls;
create policy calls_answer_or_decline on public.calls
  for update to authenticated
  using (callee_id = (select auth.uid()) and status = 'ringing')
  with check (
    callee_id = (select auth.uid())
    and status in ('accepted', 'rejected', 'missed')
  );

drop policy if exists calls_cancel_outgoing on public.calls;
create policy calls_cancel_outgoing on public.calls
  for update to authenticated
  using (caller_id = (select auth.uid()) and status = 'ringing')
  with check (caller_id = (select auth.uid()) and status = 'cancelled');

drop policy if exists calls_end_as_caller on public.calls;
create policy calls_end_as_caller on public.calls
  for update to authenticated
  using (caller_id = (select auth.uid()) and status = 'accepted')
  with check (caller_id = (select auth.uid()) and status = 'ended');

drop policy if exists calls_end_as_callee on public.calls;
create policy calls_end_as_callee on public.calls
  for update to authenticated
  using (callee_id = (select auth.uid()) and status = 'accepted')
  with check (callee_id = (select auth.uid()) and status = 'ended');

drop policy if exists call_signals_select_receiver on public.call_signals;
create policy call_signals_select_receiver on public.call_signals
  for select to authenticated
  using (
    receiver_id = (select auth.uid())
    and exists (
      select 1 from public.calls call_row
      where call_row.id = call_signals.call_id
        and call_row.status in ('ringing', 'accepted')
        and (
          (call_row.caller_id = call_signals.sender_id and call_row.callee_id = call_signals.receiver_id)
          or (call_row.callee_id = call_signals.sender_id and call_row.caller_id = call_signals.receiver_id)
        )
    )
  );

drop policy if exists call_signals_insert_participant on public.call_signals;
create policy call_signals_insert_participant on public.call_signals
  for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and sender_id <> receiver_id
    and exists (
      select 1 from public.calls call_row
      where call_row.id = call_signals.call_id
        and call_row.status in ('ringing', 'accepted')
        and (
          (call_row.caller_id = call_signals.sender_id and call_row.callee_id = call_signals.receiver_id)
          or (call_row.callee_id = call_signals.sender_id and call_row.caller_id = call_signals.receiver_id)
        )
    )
  );

-- Keep the signaling tables available to Postgres Changes subscriptions. RLS still limits each row to its participants.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'calls'
  ) then
    alter publication supabase_realtime add table public.calls;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'call_signals'
  ) then
    alter publication supabase_realtime add table public.call_signals;
  end if;
exception when undefined_object then
  raise notice 'Publication supabase_realtime is unavailable; enable it for public.calls and public.call_signals.';
end;
$$;
