-- Wasla 1.20: purge newly opted-in message payloads only after every recipient
-- account has persisted the full message and attachment locally. Existing rows
-- and clients that do not set ephemeral=true are deliberately left untouched.

alter table public.messages
  add column if not exists ephemeral boolean not null default false,
  add column if not exists payload_deleted_at timestamptz;

create table if not exists private.message_delivery_receipts (
  message_id uuid not null references public.messages(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  delivered_at timestamptz,
  excluded_at timestamptz,
  primary key (message_id, recipient_id)
);
alter table private.message_delivery_receipts
  add column if not exists excluded_at timestamptz;
alter table private.message_delivery_receipts enable row level security;
revoke all on private.message_delivery_receipts from public, anon, authenticated;

create or replace function private.capture_ephemeral_recipients()
returns trigger
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
begin
  if new.ephemeral then
    insert into private.message_delivery_receipts (message_id, recipient_id)
    select new.id, cm.user_id
    from public.conversation_members cm
    where cm.conversation_id = new.conversation_id
      and cm.user_id <> new.sender_id
    on conflict (message_id, recipient_id) do nothing;
  end if;
  return new;
end;
$$;
revoke all on function private.capture_ephemeral_recipients() from public, anon, authenticated;

drop trigger if exists capture_ephemeral_recipients on public.messages;
create trigger capture_ephemeral_recipients
after insert on public.messages
for each row execute function private.capture_ephemeral_recipients();

create or replace function public.acknowledge_ephemeral_message(p_message_id uuid)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public, private, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_message public.messages%rowtype;
  v_recipient_count integer;
  v_pending_count integer;
  v_payload_deleted boolean := false;
  v_media_path text;
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;

  select * into v_message
  from public.messages m
  where m.id = p_message_id
  for update;
  if not found then
    raise exception 'Message not found';
  end if;
  if not v_message.ephemeral then
    raise exception 'Message is not eligible for local-only delivery';
  end if;
  if v_message.sender_id = v_user_id
     or not exists (
       select 1 from private.message_delivery_receipts r
       where r.message_id = p_message_id and r.recipient_id = v_user_id
     ) then
    raise exception 'User is not a recipient of this message';
  end if;

  update private.message_delivery_receipts r
  set delivered_at = coalesce(r.delivered_at, now())
  where r.message_id = p_message_id and r.recipient_id = v_user_id;

  update public.messages m
  set delivered_at = coalesce(m.delivered_at, now())
  where m.id = p_message_id;

  update private.message_delivery_receipts r
  set excluded_at = coalesce(r.excluded_at, now())
  where r.message_id = p_message_id
    and r.delivered_at is null
    and r.excluded_at is null
    and not exists (
      select 1 from public.conversation_members cm
      where cm.conversation_id = v_message.conversation_id
        and cm.user_id = r.recipient_id
    );

  select count(*) filter (where r.excluded_at is null)::integer,
         count(*) filter (
           where r.delivered_at is null and r.excluded_at is null
         )::integer
    into v_recipient_count, v_pending_count
  from private.message_delivery_receipts r
  where r.message_id = p_message_id;

  if v_recipient_count > 0 and v_pending_count = 0
     and v_message.payload_deleted_at is null then
    update public.messages m
    set content = 'تم التسليم',
        payload_deleted_at = now(),
        delivered_at = coalesce(m.delivered_at, now())
    where m.id = p_message_id;
    v_payload_deleted := true;
    v_media_path := v_message.media_path;
  elsif v_message.payload_deleted_at is not null then
    v_payload_deleted := true;
    v_media_path := v_message.media_path;
  end if;

  return jsonb_build_object(
    'payload_deleted', v_payload_deleted,
    'media_path', v_media_path
  );
end;
$$;
revoke all on function public.acknowledge_ephemeral_message(uuid) from public, anon;
grant execute on function public.acknowledge_ephemeral_message(uuid) to authenticated;

-- Called only after Storage confirms that the object has been removed. A media
-- row becomes a content-free text tombstone so existing FKs and chat ordering
-- remain valid without retaining the media reference or original body.
create or replace function public.finalize_message_media_cleanup(p_message_id uuid)
returns void
language plpgsql
volatile
security definer
set search_path = public, private, pg_temp
as $$
declare
  v_conversation_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  select m.conversation_id into v_conversation_id
  from public.messages m
  where m.id = p_message_id
    and m.payload_deleted_at is not null
    and m.media_path is not null
  for update;
  if v_conversation_id is null then
    return;
  end if;
  if not private.is_conversation_member(v_conversation_id) then
    raise exception 'User is not a conversation member';
  end if;
  update public.messages m
  set message_type = 'text', media_path = null, media_duration_seconds = null
  where m.id = p_message_id and m.payload_deleted_at is not null;
end;
$$;
revoke all on function public.finalize_message_media_cleanup(uuid) from public, anon;
grant execute on function public.finalize_message_media_cleanup(uuid) to authenticated;

-- Recipients may remove a media object only after the database records that all
-- target accounts acknowledged local persistence. Sender-owned cleanup remains
-- governed by the existing wasla_media_delete_own policy.
drop policy if exists wasla_media_delete_after_delivery on storage.objects;
create policy wasla_media_delete_after_delivery on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'wasla-media'
    and exists (
      select 1
      from public.messages m
      where m.media_path = storage.objects.name
        and m.payload_deleted_at is not null
        and private.is_conversation_member(m.conversation_id)
    )
  );
