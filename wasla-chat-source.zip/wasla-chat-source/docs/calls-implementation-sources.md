# مراجع تنفيذ المكالمات

- حزمة Flutter WebRTC واستخدامها على Android، والمتطلبات المعلنة للكاميرا والميكروفون والشبكة: [flutter_webrtc على pub.dev](https://pub.dev/packages/flutter_webrtc). تم استخدام إصدار `1.6.2+hotfix.4` في هذه النسخة.
- صلاحيات Realtime وطريقة عزل Broadcast/Presence عبر RLS: [Supabase Realtime Authorization](https://supabase.com/docs/guides/realtime/authorization). يستخدم هذا التنفيذ Postgres Changes مع RLS على جداول المكالمات والإشارات، بدل Broadcast.
- حماية تغيير حالة المكالمة والاستعلامات المقيدة: [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security).

## ملاحظة تشغيل

تبادل SDP/ICE يمر عبر Supabase، أما الصوت/الفيديو فينتقل عبر WebRTC وSTUN العام. يلزم خادم TURN موثوق لتحسين نجاح الاتصال خلف NAT والشبكات المقيدة؛ لا تضع بيانات اعتماد TURN ثابتة داخل APK. يتطلب الرنين خارج التطبيق إعداد إشعارات خلفية منفصلًا.
