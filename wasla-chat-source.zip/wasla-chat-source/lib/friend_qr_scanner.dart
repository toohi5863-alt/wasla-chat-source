import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';

import 'friend_qr_code.dart';

class FriendQrScannerScreen extends StatefulWidget {
  const FriendQrScannerScreen({super.key});

  @override
  State<FriendQrScannerScreen> createState() => _FriendQrScannerScreenState();
}

class _FriendQrScannerScreenState extends State<FriendQrScannerScreen>
    with WidgetsBindingObserver {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    facing: CameraFacing.back,
    formats: const [BarcodeFormat.qrCode],
  );

  PermissionStatus? _cameraPermission;
  bool _checkingPermission = true;
  bool _scanInProgress = false;
  DateTime? _lastInvalidNotice;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_requestCameraPermission());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    unawaited(_controller.dispose());
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        _cameraPermission?.isGranted != true) {
      unawaited(_requestCameraPermission());
    }
  }

  Future<void> _requestCameraPermission() async {
    if (mounted) setState(() => _checkingPermission = true);
    var status = await Permission.camera.status;
    if (!status.isGranted &&
        !status.isPermanentlyDenied &&
        !status.isRestricted) {
      status = await Permission.camera.request();
    }
    if (!mounted) return;
    setState(() {
      _cameraPermission = status;
      _checkingPermission = false;
    });
  }

  Future<void> _openCameraSettings() async {
    await openAppSettings();
  }

  Future<void> _retryCamera() async {
    await _requestCameraPermission();
    if (!mounted || _cameraPermission?.isGranted != true) return;
    try {
      await _controller.start();
    } catch (_) {
      // MobileScanner's error builder remains visible and lets the user retry.
    }
  }

  Future<void> _toggleTorch() async {
    try {
      await _controller.toggleTorch();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الفلاش غير متاح على هذا الجهاز.')),
      );
    }
  }

  void _onDetect(BarcodeCapture capture) {
    if (_scanInProgress) return;
    String? value;
    for (final barcode in capture.barcodes) {
      if (barcode.format == BarcodeFormat.qrCode && barcode.rawValue != null) {
        value = barcode.rawValue;
        break;
      }
    }
    if (value == null) return;

    final parsed = FriendQrCode.parse(value);
    if (parsed == null) {
      final now = DateTime.now();
      if (_lastInvalidNotice == null ||
          now.difference(_lastInvalidNotice!) > const Duration(seconds: 2)) {
        _lastInvalidNotice = now;
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(
            const SnackBar(
              content: Text('هذا الرمز غير صالح لإضافة صديق على وصال.'),
            ),
          );
      }
      return;
    }

    _scanInProgress = true;
    unawaited(_finishScan(parsed));
  }

  Future<void> _finishScan(FriendQrCode code) async {
    try {
      await _controller.stop();
    } catch (_) {
      // Returning the successfully parsed code is more useful than blocking.
    }
    if (!mounted) return;
    Navigator.of(context).pop(code);
  }

  Widget _permissionMessage({required bool permanent}) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.no_photography_outlined,
            size: 54,
            color: Colors.white70,
          ),
          const SizedBox(height: 16),
          Text(
            permanent
                ? 'صلاحية الكاميرا موقوفة. فعّلها من إعدادات التطبيق لمسح الرمز.'
                : 'يلزم السماح للكاميرا حتى تتمكن من مسح رمز QR.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, height: 1.5),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: permanent
                ? _openCameraSettings
                : _requestCameraPermission,
            icon: Icon(
              permanent ? Icons.settings_outlined : Icons.camera_alt_outlined,
            ),
            label: Text(permanent ? 'فتح إعدادات التطبيق' : 'السماح بالكاميرا'),
          ),
        ],
      ),
    ),
  );

  Widget _scannerError(BuildContext context, MobileScannerException error) =>
      Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.camera_alt_outlined,
                size: 52,
                color: Colors.white70,
              ),
              const SizedBox(height: 16),
              const Text(
                'تعذر تشغيل الكاميرا. تحقق من الصلاحية وأعد المحاولة.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, height: 1.5),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _retryCamera,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final permission = _cameraPermission;
    final cameraReady = permission?.isGranted == true;
    final permanentlyBlocked =
        permission?.isPermanentlyDenied == true ||
        permission?.isRestricted == true;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: const Text('مسح رمز QR'),
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          actions: [
            if (cameraReady)
              IconButton(
                tooltip: 'تشغيل الفلاش',
                onPressed: () => unawaited(_toggleTorch()),
                icon: const Icon(Icons.flash_on_outlined),
              ),
          ],
        ),
        body: _checkingPermission
            ? const Center(child: CircularProgressIndicator())
            : !cameraReady
            ? _permissionMessage(permanent: permanentlyBlocked)
            : Stack(
                fit: StackFit.expand,
                children: [
                  MobileScanner(
                    controller: _controller,
                    onDetect: _onDetect,
                    errorBuilder: _scannerError,
                  ),
                  IgnorePointer(
                    child: Center(
                      child: Container(
                        width: 264,
                        height: 264,
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Theme.of(context).colorScheme.primary,
                            width: 3,
                          ),
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: double.infinity,
                      color: Colors.black.withValues(alpha: .62),
                      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
                      child: const Text(
                        'وجّه الكاميرا نحو رمز وصال لفتح ملف صاحبه.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, height: 1.5),
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
