import 'package:flutter_test/flutter_test.dart';
import 'package:chat/incoming_chat_sound_gate.dart';

void main() {
  group('IncomingChatSoundGate', () {
    test('does not play for history loads or non-insert events', () {
      final gate = IncomingChatSoundGate();

      expect(
        gate.shouldPlay(
          isInsert: false,
          messageId: 'old-message',
          senderId: 'peer',
          currentUserId: 'me',
        ),
        isFalse,
      );
      expect(
        gate.shouldPlay(
          isInsert: false,
          messageId: 'updated-message',
          senderId: 'peer',
          currentUserId: 'me',
        ),
        isFalse,
      );
    });

    test('plays for a fresh insert from another sender, once only', () {
      final gate = IncomingChatSoundGate();

      bool receive() => gate.shouldPlay(
        isInsert: true,
        messageId: 'message-1',
        senderId: 'peer',
        currentUserId: 'me',
      );

      expect(receive(), isTrue);
      expect(receive(), isFalse);
    });

    test('does not play for a message sent by the current user', () {
      final gate = IncomingChatSoundGate();

      expect(
        gate.shouldPlay(
          isInsert: true,
          messageId: 'outgoing-message',
          senderId: 'me',
          currentUserId: 'me',
        ),
        isFalse,
      );
    });

    test('does not play when sender or message identity is unavailable', () {
      final gate = IncomingChatSoundGate();

      expect(
        gate.shouldPlay(
          isInsert: true,
          messageId: 'message-without-sender',
          senderId: null,
          currentUserId: 'me',
        ),
        isFalse,
      );
      expect(
        gate.shouldPlay(
          isInsert: true,
          messageId: null,
          senderId: 'peer',
          currentUserId: 'me',
        ),
        isFalse,
      );
    });
  });
}
