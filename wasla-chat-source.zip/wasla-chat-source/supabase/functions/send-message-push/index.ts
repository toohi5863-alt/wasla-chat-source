import { createClient } from 'npm:@supabase/supabase-js@2';

const encoder = new TextEncoder();
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-wasla-webhook-secret, x-wasla-device-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const categories = ['messages', 'groups', 'channels', 'statuses', 'calls'] as const;
type Category = typeof categories[number];
type AdminClient = ReturnType<typeof createClient<any>>;
type JsonRow = Record<string, unknown>;

type WebhookPayload = {
  type?: string;
  table?: string;
  schema?: string;
  message_id?: string;
  record?: JsonRow;
  old_record?: JsonRow;
};

type ServiceAccount = {
  project_id: string;
  client_email: string;
  private_key: string;
};

type PushPreferences = {
  messages_enabled: boolean;
  groups_enabled: boolean;
  channels_enabled: boolean;
  statuses_enabled: boolean;
  calls_enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  show_message_preview: boolean;
  do_not_disturb: boolean;
};

type PushNotice = {
  title: string;
  body: string;
  data: Record<string, string>;
  tag: string;
  privateContent?: boolean;
  ttl?: string;
};

type DeviceRow = { token: string; user_id: string };

type NoticeFactory = (preferences: PushPreferences) => PushNotice;

const defaultPreferences: PushPreferences = {
  messages_enabled: true,
  groups_enabled: true,
  channels_enabled: true,
  statuses_enabled: false,
  calls_enabled: true,
  sound_enabled: true,
  vibration_enabled: true,
  show_message_preview: true,
  do_not_disturb: false,
};

function stringValue(row: JsonRow | null | undefined, key: string): string {
  const value = row?.[key];
  return typeof value === 'string' ? value : '';
}

function boolValue(row: JsonRow | undefined, key: string, fallback: boolean): boolean {
  const value = row?.[key];
  return typeof value === 'boolean' ? value : fallback;
}

function stringList(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((item): item is string => typeof item === 'string');
}

function base64Url(bytes: Uint8Array): string {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/g, '');
}

function constantTimeEqual(left: string, right: string): boolean {
  if (!left || !right || left.length !== right.length) return false;
  let different = 0;
  for (let i = 0; i < left.length; i++) {
    different |= left.charCodeAt(i) ^ right.charCodeAt(i);
  }
  return different === 0;
}

async function createGoogleAccessToken(account: ServiceAccount): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = base64Url(encoder.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const claims = base64Url(encoder.encode(JSON.stringify({
    iss: account.client_email,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  })));
  const unsigned = `${header}.${claims}`;
  const pem = account.private_key
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\s/g, '');
  const privateKey = Uint8Array.from(atob(pem), (char) => char.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    'pkcs8',
    privateKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const signature = new Uint8Array(
    await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, encoder.encode(unsigned)),
  );
  const assertion = `${unsigned}.${base64Url(signature)}`;
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
    }),
  });
  if (!response.ok) throw new Error(`Google OAuth returned ${response.status}`);
  const data = await response.json();
  if (typeof data.access_token !== 'string') throw new Error('Google OAuth returned no token');
  return data.access_token;
}

function preferencesFor(row: JsonRow | undefined): PushPreferences {
  return {
    messages_enabled: boolValue(row, 'messages_enabled', defaultPreferences.messages_enabled),
    groups_enabled: boolValue(row, 'groups_enabled', defaultPreferences.groups_enabled),
    channels_enabled: boolValue(row, 'channels_enabled', defaultPreferences.channels_enabled),
    statuses_enabled: boolValue(row, 'statuses_enabled', defaultPreferences.statuses_enabled),
    calls_enabled: boolValue(row, 'calls_enabled', defaultPreferences.calls_enabled),
    sound_enabled: boolValue(row, 'sound_enabled', defaultPreferences.sound_enabled),
    vibration_enabled: boolValue(row, 'vibration_enabled', defaultPreferences.vibration_enabled),
    show_message_preview: boolValue(row, 'show_message_preview', defaultPreferences.show_message_preview),
    do_not_disturb: boolValue(row, 'do_not_disturb', defaultPreferences.do_not_disturb),
  };
}

function categoryEnabled(preferences: PushPreferences, category: Category): boolean {
  switch (category) {
    case 'messages': return preferences.messages_enabled;
    case 'groups': return preferences.groups_enabled;
    case 'channels': return preferences.channels_enabled;
    case 'statuses': return preferences.statuses_enabled;
    case 'calls': return preferences.calls_enabled;
  }
}

function channelId(category: Category, preferences: PushPreferences): string {
  const sound = preferences.sound_enabled ? 'sound' : 'silent';
  const vibration = preferences.vibration_enabled ? 'vibrate' : 'no_vibrate';
  return `wasla_${category}_${sound}_${vibration}`;
}

function messageText(message: JsonRow): string {
  const messageType = stringValue(message, 'message_type') || 'text';
  switch (messageType) {
    case 'image': return 'أرسل صورة';
    case 'video': return 'أرسل مقطع فيديو';
    case 'audio': return 'أرسل رسالة صوتية';
    case 'file': return 'أرسل ملفًا';
    case 'location': return 'أرسل موقعًا';
    default: return stringValue(message, 'content').trim();
  }
}

function mutedUntil(row: JsonRow | undefined): boolean {
  if (!row) return false;
  if (row.notifications_enabled === false) return true;
  const value = row.muted_until;
  if (typeof value !== 'string' || !value) return false;
  const until = Date.parse(value);
  return Number.isFinite(until) && until > Date.now();
}

async function deliverToUsers(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  recipientIds: string[],
  category: Category,
  noticeFactory: NoticeFactory,
  conversationId?: string,
  deliveryProbeMessageId?: string,
  dataOnly = false,
): Promise<number> {
  const uniqueIds = [...new Set(recipientIds)].filter((id) => id.length > 0);
  if (!uniqueIds.length) return 0;

  const { data: preferenceRows, error: preferenceError } = await admin
    .from('notification_preferences')
    .select('user_id,messages_enabled,groups_enabled,channels_enabled,statuses_enabled,calls_enabled,sound_enabled,vibration_enabled,show_message_preview,do_not_disturb')
    .in('user_id', uniqueIds)
    .limit(500);
  if (preferenceError) throw new Error('Could not load notification preferences');
  const preferenceByUser = new Map<string, PushPreferences>();
  for (const row of preferenceRows ?? []) {
    preferenceByUser.set(row.user_id, preferencesFor(row));
  }

  const conversationByUser = new Map<string, JsonRow>();
  if (conversationId) {
    const { data: conversationRows, error: conversationError } = await admin
      .from('conversation_notification_preferences')
      .select('user_id,notifications_enabled,muted_until')
      .eq('conversation_id', conversationId)
      .in('user_id', uniqueIds)
      .limit(500);
    if (conversationError) throw new Error('Could not load conversation mute settings');
    for (const row of conversationRows ?? []) {
      conversationByUser.set(row.user_id, row);
    }
  }

  const allowedIds = uniqueIds.filter((userId) => {
    const preferences = preferenceByUser.get(userId) ?? defaultPreferences;
    return !preferences.do_not_disturb &&
      categoryEnabled(preferences, category) &&
      !mutedUntil(conversationByUser.get(userId));
  });
  if (!allowedIds.length) return 0;

  const { data: devices, error: devicesError } = await admin
    .from('push_devices')
    .select('token,user_id')
    .in('user_id', allowedIds)
    .eq('platform', 'android')
    .limit(1000);
  if (devicesError) throw new Error('Could not load recipient devices');
  if (!devices?.length) return 0;

  const results = await Promise.all((devices as DeviceRow[]).map(async (device) => {
    const preferences = preferenceByUser.get(device.user_id) ?? defaultPreferences;
    const notice = noticeFactory(preferences);
    const data = Object.fromEntries(
      Object.entries(notice.data).map(([key, value]) => [key, String(value)]),
    );
    const notification: Record<string, unknown> = {
      channel_id: channelId(category, preferences),
      icon: 'ic_stat_wasla',
      visibility: notice.privateContent ? 'PRIVATE' : 'PUBLIC',
      tag: notice.tag,
    };
    if (preferences.sound_enabled) notification.sound = 'default';

    // Calls use data-only FCM so Android can run the app's background handler
    // and create a ringing, full-screen local notification. All other notice
    // categories retain the existing system-rendered notification payload.
    const messagePayload = dataOnly
      ? {
          token: device.token,
          data: {
            ...data,
            calls_enabled: String(preferences.calls_enabled),
            sound_enabled: String(preferences.sound_enabled),
            vibration_enabled: String(preferences.vibration_enabled),
            do_not_disturb: String(preferences.do_not_disturb),
          },
          android: {
            priority: 'HIGH',
            ttl: notice.ttl ?? '3600s',
          },
        }
      : {
          token: device.token,
          notification: {
            title: notice.title.slice(0, 180),
            body: notice.body.slice(0, 1000),
          },
          data,
          android: {
            priority: 'HIGH',
            ttl: notice.ttl ?? '3600s',
            notification,
          },
        };

    const response = await fetch(
      `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(account.project_id)}/messages:send`,
      {
        method: 'POST',
        headers: {
          authorization: `Bearer ${accessToken}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({ message: messagePayload }),
      },
    );
    if (response.ok) {
      if (deliveryProbeMessageId) {
        try {
          const probeResponse = await fetch(
            `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(account.project_id)}/messages:send`,
            {
              method: 'POST',
              headers: {
                authorization: `Bearer ${accessToken}`,
                'content-type': 'application/json',
              },
              body: JSON.stringify({
                message: {
                  token: device.token,
                  data: {
                    type: 'delivery_probe',
                    message_id: deliveryProbeMessageId,
                  },
                  android: { priority: 'HIGH', ttl: '3600s' },
                },
              }),
            },
          );
          if (!probeResponse.ok) {
            console.error(`FCM delivery probe failed with status ${probeResponse.status}`);
          }
        } catch (_) {
          // The normal notification was accepted; a later app connection can retry the receipt.
          console.error('FCM delivery probe could not be sent');
        }
      }
      return { ok: true, token: device.token, invalid: false };
    }
    const detail = await response.text();
    if (response.status === 404 || detail.includes('UNREGISTERED')) {
      return { ok: false, token: device.token, invalid: true };
    }
    console.error(`FCM send failed with status ${response.status}`);
    return { ok: false, token: device.token, invalid: false };
  }));

  const staleTokens = results
    .filter((result) => result.invalid)
    .map((result) => result.token);
  if (staleTokens.length) {
    await admin.from('push_devices').delete().in('token', staleTokens);
  }
  return results.filter((result) => result.ok).length;
}

async function sendMessagePush(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  message: JsonRow,
): Promise<number> {
  const messageId = stringValue(message, 'id');
  const conversationId = stringValue(message, 'conversation_id');
  const senderId = stringValue(message, 'sender_id');
  if (!messageId || !conversationId || !senderId) throw new Error('Invalid message payload');

  const [membersResult, senderResult, groupResult] = await Promise.all([
    admin.from('conversation_members').select('user_id')
      .eq('conversation_id', conversationId).neq('user_id', senderId).limit(500),
    admin.from('profiles').select('display_name,username').eq('id', senderId).maybeSingle(),
    admin.from('groups').select('name,listing_type').eq('conversation_id', conversationId).maybeSingle(),
  ]);
  if (membersResult.error || senderResult.error || groupResult.error) {
    throw new Error('Could not resolve message recipients');
  }
  const recipientIds = (membersResult.data ?? []).map((row) => row.user_id as string);
  if (!recipientIds.length) return 0;

  const group = groupResult.data;
  const listingType = group?.listing_type;
  const category: Category = !group
    ? 'messages'
    : listingType === 'room' ? 'channels' : 'groups';
  const senderName = senderResult.data?.display_name?.trim() ||
    senderResult.data?.username?.trim() || 'مستخدم وصال';
  const groupName = group?.name?.trim() || (category === 'channels' ? 'قناة' : 'مجموعة');
  const text = messageText(message);

  return await deliverToUsers(
    admin,
    account,
    accessToken,
    recipientIds,
    category,
    (preferences) => {
      const showPreview = preferences.show_message_preview;
      const title = category === 'messages' ? senderName : groupName;
      const body = category === 'messages'
        ? showPreview ? text || 'أرسل لك رسالة جديدة' : 'أرسل لك رسالة جديدة'
        : category === 'channels'
        ? showPreview ? `${senderName}: ${text || 'نشر رسالة جديدة'}` : `${senderName}: نشر رسالة جديدة`
        : showPreview ? `${senderName}: ${text || 'أرسل رسالة جديدة'}` : `${senderName}: أرسل رسالة جديدة`;
      return {
        title,
        body,
        data: {
          type: 'message',
          category,
          message_id: messageId,
          conversation_id: conversationId,
          sender_id: senderId,
          title,
          body,
        },
        tag: messageId,
        privateContent: !showPreview,
      };
    },
    conversationId,
    group ? undefined : messageId,
  );
}

async function sendReactionPush(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  reaction: JsonRow,
): Promise<number> {
  const messageId = stringValue(reaction, 'message_id');
  const reactorId = stringValue(reaction, 'user_id');
  if (!messageId || !reactorId) return 0;

  const { data: message, error: messageError } = await admin
    .from('messages')
    .select('id,conversation_id,sender_id')
    .eq('id', messageId)
    .maybeSingle();
  if (messageError) throw new Error('Could not load reacted message');
  if (!message || message.sender_id === reactorId) return 0;

  const [membership, reactor, group] = await Promise.all([
    admin.from('conversation_members').select('user_id')
      .eq('conversation_id', message.conversation_id).eq('user_id', reactorId).maybeSingle(),
    admin.from('profiles').select('display_name,username').eq('id', reactorId).maybeSingle(),
    admin.from('groups').select('name,listing_type')
      .eq('conversation_id', message.conversation_id).maybeSingle(),
  ]);
  if (membership.error || reactor.error || group.error) throw new Error('Could not resolve reaction sender');
  if (!membership.data) return 0;

  const category: Category = !group.data
    ? 'messages'
    : group.data.listing_type === 'room' ? 'channels' : 'groups';
  const reactorName = reactor.data?.display_name?.trim() ||
    reactor.data?.username?.trim() || 'أحد أصدقائك';
  const groupName = group.data?.name?.trim() || (category === 'channels' ? 'قناة' : 'مجموعة');
  const emoji = stringValue(reaction, 'emoji');
  const recipientId = message.sender_id as string;

  return await deliverToUsers(
    admin,
    account,
    accessToken,
    [recipientId],
    category,
    (preferences) => {
      const title = category === 'messages' ? reactorName : groupName;
      const body = preferences.show_message_preview
        ? `تفاعل ${reactorName} مع رسالتك${emoji ? `: ${emoji}` : ''}`
        : 'تفاعل أحدهم مع رسالتك';
      return {
        title,
        body,
        data: {
          type: 'reaction',
          category,
          message_id: messageId,
          conversation_id: message.conversation_id as string,
          sender_id: reactorId,
          title,
          body,
        },
        tag: `reaction-${messageId}`,
        privateContent: !preferences.show_message_preview,
      };
    },
    message.conversation_id as string,
  );
}

async function sendStatusPush(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  status: JsonRow,
): Promise<number> {
  const statusId = stringValue(status, 'id');
  const authorId = stringValue(status, 'user_id');
  if (!statusId || !authorId) return 0;
  const expiresAt = Date.parse(stringValue(status, 'expires_at'));
  if (Number.isFinite(expiresAt) && expiresAt <= Date.now()) return 0;

  const { data: subscriptions, error: subscriptionError } = await admin
    .from('status_notification_subscriptions')
    .select('user_id')
    .eq('author_id', authorId)
    .neq('user_id', authorId)
    .limit(500);
  if (subscriptionError) throw new Error('Could not load status subscribers');
  const candidates = [...new Set((subscriptions ?? []).map((row) => row.user_id as string))];
  if (!candidates.length) return 0;

  const [outgoing, incoming, author] = await Promise.all([
    admin.from('friend_requests').select('addressee_id')
      .eq('requester_id', authorId).eq('status', 'accepted').in('addressee_id', candidates).limit(500),
    admin.from('friend_requests').select('requester_id')
      .eq('addressee_id', authorId).eq('status', 'accepted').in('requester_id', candidates).limit(500),
    admin.from('profiles').select('display_name,username').eq('id', authorId).maybeSingle(),
  ]);
  if (outgoing.error || incoming.error || author.error) {
    throw new Error('Could not verify status audience');
  }
  const acceptedFriends = new Set<string>([
    ...(outgoing.data ?? []).map((row) => row.addressee_id as string),
    ...(incoming.data ?? []).map((row) => row.requester_id as string),
  ]);
  const privacy = stringValue(status, 'privacy') || 'friends';
  const selectedAudience = new Set(stringList(status.audience_user_ids));
  const recipients = candidates.filter((userId) =>
    acceptedFriends.has(userId) &&
    (privacy === 'friends' || (privacy === 'selected' && selectedAudience.has(userId)))
  );
  if (!recipients.length) return 0;

  const authorName = author.data?.display_name?.trim() ||
    author.data?.username?.trim() || 'أحد أصدقائك';
  return await deliverToUsers(
    admin,
    account,
    accessToken,
    recipients,
    'statuses',
    () => ({
      title: authorName,
      body: 'نشر حالة جديدة',
      data: {
        type: 'status',
        category: 'statuses',
        status_id: statusId,
        sender_id: authorId,
        title: authorName,
        body: 'نشر حالة جديدة',
      },
      tag: `status-${statusId}`,
      privateContent: true,
    }),
  );
}

async function sendCallPush(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  call: JsonRow,
): Promise<number> {
  const callId = stringValue(call, 'id');
  const callerId = stringValue(call, 'caller_id');
  const calleeId = stringValue(call, 'callee_id');
  const conversationId = stringValue(call, 'conversation_id');
  if (!callId || !callerId || !calleeId || !conversationId || stringValue(call, 'status') !== 'ringing') {
    return 0;
  }
  const createdAt = Date.parse(stringValue(call, 'created_at'));
  if (Number.isFinite(createdAt) && Date.now() - createdAt > 90_000) return 0;

  const { data: caller, error } = await admin
    .from('profiles')
    .select('display_name,username')
    .eq('id', callerId)
    .maybeSingle();
  if (error) throw new Error('Could not resolve incoming caller');
  const callerName = caller?.display_name?.trim() || caller?.username?.trim() || 'أحد أصدقائك';
  const title = 'مكالمة واردة';
  const body = `${callerName} يتصل بك`;
  return await deliverToUsers(
    admin,
    account,
    accessToken,
    [calleeId],
    'calls',
    () => ({
      title,
      body,
      data: {
        type: 'incoming_call',
        category: 'calls',
        call_id: callId,
        conversation_id: conversationId,
        caller_id: callerId,
        caller_name: callerName,
        media_type: stringValue(call, 'media_type') || 'audio',
        title,
        body,
      },
      tag: `call-${callId}`,
      ttl: '90s',
    }),
    undefined,
    undefined,
    true,
  );
}

async function sendVerificationPush(
  admin: AdminClient,
  account: ServiceAccount,
  accessToken: string,
  profileChange: JsonRow,
  previousProfile: JsonRow | undefined,
): Promise<number> {
  const userId = stringValue(profileChange, 'id');
  if (!userId || profileChange.is_verified !== true || previousProfile?.is_verified !== false) {
    return 0;
  }

  // Ignore stale/out-of-order webhook deliveries if verification was revoked
  // before this event reached the push function.
  const { data: profile, error: profileError } = await admin
    .from('profiles')
    .select('id,is_verified')
    .eq('id', userId)
    .maybeSingle();
  if (profileError) throw new Error('Could not validate verified profile');
  if (!profile || profile.is_verified !== true) return 0;

  const [devicesResult, preferencesResult] = await Promise.all([
    admin.from('push_devices').select('token').eq('user_id', userId)
      .eq('platform', 'android').limit(1000),
    admin.from('notification_preferences').select('sound_enabled,vibration_enabled')
      .eq('user_id', userId).maybeSingle(),
  ]);
  if (devicesResult.error || preferencesResult.error) {
    throw new Error('Could not load verification notification settings');
  }
  const devices = devicesResult.data ?? [];
  if (!devices.length) return 0;

  // Account verification notices are administrative account events, so they
  // are not suppressed by message-category switches or Do Not Disturb. The
  // member's sound and vibration preferences still choose the Android channel.
  const soundEnabled = preferencesResult.data?.sound_enabled !== false;
  const vibrationEnabled = preferencesResult.data?.vibration_enabled !== false;
  const channelId = `wasla_account_${soundEnabled ? 'sound' : 'silent'}_${vibrationEnabled ? 'vibrate' : 'no_vibrate'}`;
  const title = 'حسابك موثّق الآن';
  const body = 'تم منح حسابك في وصال شارة التوثيق.';
  const results = await Promise.all(devices.map(async (device: { token: string }) => {
    const response = await fetch(
      `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(account.project_id)}/messages:send`,
      {
        method: 'POST',
        headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          message: {
            token: device.token,
            notification: { title, body },
            data: {
              type: 'account_verification',
              category: 'account',
              user_id: userId,
              title,
              body,
            },
            android: {
              priority: 'HIGH',
              ttl: '86400s',
              notification: {
                channel_id: channelId,
                icon: 'ic_stat_wasla',
                visibility: 'PUBLIC',
                tag: `verification-${userId}`,
                ...(soundEnabled ? { sound: 'default' } : {}),
              },
            },
          },
        }),
      },
    );
    if (response.ok) return { token: device.token, sent: true, invalid: false };
    const detail = await response.text();
    if (response.status === 404 || detail.includes('UNREGISTERED')) {
      return { token: device.token, sent: false, invalid: true };
    }
    console.error(`Verification FCM send failed with status ${response.status}`);
    return { token: device.token, sent: false, invalid: false };
  }));

  const staleTokens = results.filter((result) => result.invalid).map((result) => result.token);
  if (staleTokens.length) await admin.from('push_devices').delete().in('token', staleTokens);
  return results.filter((result) => result.sent).length;
}

async function acknowledgeMessageDelivery(
  admin: AdminClient,
  request: Request,
  payload: WebhookPayload,
): Promise<Response> {
  const deviceToken = request.headers.get('x-wasla-device-token') ?? '';
  const messageId = payload.message_id ?? '';
  if (deviceToken.length < 20 || deviceToken.length > 8192 || !messageId) {
    return new Response('Invalid delivery receipt', { status: 400, headers: corsHeaders });
  }

  const { data: device, error: deviceError } = await admin
    .from('push_devices')
    .select('user_id')
    .eq('token', deviceToken)
    .maybeSingle();
  if (deviceError) throw new Error('Could not validate delivery device');
  if (!device) return new Response('Unknown delivery device', { status: 401, headers: corsHeaders });

  const { data: message, error: messageError } = await admin
    .from('messages')
    .select('id,conversation_id,sender_id,delivered_at')
    .eq('id', messageId)
    .maybeSingle();
  if (messageError) throw new Error('Could not load delivery message');
  if (!message) return new Response('Message not found', { status: 404, headers: corsHeaders });

  const [membership, group] = await Promise.all([
    admin.from('conversation_members').select('user_id')
      .eq('conversation_id', message.conversation_id)
      .eq('user_id', device.user_id).maybeSingle(),
    admin.from('groups').select('conversation_id')
      .eq('conversation_id', message.conversation_id).maybeSingle(),
  ]);
  if (membership.error || group.error) throw new Error('Could not validate message recipient');
  if (!membership.data || message.sender_id === device.user_id) {
    return new Response('Device is not a message recipient', { status: 403, headers: corsHeaders });
  }
  // A single delivered_at cannot represent per-member group receipts.
  if (group.data) return Response.json({ ignored: true }, { headers: corsHeaders });

  if (!message.delivered_at) {
    const { error: updateError } = await admin
      .from('messages')
      .update({ delivered_at: new Date().toISOString() })
      .eq('id', messageId)
      .is('delivered_at', null);
    if (updateError) throw new Error('Could not save delivery receipt');
  }
  return Response.json({ delivered: true }, { headers: corsHeaders });
}

Deno.serve(async (request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405, headers: corsHeaders });
  }

  try {
    const payload = await request.json() as WebhookPayload;
    if (payload.type === 'DELIVERY_ACK') {
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
      if (!supabaseUrl || !serviceRoleKey) {
        throw new Error('Missing delivery receipt service configuration');
      }
      const admin = createClient(supabaseUrl, serviceRoleKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      });
      return await acknowledgeMessageDelivery(admin, request, payload);
    }
    if (payload.schema !== 'public') {
      return Response.json({ ignored: true }, { headers: corsHeaders });
    }
    const suppliedSecret = request.headers.get('x-wasla-webhook-secret') ?? '';
    const secretName = payload.table === 'messages'
      ? 'PUSH_WEBHOOK_SECRET'
      : 'PUSH_EVENT_WEBHOOK_SECRET';
    const expectedSecret = Deno.env.get(secretName) ?? '';
    if (!constantTimeEqual(suppliedSecret, expectedSecret)) {
      return new Response('Unauthorized', { status: 401, headers: corsHeaders });
    }
    if (!payload.table) {
      return Response.json({ ignored: true }, { headers: corsHeaders });
    }
    const verificationGrant = payload.table === 'profiles' &&
      payload.type === 'UPDATE' &&
      payload.record?.is_verified === true &&
      payload.old_record?.is_verified === false;
    if (payload.table === 'profiles' && !verificationGrant) {
      return Response.json({ ignored: true }, { headers: corsHeaders });
    }
    if (payload.table !== 'profiles' && (payload.type !== 'INSERT' || !payload.record)) {
      return Response.json({ ignored: true }, { headers: corsHeaders });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const rawAccount = Deno.env.get('FCM_SERVICE_ACCOUNT_JSON');
    if (!supabaseUrl || !serviceRoleKey || !rawAccount) {
      throw new Error('Missing push service configuration');
    }
    const account = JSON.parse(rawAccount) as ServiceAccount;
    if (!account.project_id || !account.client_email || !account.private_key) {
      throw new Error('Invalid Firebase service account JSON');
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const accessToken = await createGoogleAccessToken(account);
    let sent = 0;
    switch (payload.table) {
      case 'messages':
        sent = await sendMessagePush(admin, account, accessToken, payload.record!);
        break;
      case 'message_reactions':
        sent = await sendReactionPush(admin, account, accessToken, payload.record!);
        break;
      case 'status_posts':
        sent = await sendStatusPush(admin, account, accessToken, payload.record!);
        break;
      case 'calls':
        sent = await sendCallPush(admin, account, accessToken, payload.record!);
        break;
      case 'profiles':
        sent = await sendVerificationPush(
          admin,
          account,
          accessToken,
          payload.record!,
          payload.old_record,
        );
        break;
      default:
        return Response.json({ ignored: true }, { headers: corsHeaders });
    }
    return Response.json({ sent }, { headers: corsHeaders });
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown push error');
    return new Response('Push delivery failed', { status: 500, headers: corsHeaders });
  }
});
