import 'dart:async';

typedef RingtoneAction = Future<void> Function();

/// Coordinates one looping ringtone for an incoming call at a time.
///
/// The caller decides whether alerts are enabled and whether a call screen is
/// already open. This class guarantees idempotent starts and stops so duplicate
/// realtime events cannot create overlapping playback.
class IncomingCallRingtoneController {
  IncomingCallRingtoneController({required this.play, required this.stop});

  final RingtoneAction play;
  final RingtoneAction stop;
  final Set<String> _handledCallIds = <String>{};
  Future<void> _playerQueue = Future<void>.value();
  String? _activeCallId;
  bool _disposed = false;

  String? get activeCallId => _activeCallId;
  bool get isRinging => _activeCallId != null;

  Future<bool> startForIncoming({
    required String callId,
    required bool isIncoming,
    required bool alertsEnabled,
    required bool callScreenOpen,
  }) async {
    if (_disposed ||
        callId.isEmpty ||
        !isIncoming ||
        !alertsEnabled ||
        callScreenOpen ||
        _activeCallId != null ||
        !_handledCallIds.add(callId)) {
      return false;
    }

    _activeCallId = callId;
    try {
      await _enqueue(() async {
        // A stop may have been requested while this start was queued.
        if (!_disposed && _activeCallId == callId) await play();
      });
      return _activeCallId == callId;
    } catch (_) {
      if (_activeCallId == callId) _activeCallId = null;
      await _enqueue(stop).catchError((Object _) {});
      return false;
    }
  }

  Future<void> stopForCall(String callId) async {
    if (_activeCallId != callId) return;
    _activeCallId = null;
    await _enqueue(stop).catchError((Object _) {});
  }

  Future<void> stopAll() async {
    if (_activeCallId == null) return;
    _activeCallId = null;
    await _enqueue(stop).catchError((Object _) {});
  }

  Future<void> dispose() async {
    await stopAll();
    _disposed = true;
  }

  Future<void> _enqueue(RingtoneAction action) {
    final operation = _playerQueue.then((_) => action());
    _playerQueue = operation.catchError((Object _) {});
    return operation;
  }
}
