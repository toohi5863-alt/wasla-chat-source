class FriendshipStatus {
  const FriendshipStatus({
    this.status = 'none',
    this.requesterId,
    this.addresseeId,
    this.createdAt,
  });

  final String status;
  final String? requesterId;
  final String? addresseeId;
  final DateTime? createdAt;

  bool get isPending => status == 'pending';
  bool get isAccepted => status == 'accepted';
  bool get isOutgoing => isPending && requesterId != null;
  bool isOutgoingFor(String userId) => isPending && requesterId == userId;
  bool isIncomingFor(String userId) => isPending && addresseeId == userId;

  factory FriendshipStatus.fromMap(Map<String, dynamic>? map) =>
      FriendshipStatus(
        status: map?['status']?.toString() ?? 'none',
        requesterId: map?['requester_id']?.toString(),
        addresseeId: map?['addressee_id']?.toString(),
        createdAt: _parseDate(map?['created_at']),
      );
}

class Friend {
  const Friend({
    required this.userId,
    required this.username,
    required this.displayName,
    this.avatarPath,
  });

  final String userId;
  final String username;
  final String displayName;
  final String? avatarPath;

  String get label => displayName.isNotEmpty ? displayName : '@$username';

  factory Friend.fromMap(Map<String, dynamic> map) => Friend(
    userId: map['friend_id']?.toString() ?? '',
    username: map['username']?.toString() ?? '',
    displayName: map['display_name']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
  );
}

class FriendRequest {
  const FriendRequest({
    required this.requesterId,
    required this.username,
    required this.displayName,
    this.avatarPath,
    this.createdAt,
  });

  final String requesterId;
  final String username;
  final String displayName;
  final String? avatarPath;
  final DateTime? createdAt;

  String get label => displayName.isNotEmpty ? displayName : '@$username';

  factory FriendRequest.fromMap(Map<String, dynamic> map) => FriendRequest(
    requesterId: map['requester_id']?.toString() ?? '',
    username: map['username']?.toString() ?? '',
    displayName: map['display_name']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
    createdAt: _parseDate(map['created_at']),
  );
}

DateTime? _parseDate(dynamic value) =>
    value == null ? null : DateTime.tryParse(value.toString());
