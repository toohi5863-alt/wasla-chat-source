-- Enforce story expiry on the server; clients cannot extend a status lifetime.
create or replace function public.enforce_status_expiry()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  new.created_at := now();
  new.expires_at := new.created_at + interval '24 hours';
  return new;
end;
$$;
revoke all on function public.enforce_status_expiry() from public, anon, authenticated;

drop trigger if exists status_posts_enforce_expiry on public.status_posts;
create trigger status_posts_enforce_expiry
before insert on public.status_posts
for each row execute function public.enforce_status_expiry();
