import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Stores call-history visibility per account on this device only.
/// This does not delete or update any server-side call record.
class CallHistoryPreferencesStore {
  CallHistoryPreferencesStore({
    Future<Directory> Function()? supportDirectoryProvider,
  }) : _supportDirectoryProvider =
           supportDirectoryProvider ?? getApplicationSupportDirectory;

  static const _fileName = 'wasla_call_history_preferences.json';
  final Future<Directory> Function() _supportDirectoryProvider;

  Future<File> _file() async {
    final directory = await _supportDirectoryProvider();
    await directory.create(recursive: true);
    return File('${directory.path}/$_fileName');
  }

  Future<Set<String>> load(String userId) async {
    final file = await _file();
    if (!await file.exists()) return <String>{};

    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! Map) return <String>{};
      final users = decoded['users'];
      if (users is! Map) return <String>{};
      final hiddenCallIds = users[userId];
      if (hiddenCallIds is! List) return <String>{};
      return hiddenCallIds
          .where((value) => value != null && value.toString().isNotEmpty)
          .map((value) => value.toString())
          .toSet();
    } on FormatException {
      return <String>{};
    }
  }

  Future<void> save(String userId, Set<String> hiddenCallIds) async {
    final file = await _file();
    Map<String, dynamic> root = <String, dynamic>{'users': <String, dynamic>{}};

    if (await file.exists()) {
      try {
        final decoded = jsonDecode(await file.readAsString());
        if (decoded is Map) root = Map<String, dynamic>.from(decoded);
      } on FormatException {
        // Start a clean preference document if the old local file is damaged.
      }
    }

    final usersValue = root['users'];
    final users = usersValue is Map
        ? Map<String, dynamic>.from(usersValue)
        : <String, dynamic>{};
    users[userId] = hiddenCallIds.toList()..sort();
    root['users'] = users;

    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(jsonEncode(root), flush: true);
    await temporary.rename(file.path);
  }
}
