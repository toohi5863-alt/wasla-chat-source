import 'dart:io';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'friendship_models.dart';
import 'notification_preferences.dart';
import 'push_notifications.dart';

class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({
    required this.client,
    required this.userId,
    super.key,
  });

  final SupabaseClient client;
  final String userId;

  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  PushNotificationPreferences _preferences =
      const PushNotificationPreferences();
  List<_ConversationOption> _conversations = const [];
  List<Friend> _friends = const [];
  final Map<String, ConversationNotificationPreference> _conversationPrefs = {};
  Set<String> _statusSubscriptions = <String>{};
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final settingsRow = await widget.client
          .from('notification_preferences')
          .select()
          .eq('user_id', widget.userId)
          .maybeSingle();
      final membershipRows = await widget.client
          .from('group_members')
          .select('conversation_id')
          .eq('user_id', widget.userId);
      final ids = membershipRows
          .map((row) => row['conversation_id']?.toString() ?? '')
          .where((id) => id.isNotEmpty)
          .toSet()
          .toList();

      final conversationRows = ids.isEmpty
          ? <Map<String, dynamic>>[]
          : (await widget.client
                    .from('groups')
                    .select('conversation_id,name,listing_type')
                    .inFilter('conversation_id', ids))
                .map((row) => Map<String, dynamic>.from(row))
                .toList();
      final preferenceRows = ids.isEmpty
          ? <Map<String, dynamic>>[]
          : (await widget.client
                    .from('conversation_notification_preferences')
                    .select('conversation_id,notifications_enabled,muted_until')
                    .eq('user_id', widget.userId)
                    .inFilter('conversation_id', ids))
                .map((row) => Map<String, dynamic>.from(row))
                .toList();
      final rawFriends = await widget.client.rpc('list_friends') as List;
      final subscriptionRows = await widget.client
          .from('status_notification_subscriptions')
          .select('author_id')
          .eq('user_id', widget.userId);

      if (!mounted) return;
      _conversationPrefs
        ..clear()
        ..addEntries(
          preferenceRows.map((row) {
            final id = row['conversation_id'].toString();
            return MapEntry(
              id,
              ConversationNotificationPreference.fromMap(row),
            );
          }),
        );
      setState(() {
        _preferences = PushNotificationPreferences.fromMap(
          settingsRow == null ? null : Map<String, dynamic>.from(settingsRow),
        );
        _conversations =
            conversationRows
                .map(
                  (row) => _ConversationOption(
                    id: row['conversation_id'].toString(),
                    name: row['name']?.toString().trim().isNotEmpty == true
                        ? row['name'].toString().trim()
                        : 'محادثة جماعية',
                    isChannel: row['listing_type']?.toString() == 'room',
                  ),
                )
                .toList()
              ..sort((a, b) => a.name.compareTo(b.name));
        _friends = rawFriends
            .map((row) => Friend.fromMap(Map<String, dynamic>.from(row as Map)))
            .where((friend) => friend.userId.isNotEmpty)
            .toList();
        _statusSubscriptions = subscriptionRows
            .map((row) => row['author_id']?.toString() ?? '')
            .where((id) => id.isNotEmpty)
            .toSet();
        _loading = false;
      });
      PushNotifications.instance.updatePreferences(_preferences);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error =
            'تعذر تحميل إعدادات الإشعارات. تحقق من اتصال الإنترنت وترحيل 018.';
      });
    }
  }

  Future<void> _savePreferences(PushNotificationPreferences next) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await widget.client.from('notification_preferences').upsert({
        'user_id': widget.userId,
        ...next.toMap(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id');
      if (!mounted) return;
      setState(() => _preferences = next);
      PushNotifications.instance.updatePreferences(next);
    } catch (_) {
      _showError('تعذر حفظ الإعداد. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _setConversationPreference(
    String conversationId, {
    required bool enabled,
    DateTime? mutedUntil,
  }) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await widget.client.from('conversation_notification_preferences').upsert({
        'user_id': widget.userId,
        'conversation_id': conversationId,
        'notifications_enabled': enabled,
        'muted_until': mutedUntil?.toUtc().toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,conversation_id');
      if (!mounted) return;
      setState(() {
        _conversationPrefs[conversationId] = ConversationNotificationPreference(
          notificationsEnabled: enabled,
          mutedUntil: mutedUntil?.toUtc(),
        );
      });
      await PushNotifications.instance.refreshPreferences();
    } catch (_) {
      _showError('تعذر تحديث كتم المحادثة.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _setStatusSubscription(Friend friend, bool enabled) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      if (enabled) {
        await widget.client.from('status_notification_subscriptions').upsert({
          'user_id': widget.userId,
          'author_id': friend.userId,
        }, onConflict: 'user_id,author_id');
      } else {
        await widget.client
            .from('status_notification_subscriptions')
            .delete()
            .eq('user_id', widget.userId)
            .eq('author_id', friend.userId);
      }
      if (!mounted) return;
      setState(() {
        if (enabled) {
          _statusSubscriptions.add(friend.userId);
        } else {
          _statusSubscriptions.remove(friend.userId);
        }
      });
    } catch (_) {
      _showError('تعذر تحديث متابعة الحالة. تأكد أن الشخص ما زال ضمن أصدقائك.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  String _conversationStatus(String id) {
    final preference = _conversationPrefs[id];
    if (preference == null) return 'الإشعارات مفعّلة';
    if (!preference.notificationsEnabled) return 'مكتومة حتى تعيد تشغيلها';
    final until = preference.mutedUntil;
    if (until != null && until.isAfter(DateTime.now().toUtc())) {
      final local = until.toLocal();
      final minute = local.minute.toString().padLeft(2, '0');
      return 'مكتومة حتى ${local.day}/${local.month} ${local.hour}:$minute';
    }
    return 'الإشعارات مفعّلة';
  }

  Future<void> _chooseConversationMute(_ConversationOption option) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(
                option.name,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                option.isChannel ? 'إشعارات القناة' : 'إشعارات المجموعة',
              ),
            ),
            _muteChoice('تشغيل الإشعارات', 'on'),
            _muteChoice('كتم دائم', 'off'),
            _muteChoice('كتم ساعة', '1h'),
            _muteChoice('كتم 8 ساعات', '8h'),
            _muteChoice('كتم 24 ساعة', '24h'),
            _muteChoice('كتم أسبوع', '7d'),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected == null) return;
    if (selected == 'on') {
      await _setConversationPreference(option.id, enabled: true);
    } else if (selected == 'off') {
      await _setConversationPreference(option.id, enabled: false);
    } else {
      final duration = switch (selected) {
        '1h' => const Duration(hours: 1),
        '8h' => const Duration(hours: 8),
        '24h' => const Duration(hours: 24),
        _ => const Duration(days: 7),
      };
      await _setConversationPreference(
        option.id,
        enabled: true,
        mutedUntil: DateTime.now().toUtc().add(duration),
      );
    }
  }

  ListTile _muteChoice(String title, String value) =>
      ListTile(title: Text(title), onTap: () => Navigator.pop(context, value));

  Widget _switch({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    IconData? icon,
  }) => SwitchListTile.adaptive(
    secondary: icon == null ? null : Icon(icon),
    title: Text(title),
    subtitle: Text(subtitle),
    value: value,
    onChanged: _saving ? null : onChanged,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          IconButton(
            tooltip: 'تحديث',
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _load,
                      child: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              children: [
                Card(
                  elevation: 0,
                  child: Column(
                    children: [
                      _switch(
                        title: 'إشعارات الرسائل والتفاعلات',
                        subtitle: 'الرسائل الخاصة والتفاعلات على رسائلك',
                        value: _preferences.messagesEnabled,
                        icon: Icons.chat_bubble_outline,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(messagesEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'إشعارات المجموعات',
                        subtitle: 'رسائل المجموعات التي انضممت إليها',
                        value: _preferences.groupsEnabled,
                        icon: Icons.groups_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(groupsEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'إشعارات القنوات والغرف العامة',
                        subtitle:
                            'تُعامل الغرف العامة التي انضممت إليها كقنوات',
                        value: _preferences.channelsEnabled,
                        icon: Icons.campaign_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(channelsEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'إشعارات الحالات',
                        subtitle:
                            'تنبيهات اختيارية للأصدقاء الذين تختارهم أدناه',
                        value: _preferences.statusesEnabled,
                        icon: Icons.circle_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(statusesEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'إشعارات المكالمات',
                        subtitle: 'إشعار عند ورود مكالمة فردية',
                        value: _preferences.callsEnabled,
                        icon: Icons.call_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(callsEnabled: value),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  elevation: 0,
                  child: Column(
                    children: [
                      _switch(
                        title: 'صوت الإشعار',
                        subtitle: 'استخدم صوت قناة إشعارات وصال',
                        value: _preferences.soundEnabled,
                        icon: Icons.volume_up_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(soundEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'الاهتزاز',
                        subtitle: 'اهتزاز الجهاز عند وصول إشعار',
                        value: _preferences.vibrationEnabled,
                        icon: Icons.vibration,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(vibrationEnabled: value),
                        ),
                      ),
                      _switch(
                        title: 'إظهار محتوى الرسالة على شاشة القفل',
                        subtitle: 'عند الإيقاف يظهر تنبيه عام بدل نص الرسالة',
                        value: _preferences.showMessagePreview,
                        icon: Icons.visibility_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(showMessagePreview: value),
                        ),
                      ),
                      _switch(
                        title: 'عدم الإزعاج',
                        subtitle: 'يكتم إشعارات وصال حتى إيقافه؛ لا يغيّر وضع Android',
                        value: _preferences.doNotDisturb,
                        icon: Icons.notifications_off_outlined,
                        onChanged: (value) => _savePreferences(
                          _preferences.copyWith(doNotDisturb: value),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  'المجموعات والقنوات',
                  style: Theme.of(context).textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  'يمكنك تشغيل التنبيهات أو كتمها دائمًا أو لمدة محددة لكل مجموعة أو غرفة عامة على حدة.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (_conversations.isEmpty)
                  const Card(
                    elevation: 0,
                    child: ListTile(
                      leading: Icon(Icons.groups_outlined),
                      title: Text('لا توجد مجموعات أو قنوات منضم إليها'),
                    ),
                  )
                else
                  ..._conversations.map((option) {
                    final preference = _conversationPrefs[option.id];
                    final muted = preference?.isMuted ?? false;
                    return Card(
                      elevation: 0,
                      child: ListTile(
                        leading: Icon(
                          option.isChannel
                              ? Icons.campaign_outlined
                              : Icons.groups_outlined,
                        ),
                        title: Text(
                          option.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          '${option.isChannel ? 'قناة/غرفة عامة' : 'مجموعة'} · ${_conversationStatus(option.id)}',
                        ),
                        trailing: IconButton(
                          tooltip: muted
                              ? 'تغيير كتم الإشعارات'
                              : 'كتم أو تعديل الإشعارات',
                          onPressed: _saving
                              ? null
                              : () => _chooseConversationMute(option),
                          icon: Icon(
                            muted
                                ? Icons.notifications_off_outlined
                                : Icons.notifications_active_outlined,
                          ),
                        ),
                      ),
                    );
                  }),
                const SizedBox(height: 18),
                Text(
                  'تنبيهات الحالات من الأصدقاء',
                  style: Theme.of(context).textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  'اختر أشخاصًا محددين. تُرسل التنبيهات فقط إذا كان بإمكانك رؤية الحالة وفق إعداد خصوصيتها.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (_friends.isEmpty)
                  const Card(
                    elevation: 0,
                    child: ListTile(
                      leading: Icon(Icons.people_outline),
                      title: Text(
                        'أضف أصدقاء لتفعيل تنبيهات الحالات الاختيارية',
                      ),
                    ),
                  )
                else
                  ..._friends.map(
                    (friend) => Card(
                      elevation: 0,
                      child: SwitchListTile.adaptive(
                        secondary: const Icon(Icons.person_outline),
                        title: Text(friend.label),
                        subtitle: const Text('تنبيه عند نشر حالة جديدة'),
                        value: _statusSubscriptions.contains(friend.userId),
                        onChanged: _saving
                            ? null
                            : (value) => _setStatusSubscription(friend, value),
                      ),
                    ),
                  ),
                if (Platform.isAndroid) ...[
                  const SizedBox(height: 18),
                  Card(
                    elevation: 0,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: Icon(Icons.battery_saver_outlined),
                            title: Text('قيود البطارية في Android'),
                            subtitle: Text(
                              'تستخدم وصال FCM عالي الأولوية. قد تؤخر بعض الأجهزة الإشعارات إذا قيّدت تشغيل الخلفية؛ من إعدادات التطبيق اختر البطارية ثم «غير مقيّد» عند الحاجة.',
                            ),
                          ),
                          Align(
                            alignment: AlignmentDirectional.centerEnd,
                            child: OutlinedButton.icon(
                              onPressed: () => openAppSettings(),
                              icon: const Icon(Icons.settings_outlined),
                              label: const Text('فتح إعدادات التطبيق'),
                            ),
                          ),
                          const Text(
                            'إيقاف التطبيق إجباريًا من إعدادات Android قد يمنع التسليم حتى فتحه يدويًا.',
                            style: TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                if (_saving) ...[
                  const SizedBox(height: 10),
                  const LinearProgressIndicator(),
                ],
              ],
            ),
    );
  }
}

class _ConversationOption {
  const _ConversationOption({
    required this.id,
    required this.name,
    required this.isChannel,
  });

  final String id;
  final String name;
  final bool isChannel;
}
