import 'dart:io';

import 'package:chat/device_media_saver.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('sanitizes paths and resolves common media MIME types', () {
    expect(sanitizeDeviceMediaFileName('../folder/photo 1.jpg'), 'photo 1.jpg');
    expect(sanitizeDeviceMediaFileName(r'folder\voice.m4a'), 'voice.m4a');
    expect(sanitizeDeviceMediaFileName(''), 'wasla_media.bin');
    expect(mediaMimeTypeForFileName('clip.mp4'), 'video/mp4');
    expect(mediaMimeTypeForFileName('voice.m4a'), 'audio/mp4');
    expect(mediaMimeTypeForFileName('report.pdf'), 'application/pdf');
    expect(mediaMimeTypeForFileName('unknown.bin'), 'application/octet-stream');
  });

  test(
    'passes a downloaded temp file to Android and removes the temp copy',
    () async {
      final expectedBytes = [1, 2, 3, 4, 5];
      final channel = const MethodChannel('app.wasla.chat/media_saver');
      final calls = <MethodCall>[];
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(channel, (call) async {
        calls.add(call);
        if (call.method == 'getAndroidSdk') return 35;
        if (call.method == 'saveFile') {
          final args = Map<String, dynamic>.from(call.arguments as Map);
          expect(
            await File(args['filePath'] as String).readAsBytes(),
            expectedBytes,
          );
          expect(args['fileName'], 'photo.jpg');
          expect(args['mimeType'], 'image/jpeg');
          return {'location': 'Pictures/Wasla'};
        }
        return null;
      });

      final temporaryDirectory = await Directory.systemTemp.createTemp(
        'wasla-save-test-',
      );
      addTearDown(() async {
        messenger.setMockMethodCallHandler(channel, null);
        if (await temporaryDirectory.exists()) {
          await temporaryDirectory.delete(recursive: true);
        }
      });

      final saver = DeviceMediaSaver(
        channel: channel,
        isAndroid: true,
        temporaryDirectoryProvider: () async => temporaryDirectory,
        downloadToFile: (url, destination) async {
          expect(url.path, '/photo');
          await destination.writeAsBytes(expectedBytes, flush: true);
        },
      );
      final location = await saver.saveFromUrl(
        url: 'https://storage.example/photo',
        fileName: '../photo.jpg',
      );

      expect(location, 'Pictures/Wasla');
      expect(calls.map((call) => call.method), ['getAndroidSdk', 'saveFile']);
      expect(temporaryDirectory.listSync(), isEmpty);
    },
  );

  test('rejects saving to the public library on other platforms', () async {
    final saver = DeviceMediaSaver(isAndroid: false);
    await expectLater(
      saver.saveLocalFile(filePath: '/tmp/a.jpg', fileName: 'a.jpg'),
      throwsA(isA<DeviceMediaSaveException>()),
    );
  });
}
