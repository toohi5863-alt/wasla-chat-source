import 'package:chat/chat_composer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('ChatComposer', () {
    late TextEditingController controller;
    late FocusNode focusNode;
    late List<String> attachments;
    late int recordingStarts;

    setUp(() {
      controller = TextEditingController();
      focusNode = FocusNode();
      attachments = [];
      recordingStarts = 0;
    });

    tearDown(() {
      controller.dispose();
      focusNode.dispose();
    });

    Widget host({bool isSending = false}) => MaterialApp(
      home: Scaffold(
        body: Align(
          alignment: Alignment.bottomCenter,
          child: ChatComposer(
            controller: controller,
            focusNode: focusNode,
            onChanged: (_) {},
            onSubmitted: (_) {},
            onSend: () {},
            onAttachmentSelected: (option) async => attachments.add(option),
            onStartRecording: () async {
              recordingStarts++;
            },
            onStopRecording: () async {},
            onCancelRecording: () async {},
            onLockRecording: () {},
            onRetryFailedRecording: () async {},
            onDiscardFailedRecording: () async {},
            isSending: isSending,
            isRecording: false,
            isRecordingLocked: false,
            hasFailedRecording: false,
            recordingDuration: Duration.zero,
            waveform: List<double>.filled(26, .12),
            voiceAllowed: true,
            filesAllowed: true,
          ),
        ),
      ),
    );

    testWidgets('uses the Arabic prompt and starts recording only on a hold', (
      tester,
    ) async {
      await tester.pumpWidget(host());
      expect(find.text('رسالة...'), findsOneWidget);
      final microphone = find.byTooltip('اضغط مطولًا للتسجيل الصوتي');
      expect(microphone, findsOneWidget);
      await tester.tap(microphone);
      await tester.pump();
      expect(recordingStarts, 0);
    });

    testWidgets('keeps keyboard focus while a message is sent', (tester) async {
      await tester.pumpWidget(host());
      final input = find.byType(TextField);
      await tester.showKeyboard(input);
      expect(focusNode.hasFocus, isTrue);

      await tester.enterText(input, 'رسالة أولى');
      controller.clear();
      await tester.pumpWidget(host(isSending: true));
      await tester.pump();

      expect(focusNode.hasFocus, isTrue);
      expect(tester.testTextInput.hasAnyClients, isTrue);
      await tester.enterText(input, 'رسالة تالية');
      expect(controller.text, 'رسالة تالية');

      await tester.pumpWidget(host());
      await tester.pump();
      expect(focusNode.hasFocus, isTrue);
    });

    testWidgets('inserts a grapheme emoji at the current cursor position', (
      tester,
    ) async {
      controller.value = const TextEditingValue(
        text: 'ab',
        selection: TextSelection.collapsed(offset: 1),
      );
      await tester.pumpWidget(host());
      await tester.tap(find.byTooltip('إضافة إيموجي'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('😀').first);
      await tester.pump();
      expect(controller.text, 'a😀b');
      expect(controller.selection.baseOffset, 3);
    });

    testWidgets('counts Unicode graphemes and prevents insertion past 3000', (
      tester,
    ) async {
      controller.value = TextEditingValue(
        text: 'x' * 2999,
        selection: const TextSelection.collapsed(offset: 2999),
      );
      await tester.pumpWidget(host());
      await tester.tap(find.byTooltip('إضافة إيموجي'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('😀').first);
      await tester.pump();
      expect(controller.text.characters.length, 3000);
      expect(find.text('3000 / 3000'), findsOneWidget);
      await tester.tap(find.text('😀').first);
      await tester.pump();
      expect(controller.text.characters.length, 3000);
    });

    testWidgets(
      'opens attachment grid and does not invoke unsupported actions',
      (tester) async {
        await tester.pumpWidget(host());
        await tester.tap(find.byTooltip('إضافة مرفق'));
        await tester.pumpAndSettle();
        expect(find.byTooltip('المعرض'), findsOneWidget);
        expect(find.byTooltip('GIF متحرك — غير متاحة حاليًا'), findsOneWidget);
        await tester.tap(find.byTooltip('GIF متحرك — غير متاحة حاليًا'));
        await tester.pump();
        expect(attachments, isEmpty);
        expect(find.text('المرفقات'), findsOneWidget);
      },
    );

    testWidgets(
      'choosing a supported attachment invokes the parent integration',
      (tester) async {
        await tester.pumpWidget(host());
        await tester.tap(find.byTooltip('إضافة مرفق'));
        await tester.pumpAndSettle();
        await tester.tap(find.byTooltip('المعرض'));
        await tester.pump();
        expect(attachments, ['gallery']);
      },
    );
  });
}
