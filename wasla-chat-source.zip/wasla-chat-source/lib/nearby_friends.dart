import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'friendship_models.dart';
import 'friendship_service.dart';
import 'wasla_media.dart';

class NearbyPerson {
  const NearbyPerson({
    required this.userId,
    required this.username,
    required this.displayName,
    required this.distanceLabel,
    required this.friendshipStatus,
    this.avatarPath,
    this.bio = '',
  });

  final String userId;
  final String username;
  final String displayName;
  final String distanceLabel;
  final FriendshipStatus friendshipStatus;
  final String? avatarPath;
  final String bio;

  String get label => displayName.isNotEmpty ? displayName : '@$username';

  NearbyPerson copyWith({FriendshipStatus? friendshipStatus}) => NearbyPerson(
    userId: userId,
    username: username,
    displayName: displayName,
    distanceLabel: distanceLabel,
    friendshipStatus: friendshipStatus ?? this.friendshipStatus,
    avatarPath: avatarPath,
    bio: bio,
  );

  factory NearbyPerson.fromMap(Map<String, dynamic> map) => NearbyPerson(
    userId: map['user_id']?.toString() ?? '',
    username: map['username']?.toString() ?? '',
    displayName: map['display_name']?.toString() ?? '',
    distanceLabel: map['distance_label']?.toString() ?? 'قريب منك',
    friendshipStatus: FriendshipStatus.fromMap({
      'status': map['friendship_status'],
      'requester_id': map['requester_id'],
      'addressee_id': map['addressee_id'],
    }),
    avatarPath: map['avatar_path']?.toString(),
    bio: map['bio']?.toString() ?? '',
  );
}

class NearbyFriendsService {
  const NearbyFriendsService(this._client);

  final SupabaseClient _client;

  Future<bool> visibilityEnabled() async {
    final result = await _client.rpc('get_nearby_visibility');
    return result == true || result.toString().toLowerCase() == 'true';
  }

  Future<void> setVisibility(bool enabled) async {
    await _client.rpc('set_nearby_visibility', params: {'p_enabled': enabled});
  }

  Future<void> publishLocation({
    required double latitude,
    required double longitude,
  }) async {
    await _client.rpc(
      'publish_nearby_location',
      params: {'p_latitude': latitude, 'p_longitude': longitude},
    );
  }

  Future<void> clearLocation() async {
    await _client.rpc('clear_nearby_location');
  }

  Future<List<NearbyPerson>> findNearby({int limit = 50}) async {
    final result = await _client.rpc(
      'find_nearby_people',
      params: {'p_limit': limit},
    );
    return (result as List<dynamic>)
        .map(
          (row) => NearbyPerson.fromMap(Map<String, dynamic>.from(row as Map)),
        )
        .where((person) => person.userId.isNotEmpty)
        .toList();
  }
}

class NearbyFriendsScreen extends StatefulWidget {
  const NearbyFriendsScreen({super.key});

  @override
  State<NearbyFriendsScreen> createState() => _NearbyFriendsScreenState();
}

class _NearbyFriendsScreenState extends State<NearbyFriendsScreen>
    with WidgetsBindingObserver {
  late final SupabaseClient _client = Supabase.instance.client;
  late final NearbyFriendsService _service = NearbyFriendsService(_client);
  Timer? _locationTimer;
  bool _loadingSettings = true;
  bool _enabled = false;
  bool _refreshing = false;
  bool _savingVisibility = false;
  String? _error;
  List<NearbyPerson> _people = [];
  final Set<String> _busyPeople = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_loadVisibility());
  }

  @override
  void dispose() {
    _locationTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    if (_enabled) unawaited(_clearPublishedLocation());
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!_enabled) return;
    if (state == AppLifecycleState.resumed) {
      _startLocationUpdates();
      unawaited(_refreshNearby());
    } else {
      _locationTimer?.cancel();
      _locationTimer = null;
      unawaited(_clearPublishedLocation());
    }
  }

  Future<void> _loadVisibility() async {
    try {
      final enabled = await _service.visibilityEnabled();
      if (!mounted) return;
      setState(() {
        _enabled = enabled;
        _error = null;
      });
      if (enabled) {
        _startLocationUpdates();
        await _refreshNearby();
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'تعذر تحميل إعداد الظهور القريب. تحقق من الاتصال وتطبيق ترحيل 016 على الخادم.',
        );
      }
    } finally {
      if (mounted) setState(() => _loadingSettings = false);
    }
  }

  void _startLocationUpdates() {
    _locationTimer?.cancel();
    _locationTimer = Timer.periodic(
      const Duration(seconds: 45),
      (_) => unawaited(_refreshNearby()),
    );
  }

  Future<Position> _currentPosition() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw StateError('فعّل خدمة الموقع في جهازك ثم حاول مرة أخرى.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      throw StateError('لم يُسمح باستخدام الموقع. يمكنك تفعيل الإذن للمحاولة.');
    }
    if (permission == LocationPermission.deniedForever) {
      throw StateError('إذن الموقع مرفوض نهائيًا. فعّله من إعدادات الجهاز.');
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.low,
        timeLimit: Duration(seconds: 15),
      ),
    );
  }

  String _errorMessage(Object error) => error is StateError
      ? error.message
      : 'تعذر تحديث الموقع القريب. تحقق من الاتصال وحاول مجددًا.';

  Future<void> _clearPublishedLocation() async {
    try {
      await _service.clearLocation();
    } catch (_) {
      // The server stops returning stale locations after two minutes.
    }
  }

  Future<void> _setVisibility(bool value) async {
    if (_savingVisibility || _loadingSettings) return;
    setState(() {
      _savingVisibility = true;
      _error = null;
    });

    if (!value) {
      _locationTimer?.cancel();
      _locationTimer = null;
      try {
        await _service.setVisibility(false);
        if (!mounted) return;
        setState(() {
          _enabled = false;
          _people = [];
          _error = null;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إيقاف الظهور للأشخاص القريبين.')),
        );
      } catch (_) {
        if (mounted) {
          setState(
            () => _error =
                'تعذر إيقاف الميزة الآن. تحقق من الاتصال وحاول مجددًا.',
          );
          _startLocationUpdates();
        }
      } finally {
        if (mounted) setState(() => _savingVisibility = false);
      }
      return;
    }

    var enabledOnServer = false;
    try {
      final position = await _currentPosition();
      await _service.setVisibility(true);
      enabledOnServer = true;
      await _service.publishLocation(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      final people = await _service.findNearby();
      if (!mounted) return;
      setState(() {
        _enabled = true;
        _people = people;
        _error = null;
      });
      _startLocationUpdates();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'أنت الآن ظاهر للأشخاص القريبين. يمكنك إيقاف ذلك في أي وقت.',
          ),
        ),
      );
    } catch (error) {
      if (enabledOnServer) {
        try {
          await _service.setVisibility(false);
        } catch (_) {}
      }
      if (mounted) setState(() => _error = _errorMessage(error));
    } finally {
      if (mounted) setState(() => _savingVisibility = false);
    }
  }

  Future<void> _refreshNearby() async {
    if (!_enabled || _refreshing || !mounted) return;
    setState(() => _refreshing = true);
    try {
      final position = await _currentPosition();
      await _service.publishLocation(
        latitude: position.latitude,
        longitude: position.longitude,
      );
      final people = await _service.findNearby();
      if (mounted) {
        setState(() {
          _people = people;
          _error = null;
        });
      }
    } catch (error) {
      await _clearPublishedLocation();
      if (mounted) setState(() => _error = _errorMessage(error));
    } finally {
      if (mounted) setState(() => _refreshing = false);
    }
  }

  Future<void> _updateFriendship(
    NearbyPerson person, {
    required bool accept,
  }) async {
    if (_busyPeople.contains(person.userId)) return;
    setState(() => _busyPeople.add(person.userId));
    try {
      final friendships = FriendshipService(_client);
      if (accept) {
        await friendships.respond(person.userId, accept: true);
      } else {
        await friendships.sendRequest(person.userId);
      }
      final status = await friendships.statusFor(person.userId);
      if (!mounted) return;
      setState(() {
        _people = _people
            .map(
              (candidate) => candidate.userId == person.userId
                  ? candidate.copyWith(friendshipStatus: status)
                  : candidate,
            )
            .toList();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            status.isAccepted
                ? 'أصبحتما صديقين على وصال.'
                : accept
                ? 'تم قبول طلب الصداقة.'
                : 'تم إرسال طلب الصداقة.',
          ),
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر تحديث الصداقة. تحقق من الاتصال وحاول مجددًا.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busyPeople.remove(person.userId));
    }
  }

  Widget _friendshipAction(NearbyPerson person) {
    if (_busyPeople.contains(person.userId)) {
      return const SizedBox(
        width: 34,
        height: 34,
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    final currentUserId = _client.auth.currentUser?.id ?? '';
    final status = person.friendshipStatus;
    if (status.isAccepted) {
      return const Chip(
        avatar: Icon(Icons.check, size: 16),
        label: Text('صديق'),
        visualDensity: VisualDensity.compact,
      );
    }
    if (status.isIncomingFor(currentUserId)) {
      return OutlinedButton.icon(
        onPressed: () => _updateFriendship(person, accept: true),
        icon: const Icon(Icons.check, size: 17),
        label: const Text('قبول الطلب'),
        style: OutlinedButton.styleFrom(
          visualDensity: VisualDensity.compact,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          minimumSize: const Size(0, 36),
        ),
      );
    }
    if (status.isOutgoingFor(currentUserId)) {
      return const Chip(
        avatar: Icon(Icons.schedule, size: 16),
        label: Text('تم الإرسال'),
        visualDensity: VisualDensity.compact,
      );
    }
    return OutlinedButton.icon(
      onPressed: () => _updateFriendship(person, accept: false),
      icon: const Icon(Icons.person_add_alt_1, size: 17),
      label: const Text('إضافة صديق'),
      style: OutlinedButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        minimumSize: const Size(0, 36),
      ),
    );
  }

  Widget _personTile(NearbyPerson person) {
    final avatarUrl = avatarPublicUrl(_client, person.avatarPath);
    final avatarImage = avatarUrl == null ? null : NetworkImage(avatarUrl);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsetsDirectional.fromSTEB(12, 5, 8, 5),
        leading: CircleAvatar(
          backgroundImage: avatarImage,
          child: avatarImage == null ? const Icon(Icons.person_outline) : null,
        ),
        title: Text(
          person.label,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('@${person.username}'),
            if (person.bio.trim().isNotEmpty) ...[
              const SizedBox(height: 3),
              Text(person.bio, maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
            const SizedBox(height: 3),
            Row(
              children: [
                const Icon(Icons.near_me_outlined, size: 15),
                const SizedBox(width: 4),
                Text(person.distanceLabel),
              ],
            ),
          ],
        ),
        trailing: _friendshipAction(person),
      ),
    );
  }

  Widget _privacyCard(BuildContext context) => Card(
    elevation: 0,
    color: Theme.of(context).colorScheme.secondaryContainer,
    child: const Padding(
      padding: EdgeInsets.all(14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.shield_outlined),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'ميزة اختيارية ومطفأة افتراضيًا. لا يظهر لك الآخرون إلا إذا فعّلت الظهور أنت وهم. لا تُعرض إحداثياتك الدقيقة: تُقَرّب إلى نطاق يقارب كيلومترًا، وتظهر المسافة على شكل نطاق تقريبي. يُحدّث الموقع أثناء فتح هذه الشاشة فقط، ويُمسح عند إغلاقها أو انتقال التطبيق للخلفية.',
              style: TextStyle(height: 1.45),
            ),
          ),
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('أصدقاء بالقرب منك'),
      actions: [
        IconButton(
          tooltip: 'تحديث القريبين',
          onPressed: !_enabled || _refreshing ? null : _refreshNearby,
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: SafeArea(
      child: RefreshIndicator(
        onRefresh: _refreshNearby,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
          children: [
            _privacyCard(context),
            const SizedBox(height: 10),
            Card(
              elevation: 0,
              child: SwitchListTile.adaptive(
                value: _enabled,
                onChanged: _loadingSettings || _savingVisibility
                    ? null
                    : _setVisibility,
                secondary: Icon(
                  _enabled
                      ? Icons.location_on_outlined
                      : Icons.location_off_outlined,
                ),
                title: const Text(
                  'أظهرني للأشخاص القريبين',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  _enabled
                      ? 'مفعّل أثناء وجودك في هذه الشاشة'
                      : 'متوقف — لن يظهر حسابك في البحث القريب',
                ),
              ),
            ),
            if (_loadingSettings || _refreshing || _savingVisibility) ...[
              const SizedBox(height: 8),
              const LinearProgressIndicator(minHeight: 2),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Card(
                elevation: 0,
                child: ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(_error!),
                  trailing: _enabled
                      ? TextButton(
                          onPressed: _refreshing ? null : _refreshNearby,
                          child: const Text('إعادة المحاولة'),
                        )
                      : null,
                ),
              ),
            ],
            const SizedBox(height: 14),
            Text(
              'أشخاص قريبون',
              style: Theme.of(context).textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            if (!_enabled && !_loadingSettings)
              const Card(
                elevation: 0,
                child: ListTile(
                  leading: Icon(Icons.visibility_off_outlined),
                  title: Text('فعّل الظهور المتبادل لاكتشاف أشخاص قريبين'),
                  subtitle: Text('يمكنك إيقاف الميزة في أي وقت.'),
                ),
              )
            else if (!_loadingSettings &&
                !_refreshing &&
                _error == null &&
                _people.isEmpty)
              const Card(
                elevation: 0,
                child: ListTile(
                  leading: Icon(Icons.people_outline),
                  title: Text('لا يوجد أشخاص قريبون ظاهرون الآن'),
                  subtitle: Text(
                    'سيظهر هنا فقط من فعّلوا الظهور القريب أيضًا.',
                  ),
                ),
              )
            else
              ..._people.map(_personTile),
          ],
        ),
      ),
    ),
  );
}
