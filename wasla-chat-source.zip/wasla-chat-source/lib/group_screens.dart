import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'chat_models.dart';
import 'admin_identity.dart';
import 'group_models.dart';
import 'presence_status.dart';
import 'public_discovery_models.dart';

SupabaseClient get _db => Supabase.instance.client;

String? groupAvatarUrl(String? path) {
  if (path == null || path.isEmpty) return null;
  return _db.storage.from('wasla-group-avatars').getPublicUrl(path);
}

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _description = TextEditingController();
  final _search = TextEditingController();
  final Map<String, Map<String, dynamic>> _selected = {};
  List<Map<String, dynamic>> _people = [];
  Uint8List? _avatarBytes;
  bool _private = false;
  bool _discoverable = false;
  String _listingType = 'group';
  String _category = 'other';
  bool _searching = false;
  bool _creating = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    _search.dispose();
    super.dispose();
  }

  Future<void> _searchPeople() async {
    final query = _search.text.trim();
    if (query.isEmpty) {
      setState(() => _people = []);
      return;
    }
    final username = query.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '');
    final display = query
        .replaceAll(RegExp(r'[^a-zA-Z0-9\u0600-\u06FF ]'), '')
        .trim();
    setState(() {
      _searching = true;
      _error = null;
    });
    try {
      final requests = <Future<List<Map<String, dynamic>>>>[];
      if (username.isNotEmpty) {
        requests.add(
          _db
              .from('profiles')
              .select('id, username, display_name, avatar_path')
              .ilike('username', '$username%')
              .neq('id', _db.auth.currentUser!.id)
              .order('username')
              .limit(20),
        );
      }
      if (display.isNotEmpty) {
        requests.add(
          _db
              .from('profiles')
              .select('id, username, display_name, avatar_path')
              .ilike('display_name', '%$display%')
              .neq('id', _db.auth.currentUser!.id)
              .order('username')
              .limit(20),
        );
      }
      final rows = await Future.wait(requests);
      final unique = <String, Map<String, dynamic>>{};
      for (final batch in rows) {
        for (final row in batch) {
          unique[row['id'].toString()] = Map<String, dynamic>.from(row);
        }
      }
      if (mounted) setState(() => _people = unique.values.toList());
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'تعذر البحث عن الأشخاص. حاول مجددًا.');
      }
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _pickAvatar() async {
    try {
      final image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 82,
        maxWidth: 1200,
      );
      if (image == null) return;
      final bytes = await image.readAsBytes();
      if (bytes.length > 5 * 1024 * 1024) {
        if (mounted) _message('حجم الصورة يجب ألا يتجاوز ٥ ميغابايت.');
        return;
      }
      if (mounted) setState(() => _avatarBytes = bytes);
    } catch (_) {
      if (mounted) _message('تعذر اختيار الصورة.');
    }
  }

  Future<void> _create() async {
    if (!_formKey.currentState!.validate() || _creating) return;
    setState(() {
      _creating = true;
      _error = null;
    });
    try {
      final id = (await _db.rpc(
        'create_group',
        params: {
          'p_name': _name.text.trim(),
          'p_description': _description.text.trim(),
          'p_member_ids': _selected.keys.toList(),
          'p_is_private': _private,
        },
      )).toString();
      var publiclyListed = _discoverable;
      if (publiclyListed) {
        try {
          await _db.rpc(
            'update_group_discovery_settings',
            params: {
              'p_conversation_id': id,
              'p_is_discoverable': true,
              'p_category': _category,
              'p_listing_type': _listingType,
            },
          );
        } catch (_) {
          publiclyListed = false;
          if (mounted) {
            _message(
              'تم إنشاء المجموعة، لكن تعذر نشرها. يمكنك المحاولة من جديد بعد تطبيق ترحيل 008_public_discovery.sql.',
            );
          }
        }
      }
      String? avatarPath;
      if (_avatarBytes != null) {
        final userId = _db.auth.currentUser!.id;
        avatarPath = '$id/$userId/${DateTime.now().microsecondsSinceEpoch}.jpg';
        try {
          await _db.storage
              .from('wasla-group-avatars')
              .uploadBinary(
                avatarPath,
                _avatarBytes!,
                fileOptions: const FileOptions(contentType: 'image/jpeg'),
              );
          await _db.rpc(
            'update_group_info',
            params: {
              'p_conversation_id': id,
              'p_name': _name.text.trim(),
              'p_description': _description.text.trim(),
              'p_avatar_path': avatarPath,
            },
          );
        } catch (_) {
          avatarPath = null;
          if (mounted) _message('تم إنشاء المجموعة، لكن تعذر رفع صورتها.');
        }
      }
      if (!mounted) return;
      Navigator.of(context).pop(
        ChatTarget(
          conversationId: id,
          userId: '',
          username: '',
          displayName: _name.text.trim(),
          avatarPath: avatarPath,
          isGroup: true,
          groupDescription: _description.text.trim(),
          memberCount: _selected.length + 1,
          groupRole: 'owner',
          isPublicRoom: publiclyListed && _listingType == 'room',
        ),
      );
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'تعذر إنشاء المجموعة. تأكد من الاتصال وتطبيق الترحيل 005_groups.sql على خادم وصال.',
        );
      }
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  void _message(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إنشاء مجموعة')),
    body: SafeArea(
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Center(
                  child: InkWell(
                    onTap: _pickAvatar,
                    borderRadius: BorderRadius.circular(42),
                    child: CircleAvatar(
                      radius: 42,
                      backgroundColor: const Color(0xFFE4F3EF),
                      backgroundImage: _avatarBytes == null
                          ? null
                          : MemoryImage(_avatarBytes!),
                      child: _avatarBytes == null
                          ? const Icon(Icons.camera_alt_outlined, size: 30)
                          : null,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                const Center(
                  child: Text(
                    'أضف صورة للمجموعة (اختياري)',
                    style: TextStyle(color: Color(0xFF71827D)),
                  ),
                ),
                const SizedBox(height: 18),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _name,
                        maxLength: 80,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'اسم المجموعة',
                          prefixIcon: Icon(Icons.groups_outlined),
                        ),
                        validator: (value) =>
                            value == null || value.trim().length < 2
                            ? 'اكتب اسمًا من حرفين على الأقل.'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _description,
                        maxLength: 500,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: 'وصف المجموعة (اختياري)',
                          alignLabelWithHint: true,
                        ),
                      ),
                    ],
                  ),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  value: _private,
                  onChanged: (value) => setState(() {
                    _private = value;
                    if (value) _discoverable = false;
                  }),
                  title: const Text('مجموعة خاصة'),
                  subtitle: const Text(
                    'يتطلب الانضمام موافقة المالك أو المشرف.',
                  ),
                ),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  value: _discoverable,
                  onChanged: _private
                      ? null
                      : (value) => setState(() => _discoverable = value),
                  title: const Text('إظهار في الاستكشاف العام'),
                  subtitle: const Text(
                    'ستظهر المجموعة واسمها ووصفها وعدد أعضائها للمستخدمين المسجلين.',
                  ),
                ),
                if (_discoverable) ...[
                  const SizedBox(height: 8),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(
                        value: 'group',
                        label: Text('مجموعة'),
                        icon: Icon(Icons.groups_outlined),
                      ),
                      ButtonSegment(
                        value: 'room',
                        label: Text('غرفة دردشة'),
                        icon: Icon(Icons.forum_outlined),
                      ),
                    ],
                    selected: {_listingType},
                    onSelectionChanged: (values) =>
                        setState(() => _listingType = values.first),
                  ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(
                      'التصنيف',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                  Wrap(
                    spacing: 6,
                    children: PublicCategory.values
                        .skip(1)
                        .map(
                          (category) => ChoiceChip(
                            label: Text(category.label),
                            selected: _category == category.value,
                            onSelected: (_) =>
                                setState(() => _category = category.value),
                          ),
                        )
                        .toList(),
                  ),
                ],
                const Divider(height: 26),
                Text(
                  'إضافة أعضاء عند الإنشاء (${_selected.length})',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _search,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _searchPeople(),
                  decoration: InputDecoration(
                    hintText: 'ابحث بالاسم أو اسم المستخدم',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: IconButton(
                      onPressed: _searchPeople,
                      icon: const Icon(Icons.arrow_forward),
                    ),
                  ),
                ),
                if (_searching) const LinearProgressIndicator(minHeight: 2),
                if (_selected.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: _selected.entries
                        .map(
                          (entry) => Chip(
                            label: AdminIdentityText(
                              userId: entry.key,
                              label:
                                  entry.value['display_name']
                                          ?.toString()
                                          .isNotEmpty ==
                                      true
                                  ? entry.value['display_name'].toString()
                                  : '@${entry.value['username']}',
                            ),
                            onDeleted: () =>
                                setState(() => _selected.remove(entry.key)),
                          ),
                        )
                        .toList(),
                  ),
                ],
                ..._people.map((person) {
                  final id = person['id'].toString();
                  final selected = _selected.containsKey(id);
                  final name = person['display_name']?.toString() ?? '';
                  return CheckboxListTile(
                    value: selected,
                    controlAffinity: ListTileControlAffinity.leading,
                    title: AdminIdentityText(
                      userId: id,
                      label: name.isEmpty ? '@${person['username']}' : name,
                    ),
                    subtitle: Text('@${person['username']}'),
                    onChanged: (value) => setState(() {
                      if (value == true) {
                        if (_selected.length < 99) _selected[id] = person;
                      } else {
                        _selected.remove(id);
                      }
                    }),
                  );
                }),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      _error!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 14),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _creating ? null : _create,
                icon: _creating
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.group_add_outlined),
                label: Text(_creating ? 'جارٍ الإنشاء...' : 'إنشاء المجموعة'),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class JoinGroupScreen extends StatefulWidget {
  const JoinGroupScreen({super.key, this.initialToken});
  final String? initialToken;

  @override
  State<JoinGroupScreen> createState() => _JoinGroupScreenState();
}

class _JoinGroupScreenState extends State<JoinGroupScreen> {
  late final TextEditingController _token;
  final _message = TextEditingController();
  bool _busy = false;
  String? _notice;
  String? _error;

  @override
  void initState() {
    super.initState();
    _token = TextEditingController(text: widget.initialToken ?? '');
  }

  @override
  void dispose() {
    _token.dispose();
    _message.dispose();
    super.dispose();
  }

  String _extractToken(String raw) {
    final value = raw.trim();
    final uri = Uri.tryParse(value);
    if (uri != null &&
        uri.scheme == 'wasla' &&
        uri.host == 'join' &&
        uri.pathSegments.isNotEmpty) {
      return uri.pathSegments.first;
    }
    final marker = value.lastIndexOf('/join/');
    return marker >= 0
        ? value.substring(marker + 6).split(RegExp(r'[?#]')).first
        : value;
  }

  Future<void> _join() async {
    final token = _extractToken(_token.text);
    if (token.length < 12) {
      setState(() => _error = 'أدخل رابط دعوة صالحًا أو رمزه.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      final result = await _db.rpc(
        'join_group_by_invite',
        params: {'p_token': token, 'p_message': _message.text.trim()},
      );
      final data = Map<String, dynamic>.from(result as Map);
      final status = data['status']?.toString();
      if (status == 'joined' || status == 'already_member') {
        final id = data['conversation_id'].toString();
        final group = await _db
            .from('groups')
            .select('name, description, avatar_path')
            .eq('conversation_id', id)
            .single();
        final members = await _db
            .from('group_members')
            .select('user_id')
            .eq('conversation_id', id);
        if (!mounted) return;
        Navigator.of(context).pop(
          ChatTarget(
            conversationId: id,
            userId: '',
            username: '',
            displayName:
                group['name']?.toString() ??
                data['group_name']?.toString() ??
                'مجموعة',
            avatarPath: group['avatar_path']?.toString(),
            isGroup: true,
            groupDescription: group['description']?.toString() ?? '',
            memberCount: members.length,
            groupRole: 'member',
          ),
        );
      } else {
        setState(
          () => _notice =
              'تم إرسال طلب الانضمام. سيظهر لك عند موافقة المالك أو المشرف.',
        );
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'الرابط غير صالح أو تعذر الانضمام. تأكد من الاتصال وتطبيق الترحيل 005_groups.sql على الخادم.',
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الانضمام إلى مجموعة')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Icon(
          Icons.group_add_outlined,
          size: 58,
          color: Color(0xFF087F72),
        ),
        const SizedBox(height: 10),
        const Text(
          'أدخل رابط الدعوة أو الرمز',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 20),
        TextField(
          controller: _token,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
            labelText: 'رابط أو رمز الدعوة',
            prefixIcon: Icon(Icons.link),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _message,
          maxLength: 300,
          maxLines: 2,
          decoration: const InputDecoration(
            labelText: 'رسالة للمالك (اختيارية)',
            alignLabelWithHint: true,
          ),
        ),
        if (_error != null) _GroupNotice(text: _error!, error: true),
        if (_notice != null) _GroupNotice(text: _notice!, error: false),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _busy ? null : _join,
          icon: _busy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.login),
          label: Text(_busy ? 'جارٍ التحقق...' : 'متابعة'),
        ),
      ],
    ),
  );
}

class GroupPeoplePickerScreen extends StatefulWidget {
  const GroupPeoplePickerScreen({super.key, this.excludeIds = const {}});
  final Set<String> excludeIds;

  @override
  State<GroupPeoplePickerScreen> createState() =>
      _GroupPeoplePickerScreenState();
}

class _GroupPeoplePickerScreenState extends State<GroupPeoplePickerScreen> {
  final _query = TextEditingController();
  final Set<String> _selected = {};
  List<Map<String, dynamic>> _people = [];
  bool _busy = false;

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _query.text.trim();
    if (q.isEmpty) {
      setState(() => _people = []);
      return;
    }
    final username = q.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '');
    final display = q
        .replaceAll(RegExp(r'[^a-zA-Z0-9\u0600-\u06FF ]'), '')
        .trim();
    setState(() => _busy = true);
    try {
      final requests = <Future<List<Map<String, dynamic>>>>[];
      if (username.isNotEmpty) {
        requests.add(
          _db
              .from('profiles')
              .select('id,username,display_name')
              .ilike('username', '$username%')
              .neq('id', _db.auth.currentUser!.id)
              .limit(20),
        );
      }
      if (display.isNotEmpty) {
        requests.add(
          _db
              .from('profiles')
              .select('id,username,display_name')
              .ilike('display_name', '%$display%')
              .neq('id', _db.auth.currentUser!.id)
              .limit(20),
        );
      }
      final rows = await Future.wait(requests);
      final all = <String, Map<String, dynamic>>{};
      for (final batch in rows) {
        for (final item in batch) {
          if (!widget.excludeIds.contains(item['id'].toString())) {
            all[item['id'].toString()] = Map<String, dynamic>.from(item);
          }
        }
      }
      if (mounted) setState(() => _people = all.values.toList());
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر البحث الآن.')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('اختيار الأعضاء'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, _selected.toList()),
          child: Text('إضافة (${_selected.length})'),
        ),
      ],
    ),
    body: Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: TextField(
            controller: _query,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(
              hintText: 'ابحث بالاسم أو اسم المستخدم',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                onPressed: _search,
                icon: const Icon(Icons.arrow_forward),
              ),
            ),
          ),
        ),
        if (_busy) const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: ListView(
            children: _people.map((person) {
              final id = person['id'].toString();
              final name = person['display_name']?.toString() ?? '';
              return CheckboxListTile(
                value: _selected.contains(id),
                title: AdminIdentityText(
                  userId: id,
                  label: name.isEmpty ? '@${person['username']}' : name,
                ),
                subtitle: Text('@${person['username']}'),
                onChanged: (value) => setState(() {
                  if (value == true) {
                    _selected.add(id);
                  } else {
                    _selected.remove(id);
                  }
                }),
              );
            }).toList(),
          ),
        ),
      ],
    ),
  );
}

class GroupInfoScreen extends StatefulWidget {
  const GroupInfoScreen({required this.conversationId, super.key});
  final String conversationId;

  @override
  State<GroupInfoScreen> createState() => _GroupInfoScreenState();
}

class _GroupInfoScreenState extends State<GroupInfoScreen> {
  GroupInfo? _group;
  List<GroupMember> _members = [];
  List<GroupJoinRequest> _requests = [];
  List<Map<String, dynamic>> _pins = [];
  List<Map<String, dynamic>> _sharedMedia = [];
  List<GroupActivityEntry> _activity = [];
  final _memberSearch = TextEditingController();
  bool _loading = true;
  bool _working = false;
  String? _error;
  String? _myRole;
  String get _myId => _db.auth.currentUser!.id;
  bool get _isAdmin => _myRole == 'owner' || _myRole == 'admin';
  bool get _isOwner => _myRole == 'owner';
  bool get _canManageMembers =>
      _isOwner ||
      (_myRole == 'admin' && (_group?.adminsCanManageMembers ?? true));
  bool get _canPinMessages =>
      _isOwner ||
      (_myRole == 'admin' && (_group?.adminsCanPinMessages ?? true));

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _memberSearch.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final groupRow = await _db
          .from('groups')
          .select()
          .eq('conversation_id', widget.conversationId)
          .single();
      final memberRows = await _db
          .from('group_members')
          .select('user_id, role, joined_at')
          .eq('conversation_id', widget.conversationId)
          .order('joined_at');
      final requestRows = <Map<String, dynamic>>[];
      if (memberRows.any(
        (row) =>
            row['user_id'].toString() == _myId &&
            ['owner', 'admin'].contains(row['role']),
      )) {
        try {
          requestRows.addAll(
            (await _db
                    .from('group_join_requests')
                    .select('id,user_id,message,requested_at')
                    .eq('conversation_id', widget.conversationId)
                    .eq('status', 'pending')
                    .order('requested_at'))
                .map((row) => Map<String, dynamic>.from(row)),
          );
        } catch (_) {}
      }
      final pinRows = await _db
          .from('conversation_pinned_messages')
          .select('message_id,pinned_at')
          .eq('conversation_id', widget.conversationId)
          .order('pinned_at', ascending: false)
          .limit(50);
      final sharedMediaRows = await _db
          .from('messages')
          .select('id,content,message_type,created_at,media_path')
          .eq('conversation_id', widget.conversationId)
          .inFilter('message_type', [
            'image',
            'video',
            'file',
            'audio',
            'location',
          ])
          .order('created_at', ascending: false)
          .limit(50);
      final activityRows = await _db
          .from('group_activity')
          .select('actor_id,target_user_id,action,created_at')
          .eq('conversation_id', widget.conversationId)
          .order('created_at', ascending: false)
          .limit(30);
      final ids = <String>{
        ...memberRows.map((row) => row['user_id'].toString()),
        ...requestRows.map((row) => row['user_id'].toString()),
        ...activityRows
            .where((row) => row['actor_id'] != null)
            .map((row) => row['actor_id'].toString()),
        ...activityRows
            .where((row) => row['target_user_id'] != null)
            .map((row) => row['target_user_id'].toString()),
      };
      final profileRows = ids.isEmpty
          ? <Map<String, dynamic>>[]
          : await _db
                .from('profiles')
                .select('id,username,display_name,avatar_path')
                .inFilter('id', ids.toList());
      final profiles = {
        for (final row in profileRows)
          row['id'].toString(): Map<String, dynamic>.from(row),
      };
      final members = memberRows.map((row) {
        final id = row['user_id'].toString();
        final p = profiles[id] ?? const <String, dynamic>{};
        return GroupMember(
          userId: id,
          role: row['role'].toString(),
          username: p['username']?.toString() ?? '',
          displayName: p['display_name']?.toString() ?? '',
          avatarPath: p['avatar_path']?.toString(),
          joinedAt: DateTime.tryParse(row['joined_at'].toString()),
        );
      }).toList();
      try {
        mergeUserPresenceStatuses(
          await UserPresenceService(_db)
              .loadForUsers(members.map((member) => member.userId)),
        );
      } catch (_) {
        // Group member management remains usable if status migration is pending.
      }
      final requests = requestRows.map((row) {
        final id = row['user_id'].toString();
        final p = profiles[id] ?? const <String, dynamic>{};
        return GroupJoinRequest(
          id: row['id'].toString(),
          userId: id,
          username: p['username']?.toString() ?? '',
          displayName: p['display_name']?.toString() ?? '',
          message: row['message']?.toString() ?? '',
          requestedAt: DateTime.tryParse(row['requested_at'].toString()),
        );
      }).toList();
      final pins = <Map<String, dynamic>>[];
      if (pinRows.isNotEmpty) {
        final messageIds = pinRows
            .map((row) => row['message_id'].toString())
            .toList();
        final messages = await _db
            .from('messages')
            .select('id,content,message_type')
            .inFilter('id', messageIds);
        final byId = {for (final row in messages) row['id'].toString(): row};
        for (final row in pinRows) {
          final message = byId[row['message_id'].toString()];
          if (message != null) {
            pins.add({
              ...Map<String, dynamic>.from(message),
              'pinned_at': row['pinned_at'],
            });
          }
        }
      }
      final activity = activityRows.map((row) {
        final actor =
            profiles[row['actor_id']?.toString()] ?? const <String, dynamic>{};
        final target =
            profiles[row['target_user_id']?.toString()] ??
            const <String, dynamic>{};
        String label(Map<String, dynamic> p) =>
            (p['display_name']?.toString().isNotEmpty == true)
            ? p['display_name'].toString()
            : (p['username'] == null ? '' : '@${p['username']}');
        return GroupActivityEntry(
          action: row['action']?.toString() ?? '',
          actorName: label(actor),
          targetName: label(target),
          createdAt: DateTime.tryParse(row['created_at'].toString()),
        );
      }).toList();
      if (!mounted) return;
      setState(() {
        _group = GroupInfo.fromMap({
          ...Map<String, dynamic>.from(groupRow),
          'member_count': memberRows.length,
        });
        _members = members;
        _requests = requests;
        _pins = pins;
        _sharedMedia = sharedMediaRows
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
        _activity = activity;
        _myRole = members.where((m) => m.userId == _myId).firstOrNull?.role;
        _loading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'تعذر تحميل معلومات المجموعة.';
        });
      }
    }
  }

  Future<void> _rpc(
    String name,
    Map<String, dynamic> params, {
    String? success,
  }) async {
    if (_working) return;
    setState(() => _working = true);
    try {
      await _db.rpc(name, params: params);
      if (mounted && success != null) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(success)));
      }
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر تنفيذ العملية. تحقق من الصلاحيات والاتصال.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<bool> _confirm(
    String title,
    String body, {
    String action = 'متابعة',
  }) async =>
      await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(action),
            ),
          ],
        ),
      ) ??
      false;

  Future<void> _editInfo() async {
    final group = _group;
    if (group == null) return;
    final name = TextEditingController(text: group.name);
    final description = TextEditingController(text: group.description);
    final accepted =
        await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('تعديل معلومات المجموعة'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  maxLength: 80,
                  decoration: const InputDecoration(labelText: 'اسم المجموعة'),
                ),
                TextField(
                  controller: description,
                  maxLength: 500,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'الوصف'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('حفظ'),
              ),
            ],
          ),
        ) ??
        false;
    if (accepted && name.text.trim().length >= 2) {
      await _rpc('update_group_info', {
        'p_conversation_id': widget.conversationId,
        'p_name': name.text.trim(),
        'p_description': description.text.trim(),
        'p_avatar_path': group.avatarPath,
      }, success: 'تم تحديث المعلومات.');
    }
    name.dispose();
    description.dispose();
  }

  Future<void> _changeAvatar() async {
    final group = _group;
    if (group == null) return;
    try {
      final image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 82,
        maxWidth: 1200,
      );
      if (image == null) return;
      final bytes = await image.readAsBytes();
      if (bytes.length > 5 * 1024 * 1024) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('حجم الصورة أكبر من ٥ ميغابايت.')),
          );
        }
        return;
      }
      final path =
          '${widget.conversationId}/$_myId/${DateTime.now().microsecondsSinceEpoch}.jpg';
      await _db.storage
          .from('wasla-group-avatars')
          .uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );
      await _rpc('update_group_info', {
        'p_conversation_id': widget.conversationId,
        'p_name': group.name,
        'p_description': group.description,
        'p_avatar_path': path,
      }, success: 'تم تحديث صورة المجموعة.');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث صورة المجموعة.')),
        );
      }
    }
  }

  Future<void> _settings({String? key, bool? value}) async {
    final g = _group;
    if (g == null) return;
    await _rpc('update_group_settings', {
      'p_conversation_id': widget.conversationId,
      'p_members_can_message': key == 'members_can_message'
          ? value
          : g.membersCanMessage,
      'p_members_can_add': key == 'members_can_add' ? value : g.membersCanAdd,
      'p_members_can_edit_info': key == 'members_can_edit_info'
          ? value
          : g.membersCanEditInfo,
      'p_admins_can_manage_members': key == 'admins_can_manage_members'
          ? value
          : g.adminsCanManageMembers,
      'p_admins_can_pin_messages': key == 'admins_can_pin_messages'
          ? value
          : g.adminsCanPinMessages,
      'p_admins_can_delete_messages': key == 'admins_can_delete_messages'
          ? value
          : g.adminsCanDeleteMessages,
      'p_files_allowed': key == 'files_allowed' ? value : g.filesAllowed,
      'p_voice_allowed': key == 'voice_allowed' ? value : g.voiceAllowed,
      'p_calls_allowed': key == 'calls_allowed' ? value : g.callsAllowed,
    });
  }

  Future<void> _discoverySettings({
    bool? discoverable,
    String? category,
    String? listingType,
  }) async {
    final group = _group;
    if (group == null) return;
    await _rpc(
      'update_group_discovery_settings',
      {
        'p_conversation_id': widget.conversationId,
        'p_is_discoverable': discoverable ?? group.isDiscoverable,
        'p_category': category ?? group.category,
        'p_listing_type': listingType ?? group.listingType,
      },
      success: discoverable == null
          ? 'تم تحديث إعدادات الاستكشاف.'
          : discoverable
          ? 'أصبحت المجموعة ظاهرة في الاستكشاف.'
          : 'أُخفيت المجموعة من الاستكشاف.',
    );
  }

  Future<void> _addMembers() async {
    final ids = await Navigator.of(context).push<List<String>>(
      MaterialPageRoute(
        builder: (_) => GroupPeoplePickerScreen(
          excludeIds: _members.map((m) => m.userId).toSet(),
        ),
      ),
    );
    if (ids == null || ids.isEmpty) return;
    await _rpc('add_group_members', {
      'p_conversation_id': widget.conversationId,
      'p_user_ids': ids,
    }, success: 'تمت إضافة الأعضاء.');
  }

  Future<void> _memberAction(GroupMember member, String action) async {
    if (action == 'promote' || action == 'demote') {
      await _rpc(
        'set_group_member_role',
        {
          'p_conversation_id': widget.conversationId,
          'p_user_id': member.userId,
          'p_role': action == 'promote' ? 'admin' : 'member',
        },
        success: action == 'promote'
            ? 'تم تعيينه مشرفًا.'
            : 'تم إلغاء صلاحية الإشراف.',
      );
    } else if (action == 'remove' || action == 'ban') {
      final confirmed = await _confirm(
        action == 'ban' ? 'حظر العضو' : 'إزالة العضو',
        'هل تريد ${action == 'ban' ? 'حظر' : 'إزالة'} ${member.displayLabel} من المجموعة؟',
        action: action == 'ban' ? 'حظر' : 'إزالة',
      );
      if (confirmed) {
        await _rpc(
          action == 'ban' ? 'ban_group_member' : 'remove_group_member',
          {
            'p_conversation_id': widget.conversationId,
            'p_user_id': member.userId,
          },
          success: action == 'ban' ? 'تم حظر العضو.' : 'تمت إزالة العضو.',
        );
      }
    } else if (action == 'transfer') {
      final confirmed = await _confirm(
        'نقل ملكية المجموعة',
        'ستصبح ${member.displayLabel} مالك المجموعة، وستتحول صلاحيتك إلى مشرف.',
        action: 'نقل الملكية',
      );
      if (confirmed) {
        await _rpc('transfer_group_owner', {
          'p_conversation_id': widget.conversationId,
          'p_user_id': member.userId,
        }, success: 'تم نقل الملكية.');
      }
    }
  }

  Future<void> _rotateInvite() async {
    final confirmed = await _confirm(
      'تجديد رابط الدعوة',
      'سيصبح الرابط الحالي غير صالح، وسيحتاج الأعضاء إلى استخدام الرابط الجديد.',
      action: 'تجديد',
    );
    if (!confirmed) return;
    try {
      await _db.rpc(
        'rotate_group_invite',
        params: {'p_conversation_id': widget.conversationId},
      );
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إنشاء رابط دعوة جديد.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر تجديد الرابط.')));
      }
    }
  }

  Future<void> _resolveRequest(GroupJoinRequest request, bool accept) async =>
      _rpc('resolve_group_join_request', {
        'p_request_id': request.id,
        'p_accept': accept,
      }, success: accept ? 'تم قبول طلب الانضمام.' : 'تم رفض الطلب.');

  Future<void> _openReports() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) =>
            GroupReportsScreen(conversationId: widget.conversationId),
      ),
    );
    await _load();
  }

  Future<void> _reportMember(GroupMember member) async {
    final reason = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(
                'الإبلاغ عن ${member.displayLabel}',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text('سيصل البلاغ إلى مشرفي المجموعة.'),
            ),
            for (final item in const [
              ('spam', 'رسائل مزعجة أو احتيال'),
              ('harassment', 'مضايقة أو إساءة'),
              ('inappropriate', 'محتوى غير مناسب'),
              ('impersonation', 'انتحال شخصية'),
              ('other', 'سبب آخر'),
            ])
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: Text(item.$2),
                onTap: () => Navigator.pop(context, item.$1),
              ),
          ],
        ),
      ),
    );
    if (reason == null) return;
    try {
      await _db.rpc(
        'submit_public_content_report',
        params: {
          'p_conversation_id': widget.conversationId,
          'p_report_type': 'user',
          'p_target_user_id': member.userId,
          'p_reason': reason,
          'p_details': '',
        },
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('شكرًا، أُرسل البلاغ للمراجعة.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر إرسال البلاغ الآن.')),
        );
      }
    }
  }

  Future<void> _pin(String messageId, bool pin) async =>
      _rpc('set_group_message_pinned', {
        'p_conversation_id': widget.conversationId,
        'p_message_id': messageId,
        'p_pinned': pin,
      }, success: pin ? 'تم تثبيت الرسالة.' : 'تم إلغاء تثبيت الرسالة.');

  String _activityText(GroupActivityEntry e) {
    final actor = e.actorName.isEmpty ? 'أحد الأعضاء' : e.actorName;
    final target = e.targetName.isEmpty ? 'عضوًا' : e.targetName;
    switch (e.action) {
      case 'group_created':
        return 'أنشأ $actor المجموعة';
      case 'member_added':
        return 'أضاف $actor $target';
      case 'member_joined':
        return 'انضم $target إلى المجموعة';
      case 'member_left':
        return 'غادر $target المجموعة';
      case 'member_removed':
        return 'أزال $actor $target';
      case 'member_banned':
        return 'حظر $actor $target';
      case 'member_promoted':
        return 'رقّى $actor $target إلى مشرف';
      case 'admin_demoted':
        return 'ألغى $actor صلاحية إشراف $target';
      case 'group_name_changed':
        return 'غيّر $actor اسم المجموعة';
      case 'group_avatar_changed':
        return 'غيّر $actor صورة المجموعة';
      case 'group_info_changed':
        return 'حدّث $actor معلومات المجموعة';
      case 'settings_changed':
        return 'عدّل $actor إعدادات المجموعة';
      case 'invite_rotated':
        return 'جدّد $actor رابط الدعوة';
      case 'message_pinned':
        return 'ثبّت $actor رسالة';
      case 'message_unpinned':
        return 'ألغى $actor تثبيت رسالة';
      case 'join_requested':
        return 'أرسل $target طلب انضمام';
      case 'join_request_accepted':
        return 'قَبِل $actor طلب $target';
      case 'join_request_rejected':
        return 'رفض $actor طلب $target';
      case 'ownership_transferred':
        return 'نقل $actor ملكية المجموعة إلى $target';
      default:
        return 'حدّث $actor المجموعة';
    }
  }

  Future<void> _leave() async {
    if (!await _confirm(
      'مغادرة المجموعة',
      'لن تتمكن من قراءة الرسائل الجديدة بعد المغادرة.',
      action: 'مغادرة',
    )) {
      return;
    }
    try {
      await _db.rpc(
        'leave_group',
        params: {'p_conversation_id': widget.conversationId},
      );
      if (mounted) Navigator.pop(context, 'left');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('يجب نقل الملكية قبل مغادرة المالك.')),
        );
      }
    }
  }

  Future<void> _delete() async {
    if (!await _confirm(
      'حذف المجموعة نهائيًا',
      'سيُحذف سجل المجموعة ورسائلها وأعضاؤها نهائيًا. لا يمكن التراجع عن ذلك.',
      action: 'حذف نهائي',
    )) {
      return;
    }
    try {
      await _removeGroupStorageObjects();
      await _db.rpc(
        'delete_group',
        params: {'p_conversation_id': widget.conversationId},
      );
      if (mounted) Navigator.pop(context, 'deleted');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'تعذر تنظيف ملفات المجموعة أو حذفها. لم يُحذف سجل المجموعة.',
            ),
          ),
        );
      }
    }
  }

  Future<void> _removeGroupStorageObjects() async {
    final media = _db.storage.from('wasla-media');
    final rootObjects = await media.list(
      path: widget.conversationId,
      searchOptions: const SearchOptions(limit: 1000),
    );
    final paths = <String>[];
    for (final entry in rootObjects) {
      if (entry.id != null) {
        paths.add('${widget.conversationId}/${entry.name}');
        continue;
      }
      var offset = 0;
      while (true) {
        final files = await media.list(
          path: '${widget.conversationId}/${entry.name}',
          searchOptions: SearchOptions(limit: 1000, offset: offset),
        );
        paths.addAll(
          files
              .where((file) => file.id != null)
              .map(
                (file) => '${widget.conversationId}/${entry.name}/${file.name}',
              ),
        );
        if (files.length < 1000) break;
        offset += files.length;
      }
    }
    if (paths.isNotEmpty) await media.remove(paths);
    final avatarPath = _group?.avatarPath;
    if (avatarPath != null && avatarPath.isNotEmpty) {
      await _db.storage.from('wasla-group-avatars').remove([avatarPath]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final group = _group;
    final filteredMembers = _members
        .where(
          (m) => '${m.displayLabel} @${m.username}'.toLowerCase().contains(
            _memberSearch.text.trim().toLowerCase(),
          ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(group?.name ?? 'معلومات المجموعة'),
        actions: [
          if (_isAdmin)
            IconButton(
              tooltip: 'تعديل المعلومات',
              onPressed: _editInfo,
              icon: const Icon(Icons.edit_outlined),
            ),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'leave') _leave();
              if (value == 'delete') _delete();
            },
            itemBuilder: (_) => [
              if (!_isOwner)
                const PopupMenuItem(
                  value: 'leave',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.exit_to_app),
                    title: Text('مغادرة المجموعة'),
                  ),
                ),
              if (_isOwner)
                const PopupMenuItem(
                  value: 'delete',
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.delete_outline),
                    title: Text('حذف المجموعة'),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_error!),
                  TextButton(
                    onPressed: _load,
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            )
          : group == null
          ? const SizedBox.shrink()
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Center(
                    child: Column(
                      children: [
                        Stack(
                          children: [
                            CircleAvatar(
                              radius: 44,
                              backgroundColor: const Color(0xFFE4F3EF),
                              backgroundImage:
                                  groupAvatarUrl(group.avatarPath) == null
                                  ? null
                                  : NetworkImage(
                                      groupAvatarUrl(group.avatarPath)!,
                                    ),
                              child: group.avatarPath == null
                                  ? const Icon(
                                      Icons.groups_outlined,
                                      size: 38,
                                      color: Color(0xFF087F72),
                                    )
                                  : null,
                            ),
                            if (_isAdmin || group.membersCanEditInfo)
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: IconButton.filled(
                                  onPressed: _changeAvatar,
                                  icon: const Icon(Icons.camera_alt, size: 18),
                                  tooltip: 'تغيير صورة المجموعة',
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          group.name,
                          style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (group.description.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(
                              group.description,
                              textAlign: TextAlign.center,
                              style: const TextStyle(color: Color(0xFF60736E)),
                            ),
                          ),
                        const SizedBox(height: 4),
                        Text(
                          '${group.memberCount} أعضاء · ${_isOwner
                              ? 'المالك'
                              : _myRole == 'admin'
                              ? 'مشرف'
                              : 'عضو'}',
                          style: const TextStyle(color: Color(0xFF71827D)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  _sectionTitle('رابط الدعوة', Icons.link),
                  Card(
                    elevation: 0,
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(Icons.link),
                          title: const Text('دعوة للانضمام'),
                          subtitle: Text(
                            'wasla://join/${group.inviteToken}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          onTap: () => Clipboard.setData(
                            ClipboardData(
                              text: 'wasla://join/${group.inviteToken}',
                            ),
                          ),
                        ),
                        Wrap(
                          alignment: WrapAlignment.center,
                          children: [
                            TextButton.icon(
                              onPressed: () async {
                                final messenger = ScaffoldMessenger.of(context);
                                await Clipboard.setData(
                                  ClipboardData(
                                    text: 'wasla://join/${group.inviteToken}',
                                  ),
                                );
                                if (!mounted) return;
                                messenger.showSnackBar(
                                  const SnackBar(
                                    content: Text('تم نسخ رابط الدعوة.'),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.copy),
                              label: const Text('نسخ'),
                            ),
                            TextButton.icon(
                              onPressed: () => SharePlus.instance.share(
                                ShareParams(
                                  text:
                                      'انضم إلى مجموعة ${group.name}\nwasla://join/${group.inviteToken}',
                                ),
                              ),
                              icon: const Icon(Icons.share_outlined),
                              label: const Text('مشاركة'),
                            ),
                            TextButton.icon(
                              onPressed: () => showDialog<void>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('رمز QR للدعوة'),
                                  content: SizedBox(
                                    width: 250,
                                    height: 260,
                                    child: Column(
                                      children: [
                                        QrImageView(
                                          data:
                                              'wasla://join/${group.inviteToken}',
                                          size: 210,
                                        ),
                                        const Text(
                                          'امسح الرمز لفتح رابط المجموعة',
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              icon: const Icon(Icons.qr_code_2),
                              label: const Text('QR'),
                            ),
                            if (_canManageMembers)
                              TextButton.icon(
                                onPressed: _working ? null : _rotateInvite,
                                icon: const Icon(Icons.refresh),
                                label: const Text('تجديد'),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (_isOwner) ...[
                    const SizedBox(height: 12),
                    _sectionTitle('الاستكشاف العام', Icons.explore_outlined),
                    Card(
                      elevation: 0,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: Column(
                          children: [
                            SwitchListTile.adaptive(
                              value: group.isDiscoverable,
                              onChanged: _working || group.isPrivate
                                  ? null
                                  : (value) =>
                                        _discoverySettings(discoverable: value),
                              title: const Text('إظهار المجموعة في الاستكشاف'),
                              subtitle: Text(
                                group.isPrivate
                                    ? 'المجموعة الخاصة لا تظهر للعامة. أنشئ مجموعة عامة إذا أردت فتحها للجميع.'
                                    : 'عند التفعيل يستطيع المستخدمون المسجلون العثور عليها والانضمام مباشرة.',
                              ),
                            ),
                            if (group.isDiscoverable) ...[
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 6,
                                ),
                                child: SegmentedButton<String>(
                                  segments: const [
                                    ButtonSegment(
                                      value: 'group',
                                      label: Text('مجموعة'),
                                      icon: Icon(Icons.groups_outlined),
                                    ),
                                    ButtonSegment(
                                      value: 'room',
                                      label: Text('غرفة دردشة'),
                                      icon: Icon(Icons.forum_outlined),
                                    ),
                                  ],
                                  selected: {group.listingType},
                                  onSelectionChanged: (values) =>
                                      _discoverySettings(
                                        listingType: values.first,
                                      ),
                                ),
                              ),
                              Wrap(
                                spacing: 6,
                                children: PublicCategory.values
                                    .skip(1)
                                    .map(
                                      (category) => ChoiceChip(
                                        label: Text(category.label),
                                        selected:
                                            group.category == category.value,
                                        onSelected: _working
                                            ? null
                                            : (_) => _discoverySettings(
                                                category: category.value,
                                              ),
                                      ),
                                    )
                                    .toList(),
                              ),
                              const SizedBox(height: 8),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                  if (_isAdmin && _requests.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    _sectionTitle(
                      'طلبات الانضمام (${_requests.length})',
                      Icons.person_add_alt_1,
                    ),
                    ..._requests.map(
                      (request) => Card(
                        elevation: 0,
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.person_outline),
                          ),
                          title: AdminIdentityText(
                            userId: request.userId,
                            label: request.displayLabel,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            request.message.isEmpty
                                ? 'طلب انضمام جديد'
                                : request.message,
                          ),
                          trailing: Wrap(
                            children: [
                              IconButton(
                                tooltip: 'قبول',
                                onPressed: () => _resolveRequest(request, true),
                                icon: const Icon(
                                  Icons.check_circle_outline,
                                  color: Color(0xFF087F72),
                                ),
                              ),
                              IconButton(
                                tooltip: 'رفض',
                                onPressed: () =>
                                    _resolveRequest(request, false),
                                icon: const Icon(
                                  Icons.cancel_outlined,
                                  color: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                  if (_isAdmin) ...[
                    const SizedBox(height: 10),
                    _sectionTitle('إدارة المحتوى', Icons.shield_outlined),
                    Card(
                      elevation: 0,
                      child: ListTile(
                        leading: const Icon(Icons.flag_outlined),
                        title: const Text('بلاغات المحتوى'),
                        subtitle: const Text(
                          'راجع البلاغات واتخذ إجراءً أو أغلقها.',
                        ),
                        trailing: const Icon(Icons.chevron_left),
                        onTap: _openReports,
                      ),
                    ),
                  ],
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _sectionTitle(
                          'الأعضاء (${_members.length})',
                          Icons.people_outline,
                        ),
                      ),
                      if (_canManageMembers || group.membersCanAdd)
                        IconButton(
                          tooltip: 'إضافة أعضاء',
                          onPressed: _addMembers,
                          icon: const Icon(Icons.person_add_alt_1),
                        ),
                    ],
                  ),
                  TextField(
                    controller: _memberSearch,
                    onChanged: (_) => setState(() {}),
                    decoration: const InputDecoration(
                      hintText: 'ابحث داخل الأعضاء',
                      prefixIcon: Icon(Icons.search),
                      isDense: true,
                    ),
                  ),
                  const SizedBox(height: 6),
                  ...filteredMembers.map(_memberTile),
                  if (_pins.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    _sectionTitle(
                      'الرسائل المثبتة (${_pins.length})',
                      Icons.push_pin_outlined,
                    ),
                    ..._pins.map(
                      (pin) => Card(
                        elevation: 0,
                        child: ListTile(
                          leading: const Icon(Icons.push_pin_outlined),
                          title: Text(
                            pin['content']?.toString() ??
                                _messageTypeLabel(
                                  pin['message_type']?.toString() ?? 'text',
                                ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          trailing: _canPinMessages
                              ? IconButton(
                                  tooltip: 'إلغاء التثبيت',
                                  onPressed: () =>
                                      _pin(pin['id'].toString(), false),
                                  icon: const Icon(Icons.close),
                                )
                              : null,
                        ),
                      ),
                    ),
                  ],
                  if (_sharedMedia.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    _sectionTitle(
                      'الوسائط والملفات المشتركة',
                      Icons.perm_media_outlined,
                    ),
                    ..._sharedMedia.map(
                      (item) => Card(
                        elevation: 0,
                        child: ListTile(
                          leading: Icon(switch (item['message_type']) {
                            'image' => Icons.image_outlined,
                            'video' => Icons.videocam_outlined,
                            'audio' => Icons.mic_none,
                            'location' => Icons.location_on_outlined,
                            _ => Icons.insert_drive_file_outlined,
                          }),
                          title: Text(
                            item['content']?.toString() ??
                                _messageTypeLabel(
                                  item['message_type']?.toString() ?? 'file',
                                ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${_messageTypeLabel(item['message_type']?.toString() ?? 'file')} · ${item['created_at']?.toString().split('T').first ?? ''}',
                          ),
                          onTap: () => _openSharedMedia(item),
                        ),
                      ),
                    ),
                  ],
                  if (_isOwner) ...[
                    const SizedBox(height: 12),
                    _sectionTitle('إعدادات المجموعة', Icons.tune),
                    Card(
                      elevation: 0,
                      child: Column(
                        children: [
                          _switch(
                            'السماح للأعضاء بإرسال الرسائل',
                            'members_can_message',
                            group.membersCanMessage,
                          ),
                          _switch(
                            'السماح للأعضاء بإضافة أشخاص',
                            'members_can_add',
                            group.membersCanAdd,
                          ),
                          _switch(
                            'السماح للأعضاء بتعديل المعلومات',
                            'members_can_edit_info',
                            group.membersCanEditInfo,
                          ),
                          _switch(
                            'السماح للمشرفين بإدارة الأعضاء',
                            'admins_can_manage_members',
                            group.adminsCanManageMembers,
                          ),
                          _switch(
                            'السماح للمشرفين بتثبيت الرسائل',
                            'admins_can_pin_messages',
                            group.adminsCanPinMessages,
                          ),
                          _switch(
                            'السماح للمشرفين بحذف رسائل الآخرين',
                            'admins_can_delete_messages',
                            group.adminsCanDeleteMessages,
                          ),
                          _switch(
                            'السماح بالصور والملفات',
                            'files_allowed',
                            group.filesAllowed,
                          ),
                          _switch(
                            'السماح بالرسائل الصوتية',
                            'voice_allowed',
                            group.voiceAllowed,
                          ),
                          _switch(
                            'السماح بالمكالمات الجماعية',
                            'calls_allowed',
                            group.callsAllowed,
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  _sectionTitle('سجل نشاط المجموعة', Icons.history),
                  if (_activity.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'لا يوجد نشاط مسجل بعد.',
                        style: TextStyle(color: Color(0xFF71827D)),
                      ),
                    ),
                  ..._activity.map(
                    (entry) => ListTile(
                      dense: true,
                      leading: const Icon(
                        Icons.circle,
                        size: 8,
                        color: Color(0xFF087F72),
                      ),
                      title: Text(_activityText(entry)),
                      subtitle: entry.createdAt == null
                          ? null
                          : Text(
                              '${entry.createdAt!.toLocal()}'.split('.').first,
                              style: const TextStyle(fontSize: 11),
                            ),
                    ),
                  ),
                  if (_working)
                    const Padding(
                      padding: EdgeInsets.all(12),
                      child: LinearProgressIndicator(),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _memberTile(GroupMember member) {
    final own = member.userId == _myId;
    final roleLabel = switch (member.role) {
      'owner' => 'المالك',
      'admin' => 'مشرف',
      _ => 'عضو',
    };
    final canManage =
        _canManageMembers &&
        !own &&
        member.role != 'owner' &&
        (_isOwner || member.role == 'member');
    return ValueListenableBuilder<Map<String, UserPresenceStatus>>(
      valueListenable: userPresenceStatuses,
      builder: (context, statuses, _) {
        final status = statuses[member.userId];
        return ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Stack(
            clipBehavior: Clip.none,
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFFE4F3EF),
                backgroundImage: member.avatarPath == null
                    ? null
                    : NetworkImage(
                        _db.storage
                            .from('wasla-avatars')
                            .getPublicUrl(member.avatarPath!),
                      ),
                child: member.avatarPath == null
                    ? Text(
                        member.displayLabel.isEmpty
                            ? '?'
                            : member.displayLabel.substring(0, 1),
                      )
                    : null,
              ),
              if (status != null)
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: PresenceStatusDot(
                    status: status,
                    userId: member.userId,
                    size: 13,
                  ),
                ),
            ],
          ),
          title: Row(
            children: [
              Expanded(
                child: AdminIdentityText(
                  userId: member.userId,
                  label: member.displayLabel,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              if (status != null) ...[
                const SizedBox(width: 6),
                PresenceStatusLabel(
                  status: status,
                  userId: member.userId,
                  fontSize: 10,
                  dotSize: 7,
                ),
              ],
            ],
          ),
          subtitle: Text('@${member.username} · $roleLabel'),
          trailing: own
              ? null
              : PopupMenuButton<String>(
                  onSelected: (action) {
                    if (action == 'report') {
                      _reportMember(member);
                    } else {
                      _memberAction(member, action);
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(
                      value: 'report',
                      child: Text('الإبلاغ عن العضو'),
                    ),
                    if (canManage && _isOwner && member.role == 'member')
                      const PopupMenuItem(
                        value: 'promote',
                        child: Text('تعيين مشرف'),
                      ),
                    if (canManage && _isOwner && member.role == 'admin')
                      const PopupMenuItem(
                        value: 'demote',
                        child: Text('إلغاء الإشراف'),
                      ),
                    if (canManage && _isOwner)
                      const PopupMenuItem(
                        value: 'transfer',
                        child: Text('نقل الملكية'),
                      ),
                    if (canManage) ...[
                      const PopupMenuItem(
                        value: 'remove',
                        child: Text('إزالة من المجموعة'),
                      ),
                      const PopupMenuItem(
                        value: 'ban',
                        child: Text('حظر من المجموعة'),
                      ),
                    ],
                  ],
                ),
        );
      },
    );
  }

  Widget _switch(String title, String key, bool value) =>
      SwitchListTile.adaptive(
        title: Text(title, style: const TextStyle(fontSize: 14)),
        value: value,
        onChanged: _working ? null : (next) => _settings(key: key, value: next),
      );

  Widget _sectionTitle(String title, IconData icon) => Padding(
    padding: const EdgeInsets.only(bottom: 8, top: 4),
    child: Row(
      children: [
        Icon(icon, color: const Color(0xFF087F72), size: 20),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    ),
  );

  String _messageTypeLabel(String type) => switch (type) {
    'image' => 'صورة',
    'audio' => 'رسالة صوتية',
    'video' => 'فيديو',
    'file' => 'ملف',
    'location' => 'موقع',
    _ => 'رسالة',
  };

  Future<void> _openSharedMedia(Map<String, dynamic> item) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final type = item['message_type']?.toString() ?? '';
      final content = item['content']?.toString() ?? '';
      final Uri uri;
      if (type == 'location') {
        uri = Uri.https('www.google.com', '/maps/search/', {
          'api': '1',
          'query': content,
        });
      } else {
        final path = item['media_path']?.toString();
        if (path == null || path.isEmpty) return;
        final signedUrl = await _db.storage
            .from('wasla-media')
            .createSignedUrl(path, 3600);
        uri = Uri.parse(signedUrl);
      }
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw StateError('No application can open the shared item');
      }
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر فتح الوسائط أو الملف.')),
        );
      }
    }
  }
}

class _GroupNotice extends StatelessWidget {
  const _GroupNotice({required this.text, required this.error});
  final String text;
  final bool error;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(vertical: 8),
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: error ? const Color(0xFFFFEEEE) : const Color(0xFFE5F6EF),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text(
      text,
      style: TextStyle(
        color: error ? Colors.red.shade800 : const Color(0xFF17664D),
      ),
    ),
  );
}

class GroupReportsScreen extends StatefulWidget {
  const GroupReportsScreen({required this.conversationId, super.key});
  final String conversationId;

  @override
  State<GroupReportsScreen> createState() => _GroupReportsScreenState();
}

class _GroupReportsScreenState extends State<GroupReportsScreen> {
  List<Map<String, dynamic>> _reports = [];
  bool _loading = true;
  bool _working = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _db.rpc(
        'list_public_content_reports',
        params: {'p_conversation_id': widget.conversationId},
      );
      if (mounted) {
        setState(() {
          _reports = (rows as List<dynamic>)
              .map((row) => Map<String, dynamic>.from(row as Map))
              .toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'تعذر تحميل البلاغات. تأكد من أنك مالك أو مشرف المجموعة.';
        });
      }
    }
  }

  Future<bool> _confirm(String title, String detail, String action) async =>
      await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: Text(detail),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(action),
            ),
          ],
        ),
      ) ??
      false;

  Future<void> _resolve(Map<String, dynamic> report, String status) async {
    if (_working) return;
    setState(() => _working = true);
    try {
      await _db.rpc(
        'resolve_public_content_report',
        params: {
          'p_report_id': report['report_id'].toString(),
          'p_status': status,
        },
      );
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث حالة البلاغ.')),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _banAndResolve(Map<String, dynamic> report) async {
    final target = report['target_user_id']?.toString();
    if (target == null || target.isEmpty) return;
    final targetName = report['target_user_name']?.toString() ?? 'هذا العضو';
    if (!await _confirm(
      'حظر العضو من المجموعة',
      'سيُزال $targetName من المجموعة ولن يتمكن من الانضمام إليها مجددًا.',
      'حظر العضو',
    )) {
      return;
    }
    if (_working) return;
    setState(() => _working = true);
    try {
      await _db.rpc(
        'ban_group_member',
        params: {
          'p_conversation_id': widget.conversationId,
          'p_user_id': target,
        },
      );
      await _db.rpc(
        'resolve_public_content_report',
        params: {
          'p_report_id': report['report_id'].toString(),
          'p_status': 'actioned',
        },
      );
      await _load();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر حظر العضو. تحقق من دورك ومن عضويته الحالية.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  String _reason(String value) => switch (value) {
    'spam' => 'رسائل مزعجة أو احتيال',
    'harassment' => 'مضايقة أو إساءة',
    'inappropriate' => 'محتوى غير مناسب',
    'impersonation' => 'انتحال شخصية',
    _ => 'سبب آخر',
  };

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('بلاغات المحتوى')),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
        ? Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_error!, textAlign: TextAlign.center),
                TextButton(
                  onPressed: _load,
                  child: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          )
        : RefreshIndicator(
            onRefresh: _load,
            child: _reports.isEmpty
                ? ListView(
                    children: const [
                      SizedBox(height: 170),
                      Icon(Icons.verified_user_outlined, size: 44),
                      SizedBox(height: 12),
                      Center(child: Text('لا توجد بلاغات حتى الآن.')),
                    ],
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(14),
                    itemCount: _reports.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final report = _reports[index];
                      final isUser = report['report_type'] == 'user';
                      final open = report['status'] == 'open';
                      final target = report['target_user_name']?.toString();
                      final created = DateTime.tryParse(
                        report['created_at']?.toString() ?? '',
                      );
                      return Card(
                        elevation: 0,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    isUser
                                        ? Icons.person_outline
                                        : Icons.groups_outlined,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      isUser
                                          ? 'بلاغ عن ${target ?? 'عضو'}'
                                          : 'بلاغ عن المجموعة أو الغرفة',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                  Chip(
                                    label: Text(
                                      open
                                          ? 'مفتوح'
                                          : report['status'] == 'actioned'
                                          ? 'تم الإجراء'
                                          : 'مغلق',
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'السبب: ${_reason(report['reason']?.toString() ?? '')}',
                              ),
                              Text(
                                'مقدّم البلاغ: ${report['reporter_name'] ?? 'مستخدم'}',
                              ),
                              if ((report['details']?.toString() ?? '')
                                  .trim()
                                  .isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(top: 6),
                                  child: Text(report['details'].toString()),
                                ),
                              if (created != null)
                                Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Text(
                                    '${created.toLocal()}'.split('.').first,
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall,
                                  ),
                                ),
                              if (open) ...[
                                const Divider(height: 20),
                                Wrap(
                                  spacing: 8,
                                  children: [
                                    if (isUser && target != null)
                                      OutlinedButton.icon(
                                        onPressed: _working
                                            ? null
                                            : () => _banAndResolve(report),
                                        icon: const Icon(Icons.block_outlined),
                                        label: const Text('حظر العضو'),
                                      ),
                                    TextButton(
                                      onPressed: _working
                                          ? null
                                          : () => _resolve(report, 'dismissed'),
                                      child: const Text('إغلاق دون إجراء'),
                                    ),
                                    if (!isUser)
                                      FilledButton.tonal(
                                        onPressed: _working
                                            ? null
                                            : () =>
                                                  _resolve(report, 'actioned'),
                                        child: const Text('تمت المراجعة'),
                                      ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
  );
}
