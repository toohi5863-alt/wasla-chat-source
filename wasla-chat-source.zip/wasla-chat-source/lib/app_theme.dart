import 'package:flutter/material.dart';

import 'app_settings.dart';

ThemeData buildWaslaTheme({
  required AppThemeOption option,
  required Brightness brightness,
  required bool highContrast,
  required bool compactLayout,
}) {
  final dark = brightness == Brightness.dark;
  final seed = option.color;
  final surface = dark
      ? Color.lerp(const Color(0xFF17221F), seed, .075)!
      : const Color(0xFFFCFDFD);
  final background = dark
      ? Color.lerp(const Color(0xFF101916), seed, .06)!
      : Color.lerp(const Color(0xFFF3F7F5), seed, .025)!;
  final outline = highContrast
      ? dark
            ? const Color(0xFF9CB0A6)
            : const Color(0xFF52645B)
      : dark
      ? Color.lerp(const Color(0xFF293A35), seed, .12)!
      : Color.lerp(const Color(0xFFE4ECE8), seed, .16)!;
  final focus = dark ? Color.lerp(seed, Colors.white, .2)! : seed;
  final scheme = ColorScheme.fromSeed(
    seedColor: seed,
    brightness: brightness,
    primary: seed,
    surface: surface,
    contrastLevel: highContrast ? 1.0 : 0.0,
  );

  return ThemeData(
    useMaterial3: true,
    fontFamily: 'IBMPlexSansArabic',
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    visualDensity: compactLayout
        ? VisualDensity.compact
        : VisualDensity.standard,
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: outline),
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: scheme.onSurface,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: outline),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: outline),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide(color: focus, width: 1.5),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
  );
}
