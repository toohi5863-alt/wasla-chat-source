class FriendQrCode {
  const FriendQrCode._({this.userId, this.username});

  final String? userId;
  final String? username;

  bool get identifiesUserId => userId != null;

  static final RegExp _userIdPattern = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );
  static final RegExp _usernamePattern = RegExp(r'^@[A-Za-z0-9_]{1,32}$');

  /// Accepts stable Wasla user links and legacy QR codes containing @username.
  /// Any other URL or payload is rejected instead of being treated as a search.
  static FriendQrCode? parse(String? rawValue) {
    final value = rawValue?.trim();
    if (value == null || value.isEmpty || value.length > 256) return null;

    if (_usernamePattern.hasMatch(value)) {
      return FriendQrCode._(username: value.substring(1));
    }

    final uri = Uri.tryParse(value);
    if (uri == null ||
        uri.scheme != 'wasla' ||
        uri.host != 'user' ||
        uri.hasQuery ||
        uri.hasFragment ||
        uri.userInfo.isNotEmpty ||
        uri.pathSegments.length != 1) {
      return null;
    }

    final id = uri.pathSegments.single;
    if (!_userIdPattern.hasMatch(id)) return null;
    return FriendQrCode._(userId: id.toLowerCase());
  }
}
