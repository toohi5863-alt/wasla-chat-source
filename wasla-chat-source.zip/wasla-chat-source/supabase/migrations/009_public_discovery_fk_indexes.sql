-- Cover foreign keys added for public discovery, moderation and room presence.
create index if not exists public_room_presence_user_id_idx
  on public.public_room_presence (user_id);
create index if not exists public_content_reports_reporter_id_idx
  on public.public_content_reports (reporter_id);
create index if not exists public_content_reports_target_user_id_idx
  on public.public_content_reports (target_user_id);
create index if not exists public_content_reports_reviewed_by_idx
  on public.public_content_reports (reviewed_by);
