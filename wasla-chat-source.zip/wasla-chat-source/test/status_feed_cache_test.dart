import 'dart:io';

import 'package:chat/status_feed_cache.dart';
import 'package:chat/status_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late Directory temporaryDirectory;
  late DateTime now;
  late StatusFeedCache cache;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp(
      'wasla-status-feed-test-',
    );
    now = DateTime.utc(2026, 10, 9, 10);
    cache = StatusFeedCache(
      directoryProvider: () async => temporaryDirectory,
      clock: () => now,
    );
  });

  tearDown(() async {
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  StatusItem makeStatus(String id, DateTime expiry) => StatusItem(
    id: id,
    userId: 'author',
    username: 'author',
    displayName: 'صاحب الحالة',
    contentType: 'image',
    body: null,
    mediaPath: 'author/$id.jpg',
    backgroundColor: 0xFF087F72,
    privacy: 'friends',
    createdAt: now,
    expiresAt: expiry,
    isMine: false,
    isViewed: true,
    viewsCount: 0,
  );

  test('restores active statuses offline and isolates account data', () async {
    final expiry = now.add(const Duration(hours: 24));
    await cache.save('account-a', [makeStatus('active', expiry)]);

    final restored = await cache.load('account-a');
    final otherAccount = await cache.load('account-b');

    expect(restored, hasLength(1));
    expect(restored!.single.id, 'active');
    expect(restored.single.mediaPath, 'author/active.jpg');
    expect(otherAccount, isNull);
  });

  test(
    'filters and rewrites expired statuses when restoring offline',
    () async {
      final expiry = now.add(const Duration(seconds: 1));
      await cache.save('account-a', [makeStatus('expires-soon', expiry)]);

      now = expiry.add(const Duration(milliseconds: 1));
      final restored = await cache.load('account-a');

      expect(restored, isEmpty);
      expect(await cache.load('account-a'), isEmpty);
    },
  );

  test('does not persist an already expired status', () async {
    final expiry = now.subtract(const Duration(seconds: 1));
    await cache.save('account-a', [makeStatus('old', expiry)]);

    expect(await cache.load('account-a'), isEmpty);
  });
}
