package app.wasla.chat

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.IOException

class MainActivity : FlutterActivity() {
    private val mediaChannelName = "app.wasla.chat/media_saver"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, mediaChannelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getAndroidSdk" -> result.success(Build.VERSION.SDK_INT)
                    "saveFile" -> {
                        try {
                            result.success(saveFile(call))
                        } catch (error: SecurityException) {
                            result.error("permission_denied", error.message, null)
                        } catch (error: Exception) {
                            result.error("save_failed", error.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun saveFile(call: MethodCall): Map<String, String> {
        val sourcePath = call.argument<String>("filePath")
            ?: throw IOException("Missing source file")
        val requestedName = call.argument<String>("fileName")
            ?: throw IOException("Missing file name")
        val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
        val source = File(sourcePath)
        if (!source.isFile || source.length() == 0L) {
            throw IOException("Source file is missing or empty")
        }
        val fileName = safeFileName(requestedName)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveWithMediaStore(source, fileName, mimeType)
        } else {
            saveWithLegacyStorage(source, fileName, mimeType)
        }
    }

    private fun saveWithMediaStore(
        source: File,
        requestedName: String,
        mimeType: String,
    ): Map<String, String> {
        val (collection, relativePath) = when {
            mimeType.startsWith("image/") -> Pair(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_PICTURES}/Wasla",
            )
            mimeType.startsWith("video/") -> Pair(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_MOVIES}/Wasla",
            )
            else -> Pair(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                "${Environment.DIRECTORY_DOWNLOADS}/Wasla",
            )
        }
        val displayName = nextAvailableMediaStoreName(
            collection,
            relativePath,
            requestedName,
        )
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(collection, values)
            ?: throw IOException("Could not create destination")
        try {
            val output = contentResolver.openOutputStream(uri)
                ?: throw IOException("Could not open destination")
            output.use { stream -> source.inputStream().use { it.copyTo(stream) } }
            val completed = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            contentResolver.update(uri, completed, null, null)
            return mapOf("location" to relativePath, "displayName" to displayName)
        } catch (error: Exception) {
            contentResolver.delete(uri, null, null)
            throw error
        }
    }

    private fun nextAvailableMediaStoreName(
        collection: Uri,
        relativePath: String,
        requestedName: String,
    ): String {
        val dot = requestedName.lastIndexOf('.')
        val base = if (dot > 0) requestedName.substring(0, dot) else requestedName
        val extension = if (dot > 0) requestedName.substring(dot) else ""
        var candidate = requestedName
        var suffix = 1
        while (mediaStoreNameExists(collection, relativePath, candidate)) {
            candidate = "$base ($suffix)$extension"
            suffix += 1
        }
        return candidate
    }

    private fun mediaStoreNameExists(
        collection: Uri,
        relativePath: String,
        displayName: String,
    ): Boolean {
        val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ? AND ${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
        return contentResolver.query(
            collection,
            projection,
            selection,
            arrayOf(displayName, relativePath),
            null,
        )?.use { cursor -> cursor.moveToFirst() } ?: false
    }

    @Suppress("DEPRECATION")
    private fun saveWithLegacyStorage(
        source: File,
        requestedName: String,
        mimeType: String,
    ): Map<String, String> {
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            throw SecurityException("Storage permission is required")
        }
        val directoryName = when {
            mimeType.startsWith("image/") -> Environment.DIRECTORY_PICTURES
            mimeType.startsWith("video/") -> Environment.DIRECTORY_MOVIES
            else -> Environment.DIRECTORY_DOWNLOADS
        }
        val folder = File(
            Environment.getExternalStoragePublicDirectory(directoryName),
            "Wasla",
        )
        if (!folder.exists() && !folder.mkdirs()) {
            throw IOException("Could not create destination folder")
        }
        val destination = nextAvailableLegacyFile(folder, requestedName)
        source.copyTo(destination, overwrite = false)
        MediaScannerConnection.scanFile(
            this,
            arrayOf(destination.absolutePath),
            arrayOf(mimeType),
            null,
        )
        return mapOf(
            "location" to "${directoryName}/Wasla",
            "displayName" to destination.name,
        )
    }

    private fun nextAvailableLegacyFile(folder: File, requestedName: String): File {
        val dot = requestedName.lastIndexOf('.')
        val base = if (dot > 0) requestedName.substring(0, dot) else requestedName
        val extension = if (dot > 0) requestedName.substring(dot) else ""
        var candidate = File(folder, requestedName)
        var suffix = 1
        while (candidate.exists()) {
            candidate = File(folder, "$base ($suffix)$extension")
            suffix += 1
        }
        return candidate
    }

    private fun safeFileName(value: String): String {
        val leaf = value.replace('\\', '/').substringAfterLast('/').trim()
        val cleaned = leaf.replace(Regex("[\\u0000-\\u001F\\u007F]"), "")
        return if (cleaned.isEmpty() || cleaned == "." || cleaned == "..") {
            "wasla_media.bin"
        } else {
            cleaned
        }
    }
}
