import 'package:flutter_test/flutter_test.dart';

import 'package:chat/presence.dart';

void main() {
  group('formatLastSeenLabel', () {
    final now = DateTime.utc(2026, 10, 8, 2, 30);

    test('handles unavailable, recent, and future timestamps', () {
      expect(formatLastSeenLabel(null, now: now), 'آخر ظهور غير متاح');
      expect(
        formatLastSeenLabel(
          now.subtract(const Duration(seconds: 20)),
          now: now,
        ),
        'آخر ظهور منذ لحظات',
      );
      expect(
        formatLastSeenLabel(now.add(const Duration(seconds: 2)), now: now),
        'آخر ظهور الآن',
      );
    });

    test('uses Arabic minute and hour forms', () {
      expect(
        formatLastSeenLabel(now.subtract(const Duration(minutes: 1)), now: now),
        'آخر ظهور منذ دقيقة',
      );
      expect(
        formatLastSeenLabel(now.subtract(const Duration(minutes: 5)), now: now),
        'آخر ظهور منذ ٥ دقائق',
      );
      expect(
        formatLastSeenLabel(now.subtract(const Duration(hours: 2)), now: now),
        'آخر ظهور منذ ساعتين',
      );
    });

    test('uses day and calendar-date forms for older timestamps', () {
      expect(
        formatLastSeenLabel(now.subtract(const Duration(hours: 30)), now: now),
        'آخر ظهور أمس',
      );
      expect(
        formatLastSeenLabel(now.subtract(const Duration(days: 3)), now: now),
        'آخر ظهور منذ ٣ أيام',
      );
      expect(
        formatLastSeenLabel(now.subtract(const Duration(days: 12)), now: now),
        startsWith('آخر ظهور بتاريخ '),
      );
    });
  });

  group('connectionStatusLabel', () {
    final now = DateTime.utc(2026, 10, 8, 2, 30);

    test('shows live connection even when the saved last seen is old', () {
      expect(
        connectionStatusLabel(
          online: true,
          lastSeenAt: now.subtract(const Duration(days: 3)),
          now: now,
        ),
        'متصل الآن',
      );
    });

    test('shows last seen when offline and while connection is loading', () {
      expect(
        connectionStatusLabel(
          online: false,
          lastSeenAt: now.subtract(const Duration(hours: 2)),
          now: now,
        ),
        'آخر ظهور منذ ساعتين',
      );
      expect(
        connectionStatusLabel(
          online: false,
          lastSeenAt: null,
          lastSeenLoaded: false,
          now: now,
        ),
        'جارٍ التحقق من الاتصال',
      );
    });
  });
}
