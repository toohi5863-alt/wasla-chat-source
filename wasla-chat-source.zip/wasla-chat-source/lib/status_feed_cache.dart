import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'status_models.dart';

/// Keeps the last authorized status feed in private app storage so viewed
/// statuses can be reopened when the device is offline. Expired entries are
/// removed whenever the feed is read or refreshed.
class StatusFeedCache {
  StatusFeedCache({
    Future<Directory> Function()? directoryProvider,
    DateTime Function()? clock,
  }) : _directoryProvider = directoryProvider ?? getApplicationSupportDirectory,
       _clock = clock ?? DateTime.now;

  final Future<Directory> Function() _directoryProvider;
  final DateTime Function() _clock;

  Future<void> save(String accountId, Iterable<StatusItem> statuses) async {
    final now = _clock();
    final active = statuses.where((status) => status.expiresAt.isAfter(now));
    final file = await _fileFor(accountId);
    await file.parent.create(recursive: true);
    final temporary = File('${file.path}.part');
    final jsonStatuses = active.map(_toMap).toList(growable: false);
    try {
      await temporary.writeAsString(jsonEncode(jsonStatuses), flush: true);
      if (await file.exists()) await file.delete();
      await temporary.rename(file.path);
    } finally {
      if (await temporary.exists()) await temporary.delete();
    }
  }

  /// Returns null only when no feed has ever been saved; an empty list means
  /// there is a saved feed, but every entry in it has expired.
  Future<List<StatusItem>?> load(String accountId) async {
    final file = await _fileFor(accountId);
    if (!await file.exists()) return null;
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! List) return null;
      final statuses = decoded
          .whereType<Map>()
          .map((row) => StatusItem.fromMap(Map<String, dynamic>.from(row)))
          .where((status) => status.expiresAt.isAfter(_clock()))
          .toList(growable: false);
      await save(accountId, statuses);
      return statuses;
    } on FileSystemException {
      return null;
    } on FormatException {
      return null;
    } on TypeError {
      return null;
    }
  }

  Future<File> _fileFor(String accountId) async {
    final root = await _directoryProvider();
    final accountKey = base64Url
        .encode(utf8.encode(accountId))
        .replaceAll('=', '');
    return File(
      '${root.path}${Platform.pathSeparator}wasla_status_feed_$accountKey.json',
    );
  }

  Map<String, Object?> _toMap(StatusItem status) => <String, Object?>{
    'id': status.id,
    'user_id': status.userId,
    'username': status.username,
    'display_name': status.displayName,
    'avatar_path': status.avatarPath,
    'content_type': status.contentType,
    'body': status.body,
    'media_path': status.mediaPath,
    'background_color': status.backgroundColor,
    'privacy': status.privacy,
    'created_at': status.createdAt.toUtc().toIso8601String(),
    'expires_at': status.expiresAt.toUtc().toIso8601String(),
    'is_mine': status.isMine,
    'is_viewed': status.isViewed,
    'views_count': status.viewsCount,
  };
}
