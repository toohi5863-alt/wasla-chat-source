import 'dart:async';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'chat_models.dart';
import 'public_discovery_models.dart';

SupabaseClient get _db => Supabase.instance.client;

class PublicDiscoveryScreen extends StatefulWidget {
  const PublicDiscoveryScreen({required this.onOpenChat, super.key});
  final Future<void> Function(ChatTarget target) onOpenChat;

  @override
  State<PublicDiscoveryScreen> createState() => _PublicDiscoveryScreenState();
}

class _PublicDiscoveryScreenState extends State<PublicDiscoveryScreen> {
  final _search = TextEditingController();
  Timer? _searchDebounce;
  Timer? _refreshTimer;
  List<PublicListing> _listings = [];
  String _listingType = 'group';
  String _category = 'all';
  String _sort = 'active';
  bool _activeOnly = false;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _refreshTimer?.cancel();
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await _db.rpc(
        'discover_public_listings',
        params: {
          'p_listing_type': _listingType,
          'p_search': _search.text.trim(),
          'p_category': _category,
          'p_sort': _sort,
          'p_active_only': _activeOnly,
          'p_limit': 50,
          'p_offset': 0,
        },
      );
      final listings = (data as List<dynamic>)
          .map(
            (row) =>
                PublicListing.fromMap(Map<String, dynamic>.from(row as Map)),
          )
          .toList();
      if (mounted) setState(() => _listings = listings);
    } catch (_) {
      if (mounted) {
        setState(
          () =>
              _error = 'تعذر تحميل الاستكشاف. تحقق من اتصالك ثم أعد المحاولة.',
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _searchChanged(String _) {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 350), _load);
  }

  Future<void> _preview(PublicListing listing) async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(
        builder: (_) => PublicListingDetailsScreen(listing: listing),
      ),
    );
    if (!mounted || target == null) return;
    await widget.onOpenChat(target);
    if (mounted) await _load();
  }

  Future<void> _share(PublicListing listing) async {
    await SharePlus.instance.share(
      ShareParams(
        text:
            'اكتشف ${listing.isRoom ? 'غرفة الدردشة' : 'المجموعة'} ${listing.name}\n${listing.publicLink}',
      ),
    );
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: _load,
    child: ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 116),
      children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(
              value: 'group',
              label: Text('المجموعات العامة'),
              icon: Icon(Icons.groups_outlined),
            ),
            ButtonSegment(
              value: 'room',
              label: Text('الدردشات العامة'),
              icon: Icon(Icons.forum_outlined),
            ),
          ],
          selected: {_listingType},
          onSelectionChanged: (value) {
            setState(() => _listingType = value.first);
            _load();
          },
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _search,
          textInputAction: TextInputAction.search,
          onChanged: _searchChanged,
          onSubmitted: (_) => _load(),
          decoration: InputDecoration(
            hintText: _listingType == 'room'
                ? 'ابحث عن دردشة أو موضوع'
                : 'ابحث عن مجموعة بالاسم أو الكلمات المفتاحية',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: _search.text.isEmpty
                ? null
                : IconButton(
                    tooltip: 'مسح البحث',
                    onPressed: () {
                      _search.clear();
                      _load();
                    },
                    icon: const Icon(Icons.close),
                  ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: PublicCategory.values.length,
            separatorBuilder: (_, _) => const SizedBox(width: 7),
            itemBuilder: (context, index) {
              final category = PublicCategory.values[index];
              return ChoiceChip(
                label: Text(category.label),
                selected: category.value == _category,
                onSelected: (_) {
                  setState(() => _category = category.value);
                  _load();
                },
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 6,
          children: [
            ChoiceChip(
              label: const Text('الأكثر نشاطًا'),
              selected: _sort == 'active',
              onSelected: (_) {
                setState(() => _sort = 'active');
                _load();
              },
            ),
            ChoiceChip(
              label: const Text('الأحدث'),
              selected: _sort == 'newest',
              onSelected: (_) {
                setState(() => _sort = 'newest');
                _load();
              },
            ),
            if (_listingType == 'room')
              FilterChip(
                label: const Text('النشطة الآن'),
                selected: _activeOnly,
                onSelected: (value) {
                  setState(() => _activeOnly = value);
                  _load();
                },
              ),
          ],
        ),
        const SizedBox(height: 6),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        if (_error != null)
          _DiscoveryMessage(
            text: _error!,
            action: TextButton(
              onPressed: _load,
              child: const Text('إعادة المحاولة'),
            ),
          ),
        if (!_loading && _error == null && _listings.isEmpty)
          _DiscoveryMessage(
            text: _search.text.isEmpty
                ? 'لا توجد ${_listingType == 'room' ? 'غرف عامة' : 'مجموعات عامة'} بعد. يمكنك إنشاء واحدة واختيار إظهارها في الاستكشاف.'
                : 'لا توجد نتائج مطابقة. جرّب كلمات أو تصنيفًا آخر.',
          ),
        ..._listings.map(
          (listing) => _ListingCard(
            listing: listing,
            onTap: () => _preview(listing),
            onShare: () => _share(listing),
          ),
        ),
      ],
    ),
  );
}

class PublicListingDetailsScreen extends StatefulWidget {
  const PublicListingDetailsScreen({required this.listing, super.key});
  final PublicListing listing;

  @override
  State<PublicListingDetailsScreen> createState() =>
      _PublicListingDetailsScreenState();
}

class _PublicListingDetailsScreenState
    extends State<PublicListingDetailsScreen> {
  bool _working = false;

  Future<void> _join() async {
    if (_working) return;
    setState(() => _working = true);
    try {
      await _db.rpc(
        'join_public_listing',
        params: {'p_conversation_id': widget.listing.conversationId},
      );
      if (mounted) Navigator.of(context).pop(widget.listing.toChatTarget());
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'تعذر الانضمام. قد تكون الغرفة خاصة أو تم حظرك منها.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _share() async {
    await SharePlus.instance.share(
      ShareParams(
        text:
            'انضم إلى ${widget.listing.isRoom ? 'غرفة الدردشة' : 'المجموعة'} ${widget.listing.name}\n${widget.listing.publicLink}',
      ),
    );
  }

  Future<void> _report() async {
    final reason = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'الإبلاغ عن المحتوى',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text('سيصل البلاغ إلى مشرفي المجموعة أو الغرفة.'),
            ),
            for (final item in const [
              ('spam', 'رسائل مزعجة أو احتيال'),
              ('harassment', 'مضايقة أو إساءة'),
              ('inappropriate', 'محتوى غير مناسب'),
              ('other', 'سبب آخر'),
            ])
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: Text(item.$2),
                onTap: () => Navigator.pop(context, item.$1),
              ),
          ],
        ),
      ),
    );
    if (reason == null) return;
    try {
      await _db.rpc(
        'submit_public_content_report',
        params: {
          'p_conversation_id': widget.listing.conversationId,
          'p_report_type': 'listing',
          'p_target_user_id': null,
          'p_reason': reason,
          'p_details': '',
        },
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('شكرًا، أُرسل البلاغ للمراجعة.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر إرسال البلاغ الآن.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final listing = widget.listing;
    final avatarUrl = listing.avatarPath == null || listing.avatarPath!.isEmpty
        ? null
        : _db.storage
              .from('wasla-group-avatars')
              .getPublicUrl(listing.avatarPath!);
    return Scaffold(
      appBar: AppBar(
        title: const Text('معاينة قبل الانضمام'),
        actions: [
          IconButton(
            tooltip: 'مشاركة الرابط',
            onPressed: _share,
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            tooltip: 'الإبلاغ',
            onPressed: _report,
            icon: const Icon(Icons.flag_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
        children: [
          Center(
            child: CircleAvatar(
              radius: 43,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              backgroundImage: avatarUrl == null
                  ? null
                  : NetworkImage(avatarUrl),
              child: avatarUrl == null
                  ? Icon(
                      listing.isRoom
                          ? Icons.forum_outlined
                          : Icons.groups_outlined,
                      size: 38,
                    )
                  : null,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            listing.name,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Center(child: Chip(label: Text(listing.categoryLabel))),
          if (listing.description.trim().isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              listing.description,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge
                  ?.copyWith(height: 1.55),
            ),
          ],
          const SizedBox(height: 22),
          Card(
            elevation: 0,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.people_outline),
                  title: const Text('الأعضاء'),
                  trailing: Text('${listing.memberCount}'),
                ),
                if (listing.isRoom)
                  ListTile(
                    leading: Icon(
                      Icons.circle,
                      color: listing.isActive ? Colors.green : Colors.grey,
                      size: 14,
                    ),
                    title: const Text('الموجودون الآن'),
                    trailing: Text('${listing.roomOnlineCount}'),
                  ),
                if (listing.activity7d > 0)
                  ListTile(
                    leading: const Icon(Icons.bolt_outlined),
                    title: const Text('الرسائل خلال ٧ أيام'),
                    trailing: Text('${listing.activity7d}'),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _share,
            icon: const Icon(Icons.link),
            label: const Text('مشاركة رابط عام'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _working ? null : _join,
            icon: _working
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Icon(
                    listing.isMember
                        ? Icons.forum_outlined
                        : Icons.group_add_outlined,
                  ),
            label: Text(
              _working
                  ? 'جارٍ الانضمام...'
                  : listing.isMember
                  ? 'فتح الدردشة'
                  : listing.isRoom
                  ? 'دخول مباشر للدردشة'
                  : 'الانضمام للمجموعة',
            ),
          ),
        ],
      ),
    );
  }
}

class _ListingCard extends StatelessWidget {
  const _ListingCard({
    required this.listing,
    required this.onTap,
    required this.onShare,
  });
  final PublicListing listing;
  final VoidCallback onTap;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    final avatarUrl = listing.avatarPath == null || listing.avatarPath!.isEmpty
        ? null
        : _db.storage
              .from('wasla-group-avatars')
              .getPublicUrl(listing.avatarPath!);
    final activeColor = listing.isActive
        ? const Color(0xFF178A63)
        : const Color(0xFF71827D);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(top: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 12, 13, 8),
          child: Column(
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 27,
                    backgroundColor: Theme.of(context)
                        .colorScheme
                        .primaryContainer,
                    backgroundImage: avatarUrl == null
                        ? null
                        : NetworkImage(avatarUrl),
                    child: avatarUrl == null
                        ? Icon(
                            listing.isRoom
                                ? Icons.forum_outlined
                                : Icons.groups_outlined,
                          )
                        : null,
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          listing.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          listing.categoryLabel,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                  if (listing.isRoom)
                    Icon(Icons.circle, size: 10, color: activeColor),
                  IconButton(
                    tooltip: 'مشاركة رابط',
                    onPressed: onShare,
                    icon: const Icon(Icons.share_outlined),
                  ),
                ],
              ),
              if (listing.description.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 9),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(
                      listing.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodyMedium
                          ?.copyWith(height: 1.35),
                    ),
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  _Stat(
                    icon: Icons.people_outline,
                    label: '${listing.memberCount} عضو',
                  ),
                  if (listing.isRoom) ...[
                    const SizedBox(width: 14),
                    _Stat(
                      icon: Icons.circle,
                      label: '${listing.roomOnlineCount} حاضر',
                      color: activeColor,
                    ),
                  ] else if (listing.activity7d > 0) ...[
                    const SizedBox(width: 14),
                    _Stat(
                      icon: Icons.bolt_outlined,
                      label: '${listing.activity7d} نشط هذا الأسبوع',
                    ),
                  ],
                  const Spacer(),
                  TextButton(onPressed: onTap, child: const Text('معاينة')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.icon, required this.label, this.color});
  final IconData icon;
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(
        icon,
        size: 15,
        color: color ?? Theme.of(context).colorScheme.onSurfaceVariant,
      ),
      const SizedBox(width: 4),
      Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: color ?? Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    ],
  );
}

class _DiscoveryMessage extends StatelessWidget {
  const _DiscoveryMessage({required this.text, this.action});
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 18),
    child: Column(
      children: [
        Icon(
          Icons.explore_outlined,
          size: 42,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: 10),
        Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(height: 1.5),
        ),
        ?action,
      ],
    ),
  );
}
