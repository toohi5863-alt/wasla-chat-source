-- Restrict the app-wide presence channel to signed-in Wasla users.
-- No application data is changed by this policy-only migration.
drop policy if exists wasla_presence_read_authenticated on realtime.messages;
create policy wasla_presence_read_authenticated on realtime.messages
  for select to authenticated
  using (realtime.topic() = 'wasla-presence-v1');

drop policy if exists wasla_presence_send_authenticated on realtime.messages;
create policy wasla_presence_send_authenticated on realtime.messages
  for insert to authenticated
  with check (realtime.topic() = 'wasla-presence-v1');
