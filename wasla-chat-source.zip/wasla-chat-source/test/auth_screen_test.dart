import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:chat/main.dart';

void main() {
  testWidgets('keeps email/password login and offers email signup', (
    tester,
  ) async {
    await tester.pumpWidget(const MaterialApp(home: SignInScreen()));

    expect(find.text('البريد الإلكتروني'), findsOneWidget);
    expect(find.text('كلمة المرور'), findsOneWidget);
    expect(find.text('تسجيل الدخول'), findsOneWidget);
    expect(find.textContaining('واتساب'), findsNothing);
    expect(find.text('مستخدم جديد؟ أنشئ حسابًا'), findsOneWidget);

    await tester.tap(find.text('مستخدم جديد؟ أنشئ حسابًا'));
    await tester.pumpAndSettle();

    expect(find.text('الاسم الظاهر'), findsOneWidget);
    expect(find.text('اسم المستخدم'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('إنشاء الحساب'),
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();
    expect(find.text('إنشاء الحساب'), findsOneWidget);
    expect(find.textContaining('واتساب'), findsNothing);
  });
}
