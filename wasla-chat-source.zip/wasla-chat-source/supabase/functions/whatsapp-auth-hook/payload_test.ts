import { buildAuthenticationTemplatePayload } from "./payload.ts";

Deno.test("builds a Meta copy-code authentication template payload", () => {
  const payload = buildAuthenticationTemplatePayload({
    phone: "+967771234567",
    otp: "123456",
    templateName: "wasla_otp",
    language: "ar",
  });

  if (payload.messaging_product !== "whatsapp") {
    throw new Error("Wrong product");
  }
  if (payload.to !== "967771234567") throw new Error("Recipient must omit +");
  if (payload.template.name !== "wasla_otp") throw new Error("Wrong template");
  if (payload.template.language.code !== "ar") {
    throw new Error("Wrong language");
  }
  const body = payload.template.components[0];
  const button = payload.template.components[1];
  const bodyParameters = body.parameters as Array<
    { type: string; text: string }
  >;
  const buttonParameters = button.parameters as Array<
    { type: string; text: string }
  >;
  if (bodyParameters[0]?.text !== "123456") {
    throw new Error("OTP missing from body");
  }
  if (button.sub_type !== "url" || buttonParameters[0]?.text !== "123456") {
    throw new Error("Copy-code OTP button is malformed");
  }
});

Deno.test("rejects an invalid E.164 number", () => {
  let rejected = false;
  try {
    buildAuthenticationTemplatePayload({
      phone: "0771234567",
      otp: "123456",
      templateName: "wasla_otp",
      language: "ar",
    });
  } catch (_) {
    rejected = true;
  }
  if (!rejected) throw new Error("Expected invalid phone to be rejected");
});

Deno.test("rejects a malformed OTP before contacting Meta", () => {
  let rejected = false;
  try {
    buildAuthenticationTemplatePayload({
      phone: "+967771234567",
      otp: "12345",
      templateName: "wasla_otp",
      language: "ar",
    });
  } catch (_) {
    rejected = true;
  }
  if (!rejected) throw new Error("Expected invalid OTP to be rejected");
});
