import 'package:chat/app_sections.dart';
import 'package:chat/app_settings.dart';
import 'package:chat/friendship_models.dart';
import 'package:chat/presence_status.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('friends section lists accepted friends with remove controls', (
    tester,
  ) async {
    var opened = false;
    var removed = false;
    var nearbyOpened = false;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FriendsSection(
            friends: const [
              Friend(
                userId: 'friend-id',
                username: 'sara',
                displayName: 'سارة',
              ),
            ],
            friendsLoading: false,
            friendsError: null,
            onRefreshFriends: () {},
            onOpenFriend: (_) => opened = true,
            onRemoveFriend: (_) => removed = true,
            onSearchUsers: () {},
            onNearbyFriends: () => nearbyOpened = true,
            onFriendRequests: () {},
            pendingFriendRequests: 0,
            onShowQr: () {},
            onInvite: () {},
            onOpenSettings: () {},
          ),
        ),
      ),
    );

    expect(find.text('الأصدقاء (1)'), findsOneWidget);
    expect(find.text('سارة'), findsOneWidget);
    await tester.tap(find.text('سارة'));
    expect(opened, isTrue);
    await tester.tap(find.byTooltip('إلغاء الصداقة'));
    expect(removed, isTrue);
    final nearbyAction = find.text('اكتشف أصدقاء بالقرب منك');
    await tester.ensureVisible(nearbyAction);
    await tester.tap(nearbyAction);
    expect(nearbyOpened, isTrue);
  });

  testWidgets('friends search filters by display name and username', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FriendsSection(
            friends: const [
              Friend(
                userId: 'friend-1',
                username: 'sara_dev',
                displayName: 'سارة',
              ),
              Friend(
                userId: 'friend-2',
                username: 'layla',
                displayName: 'ليلى',
              ),
            ],
            friendsLoading: false,
            friendsError: null,
            onRefreshFriends: () {},
            onOpenFriend: (_) {},
            onRemoveFriend: (_) {},
            onSearchUsers: () {},
            onNearbyFriends: () {},
            onFriendRequests: () {},
            pendingFriendRequests: 0,
            onShowQr: () {},
            onInvite: () {},
            onOpenSettings: () {},
          ),
        ),
      ),
    );

    final searchField = find.byType(TextField);
    await tester.enterText(searchField, 'sara_dev');
    expect(find.text('سارة'), findsOneWidget);
    expect(find.text('ليلى'), findsNothing);

    await tester.enterText(searchField, 'غير_موجود');
    await tester.pump();
    expect(find.text('لم نعثر على صديق بهذا الاسم'), findsOneWidget);
  });

  testWidgets('friends quick actions call their handlers', (tester) async {
    var addTapped = false;
    var requestsTapped = false;
    var qrTapped = false;
    var inviteTapped = false;
    var settingsTapped = false;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: FriendsSection(
            friends: const [],
            friendsLoading: false,
            friendsError: null,
            onRefreshFriends: () {},
            onOpenFriend: (_) {},
            onRemoveFriend: (_) {},
            onSearchUsers: () => addTapped = true,
            onNearbyFriends: () {},
            onFriendRequests: () => requestsTapped = true,
            pendingFriendRequests: 3,
            onShowQr: () => qrTapped = true,
            onInvite: () => inviteTapped = true,
            onOpenSettings: () => settingsTapped = true,
          ),
        ),
      ),
    );

    await tester.tap(find.text('إضافة صديق'));
    await tester.tap(find.text('الطلبات'));
    await tester.tap(find.text('رمز QR'));
    await tester.tap(find.text('دعوة'));
    await tester.tap(find.byTooltip('الإعدادات'));

    expect(addTapped, isTrue);
    expect(requestsTapped, isTrue);
    expect(qrTapped, isTrue);
    expect(inviteTapped, isTrue);
    expect(settingsTapped, isTrue);
    expect(find.text('3'), findsOneWidget);
  });

  testWidgets('settings can change theme and expose chat archive export', (
    tester,
  ) async {
    ThemeMode? selectedTheme;
    AppTextSize? selectedTextSize;
    MessageBubbleStyle? selectedBubbleStyle;
    bool? selectedReduceMotion;
    bool? selectedHighContrast;
    bool? selectedCompactLayout;
    bool? selectedChatStatusHighlights;
    var exportTapped = false;
    var saveOptionsTapped = false;
    var presenceTapped = false;
    var selectedThemeId = 'wasla';
    List<AppThemeOption> customThemes = const [];
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SettingsSection(
            onProfile: () {},
            onInfo: (_, _) {},
            onNotifications: () {},
            onSaveMediaOptions: () => saveOptionsTapped = true,
            onPresenceStatus: () => presenceTapped = true,
            presenceStatus: UserPresenceStatus.available,
            onSignOut: () {},
            themeMode: ThemeMode.system,
            onThemeModeChanged: (value) => selectedTheme = value,
            themeId: selectedThemeId,
            customThemes: customThemes,
            onThemeIdChanged: (value) => selectedThemeId = value,
            onCustomThemeCreated: (value) {
              customThemes = [...customThemes, value];
              selectedThemeId = value.id;
            },
            onCustomThemesChanged: (value) => customThemes = value,
            textSize: AppTextSize.standard,
            onTextSizeChanged: (value) => selectedTextSize = value,
            bubbleStyle: MessageBubbleStyle.classic,
            onBubbleStyleChanged: (value) => selectedBubbleStyle = value,
            reduceMotion: false,
            onReduceMotionChanged: (value) => selectedReduceMotion = value,
            highContrast: false,
            onHighContrastChanged: (value) => selectedHighContrast = value,
            compactLayout: false,
            onCompactLayoutChanged: (value) => selectedCompactLayout = value,
            showChatStatusHighlights: true,
            onShowChatStatusHighlightsChanged: (value) =>
                selectedChatStatusHighlights = value,
            onExportData: () => exportTapped = true,
          ),
        ),
      ),
    );

    expect(find.text('حالة التواجد'), findsOneWidget);
    await tester.tap(find.text('المظهر والتخصيص'));
    await tester.pumpAndSettle();
    final chatStatusesLabel = find.text('إظهار الحالات أعلى الدردشات');
    await tester.ensureVisible(chatStatusesLabel);
    await tester.tap(chatStatusesLabel);
    expect(selectedChatStatusHighlights, isFalse);
    final presenceLabel = find.text('حالة التواجد');
    await tester.ensureVisible(presenceLabel);
    await tester.tap(presenceLabel);
    expect(presenceTapped, isTrue);

    await tester.tap(find.text('المظهر'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('داكن'));
    await tester.pumpAndSettle();
    expect(selectedTheme, ThemeMode.dark);

    final textSizeLabel = find.text('حجم النص');
    await tester.ensureVisible(textSizeLabel);
    await tester.tap(textSizeLabel);
    await tester.pumpAndSettle();
    await tester.tap(find.text('كبير جدًا'));
    await tester.pumpAndSettle();
    expect(selectedTextSize, AppTextSize.extraLarge);

    final bubbleStyleLabel = find.text('شكل فقاعات الرسائل');
    await tester.ensureVisible(bubbleStyleLabel);
    await tester.tap(bubbleStyleLabel);
    await tester.pumpAndSettle();
    expect(find.text('معاينة مباشرة'), findsOneWidget);
    await tester.tap(find.text('مستدير'));
    await tester.pumpAndSettle();
    expect(selectedBubbleStyle, MessageBubbleStyle.rounded);

    final reduceMotionLabel = find.text('تقليل الحركة');
    await tester.ensureVisible(reduceMotionLabel);
    await tester.tap(reduceMotionLabel);
    expect(selectedReduceMotion, isTrue);

    final highContrastLabel = find.text('تباين عالٍ');
    await tester.ensureVisible(highContrastLabel);
    await tester.tap(highContrastLabel);
    expect(selectedHighContrast, isTrue);

    final compactLayoutLabel = find.text('واجهة مدمجة');
    await tester.ensureVisible(compactLayoutLabel);
    await tester.tap(compactLayoutLabel);
    expect(selectedCompactLayout, isTrue);

    await tester.tap(find.text('البيانات والوسائط'));
    await tester.pumpAndSettle();
    final exportLabel = find.textContaining('تصدير JSON غير مشفر');
    await tester.ensureVisible(exportLabel);
    await tester.tap(exportLabel);
    expect(exportTapped, isTrue);

    final saveOptionsLabel = find.text('حفظ الوسائط والحالات');
    await tester.ensureVisible(saveOptionsLabel);
    await tester.tap(saveOptionsLabel);
    expect(saveOptionsTapped, isTrue);
  });
}
