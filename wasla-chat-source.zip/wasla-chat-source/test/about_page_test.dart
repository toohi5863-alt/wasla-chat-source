import 'package:chat/about_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('about page shows the current version, company, and features', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(const MaterialApp(home: AboutPage()));
    await tester.pump(const Duration(milliseconds: 950));

    expect(find.text('حول وصال'), findsOneWidget);
    expect(find.text('الإصدار 1.19.8+48'), findsOneWidget);
    expect(find.text('شركة الصرم للتطوير والبرمجيات'), findsWidgets);
    expect(find.text('محادثات'), findsOneWidget);
    expect(find.text('القريبون'), findsOneWidget);
    expect(find.text('Darwish71'), findsNothing);
    expect(find.text('عبر وصال'), findsOneWidget);
  });

  testWidgets('legal information and external actions are disclosed first', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(const MaterialApp(home: AboutPage()));
    await tester.pump(const Duration(milliseconds: 950));

    final privacyButton = find.text('الخصوصية');
    await tester.ensureVisible(privacyButton);
    await tester.pump(const Duration(milliseconds: 350));
    await tester.tap(privacyButton);
    await tester.pump(const Duration(milliseconds: 350));
    expect(
      find.text('رابط سياسة الخصوصية الرسمية غير مضاف في هذا الإصدار.'),
      findsOneWidget,
    );
    await tester.binding.handlePopRoute();
    await tester.pump(const Duration(milliseconds: 350));

    final emailButton = find.text('البريد');
    await tester.ensureVisible(emailButton);
    await tester.pump(const Duration(milliseconds: 350));
    await tester.tap(emailButton);
    await tester.pump(const Duration(milliseconds: 350));
    expect(find.text('فتح تطبيق البريد'), findsOneWidget);
    expect(find.text('إلغاء'), findsOneWidget);
    await tester.binding.handlePopRoute();
    await tester.pump(const Duration(milliseconds: 350));
    expect(find.text('فتح تطبيق البريد'), findsNothing);
  });

  testWidgets('about page respects the dark theme', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(brightness: Brightness.dark),
        home: const AboutPage(),
      ),
    );
    await tester.pump(const Duration(milliseconds: 950));

    final scaffold = tester.widget<Scaffold>(find.byType(Scaffold));
    expect(scaffold.backgroundColor, isNot(Colors.white));
    expect(find.text('عن وصال'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
