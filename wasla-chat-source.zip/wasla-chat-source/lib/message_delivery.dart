import 'dart:typed_data';

import 'chat_local_cache.dart';
import 'chat_models.dart';

typedef MessageMediaDownloader = Future<Uint8List> Function(String storagePath);
typedef MessageDeliveryAcknowledger = Future<String?> Function(
  String messageId,
);
typedef MessageMediaRemoteDeleter = Future<void> Function(
  String messageId,
  String storagePath,
);

/// Persists each eligible incoming message (and its complete media file) before
/// asking the server to acknowledge delivery. A network or disk failure leaves
/// that message on the server for a later retry.
class LocalMessageDelivery {
  const LocalMessageDelivery({
    required this.localCache,
    required this.downloadMedia,
    required this.acknowledge,
    required this.deleteRemoteMedia,
  });

  final ChatLocalCache localCache;
  final MessageMediaDownloader downloadMedia;
  final MessageDeliveryAcknowledger acknowledge;
  final MessageMediaRemoteDeleter deleteRemoteMedia;

  Future<Set<String>> cacheAndAcknowledge({
    required String userId,
    required String conversationId,
    required List<ChatMessage> conversationMessages,
    required Iterable<ChatMessage> incomingMessages,
  }) async {
    final ready = <ChatMessage>[];
    for (final message in incomingMessages) {
      if (message.senderId == userId ||
          !message.isEphemeral ||
          message.payloadDeletedAt != null) {
        continue;
      }
      final mediaPath = message.mediaPath;
      if (mediaPath != null && mediaPath.isNotEmpty) {
        try {
          var localFile = await localCache.findMedia(userId, mediaPath);
          if (localFile == null) {
            final bytes = await downloadMedia(mediaPath);
            if (bytes.isEmpty) throw StateError('Downloaded media is empty');
            localFile = await localCache.saveMediaBytes(
              userId,
              mediaPath,
              bytes,
            );
          }
          if (!await localFile.exists() || await localFile.length() == 0) {
            continue;
          }
        } catch (_) {
          // Do not acknowledge this item; the server copy remains retryable.
          continue;
        }
      }
      ready.add(message);
    }

    // This is deliberately a hard gate. If Hive cannot persist the complete
    // conversation snapshot, no network acknowledgement is sent.
    await localCache.saveMessages(userId, conversationId, conversationMessages);

    final acknowledgedIds = <String>{};
    for (final message in ready) {
      try {
        final remoteMediaToDelete = await acknowledge(message.id);
        if (remoteMediaToDelete != null && remoteMediaToDelete.isNotEmpty) {
          try {
            await deleteRemoteMedia(message.id, remoteMediaToDelete);
          } catch (_) {
            // The database tombstone is already safe; a later sync retries the
            // storage cleanup while its path remains in the tombstone row.
          }
        }
        acknowledgedIds.add(message.id);
      } catch (_) {
        // Keep this message pending on the server and retry on the next sync.
      }
    }
    return acknowledgedIds;
  }
}
