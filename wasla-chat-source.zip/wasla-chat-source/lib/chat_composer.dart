import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const int _maxMessageGraphemes = 3000;
const Color _composerViolet = Color(0xFF7C4DFF);
const Color _composerBlue = Color(0xFF3977FF);
const Color _composerCyan = Color(0xFF45D9F5);
const Color _composerRed = Color(0xFFFF4D61);
const Color _composerOrange = Color(0xFFFFAA45);
const Color _composerSurfaceDark = Color(0xFF1A1E2B);

/// Chat input, attachment/emoji panels, and hold-to-record controls.
/// All messaging/storage actions are delegated to the conversation screen.
class ChatComposer extends StatefulWidget {
  const ChatComposer({
    required this.controller,
    required this.focusNode,
    required this.onChanged,
    required this.onSubmitted,
    required this.onSend,
    required this.onAttachmentSelected,
    required this.onStartRecording,
    required this.onStopRecording,
    required this.onCancelRecording,
    required this.onLockRecording,
    required this.onRetryFailedRecording,
    required this.onDiscardFailedRecording,
    required this.isSending,
    required this.isRecording,
    required this.isRecordingLocked,
    required this.hasFailedRecording,
    required this.recordingDuration,
    required this.waveform,
    required this.voiceAllowed,
    required this.filesAllowed,
    this.replySender,
    this.replyText,
    this.onCancelReply,
    super.key,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onChanged;
  final ValueChanged<String> onSubmitted;
  final VoidCallback onSend;
  final Future<void> Function(String option) onAttachmentSelected;
  final Future<void> Function() onStartRecording;
  final Future<void> Function() onStopRecording;
  final Future<void> Function() onCancelRecording;
  final VoidCallback onLockRecording;
  final Future<void> Function() onRetryFailedRecording;
  final Future<void> Function() onDiscardFailedRecording;
  final bool isSending;
  final bool isRecording;
  final bool isRecordingLocked;
  final bool hasFailedRecording;
  final Duration recordingDuration;
  final List<double> waveform;
  final bool voiceAllowed;
  final bool filesAllowed;
  final String? replySender;
  final String? replyText;
  final VoidCallback? onCancelReply;

  @override
  State<ChatComposer> createState() => _ChatComposerState();
}

enum _ComposerPanel { none, attachments, emoji }

class _ChatComposerState extends State<ChatComposer> {
  static const _emojiCategories = <_EmojiCategory>[
    _EmojiCategory('الوجوه', Icons.sentiment_satisfied_alt_outlined, [
      '😀',
      '😃',
      '😄',
      '😁',
      '😆',
      '😅',
      '😂',
      '🤣',
      '🥹',
      '😊',
      '😇',
      '🙂',
      '🙃',
      '😉',
      '😍',
      '🥰',
      '😘',
      '😋',
      '😎',
      '🤩',
      '🤔',
      '🤗',
      '🤭',
      '😴',
      '😭',
      '😮',
      '🥳',
      '🫠',
      '🫶',
    ]),
    _EmojiCategory('الأيدي', Icons.back_hand_outlined, [
      '👋',
      '🤚',
      '🖐️',
      '✋',
      '🖖',
      '👌',
      '🤌',
      '🤏',
      '✌️',
      '🤞',
      '🫰',
      '🤟',
      '🤘',
      '🤙',
      '🫵',
      '👍',
      '👎',
      '✊',
      '👊',
      '👏',
      '🙌',
      '👐',
      '🤲',
      '🙏',
      '💪',
      '🤝',
      '🫂',
    ]),
    _EmojiCategory('الرموز', Icons.favorite_border, [
      '❤️',
      '🧡',
      '💛',
      '💚',
      '💙',
      '💜',
      '🖤',
      '🤍',
      '💔',
      '💕',
      '💞',
      '💓',
      '💖',
      '💘',
      '💝',
      '💟',
      '🔥',
      '✨',
      '⭐',
      '🌟',
      '💯',
      '✅',
      '🎉',
      '🎈',
      '💐',
      '🌹',
      '☀️',
      '💫',
    ]),
    _EmojiCategory('الحيوانات', Icons.pets_outlined, [
      '🐶',
      '🐱',
      '🐭',
      '🐹',
      '🐰',
      '🦊',
      '🐻',
      '🐼',
      '🐨',
      '🐯',
      '🦁',
      '🐮',
      '🐷',
      '🐸',
      '🐵',
      '🐔',
      '🐧',
      '🐦',
      '🦄',
      '🐝',
      '🦋',
      '🐢',
      '🐬',
      '🦜',
    ]),
    _EmojiCategory('الطعام', Icons.restaurant_outlined, [
      '🍎',
      '🍊',
      '🍋',
      '🍇',
      '🍓',
      '🍒',
      '🍉',
      '🍌',
      '🍍',
      '🥭',
      '🥑',
      '🍅',
      '🥕',
      '🌽',
      '🍕',
      '🍔',
      '🍟',
      '🌮',
      '🍰',
      '🍫',
      '🍿',
      '☕',
      '🧃',
      '🍵',
    ]),
    _EmojiCategory('الرياضة', Icons.sports_soccer_outlined, [
      '⚽',
      '🏀',
      '🏈',
      '⚾',
      '🎾',
      '🏐',
      '🏉',
      '🥏',
      '🎱',
      '🏓',
      '🏸',
      '🥊',
      '🥋',
      '⛳',
      '🏹',
      '🎣',
      '🤿',
      '⛷️',
      '🏂',
      '🏋️',
      '🤸',
      '🏆',
      '🥇',
      '🎯',
    ]),
    _EmojiCategory('السفر', Icons.flight_outlined, [
      '🚗',
      '🚕',
      '🚌',
      '🚎',
      '🏎️',
      '🚓',
      '🚑',
      '🚒',
      '🚚',
      '🚲',
      '🛵',
      '🚆',
      '🚄',
      '✈️',
      '🛫',
      '🚀',
      '🛸',
      '🚁',
      '⛵',
      '🚢',
      '🏝️',
      '🏕️',
      '🗽',
      '🌍',
    ]),
  ];

  static const _attachments = <_AttachmentOption>[
    _AttachmentOption(
      'gallery',
      'المعرض',
      Icons.photo_library_outlined,
      Color(0xFF8B5CF6),
    ),
    _AttachmentOption(
      'camera',
      'الكاميرا',
      Icons.photo_camera_outlined,
      Color(0xFF3977FF),
    ),
    _AttachmentOption(
      'audio',
      'ملف صوتي',
      Icons.graphic_eq_rounded,
      Color(0xFFEC4899),
    ),
    _AttachmentOption(
      'stickers',
      'الملصقات',
      Icons.sticky_note_2_outlined,
      Color(0xFFFFAA45),
      supported: false,
    ),
    _AttachmentOption(
      'file',
      'ملف أو مستند',
      Icons.insert_drive_file_outlined,
      Color(0xFF14B8A6),
    ),
    _AttachmentOption(
      'location',
      'موقعي الحالي',
      Icons.location_on_outlined,
      Color(0xFF35D39A),
    ),
    _AttachmentOption(
      'live_location',
      'موقع مباشر',
      Icons.my_location_outlined,
      Color(0xFFEF4444),
      supported: false,
    ),
    _AttachmentOption(
      'contact',
      'جهة اتصال',
      Icons.person_outline_rounded,
      Color(0xFF06B6D4),
      supported: false,
    ),
    _AttachmentOption(
      'poll',
      'استطلاع رأي',
      Icons.poll_outlined,
      Color(0xFF6366F1),
      supported: false,
    ),
    _AttachmentOption(
      'scheduled',
      'جدولة رسالة',
      Icons.schedule_outlined,
      Color(0xFFF59E0B),
      supported: false,
    ),
    _AttachmentOption(
      'event',
      'حدث أو تقويم',
      Icons.event_outlined,
      Color(0xFF22C55E),
      supported: false,
    ),
    _AttachmentOption(
      'gif',
      'GIF متحرك',
      Icons.gif_box_outlined,
      Color(0xFFEC4899),
      supported: false,
    ),
  ];

  _ComposerPanel _panel = _ComposerPanel.none;
  int _activeEmojiCategory = 0;
  bool _longPressStarted = false;
  bool _cancelArmed = false;
  bool _pressed = false;

  int get _graphemeCount => widget.controller.text.characters.length;
  bool get _hasText => widget.controller.text.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_handleControllerChange);
    widget.focusNode.addListener(_handleFocusChange);
  }

  @override
  void didUpdateWidget(covariant ChatComposer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_handleControllerChange);
      widget.controller.addListener(_handleControllerChange);
    }
    if (oldWidget.focusNode != widget.focusNode) {
      oldWidget.focusNode.removeListener(_handleFocusChange);
      widget.focusNode.addListener(_handleFocusChange);
    }
    if (widget.isRecordingLocked) _cancelArmed = false;
  }

  @override
  void dispose() {
    widget.controller.removeListener(_handleControllerChange);
    widget.focusNode.removeListener(_handleFocusChange);
    super.dispose();
  }

  void _handleControllerChange() {
    if (mounted) setState(() {});
  }

  void _handleFocusChange() {
    if (mounted) setState(() {});
  }

  void _togglePanel(_ComposerPanel panel) {
    if (widget.isSending || widget.isRecording || widget.hasFailedRecording) {
      return;
    }
    HapticFeedback.selectionClick();
    FocusScope.of(context).unfocus();
    setState(() => _panel = _panel == panel ? _ComposerPanel.none : panel);
  }

  void _insertEmoji(String emoji) {
    final current = widget.controller.value;
    final selection = current.selection;
    final start = selection.isValid ? selection.start : current.text.length;
    final end = selection.isValid ? selection.end : current.text.length;
    final nextText = current.text.replaceRange(start, end, emoji);
    if (nextText.characters.length > _maxMessageGraphemes) return;
    widget.controller.value = TextEditingValue(
      text: nextText,
      selection: TextSelection.collapsed(offset: start + emoji.length),
      composing: TextRange.empty,
    );
    widget.onChanged(nextText);
    HapticFeedback.selectionClick();
  }

  Future<void> _selectAttachment(_AttachmentOption option) async {
    if (!option.supported || widget.isSending || widget.isRecording) return;
    setState(() => _panel = _ComposerPanel.none);
    FocusScope.of(context).unfocus();
    await widget.onAttachmentSelected(option.id);
  }

  void _startHoldRecording(LongPressStartDetails _) {
    if (!widget.voiceAllowed ||
        widget.isSending ||
        widget.isRecording ||
        _hasText) {
      return;
    }
    _panel = _ComposerPanel.none;
    _cancelArmed = false;
    _longPressStarted = true;
    _pressed = true;
    HapticFeedback.mediumImpact();
    setState(() {});
    unawaited(widget.onStartRecording());
  }

  void _moveHoldRecording(LongPressMoveUpdateDetails details) {
    if (!_longPressStarted || !widget.isRecording || widget.isRecordingLocked) {
      return;
    }
    final offset = details.offsetFromOrigin;
    if (offset.dy < -60) {
      _cancelArmed = false;
      _longPressStarted = false;
      _pressed = false;
      widget.onLockRecording();
      HapticFeedback.mediumImpact();
    } else {
      final shouldCancel = offset.dx < -80;
      if (_cancelArmed != shouldCancel) {
        setState(() => _cancelArmed = shouldCancel);
      }
    }
  }

  void _endHoldRecording(LongPressEndDetails _) {
    _pressed = false;
    if (_longPressStarted) {
      _longPressStarted = false;
      if (_cancelArmed) {
        unawaited(widget.onCancelRecording());
      } else if (!widget.isRecordingLocked) {
        unawaited(widget.onStopRecording());
      }
    }
    _cancelArmed = false;
    if (mounted) setState(() {});
  }

  void _cancelHoldRecording() {
    _pressed = false;
    if (_longPressStarted && widget.isRecording && !widget.isRecordingLocked) {
      unawaited(widget.onCancelRecording());
    }
    _longPressStarted = false;
    _cancelArmed = false;
    if (mounted) setState(() {});
  }

  Duration get _motionDuration => MediaQuery.of(context).disableAnimations
      ? Duration.zero
      : const Duration(milliseconds: 260);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dark = theme.brightness == Brightness.dark;
    final surface = dark ? _composerSurfaceDark : theme.colorScheme.surface;
    final count = _graphemeCount;
    final counterColor = count >= 400
        ? _composerRed
        : count >= 300
        ? _composerOrange
        : theme.colorScheme.onSurfaceVariant;

    return TapRegion(
      onTapOutside: (_) {
        if (_panel != _ComposerPanel.none) {
          setState(() => _panel = _ComposerPanel.none);
        }
      },
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (widget.replyText != null)
              _ReplyPreview(
                sender: widget.replySender ?? 'رسالة',
                text: widget.replyText!,
                onClose: widget.onCancelReply,
              ),
            if (_panel != _ComposerPanel.none)
              AnimatedSwitcher(
                duration: _motionDuration,
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: const Offset(0, .06),
                      end: Offset.zero,
                    ).animate(animation),
                    child: child,
                  ),
                ),
                child: _panel == _ComposerPanel.attachments
                    ? _AttachmentsPanel(
                        key: const ValueKey('attachments'),
                        options: _attachments,
                        filesAllowed: widget.filesAllowed,
                        onSelect: _selectAttachment,
                      )
                    : _EmojiPanel(
                        key: const ValueKey('emoji'),
                        categories: _emojiCategories,
                        selectedCategory: _activeEmojiCategory,
                        onCategoryChanged: (index) =>
                            setState(() => _activeEmojiCategory = index),
                        onEmojiSelected: _insertEmoji,
                        onClose: () =>
                            setState(() => _panel = _ComposerPanel.none),
                      ),
              ),
            if (widget.hasFailedRecording)
              _FailedRecordingControls(
                duration: widget.recordingDuration,
                waveform: widget.waveform,
                onDiscard: widget.onDiscardFailedRecording,
                onRetry: widget.onRetryFailedRecording,
                sending: widget.isSending,
              )
            else if (widget.isRecording)
              _RecordingControls(
                locked: widget.isRecordingLocked,
                cancelArmed: _cancelArmed,
                duration: widget.recordingDuration,
                waveform: widget.waveform,
                onCancel: widget.onCancelRecording,
                onRetry: widget.onStopRecording,
                onLock: widget.onLockRecording,
                sending: widget.isSending,
              )
            else
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _RoundComposerButton(
                    tooltip: _panel == _ComposerPanel.attachments
                        ? 'إغلاق المرفقات'
                        : 'إضافة مرفق',
                    icon: _panel == _ComposerPanel.attachments
                        ? Icons.close_rounded
                        : Icons.add_rounded,
                    background: surface,
                    foreground: theme.colorScheme.onSurface,
                    onPressed: widget.isSending
                        ? null
                        : () => _togglePanel(_ComposerPanel.attachments),
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: AnimatedContainer(
                      duration: _motionDuration,
                      curve: Curves.easeOut,
                      constraints: const BoxConstraints(minHeight: 50),
                      decoration: BoxDecoration(
                        color: surface,
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(
                          color: widget.focusNode.hasFocus
                              ? _composerViolet.withValues(alpha: .72)
                              : theme.colorScheme.outlineVariant.withValues(
                                  alpha: .45,
                                ),
                          width: widget.focusNode.hasFocus ? 1.35 : 1,
                        ),
                        boxShadow: widget.focusNode.hasFocus
                            ? [
                                BoxShadow(
                                  color: _composerViolet.withValues(alpha: .08),
                                  blurRadius: 14,
                                ),
                              ]
                            : null,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              IconButton(
                                tooltip: _panel == _ComposerPanel.emoji
                                    ? 'إغلاق الرموز'
                                    : 'إضافة إيموجي',
                                visualDensity: VisualDensity.compact,
                                onPressed: widget.isSending
                                    ? null
                                    : () => _togglePanel(_ComposerPanel.emoji),
                                icon: Icon(
                                  _panel == _ComposerPanel.emoji
                                      ? Icons.keyboard_alt_outlined
                                      : Icons.emoji_emotions_outlined,
                                  size: 22,
                                ),
                                color: _composerViolet,
                              ),
                              Expanded(
                                child: TextField(
                                  controller: widget.controller,
                                  focusNode: widget.focusNode,
                                  minLines: 1,
                                  maxLines: 5,
                                  maxLength: _maxMessageGraphemes,
                                  maxLengthEnforcement:
                                      MaxLengthEnforcement.enforced,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  textInputAction: TextInputAction.newline,
                                  keyboardType: TextInputType.multiline,
                                  onTap: () {
                                    if (_panel != _ComposerPanel.none) {
                                      setState(
                                        () => _panel = _ComposerPanel.none,
                                      );
                                    }
                                  },
                                  onChanged: widget.onChanged,
                                  onSubmitted: widget.onSubmitted,
                                  decoration: const InputDecoration(
                                    hintText: 'رسالة...',
                                    counterText: '',
                                    isDense: true,
                                    filled: false,
                                    border: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                      vertical: 13,
                                      horizontal: 2,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                            ],
                          ),
                          if (count > 50)
                            Padding(
                              padding: const EdgeInsetsDirectional.only(
                                start: 15,
                                end: 15,
                                bottom: 5,
                              ),
                              child: Align(
                                alignment: AlignmentDirectional.centerStart,
                                child: Text(
                                  '$count / $_maxMessageGraphemes',
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: counterColor,
                                    fontWeight: count >= 300
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 7),
                  _primaryAction(theme.colorScheme.onSurface, surface),
                ],
              ),
            const SizedBox(height: 2),
          ],
        ),
      ),
    );
  }

  Widget _primaryAction(Color foreground, Color surface) {
    final isSend = _hasText;
    final canRecord =
        widget.voiceAllowed && !widget.isSending && !widget.hasFailedRecording;
    final disabled = isSend ? widget.isSending : !canRecord;
    return Tooltip(
      message: isSend ? 'إرسال الرسالة' : 'اضغط مطولًا للتسجيل الصوتي',
      child: GestureDetector(
        onTapDown: (_) {
          if (!disabled) setState(() => _pressed = true);
        },
        onTapUp: (_) {
          if (mounted) setState(() => _pressed = false);
        },
        onTapCancel: () {
          if (mounted) setState(() => _pressed = false);
        },
        onTap: () {
          if (isSend) {
            widget.onSend();
          } else if (!widget.isRecording && widget.voiceAllowed) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('اضغط مطولًا على الميكروفون للتسجيل.'),
              ),
            );
          }
        },
        onLongPressStart: isSend ? null : _startHoldRecording,
        onLongPressMoveUpdate: isSend ? null : _moveHoldRecording,
        onLongPressEnd: isSend ? null : _endHoldRecording,
        onLongPressCancel: isSend ? null : _cancelHoldRecording,
        child: AnimatedScale(
          scale: _pressed ? .93 : 1,
          duration: MediaQuery.of(context).disableAnimations
              ? Duration.zero
              : const Duration(milliseconds: 115),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 230),
            curve: Curves.easeOut,
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: disabled
                  ? null
                  : const LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: [_composerViolet, _composerBlue],
                    ),
              color: disabled ? surface : null,
              boxShadow: disabled
                  ? null
                  : [
                      BoxShadow(
                        color: _composerViolet.withValues(alpha: .22),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
            ),
            child: Center(
              child: widget.isSending && isSend
                  ? const SizedBox(
                      width: 21,
                      height: 21,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : AnimatedSwitcher(
                      duration: const Duration(milliseconds: 210),
                      transitionBuilder: (child, animation) =>
                          ScaleTransition(scale: animation, child: child),
                      child: Icon(
                        isSend ? Icons.send_rounded : Icons.mic_none_rounded,
                        key: ValueKey(isSend),
                        size: 23,
                        color: disabled
                            ? foreground.withValues(alpha: .42)
                            : Colors.white,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ReplyPreview extends StatelessWidget {
  const _ReplyPreview({required this.sender, required this.text, this.onClose});
  final String sender;
  final String text;
  final VoidCallback? onClose;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 7, right: 4, left: 4),
    padding: const EdgeInsetsDirectional.fromSTEB(12, 8, 8, 8),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surfaceContainerHighest
          .withValues(alpha: .68),
      borderRadius: BorderRadius.circular(12),
      border: const BorderDirectional(
        start: BorderSide(color: _composerCyan, width: 3),
      ),
    ),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                sender,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _composerCyan,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'إلغاء الرد',
          onPressed: onClose,
          visualDensity: VisualDensity.compact,
          icon: const Icon(Icons.close_rounded, size: 19),
        ),
      ],
    ),
  );
}

class _AttachmentsPanel extends StatelessWidget {
  const _AttachmentsPanel({
    required this.options,
    required this.filesAllowed,
    required this.onSelect,
    super.key,
  });
  final List<_AttachmentOption> options;
  final bool filesAllowed;
  final Future<void> Function(_AttachmentOption) onSelect;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final columns = (width / 78).floor().clamp(3, 6);
    final theme = Theme.of(context);
    return Container(
      height: 260,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      decoration: BoxDecoration(
        color: theme.brightness == Brightness.dark
            ? _composerSurfaceDark
            : theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: .45),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: theme.brightness == Brightness.dark ? .18 : .06,
            ),
            blurRadius: 16,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'المرفقات',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Text(
                'المتاح مميز، والباقي غير مفعّل',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.zero,
              itemCount: options.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                mainAxisSpacing: 2,
                crossAxisSpacing: 2,
                childAspectRatio: .92,
              ),
              itemBuilder: (context, index) {
                final option = options[index];
                final active =
                    option.supported &&
                    (filesAllowed || option.id == 'location');
                return Tooltip(
                  message: active
                      ? option.label
                      : '${option.label} — غير متاحة حاليًا',
                  child: InkWell(
                    borderRadius: BorderRadius.circular(15),
                    onTap: active ? () => unawaited(onSelect(option)) : null,
                    child: Opacity(
                      opacity: active ? 1 : .43,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: option.color.withValues(alpha: .2),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              option.icon,
                              color: option.color,
                              size: 22,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            option.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.labelSmall?.copyWith(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          if (!active)
                            Text(
                              'غير متاح',
                              style: theme.textTheme.labelSmall?.copyWith(
                                fontSize: 8,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _EmojiPanel extends StatelessWidget {
  const _EmojiPanel({
    required this.categories,
    required this.selectedCategory,
    required this.onCategoryChanged,
    required this.onEmojiSelected,
    required this.onClose,
    super.key,
  });
  final List<_EmojiCategory> categories;
  final int selectedCategory;
  final ValueChanged<int> onCategoryChanged;
  final ValueChanged<String> onEmojiSelected;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final category = categories[selectedCategory];
    final width = MediaQuery.sizeOf(context).width;
    final columns = (width / 46).floor().clamp(6, 8);
    return Container(
      height: 286,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
      decoration: BoxDecoration(
        color: theme.brightness == Brightness.dark
            ? _composerSurfaceDark
            : theme.colorScheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: theme.colorScheme.outlineVariant.withValues(alpha: .45),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (var i = 0; i < categories.length; i++)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 5),
                          child: ChoiceChip(
                            label: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(categories[i].icon, size: 16),
                                const SizedBox(width: 4),
                                Text(
                                  categories[i].label,
                                  style: const TextStyle(fontSize: 11),
                                ),
                              ],
                            ),
                            selected: selectedCategory == i,
                            onSelected: (_) => onCategoryChanged(i),
                            visualDensity: VisualDensity.compact,
                            labelPadding: const EdgeInsets.symmetric(
                              horizontal: 4,
                            ),
                            side: BorderSide.none,
                            selectedColor: _composerViolet.withValues(
                              alpha: .2,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              IconButton(
                tooltip: 'إغلاق منتقي الإيموجي',
                onPressed: onClose,
                icon: const Icon(Icons.close_rounded, size: 20),
              ),
            ],
          ),
          const Divider(height: 1),
          Expanded(
            child: GridView.builder(
              itemCount: category.emojis.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                mainAxisSpacing: 1,
                crossAxisSpacing: 1,
              ),
              itemBuilder: (context, index) {
                final emoji = category.emojis[index];
                return InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => onEmojiSelected(emoji),
                  child: Center(
                    child: Text(emoji, style: const TextStyle(fontSize: 27)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _RecordingControls extends StatelessWidget {
  const _RecordingControls({
    required this.locked,
    required this.cancelArmed,
    required this.duration,
    required this.waveform,
    required this.onCancel,
    required this.onRetry,
    required this.onLock,
    required this.sending,
  });
  final bool locked;
  final bool cancelArmed;
  final Duration duration;
  final List<double> waveform;
  final Future<void> Function() onCancel;
  final Future<void> Function() onRetry;
  final VoidCallback onLock;
  final bool sending;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = cancelArmed
        ? _composerRed
        : locked
        ? _composerCyan
        : _composerRed;
    return Row(
      children: [
        _RoundComposerButton(
          tooltip: 'إلغاء التسجيل',
          icon: Icons.delete_outline_rounded,
          background: _composerRed.withValues(alpha: .12),
          foreground: _composerRed,
          onPressed: () => unawaited(onCancel()),
        ),
        const SizedBox(width: 7),
        Expanded(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            constraints: const BoxConstraints(minHeight: 52),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest.withValues(
                alpha: .6,
              ),
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: color.withValues(alpha: .45)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    _PulsingRecordDot(color: color),
                    const SizedBox(width: 7),
                    Text(
                      _formatDuration(duration),
                      style: const TextStyle(
                        fontFeatures: [FontFeature.tabularFigures()],
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: _WaveformBars(
                        levels: waveform,
                        color: locked ? _composerCyan : color,
                      ),
                    ),
                    if (cancelArmed) const SizedBox(width: 6),
                    if (cancelArmed)
                      const Text(
                        'أفلت للإلغاء',
                        style: TextStyle(
                          color: _composerRed,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                  ],
                ),
                if (!locked && !cancelArmed)
                  const Padding(
                    padding: EdgeInsets.only(top: 3),
                    child: Text(
                      'اسحب للأعلى للقفل 🔒 أو لليسار للإلغاء',
                      style: TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 7),
        _RoundComposerButton(
          tooltip: locked ? 'إرسال التسجيل' : 'قفل التسجيل',
          icon: locked ? Icons.send_rounded : Icons.lock_outline_rounded,
          background: locked
              ? _composerViolet
              : _composerRed.withValues(alpha: .12),
          foreground: locked ? Colors.white : _composerRed,
          onPressed: sending
              ? null
              : locked
              ? () => unawaited(onRetry())
              : onLock,
          busy: sending && locked,
        ),
      ],
    );
  }
}

class _FailedRecordingControls extends StatelessWidget {
  const _FailedRecordingControls({
    required this.duration,
    required this.waveform,
    required this.onDiscard,
    required this.onRetry,
    required this.sending,
  });
  final Duration duration;
  final List<double> waveform;
  final Future<void> Function() onDiscard;
  final Future<void> Function() onRetry;
  final bool sending;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      _RoundComposerButton(
        tooltip: 'حذف التسجيل',
        icon: Icons.delete_outline_rounded,
        background: _composerRed.withValues(alpha: .12),
        foreground: _composerRed,
        onPressed: () => unawaited(onDiscard()),
      ),
      const SizedBox(width: 7),
      Expanded(
        child: Container(
          constraints: const BoxConstraints(minHeight: 52),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: _composerRed.withValues(alpha: .08),
            borderRadius: BorderRadius.circular(26),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.error_outline_rounded,
                    color: _composerRed,
                    size: 17,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    _formatDuration(duration),
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _WaveformBars(levels: waveform, color: _composerRed),
                  ),
                ],
              ),
              const Text(
                'تعذر حفظ الإرسال؛ التسجيل محفوظ لإعادة المحاولة',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 10, color: _composerRed),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(width: 7),
      _RoundComposerButton(
        tooltip: 'إعادة محاولة إرسال التسجيل',
        icon: Icons.refresh_rounded,
        background: const Color(0xFF7C4DFF),
        foreground: Colors.white,
        onPressed: sending ? null : () => unawaited(onRetry()),
        busy: sending,
      ),
    ],
  );
}

class _WaveformBars extends StatelessWidget {
  const _WaveformBars({required this.levels, required this.color});
  final List<double> levels;
  final Color color;

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 22,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: List.generate(26, (index) {
        final level = levels.isEmpty
            ? .12
            : levels[index % levels.length].clamp(.08, 1.0);
        return Container(
          width: 2.4,
          height: 4 + level * 17,
          decoration: BoxDecoration(
            color: color.withValues(alpha: .45 + level * .55),
            borderRadius: BorderRadius.circular(4),
          ),
        );
      }),
    ),
  );
}

class _PulsingRecordDot extends StatefulWidget {
  const _PulsingRecordDot({required this.color});
  final Color color;
  @override
  State<_PulsingRecordDot> createState() => _PulsingRecordDotState();
}

class _PulsingRecordDotState extends State<_PulsingRecordDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 850),
  )..repeat(reverse: true);
  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: Tween<double>(begin: .45, end: 1).animate(_controller),
    child: Icon(
      Icons.fiber_manual_record_rounded,
      size: 12,
      color: widget.color,
    ),
  );
}

class _RoundComposerButton extends StatelessWidget {
  const _RoundComposerButton({
    required this.tooltip,
    required this.icon,
    required this.background,
    required this.foreground,
    required this.onPressed,
    this.busy = false,
  });
  final String tooltip;
  final IconData icon;
  final Color background;
  final Color foreground;
  final VoidCallback? onPressed;
  final bool busy;

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: Material(
      color: background,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onPressed,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Center(
            child: busy
                ? SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: foreground,
                    ),
                  )
                : Icon(
                    icon,
                    color: onPressed == null
                        ? foreground.withValues(alpha: .45)
                        : foreground,
                    size: 21,
                  ),
          ),
        ),
      ),
    ),
  );
}

class _AttachmentOption {
  const _AttachmentOption(
    this.id,
    this.label,
    this.icon,
    this.color, {
    this.supported = true,
  });
  final String id;
  final String label;
  final IconData icon;
  final Color color;
  final bool supported;
}

class _EmojiCategory {
  const _EmojiCategory(this.label, this.icon, this.emojis);
  final String label;
  final IconData icon;
  final List<String> emojis;
}

String _formatDuration(Duration duration) =>
    '${duration.inMinutes.toString().padLeft(2, '0')}:${duration.inSeconds.remainder(60).toString().padLeft(2, '0')}';
