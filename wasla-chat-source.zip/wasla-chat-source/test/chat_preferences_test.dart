import 'package:flutter_test/flutter_test.dart';
import 'package:chat/chat_preferences.dart';

void main() {
  test('round-trips per-chat local preferences', () {
    final preferences = ChatListPreferences.fromMap({
      'pinned': ['c-1', 'c-2'],
      'favorites': ['c-2'],
      'archived': ['c-3'],
      'muted': ['c-1'],
      'hidden': ['c-4'],
      'deleted': ['c-5'],
    });

    final restored = ChatListPreferences.fromMap(preferences.toMap());
    expect(restored.pinned, {'c-1', 'c-2'});
    expect(restored.favorites, {'c-2'});
    expect(restored.archived, {'c-3'});
    expect(restored.muted, {'c-1'});
    expect(restored.hidden, {'c-4'});
    expect(restored.deleted, {'c-5'});
  });

  test('copyWith replaces one preference without losing the others', () {
    const original = ChatListPreferences(
      pinned: {'c-1'},
      favorites: {'c-2'},
      archived: {'c-3'},
    );

    final updated = original.copyWith(muted: {'c-4'});
    expect(updated.pinned, {'c-1'});
    expect(updated.favorites, {'c-2'});
    expect(updated.archived, {'c-3'});
    expect(updated.muted, {'c-4'});
    expect(updated.hidden, isEmpty);
    expect(updated.deleted, isEmpty);
  });

  test('ignores malformed preference fields safely', () {
    final preferences = ChatListPreferences.fromMap({
      'pinned': 'not-a-list',
      'favorites': [null, '', 'c-2'],
      'archived': 42,
    });

    expect(preferences.pinned, isEmpty);
    expect(preferences.favorites, {'c-2'});
    expect(preferences.archived, isEmpty);
  });
}
