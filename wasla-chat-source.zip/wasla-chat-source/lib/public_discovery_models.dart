import 'chat_models.dart';

class PublicCategory {
  const PublicCategory(this.value, this.label);
  final String value;
  final String label;

  static const all = PublicCategory('all', 'الكل');
  static const values = [
    all,
    PublicCategory('news', 'أخبار'),
    PublicCategory('sports', 'رياضة'),
    PublicCategory('technology', 'تقنية'),
    PublicCategory('games', 'ألعاب'),
    PublicCategory('education', 'تعليم'),
    PublicCategory('entertainment', 'ترفيه'),
    PublicCategory('other', 'أخرى'),
  ];

  static String labelFor(String value) => values
      .firstWhere(
        (category) => category.value == value,
        orElse: () => values.last,
      )
      .label;
}

class PublicListing {
  const PublicListing({
    required this.conversationId,
    required this.name,
    required this.description,
    required this.category,
    required this.listingType,
    required this.inviteToken,
    required this.memberCount,
    required this.roomOnlineCount,
    required this.activity7d,
    required this.isActive,
    required this.isMember,
    this.avatarPath,
    this.lastMessageAt,
    this.createdAt,
  });

  final String conversationId;
  final String name;
  final String description;
  final String category;
  final String listingType;
  final String inviteToken;
  final int memberCount;
  final int roomOnlineCount;
  final int activity7d;
  final bool isActive;
  final bool isMember;
  final String? avatarPath;
  final DateTime? lastMessageAt;
  final DateTime? createdAt;

  bool get isRoom => listingType == 'room';
  String get categoryLabel => PublicCategory.labelFor(category);
  String get publicLink => 'wasla://join/$inviteToken';

  ChatTarget toChatTarget() => ChatTarget(
    conversationId: conversationId,
    userId: '',
    username: '',
    displayName: name,
    avatarPath: avatarPath,
    isGroup: true,
    groupDescription: description,
    memberCount: memberCount,
    groupRole: isMember ? 'member' : null,
    isPublicRoom: isRoom,
  );

  factory PublicListing.fromMap(Map<String, dynamic> map) => PublicListing(
    conversationId: map['conversation_id']?.toString() ?? '',
    name: map['name']?.toString() ?? '',
    description: map['description']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
    category: map['category']?.toString() ?? 'other',
    listingType: map['listing_type']?.toString() ?? 'group',
    inviteToken: map['invite_token']?.toString() ?? '',
    memberCount: _number(map['member_count']),
    roomOnlineCount: _number(map['room_online_count']),
    activity7d: _number(map['activity_7d']),
    isActive: _bool(map['is_active']),
    isMember: _bool(map['is_member']),
    lastMessageAt: _date(map['last_message_at']),
    createdAt: _date(map['created_at']),
  );
}

int _number(dynamic value) =>
    value is num ? value.toInt() : int.tryParse(value?.toString() ?? '') ?? 0;

bool _bool(dynamic value) =>
    value == true || value?.toString().toLowerCase() == 'true';

DateTime? _date(dynamic value) =>
    value == null ? null : DateTime.tryParse(value.toString());
