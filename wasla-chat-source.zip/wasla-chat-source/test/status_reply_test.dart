import 'package:chat/status_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parses a private status reply and its sender profile', () {
    final reply = StatusReply.fromMap({
      'id': 'reply-1',
      'status_id': 'status-1',
      'sender_id': 'user-2',
      'body': 'جميلة جدًا',
      'created_at': '2026-10-10T08:00:00Z',
      'sender': {
        'username': 'friend_2',
        'display_name': 'صديق وصال',
        'avatar_path': 'user-2/avatar.jpg',
      },
    });

    expect(reply.id, 'reply-1');
    expect(reply.statusId, 'status-1');
    expect(reply.senderId, 'user-2');
    expect(reply.body, 'جميلة جدًا');
    expect(reply.senderLabel, 'صديق وصال');
    expect(reply.senderAvatarPath, 'user-2/avatar.jpg');
    expect(reply.createdAt.toUtc(), DateTime.utc(2026, 10, 10, 8));
  });

  test('falls back to a username when a display name is missing', () {
    final reply = StatusReply.fromMap({
      'sender': {'username': 'friend_2'},
    });

    expect(reply.senderLabel, '@friend_2');
  });
}
