import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:hive_ce/hive_ce.dart';
import 'package:path_provider/path_provider.dart';

import 'chat_models.dart';
import 'chat_outbox_message.dart';

/// On-device cache for previously synchronized chats and message media.
///
/// Each signed-in account gets a separate directory. Cached content stays in
/// the app's private support directory and is available after a restart.
class ChatLocalCache {
  ChatLocalCache({Future<Directory> Function()? supportDirectoryProvider})
    : _supportDirectoryProvider =
          supportDirectoryProvider ?? getApplicationSupportDirectory;

  static final Map<String, Future<File?>> _inFlightMediaDownloads = {};

  final Future<Directory> Function() _supportDirectoryProvider;
  Future<void> _outboxMutationTail = Future<void>.value();

  Future<Directory> _accountDirectory(String userId) async {
    final root = await _supportDirectoryProvider();
    final accountKey = _encodePathPart(userId);
    final directory = Directory(
      '${root.path}${Platform.pathSeparator}wasla_offline_cache'
      '${Platform.pathSeparator}$accountKey',
    );
    await directory.create(recursive: true);
    return directory;
  }

  Future<Box<dynamic>> _accountBox(String userId) async {
    final root = await _supportDirectoryProvider();
    final hiveDirectory = Directory(
      '${root.path}${Platform.pathSeparator}wasla_offline_cache'
      '${Platform.pathSeparator}hive',
    );
    await hiveDirectory.create(recursive: true);
    Hive.init(hiveDirectory.path);
    return Hive.openBox<dynamic>('wasla_cache_${_encodeBoxName(userId)}');
  }

  Future<List<ChatPreview>?> loadChats(String userId) async {
    final box = await _accountBox(userId);
    try {
      final cached = _decodeRows(box.get('chats'));
      if (cached != null) {
        return cached.map(ChatPreview.fromMap).toList();
      }
      final legacy = await _readLegacyChats(userId);
      if (legacy == null) return null;
      await box.put('chats', legacy.map((chat) => chat.toMap()).toList());
      return legacy;
    } catch (error, stackTrace) {
      debugPrint('Could not read cached chats: $error\n$stackTrace');
      return null;
    }
  }

  Future<void> saveChats(String userId, List<ChatPreview> chats) async {
    final box = await _accountBox(userId);
    await box.put('chats', chats.map((chat) => chat.toMap()).toList());
  }

  Future<String?> loadDraft(String userId, String conversationId) async {
    final box = await _accountBox(userId);
    final value = box.get(_draftBoxKey(conversationId));
    return value is String && value.trim().isNotEmpty ? value : null;
  }

  Future<Map<String, String>> loadDrafts(String userId) async {
    final box = await _accountBox(userId);
    final drafts = <String, String>{};
    for (final key in box.keys) {
      if (key is! String || !key.startsWith(_draftBoxKeyPrefix)) continue;
      final value = box.get(key);
      if (value is! String || value.trim().isEmpty) continue;
      try {
        final conversationId = _decodePathPart(
          key.substring(_draftBoxKeyPrefix.length),
        );
        if (conversationId.isNotEmpty) drafts[conversationId] = value;
      } on FormatException {
        // Ignore malformed keys without blocking other cached drafts.
      }
    }
    return drafts;
  }

  Future<void> saveDraft(
    String userId,
    String conversationId,
    String draft,
  ) async {
    final box = await _accountBox(userId);
    final key = _draftBoxKey(conversationId);
    if (draft.trim().isEmpty) {
      await box.delete(key);
    } else {
      await box.put(key, draft);
    }
  }

  Future<List<ChatMessage>?> loadMessages(
    String userId,
    String conversationId,
  ) async {
    final box = await _accountBox(userId);
    final key = _messagesBoxKey(conversationId);
    try {
      final cached = _decodeRows(box.get(key));
      if (cached != null) {
        return cached.map(ChatMessage.fromMap).toList();
      }
      final legacy = await _readLegacyMessages(userId, conversationId);
      if (legacy == null) return null;
      await box.put(key, legacy.map((message) => message.toMap()).toList());
      return legacy;
    } catch (error, stackTrace) {
      debugPrint('Could not read cached messages: $error\n$stackTrace');
      return null;
    }
  }

  Future<void> saveMessages(
    String userId,
    String conversationId,
    List<ChatMessage> messages,
  ) async {
    final box = await _accountBox(userId);
    await box.put(
      _messagesBoxKey(conversationId),
      messages.map((message) => message.toMap()).toList(),
    );
  }

  /// Starred message IDs are private to this account and stay on this device.
  Future<Set<String>> loadStarredMessageIds(
    String userId,
    String conversationId,
  ) async {
    final box = await _accountBox(userId);
    final value = box.get(_starredMessagesBoxKey(conversationId));
    if (value is! Iterable) return <String>{};
    return value
        .where((item) => item != null && item.toString().isNotEmpty)
        .map((item) => item.toString())
        .toSet();
  }

  Future<void> setMessageStarred(
    String userId,
    String conversationId,
    String messageId,
    bool starred,
  ) async {
    final box = await _accountBox(userId);
    final key = _starredMessagesBoxKey(conversationId);
    final value = box.get(key);
    final ids = value is Iterable
        ? value
              .where((item) => item != null && item.toString().isNotEmpty)
              .map((item) => item.toString())
              .toSet()
        : <String>{};
    if (starred) {
      ids.add(messageId);
    } else {
      ids.remove(messageId);
    }
    await box.put(key, ids.toList()..sort());
  }

  Future<List<ChatPreview>?> _readLegacyChats(String userId) async {
    final file = File(
      '${(await _accountDirectory(userId)).path}'
      '${Platform.pathSeparator}chats.json',
    );
    if (!await file.exists()) return null;
    final rows = _decodeRows(jsonDecode(await file.readAsString()));
    return rows?.map(ChatPreview.fromMap).toList();
  }

  Future<List<ChatMessage>?> _readLegacyMessages(
    String userId,
    String conversationId,
  ) async {
    final file = await _conversationMessagesFile(userId, conversationId);
    if (!await file.exists()) return null;
    final rows = _decodeRows(jsonDecode(await file.readAsString()));
    return rows?.map(ChatMessage.fromMap).toList();
  }

  Future<List<PendingOutgoingMessage>> loadPendingMessages(
    String userId,
  ) async => _readPendingMessages(userId);

  Future<void> enqueueOutgoingMessage(
    String userId,
    PendingOutgoingMessage message, {
    Uint8List? attachmentBytes,
  }) async {
    if (attachmentBytes != null) {
      final attachment = await _pendingAttachmentFile(userId, message);
      await attachment.parent.create(recursive: true);
      await attachment.writeAsBytes(attachmentBytes, flush: true);
    }
    await _serializeOutboxMutation(() async {
      final pending = await _readPendingMessages(userId);
      if (!pending.any((item) => item.id == message.id)) {
        pending.add(message);
      }
      pending.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      await _writeJson(
        await _pendingOutboxFile(userId),
        pending.map((item) => item.toMap()).toList(),
      );
    });
  }

  Future<File?> pendingAttachment(
    String userId,
    PendingOutgoingMessage message,
  ) async {
    if (message.mediaExtension == null) return null;
    final file = await _pendingAttachmentFile(userId, message);
    return await file.exists() ? file : null;
  }

  Future<void> updatePendingMessage(
    String userId,
    PendingOutgoingMessage message,
  ) => _serializeOutboxMutation(() async {
    final pending = await _readPendingMessages(userId);
    final index = pending.indexWhere((item) => item.id == message.id);
    if (index < 0) return;
    pending[index] = message;
    await _writeJson(
      await _pendingOutboxFile(userId),
      pending.map((item) => item.toMap()).toList(),
    );
  });

  Future<void> removePendingMessage(String userId, String messageId) =>
      _serializeOutboxMutation(() async {
        final pending = await _readPendingMessages(userId);
        final removed = pending.where((item) => item.id == messageId).toList();
        pending.removeWhere((item) => item.id == messageId);
        await _writeJson(
          await _pendingOutboxFile(userId),
          pending.map((item) => item.toMap()).toList(),
        );
        for (final item in removed) {
          if (item.mediaExtension == null) continue;
          final attachment = await _pendingAttachmentFile(userId, item);
          if (await attachment.exists()) await attachment.delete();
        }
      });

  Future<List<PendingOutgoingMessage>> _readPendingMessages(
    String userId,
  ) async {
    final file = await _pendingOutboxFile(userId);
    if (!await file.exists()) return [];
    try {
      final decoded = jsonDecode(await file.readAsString());
      if (decoded is! List) return [];
      return decoded
          .whereType<Map>()
          .map(
            (row) =>
                PendingOutgoingMessage.fromMap(Map<String, dynamic>.from(row)),
          )
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
    } catch (error, stackTrace) {
      debugPrint('Could not read pending messages: $error\n$stackTrace');
      return [];
    }
  }

  Future<File> _pendingOutboxFile(String userId) async {
    final directory = await _accountDirectory(userId);
    return File('${directory.path}${Platform.pathSeparator}outbox.json');
  }

  Future<File> _pendingAttachmentFile(
    String userId,
    PendingOutgoingMessage message,
  ) async {
    final directory = await _accountDirectory(userId);
    final attachmentDirectory = Directory(
      '${directory.path}${Platform.pathSeparator}outbox_media',
    );
    await attachmentDirectory.create(recursive: true);
    final safeExtension = (message.mediaExtension ?? 'bin').replaceAll(
      RegExp(r'[^a-zA-Z0-9_-]'),
      '',
    );
    return File(
      '${attachmentDirectory.path}${Platform.pathSeparator}'
      '${_encodePathPart(message.id)}.$safeExtension',
    );
  }

  Future<T> _serializeOutboxMutation<T>(Future<T> Function() operation) {
    final result = Completer<T>();
    _outboxMutationTail = _outboxMutationTail.then((_) async {
      try {
        result.complete(await operation());
      } catch (error, stackTrace) {
        result.completeError(error, stackTrace);
      }
    });
    return result.future;
  }

  Future<File?> findMedia(String userId, String storagePath) async {
    var file = await _mediaFile(userId, storagePath);
    if (!await file.exists()) {
      // Preserve files cached by older app versions, which used a .bin suffix.
      final legacyFile = await _legacyMediaFile(userId, storagePath);
      if (!await legacyFile.exists()) return null;
      file = legacyFile;
    }
    try {
      if (await file.length() == 0) {
        await file.delete();
        return null;
      }
    } catch (_) {
      return null;
    }
    return file;
  }

  Future<File> saveMediaBytes(
    String userId,
    String storagePath,
    Uint8List bytes,
  ) async {
    final file = await _mediaFile(userId, storagePath);
    await file.parent.create(recursive: true);
    final temporary = File(
      '${file.path}.tmp-${DateTime.now().microsecondsSinceEpoch}',
    );
    try {
      await temporary.writeAsBytes(bytes, flush: true);
      return await temporary.rename(file.path);
    } catch (_) {
      if (await temporary.exists()) await temporary.delete();
      rethrow;
    }
  }

  /// Downloads a signed storage URL into the private cache and returns it.
  /// Returns null on network or filesystem errors so the caller can show its
  /// normal image-loading fallback without interrupting the chat screen.
  Future<File?> cacheMediaFromUrl(
    String userId,
    String storagePath,
    String signedUrl,
  ) async {
    final existing = await findMedia(userId, storagePath);
    if (existing != null) return existing;

    final key = '${_encodePathPart(userId)}:${_encodePathPart(storagePath)}';
    final inFlight = _inFlightMediaDownloads[key];
    if (inFlight != null) return inFlight;

    final download = _downloadMediaFromUrl(userId, storagePath, signedUrl);
    _inFlightMediaDownloads[key] = download;
    try {
      return await download;
    } finally {
      if (identical(_inFlightMediaDownloads[key], download)) {
        _inFlightMediaDownloads.remove(key);
      }
    }
  }

  Future<File?> _downloadMediaFromUrl(
    String userId,
    String storagePath,
    String signedUrl,
  ) async {
    final destination = await _mediaFile(userId, storagePath);
    await destination.parent.create(recursive: true);
    final temporary = File(
      '${destination.path}.tmp-${DateTime.now().microsecondsSinceEpoch}',
    );
    final httpClient = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15)
      ..idleTimeout = const Duration(seconds: 30);
    try {
      final request = await httpClient
          .getUrl(Uri.parse(signedUrl))
          .timeout(const Duration(seconds: 20));
      final response = await request.close().timeout(
        const Duration(seconds: 30),
      );
      if (response.statusCode != HttpStatus.ok) {
        await response.drain<void>();
        return null;
      }
      final sink = temporary.openWrite();
      try {
        await response.pipe(sink);
      } catch (_) {
        await sink.close();
        rethrow;
      }
      if (!await temporary.exists() || await temporary.length() == 0) {
        return null;
      }
      return await temporary.rename(destination.path);
    } catch (error, stackTrace) {
      debugPrint('Could not cache message media: $error\n$stackTrace');
      return null;
    } finally {
      httpClient.close(force: true);
      if (await temporary.exists()) {
        try {
          await temporary.delete();
        } catch (_) {}
      }
    }
  }

  Future<File> _conversationMessagesFile(
    String userId,
    String conversationId,
  ) async {
    final directory = await _accountDirectory(userId);
    final conversations = Directory(
      '${directory.path}${Platform.pathSeparator}conversations',
    );
    await conversations.create(recursive: true);
    return File(
      '${conversations.path}${Platform.pathSeparator}'
      '${_encodePathPart(conversationId)}.json',
    );
  }

  Future<File> _mediaFile(String userId, String storagePath) async {
    final directory = await _accountDirectory(userId);
    final mediaDirectory = Directory(
      '${directory.path}${Platform.pathSeparator}media',
    );
    await mediaDirectory.create(recursive: true);
    final lastSegment = storagePath.split('/').last;
    final dot = lastSegment.lastIndexOf('.');
    final rawExtension = dot > 0 && dot < lastSegment.length - 1
        ? lastSegment.substring(dot + 1)
        : '';
    final extension = rawExtension.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '');
    return File(
      '${mediaDirectory.path}${Platform.pathSeparator}'
      '${_encodePathPart(storagePath)}.${extension.isEmpty ? 'bin' : extension}',
    );
  }

  Future<File> _legacyMediaFile(String userId, String storagePath) async {
    final directory = await _accountDirectory(userId);
    final mediaDirectory = Directory(
      '${directory.path}${Platform.pathSeparator}media',
    );
    return File(
      '${mediaDirectory.path}${Platform.pathSeparator}'
      '${_encodePathPart(storagePath)}.bin',
    );
  }

  Future<void> _writeJson(File file, Object value) async {
    await file.parent.create(recursive: true);
    final temporary = File(
      '${file.path}.tmp-${DateTime.now().microsecondsSinceEpoch}',
    );
    try {
      await temporary.writeAsString(jsonEncode(value), flush: true);
      await temporary.rename(file.path);
    } catch (_) {
      if (await temporary.exists()) await temporary.delete();
      rethrow;
    }
  }
}

String _encodePathPart(String value) =>
    base64Url.encode(utf8.encode(value)).replaceAll('=', '');

String _decodePathPart(String value) =>
    utf8.decode(base64Url.decode(base64Url.normalize(value)));

String _encodeBoxName(String value) => utf8
    .encode(value)
    .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
    .join();

String _messagesBoxKey(String conversationId) =>
    'messages_${_encodePathPart(conversationId)}';

String _starredMessagesBoxKey(String conversationId) =>
    'starred_messages_${_encodePathPart(conversationId)}';

const _draftBoxKeyPrefix = 'draft_';

String _draftBoxKey(String conversationId) =>
    '$_draftBoxKeyPrefix${_encodePathPart(conversationId)}';

List<Map<String, dynamic>>? _decodeRows(Object? value) {
  if (value is! List) return null;
  return value
      .whereType<Map>()
      .map((row) => Map<String, dynamic>.from(row))
      .toList();
}
