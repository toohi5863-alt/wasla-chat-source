-- Wasla admin control plane: additive, reversible operational switches.
-- No messages, accounts, groups, or reports are deleted by this migration.

create table if not exists public.wasla_app_settings (
  id smallint primary key default 1 check (id = 1),
  announcement_enabled boolean not null default false,
  announcement_text text not null default '',
  signups_enabled boolean not null default true,
  group_creation_enabled boolean not null default true,
  public_discovery_enabled boolean not null default true,
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id) on delete set null,
  constraint wasla_app_settings_announcement_length check (char_length(announcement_text) <= 300)
);

insert into public.wasla_app_settings(id) values (1)
on conflict (id) do nothing;

alter table public.wasla_app_settings enable row level security;
revoke all on public.wasla_app_settings from public, anon, authenticated;
grant all on public.wasla_app_settings to service_role;

create or replace function private.wasla_feature_enabled(p_feature text)
returns boolean
language sql stable security definer
set search_path = public, private, pg_temp
as $$
  select coalesce(
    case p_feature
      when 'signups_enabled' then (select s.signups_enabled from public.wasla_app_settings s where s.id = 1)
      when 'group_creation_enabled' then (select s.group_creation_enabled from public.wasla_app_settings s where s.id = 1)
      when 'public_discovery_enabled' then (select s.public_discovery_enabled from public.wasla_app_settings s where s.id = 1)
      else false
    end,
    true
  );
$$;
revoke all on function private.wasla_feature_enabled(text) from public, anon, authenticated;

create or replace function private.wasla_guard_signup()
returns trigger
language plpgsql security definer
set search_path = public, private, pg_temp
as $$
begin
  if not private.wasla_feature_enabled('signups_enabled') then
    raise exception 'New sign-ups are temporarily disabled.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_guard_signup() from public, anon, authenticated;
drop trigger if exists wasla_guard_auth_signup on auth.users;
create trigger wasla_guard_auth_signup
before insert on auth.users
for each row execute procedure private.wasla_guard_signup();

create or replace function private.wasla_guard_group_creation()
returns trigger
language plpgsql security definer
set search_path = public, private, pg_temp
as $$
begin
  if not private.wasla_feature_enabled('group_creation_enabled') then
    raise exception 'New group creation is temporarily disabled.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_guard_group_creation() from public, anon, authenticated;
drop trigger if exists wasla_guard_group_creation on public.groups;
create trigger wasla_guard_group_creation
before insert on public.groups
for each row execute procedure private.wasla_guard_group_creation();

create or replace function private.wasla_guard_public_listing()
returns trigger
language plpgsql security definer
set search_path = public, private, pg_temp
as $$
begin
  if new.is_discoverable and not private.wasla_feature_enabled('public_discovery_enabled') then
    raise exception 'Public discovery is temporarily disabled.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_guard_public_listing() from public, anon, authenticated;
drop trigger if exists wasla_guard_public_listing on public.groups;
create trigger wasla_guard_public_listing
before insert or update of is_discoverable on public.groups
for each row execute procedure private.wasla_guard_public_listing();

-- Replace only the discovery RPCs to make the global switch effective server-side.
create or replace function public.discover_public_listings(
  p_listing_type text default 'group',
  p_search text default null,
  p_category text default 'all',
  p_sort text default 'active',
  p_active_only boolean default false,
  p_limit integer default 30,
  p_offset integer default 0
)
returns table (
  conversation_id uuid,
  name text,
  description text,
  avatar_path text,
  category text,
  listing_type text,
  invite_token text,
  member_count integer,
  room_online_count integer,
  activity_7d bigint,
  last_message_at timestamptz,
  created_at timestamptz,
  is_active boolean,
  is_member boolean
)
language plpgsql stable security definer
set search_path = public, private, pg_temp
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_listing_type not in ('group', 'room') then raise exception 'Invalid listing type'; end if;
  if coalesce(p_sort, 'active') not in ('active', 'newest') then raise exception 'Invalid sort order'; end if;
  return query
  select
    g.conversation_id, g.name, g.description, g.avatar_path, g.category,
    g.listing_type, g.invite_token, members.member_count, presence.online_count,
    activity.activity_7d, activity.last_message_at, g.created_at,
    (g.listing_type = 'room' and (presence.online_count > 0 or activity.last_message_at >= now() - interval '15 minutes')),
    exists (select 1 from public.group_members mine
      where mine.conversation_id = g.conversation_id and mine.user_id = auth.uid())
  from public.groups g
  cross join lateral (
    select count(*)::integer as member_count from public.group_members gm
    where gm.conversation_id = g.conversation_id
  ) members
  cross join lateral (
    select count(*)::integer as online_count from public.public_room_presence rp
    where rp.conversation_id = g.conversation_id
      and rp.last_seen_at >= now() - interval '90 seconds'
  ) presence
  cross join lateral (
    select count(*) filter (where m.created_at >= now() - interval '7 days')::bigint as activity_7d,
      max(m.created_at) as last_message_at
    from public.messages m where m.conversation_id = g.conversation_id
  ) activity
  where private.wasla_feature_enabled('public_discovery_enabled')
    and g.is_discoverable and not g.is_private
    and g.listing_type = p_listing_type
    and (coalesce(p_category, 'all') = 'all' or g.category = p_category)
    and (nullif(trim(coalesce(p_search, '')), '') is null
      or g.name ilike '%' || left(trim(p_search), 100) || '%'
      or g.description ilike '%' || left(trim(p_search), 100) || '%')
    and (not coalesce(p_active_only, false)
      or (g.listing_type = 'room'
        and (presence.online_count > 0 or activity.last_message_at >= now() - interval '15 minutes')))
  order by
    case when coalesce(p_sort, 'active') = 'newest' then g.created_at end desc,
    case when coalesce(p_sort, 'active') <> 'newest' then activity.activity_7d end desc,
    activity.last_message_at desc nulls last, g.created_at desc
  limit greatest(1, least(coalesce(p_limit, 30), 50))
  offset greatest(0, least(coalesce(p_offset, 0), 10000));
end;
$$;

create or replace function public.join_public_listing(p_conversation_id uuid)
returns jsonb
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_group public.groups%rowtype;
  v_status text := 'joined';
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if not private.wasla_feature_enabled('public_discovery_enabled') then
    raise exception 'Public discovery is temporarily disabled.';
  end if;
  select * into v_group from public.groups
    where conversation_id = p_conversation_id and is_discoverable and not is_private
    for update;
  if not found then raise exception 'Public group or room not found'; end if;
  if exists (select 1 from public.group_banned_users b
    where b.conversation_id = p_conversation_id and b.user_id = v_me) then
    raise exception 'You cannot join this group';
  end if;
  if exists (select 1 from public.group_members gm
    where gm.conversation_id = p_conversation_id and gm.user_id = v_me) then
    v_status := 'already_member';
  else
    insert into public.conversation_members(conversation_id, user_id)
      values (p_conversation_id, v_me) on conflict do nothing;
    insert into public.group_members(conversation_id, user_id, role)
      values (p_conversation_id, v_me, 'member') on conflict do nothing;
    insert into public.group_activity(conversation_id, actor_id, action)
      values (p_conversation_id, v_me, 'member_joined');
  end if;
  return jsonb_build_object('status', v_status, 'conversation_id', v_group.conversation_id,
    'name', v_group.name, 'description', v_group.description,
    'avatar_path', v_group.avatar_path, 'listing_type', v_group.listing_type);
end;
$$;

create or replace function public.set_public_room_presence(
  p_conversation_id uuid,
  p_active boolean
)
returns void
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if not coalesce(p_active, false) then
    delete from public.public_room_presence
      where conversation_id = p_conversation_id and user_id = v_me;
    return;
  end if;
  if not private.wasla_feature_enabled('public_discovery_enabled') then
    raise exception 'Public discovery is temporarily disabled.';
  end if;
  if not exists (
    select 1 from public.groups g
    join public.group_members gm on gm.conversation_id = g.conversation_id
    where g.conversation_id = p_conversation_id and g.is_discoverable
      and not g.is_private and g.listing_type = 'room' and gm.user_id = v_me
  ) then raise exception 'Join the public room before publishing presence'; end if;
  delete from public.public_room_presence where last_seen_at < now() - interval '90 seconds';
  insert into public.public_room_presence(conversation_id, user_id, last_seen_at)
    values (p_conversation_id, v_me, now())
    on conflict (conversation_id, user_id) do update set last_seen_at = excluded.last_seen_at;
end;
$$;

create or replace function public.get_public_room_online_count(p_conversation_id uuid)
returns integer
language plpgsql stable security definer
set search_path = public, private, pg_temp
as $$
declare v_count integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not private.wasla_feature_enabled('public_discovery_enabled') then return 0; end if;
  if not exists (select 1 from public.groups g
    where g.conversation_id = p_conversation_id and g.is_discoverable
      and not g.is_private and g.listing_type = 'room') then return 0; end if;
  select count(*)::integer into v_count from public.public_room_presence rp
    where rp.conversation_id = p_conversation_id
      and rp.last_seen_at >= now() - interval '90 seconds';
  return coalesce(v_count, 0);
end;
$$;

revoke all on function public.discover_public_listings(text, text, text, text, boolean, integer, integer) from public, anon;
revoke all on function public.join_public_listing(uuid) from public, anon;
revoke all on function public.set_public_room_presence(uuid, boolean) from public, anon;
revoke all on function public.get_public_room_online_count(uuid) from public, anon;
grant execute on function public.discover_public_listings(text, text, text, text, boolean, integer, integer) to authenticated;
grant execute on function public.join_public_listing(uuid) to authenticated;
grant execute on function public.set_public_room_presence(uuid, boolean) to authenticated;
grant execute on function public.get_public_room_online_count(uuid) to authenticated;
