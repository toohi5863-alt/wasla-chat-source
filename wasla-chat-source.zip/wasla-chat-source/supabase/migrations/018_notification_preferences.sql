-- Wasla 1.11: account-wide notification controls, per-conversation mute/snooze,
-- and opt-in notifications for status posts from accepted friends.

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  messages_enabled boolean not null default true,
  groups_enabled boolean not null default true,
  channels_enabled boolean not null default true,
  statuses_enabled boolean not null default false,
  calls_enabled boolean not null default true,
  sound_enabled boolean not null default true,
  vibration_enabled boolean not null default true,
  show_message_preview boolean not null default true,
  do_not_disturb boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.notification_preferences enable row level security;
revoke all on public.notification_preferences from public, anon, authenticated;
grant select, insert, update on public.notification_preferences to authenticated;

drop policy if exists notification_preferences_select_own on public.notification_preferences;
create policy notification_preferences_select_own on public.notification_preferences
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists notification_preferences_insert_own on public.notification_preferences;
create policy notification_preferences_insert_own on public.notification_preferences
  for insert to authenticated
  with check (user_id = (select auth.uid()));

drop policy if exists notification_preferences_update_own on public.notification_preferences;
create policy notification_preferences_update_own on public.notification_preferences
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create table if not exists public.conversation_notification_preferences (
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  notifications_enabled boolean not null default true,
  muted_until timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, conversation_id),
  constraint conversation_notification_preferences_member_fkey
    foreign key (conversation_id, user_id)
    references public.conversation_members(conversation_id, user_id) on delete cascade
);

create index if not exists conversation_notification_preferences_conversation_idx
  on public.conversation_notification_preferences(conversation_id, user_id);

alter table public.conversation_notification_preferences enable row level security;
revoke all on public.conversation_notification_preferences from public, anon, authenticated;
grant select, insert, update, delete on public.conversation_notification_preferences to authenticated;

drop policy if exists conversation_notification_preferences_select_own on public.conversation_notification_preferences;
create policy conversation_notification_preferences_select_own on public.conversation_notification_preferences
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists conversation_notification_preferences_insert_own on public.conversation_notification_preferences;
create policy conversation_notification_preferences_insert_own on public.conversation_notification_preferences
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.conversation_members member
      where member.conversation_id = conversation_notification_preferences.conversation_id
        and member.user_id = (select auth.uid())
    )
  );

drop policy if exists conversation_notification_preferences_update_own on public.conversation_notification_preferences;
create policy conversation_notification_preferences_update_own on public.conversation_notification_preferences
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

drop policy if exists conversation_notification_preferences_delete_own on public.conversation_notification_preferences;
create policy conversation_notification_preferences_delete_own on public.conversation_notification_preferences
  for delete to authenticated
  using (user_id = (select auth.uid()));

create table if not exists public.status_notification_subscriptions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, author_id),
  constraint status_notification_subscriptions_not_self check (user_id <> author_id)
);

create index if not exists status_notification_subscriptions_author_idx
  on public.status_notification_subscriptions(author_id, user_id);

alter table public.status_notification_subscriptions enable row level security;
revoke all on public.status_notification_subscriptions from public, anon, authenticated;
grant select, insert, update, delete on public.status_notification_subscriptions to authenticated;

drop policy if exists status_notification_subscriptions_select_own on public.status_notification_subscriptions;
create policy status_notification_subscriptions_select_own on public.status_notification_subscriptions
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists status_notification_subscriptions_insert_friend on public.status_notification_subscriptions;
create policy status_notification_subscriptions_insert_friend on public.status_notification_subscriptions
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and author_id <> (select auth.uid())
    and exists (
      select 1 from public.friend_requests friendship
      where friendship.status = 'accepted'
        and (
          (friendship.requester_id = (select auth.uid()) and friendship.addressee_id = author_id)
          or (friendship.addressee_id = (select auth.uid()) and friendship.requester_id = author_id)
        )
    )
  );

drop policy if exists status_notification_subscriptions_update_friend on public.status_notification_subscriptions;
create policy status_notification_subscriptions_update_friend on public.status_notification_subscriptions
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and author_id <> (select auth.uid())
    and exists (
      select 1 from public.friend_requests friendship
      where friendship.status = 'accepted'
        and (
          (friendship.requester_id = (select auth.uid()) and friendship.addressee_id = author_id)
          or (friendship.addressee_id = (select auth.uid()) and friendship.requester_id = author_id)
        )
    )
  );

drop policy if exists status_notification_subscriptions_delete_own on public.status_notification_subscriptions;
create policy status_notification_subscriptions_delete_own on public.status_notification_subscriptions
  for delete to authenticated
  using (user_id = (select auth.uid()));
