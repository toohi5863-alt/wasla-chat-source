import 'dart:io';

import 'package:chat/call_history_preferences.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  late Directory directory;
  late CallHistoryPreferencesStore store;

  setUp(() async {
    directory = await Directory.systemTemp.createTemp('wasla-call-history-');
    store = CallHistoryPreferencesStore(
      supportDirectoryProvider: () async => directory,
    );
  });

  tearDown(() async {
    if (await directory.exists()) await directory.delete(recursive: true);
  });

  test('persists hidden call IDs separately for each account', () async {
    await store.save('user-a', {'call-1', 'call-2'});
    await store.save('user-b', {'call-3'});

    expect(await store.load('user-a'), {'call-1', 'call-2'});
    expect(await store.load('user-b'), {'call-3'});
    expect(await store.load('user-c'), isEmpty);
  });

  test('replacing one account list preserves other accounts', () async {
    await store.save('user-a', {'call-1'});
    await store.save('user-b', {'call-2'});
    await store.save('user-a', {'call-4'});

    expect(await store.load('user-a'), {'call-4'});
    expect(await store.load('user-b'), {'call-2'});
  });

  test('ignores malformed local preference documents safely', () async {
    await File('${directory.path}/wasla_call_history_preferences.json')
        .writeAsString('{broken');

    expect(await store.load('user-a'), isEmpty);
  });
}
