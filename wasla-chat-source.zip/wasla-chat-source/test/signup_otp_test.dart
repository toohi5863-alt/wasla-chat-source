import 'package:flutter_test/flutter_test.dart';
import 'package:chat/signup_otp.dart';

void main() {
  group('isValidSignupOtp', () {
    for (var length = 6; length <= 10; length++) {
      test('accepts $length numeric digits without changing the input', () {
        final code = '1234567890'.substring(0, length);

        expect(isValidSignupOtp(code), isTrue);
        expect(code, '1234567890'.substring(0, length));
      });
    }

    test('rejects codes shorter than six or longer than ten digits', () {
      expect(isValidSignupOtp('12345'), isFalse);
      expect(isValidSignupOtp('12345678901'), isFalse);
    });

    test('rejects non-digits and whitespace rather than altering input', () {
      expect(isValidSignupOtp('12345a'), isFalse);
      expect(isValidSignupOtp('123 456'), isFalse);
      expect(isValidSignupOtp(' 123456'), isFalse);
      expect(isValidSignupOtp('123456 '), isFalse);
    });
  });
}
