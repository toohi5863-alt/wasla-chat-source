import 'package:chat/status_helpers.dart';
import 'package:chat/status_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final now = DateTime.utc(2026, 10, 9, 10);

  StatusItem status({
    required String id,
    required String userId,
    required int minutesAgo,
    required bool viewed,
  }) => StatusItem(
    id: id,
    userId: userId,
    username: userId,
    displayName: userId,
    contentType: 'text',
    backgroundColor: 0xFF087F72,
    createdAt: now.subtract(Duration(minutes: minutesAgo)),
    expiresAt: now.add(const Duration(hours: 24)),
    isMine: userId == 'me',
    isViewed: viewed,
    viewsCount: 0,
  );

  test('groups newest first and prioritizes authors with unseen statuses', () {
    final groups = groupFriendStatuses([
      status(
        id: 'seen-old',
        userId: 'seen-friend',
        minutesAgo: 40,
        viewed: true,
      ),
      status(
        id: 'unseen-old',
        userId: 'new-friend',
        minutesAgo: 20,
        viewed: false,
      ),
      status(
        id: 'unseen-new',
        userId: 'new-friend',
        minutesAgo: 5,
        viewed: false,
      ),
      status(id: 'mine', userId: 'me', minutesAgo: 1, viewed: false),
    ], currentUserId: 'me');

    expect(groups.map((group) => group.userId), ['new-friend', 'seen-friend']);
    expect(groups.first.statuses.map((item) => item.id), [
      'unseen-new',
      'unseen-old',
    ]);
    expect(groups.first.hasUnseen, isTrue);
    expect(groups.last.hasUnseen, isFalse);
  });

  test('unseen-only feed removes viewed statuses and empty authors', () {
    final groups = groupFriendStatuses(
      [
        status(id: 'read-1', userId: 'friend-a', minutesAgo: 30, viewed: true),
        status(
          id: 'unread-1',
          userId: 'friend-a',
          minutesAgo: 10,
          viewed: false,
        ),
        status(id: 'read-2', userId: 'friend-b', minutesAgo: 1, viewed: true),
      ],
      currentUserId: 'me',
      unseenOnly: true,
    );

    expect(groups, hasLength(1));
    expect(groups.single.userId, 'friend-a');
    expect(groups.single.statuses.map((item) => item.id), ['unread-1']);
    expect(groups.single.hasUnseen, isTrue);
  });
}
