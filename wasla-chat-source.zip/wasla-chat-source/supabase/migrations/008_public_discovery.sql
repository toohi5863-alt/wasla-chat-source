-- Wasla 1.7: opt-in public discovery for groups and chat rooms.
-- Existing groups remain undiscoverable unless their owner explicitly enables it.

alter table public.groups
  add column if not exists is_discoverable boolean not null default false,
  add column if not exists category text not null default 'other'
    check (category in ('news', 'sports', 'technology', 'games', 'education', 'entertainment', 'other')),
  add column if not exists listing_type text not null default 'group'
    check (listing_type in ('group', 'room'));

create index if not exists groups_public_discovery_idx
  on public.groups (listing_type, category, created_at desc)
  where is_discoverable and not is_private;
create table if not exists public.public_room_presence (
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  last_seen_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create index if not exists public_room_presence_recent_idx
  on public.public_room_presence (conversation_id, last_seen_at desc);
create index if not exists public_room_presence_last_seen_idx
  on public.public_room_presence (last_seen_at);
alter table public.public_room_presence enable row level security;
revoke all on public.public_room_presence from public, anon, authenticated;

create table if not exists public.public_content_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  target_user_id uuid references public.profiles(id) on delete set null,
  report_type text not null check (report_type in ('listing', 'user')),
  reason text not null check (reason in ('spam', 'harassment', 'inappropriate', 'impersonation', 'other')),
  details text not null default '' check (char_length(details) <= 500),
  status text not null default 'open' check (status in ('open', 'actioned', 'dismissed')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id) on delete set null,
  constraint public_content_reports_target_check check (
    (report_type = 'listing' and target_user_id is null)
    or (report_type = 'user' and target_user_id is not null)
  )
);
create index if not exists public_content_reports_group_status_idx
  on public.public_content_reports (conversation_id, status, created_at desc);
alter table public.public_content_reports enable row level security;
revoke all on public.public_content_reports from public, anon, authenticated;
grant select on public.public_content_reports to authenticated;
drop policy if exists public_content_reports_select_own_or_admin on public.public_content_reports;
create policy public_content_reports_select_own_or_admin
  on public.public_content_reports for select to authenticated
  using (reporter_id = (select auth.uid()) or private.is_group_admin(conversation_id));

create or replace function public.update_group_discovery_settings(
  p_conversation_id uuid,
  p_is_discoverable boolean,
  p_category text,
  p_listing_type text
)
returns void
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_is_private boolean;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not private.is_group_owner(p_conversation_id) then
    raise exception 'Only the group owner can change public discovery settings';
  end if;
  if p_category not in ('news', 'sports', 'technology', 'games', 'education', 'entertainment', 'other') then
    raise exception 'Invalid category';
  end if;
  if p_listing_type not in ('group', 'room') then
    raise exception 'Invalid listing type';
  end if;
  select is_private into v_is_private from public.groups
    where conversation_id = p_conversation_id;
  if v_is_private is null then raise exception 'Group not found'; end if;
  if coalesce(p_is_discoverable, false) and v_is_private then
    raise exception 'Private groups cannot be publicly discoverable';
  end if;
  update public.groups set
    is_discoverable = coalesce(p_is_discoverable, false),
    category = p_category,
    listing_type = p_listing_type,
    updated_at = now()
  where conversation_id = p_conversation_id;
end;
$$;

create or replace function public.discover_public_listings(
  p_listing_type text default 'group',
  p_search text default null,
  p_category text default 'all',
  p_sort text default 'active',
  p_active_only boolean default false,
  p_limit integer default 30,
  p_offset integer default 0
)
returns table (
  conversation_id uuid,
  name text,
  description text,
  avatar_path text,
  category text,
  listing_type text,
  invite_token text,
  member_count integer,
  room_online_count integer,
  activity_7d bigint,
  last_message_at timestamptz,
  created_at timestamptz,
  is_active boolean,
  is_member boolean
)
language plpgsql stable security definer
set search_path = public, private, pg_temp
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_listing_type not in ('group', 'room') then raise exception 'Invalid listing type'; end if;
  if coalesce(p_sort, 'active') not in ('active', 'newest') then raise exception 'Invalid sort order'; end if;
  return query
  select
    g.conversation_id,
    g.name,
    g.description,
    g.avatar_path,
    g.category,
    g.listing_type,
    g.invite_token,
    members.member_count,
    presence.online_count,
    activity.activity_7d,
    activity.last_message_at,
    g.created_at,
    (g.listing_type = 'room' and (presence.online_count > 0 or activity.last_message_at >= now() - interval '15 minutes')),
    exists (
      select 1 from public.group_members mine
      where mine.conversation_id = g.conversation_id and mine.user_id = auth.uid()
    )
  from public.groups g
  cross join lateral (
    select count(*)::integer as member_count
    from public.group_members gm where gm.conversation_id = g.conversation_id
  ) members
  cross join lateral (
    select count(*)::integer as online_count
    from public.public_room_presence rp
    where rp.conversation_id = g.conversation_id
      and rp.last_seen_at >= now() - interval '90 seconds'
  ) presence
  cross join lateral (
    select count(*) filter (where m.created_at >= now() - interval '7 days')::bigint as activity_7d,
      max(m.created_at) as last_message_at
    from public.messages m where m.conversation_id = g.conversation_id
  ) activity
  where g.is_discoverable and not g.is_private
    and g.listing_type = p_listing_type
    and (coalesce(p_category, 'all') = 'all' or g.category = p_category)
    and (nullif(trim(coalesce(p_search, '')), '') is null
      or g.name ilike '%' || left(trim(p_search), 100) || '%'
      or g.description ilike '%' || left(trim(p_search), 100) || '%')
    and (not coalesce(p_active_only, false)
      or (g.listing_type = 'room'
        and (presence.online_count > 0 or activity.last_message_at >= now() - interval '15 minutes')))
  order by
    case when coalesce(p_sort, 'active') = 'newest' then g.created_at end desc,
    case when coalesce(p_sort, 'active') <> 'newest' then activity.activity_7d end desc,
    activity.last_message_at desc nulls last,
    g.created_at desc
  limit greatest(1, least(coalesce(p_limit, 30), 50))
  offset greatest(0, least(coalesce(p_offset, 0), 10000));
end;
$$;

create or replace function public.join_public_listing(p_conversation_id uuid)
returns jsonb
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_group public.groups%rowtype;
  v_status text := 'joined';
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  select * into v_group from public.groups
    where conversation_id = p_conversation_id and is_discoverable and not is_private
    for update;
  if not found then raise exception 'Public group or room not found'; end if;
  if exists (select 1 from public.group_banned_users b
    where b.conversation_id = p_conversation_id and b.user_id = v_me) then
    raise exception 'You cannot join this group';
  end if;
  if exists (select 1 from public.group_members gm
    where gm.conversation_id = p_conversation_id and gm.user_id = v_me) then
    v_status := 'already_member';
  else
    insert into public.conversation_members(conversation_id, user_id)
      values (p_conversation_id, v_me) on conflict do nothing;
    insert into public.group_members(conversation_id, user_id, role)
      values (p_conversation_id, v_me, 'member') on conflict do nothing;
    insert into public.group_activity(conversation_id, actor_id, action)
      values (p_conversation_id, v_me, 'member_joined');
  end if;
  return jsonb_build_object(
    'status', v_status,
    'conversation_id', v_group.conversation_id,
    'name', v_group.name,
    'description', v_group.description,
    'avatar_path', v_group.avatar_path,
    'listing_type', v_group.listing_type
  );
end;
$$;

create or replace function public.set_public_room_presence(
  p_conversation_id uuid,
  p_active boolean
)
returns void
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if not coalesce(p_active, false) then
    delete from public.public_room_presence
      where conversation_id = p_conversation_id and user_id = v_me;
    return;
  end if;
  if not exists (
    select 1 from public.groups g
    join public.group_members gm on gm.conversation_id = g.conversation_id
    where g.conversation_id = p_conversation_id and g.is_discoverable
      and not g.is_private and g.listing_type = 'room' and gm.user_id = v_me
  ) then
    raise exception 'Join the public room before publishing presence';
  end if;
  delete from public.public_room_presence
    where last_seen_at < now() - interval '90 seconds';
  insert into public.public_room_presence(conversation_id, user_id, last_seen_at)
    values (p_conversation_id, v_me, now())
    on conflict (conversation_id, user_id) do update set last_seen_at = excluded.last_seen_at;
end;
$$;

create or replace function public.get_public_room_online_count(p_conversation_id uuid)
returns integer
language plpgsql stable security definer
set search_path = public, private, pg_temp
as $$
declare
  v_count integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.groups g
    where g.conversation_id = p_conversation_id and g.is_discoverable
      and not g.is_private and g.listing_type = 'room') then
    return 0;
  end if;
  select count(*)::integer into v_count from public.public_room_presence rp
    where rp.conversation_id = p_conversation_id
      and rp.last_seen_at >= now() - interval '90 seconds';
  return coalesce(v_count, 0);
end;
$$;

create or replace function public.submit_public_content_report(
  p_conversation_id uuid,
  p_report_type text,
  p_target_user_id uuid default null,
  p_reason text default 'other',
  p_details text default ''
)
returns uuid
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_report_id uuid;
  v_is_public boolean;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_report_type not in ('listing', 'user') then raise exception 'Invalid report type'; end if;
  if p_reason not in ('spam', 'harassment', 'inappropriate', 'impersonation', 'other') then
    raise exception 'Invalid report reason';
  end if;
  if char_length(coalesce(p_details, '')) > 500 then raise exception 'Report details are too long'; end if;
  select (is_discoverable and not is_private) into v_is_public
    from public.groups where conversation_id = p_conversation_id;
  if v_is_public is null then raise exception 'Group or room not found'; end if;
  if not v_is_public and not private.is_conversation_member(p_conversation_id) then
    raise exception 'Only members can report private groups';
  end if;
  if p_report_type = 'listing' and p_target_user_id is not null then
    raise exception 'A listing report cannot name a user';
  end if;
  if p_report_type = 'user' then
    if p_target_user_id is null or p_target_user_id = v_me then raise exception 'Choose another user'; end if;
    if not exists (select 1 from public.group_members gm
      where gm.conversation_id = p_conversation_id and gm.user_id = p_target_user_id) then
      raise exception 'The reported user is not a member of this group';
    end if;
  end if;
  insert into public.public_content_reports(
    reporter_id, conversation_id, target_user_id, report_type, reason, details
  ) values (
    v_me, p_conversation_id, p_target_user_id, p_report_type, p_reason, trim(coalesce(p_details, ''))
  ) returning id into v_report_id;
  return v_report_id;
end;
$$;

create or replace function public.list_public_content_reports(p_conversation_id uuid)
returns table (
  report_id uuid,
  reporter_id uuid,
  reporter_name text,
  target_user_id uuid,
  target_user_name text,
  report_type text,
  reason text,
  details text,
  status text,
  created_at timestamptz
)
language plpgsql stable security definer
set search_path = public, private, pg_temp
as $$
begin
  if auth.uid() is null or not private.is_group_admin(p_conversation_id) then
    raise exception 'Only group moderators can view reports';
  end if;
  return query
  select r.id, r.reporter_id,
    coalesce(nullif(trim(reporter.display_name), ''), '@' || reporter.username),
    r.target_user_id,
    case when target.id is null then null
      else coalesce(nullif(trim(target.display_name), ''), '@' || target.username) end,
    r.report_type, r.reason, r.details, r.status, r.created_at
  from public.public_content_reports r
  join public.profiles reporter on reporter.id = r.reporter_id
  left join public.profiles target on target.id = r.target_user_id
  where r.conversation_id = p_conversation_id
  order by case when r.status = 'open' then 0 else 1 end, r.created_at desc
  limit 200;
end;
$$;

create or replace function public.resolve_public_content_report(
  p_report_id uuid,
  p_status text
)
returns void
language plpgsql volatile security definer
set search_path = public, private, pg_temp
as $$
declare
  v_conversation_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_status not in ('actioned', 'dismissed') then raise exception 'Invalid report status'; end if;
  select conversation_id into v_conversation_id from public.public_content_reports
    where id = p_report_id;
  if v_conversation_id is null or not private.is_group_admin(v_conversation_id) then
    raise exception 'Only group moderators can resolve reports';
  end if;
  update public.public_content_reports set status = p_status,
    reviewed_at = now(), reviewed_by = auth.uid()
  where id = p_report_id;
end;
$$;

revoke all on function public.update_group_discovery_settings(uuid, boolean, text, text) from public, anon;
revoke all on function public.discover_public_listings(text, text, text, text, boolean, integer, integer) from public, anon;
revoke all on function public.join_public_listing(uuid) from public, anon;
revoke all on function public.set_public_room_presence(uuid, boolean) from public, anon;
revoke all on function public.get_public_room_online_count(uuid) from public, anon;
revoke all on function public.submit_public_content_report(uuid, text, uuid, text, text) from public, anon;
revoke all on function public.list_public_content_reports(uuid) from public, anon;
revoke all on function public.resolve_public_content_report(uuid, text) from public, anon;
grant execute on function public.update_group_discovery_settings(uuid, boolean, text, text) to authenticated;
grant execute on function public.discover_public_listings(text, text, text, text, boolean, integer, integer) to authenticated;
grant execute on function public.join_public_listing(uuid) to authenticated;
grant execute on function public.set_public_room_presence(uuid, boolean) to authenticated;
grant execute on function public.get_public_room_online_count(uuid) to authenticated;
grant execute on function public.submit_public_content_report(uuid, text, uuid, text, text) to authenticated;
grant execute on function public.list_public_content_reports(uuid) to authenticated;
grant execute on function public.resolve_public_content_report(uuid, text) to authenticated;
