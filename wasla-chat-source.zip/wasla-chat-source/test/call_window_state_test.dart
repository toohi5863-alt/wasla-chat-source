import 'package:flutter_test/flutter_test.dart';
import 'package:chat/calls.dart';

void main() {
  group('CallWindowState', () {
    test('minimize and restore keep the same active call', () {
      final window = CallWindowState('call-42');

      expect(window.callId, 'call-42');
      expect(window.mode, CallWindowMode.expanded);
      expect(window.isCallActive, isTrue);

      window.minimize();
      expect(window.mode, CallWindowMode.minimized);
      expect(window.isCallActive, isTrue);
      expect(window.callId, 'call-42');

      window.restore();
      expect(window.mode, CallWindowMode.expanded);
      expect(window.isCallActive, isTrue);
      expect(window.callId, 'call-42');
    });

    test(
      'repeated presentation changes are idempotent and do not end a call',
      () {
        final window = CallWindowState('call-video-7');

        window.minimize();
        window.minimize();
        expect(window.isMinimized, isTrue);
        expect(window.isCallActive, isTrue);

        window.restore();
        window.restore();
        expect(window.mode, CallWindowMode.expanded);
        expect(window.isCallActive, isTrue);

        window.end();
        expect(window.isCallActive, isFalse);
        window.minimize();
        window.restore();
        expect(window.mode, CallWindowMode.expanded);
        expect(window.isCallActive, isFalse);
      },
    );
  });
}
