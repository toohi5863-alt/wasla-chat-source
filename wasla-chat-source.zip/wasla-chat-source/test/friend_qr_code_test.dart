import 'package:flutter_test/flutter_test.dart';
import 'package:chat/friend_qr_code.dart';

void main() {
  group('FriendQrCode.parse', () {
    test('accepts a stable Wasla user link and normalizes its id', () {
      final code = FriendQrCode.parse(
        'wasla://user/ABCDEF12-3456-7890-abcd-ef1234567890',
      );

      expect(code, isNotNull);
      expect(code!.identifiesUserId, isTrue);
      expect(code.userId, 'abcdef12-3456-7890-abcd-ef1234567890');
      expect(code.username, isNull);
    });

    test(
      'accepts existing username QR payloads for backwards compatibility',
      () {
        final code = FriendQrCode.parse('  @darwish_1  ');

        expect(code, isNotNull);
        expect(code!.identifiesUserId, isFalse);
        expect(code.username, 'darwish_1');
      },
    );

    test('rejects blank, malformed, unrelated and overly long payloads', () {
      expect(FriendQrCode.parse(null), isNull);
      expect(FriendQrCode.parse('   '), isNull);
      expect(FriendQrCode.parse('@bad-name'), isNull);
      expect(FriendQrCode.parse('https://example.com/@user'), isNull);
      expect(FriendQrCode.parse('wasla://join/invite-token'), isNull);
      expect(FriendQrCode.parse('wasla://user/not-a-uuid'), isNull);
      expect(
        FriendQrCode.parse(
          'wasla://user/123e4567-e89b-12d3-a456-426614174000?next=x',
        ),
        isNull,
      );
      expect(FriendQrCode.parse('x' * 257), isNull);
    });
  });
}
