import 'package:flutter_test/flutter_test.dart';

import 'package:chat/presence_status.dart';

void main() {
  group('UserPresenceStatus', () {
    test('parses the three persisted values', () {
      expect(
        UserPresenceStatus.fromValue('available'),
        UserPresenceStatus.available,
      );
      expect(
        UserPresenceStatus.fromValue('working'),
        UserPresenceStatus.working,
      );
      expect(UserPresenceStatus.fromValue('busy'), UserPresenceStatus.busy);
    });

    test('uses available as the safe fallback for unknown values', () {
      expect(UserPresenceStatus.fromValue(null), UserPresenceStatus.available);
      expect(
        UserPresenceStatus.fromValue('story'),
        UserPresenceStatus.available,
      );
    });

    test(
      'temporarily shows unavailable without replacing the saved choice',
      () {
        const selected = UserPresenceStatus.working;

        final offline = effectivePresenceStatus(selected, online: false);
        final reconnected = effectivePresenceStatus(selected, online: true);

        expect(offline, UserPresenceStatus.unavailable);
        expect(reconnected, UserPresenceStatus.working);
        expect(UserPresenceStatus.selectableStatuses, isNot(contains(offline)));
      },
    );

    test('exposes clear Arabic labels and distinct colors', () {
      expect(UserPresenceStatus.available.label, 'متواجد');
      expect(UserPresenceStatus.working.label, 'في العمل');
      expect(UserPresenceStatus.busy.label, 'مشغول');
      expect(UserPresenceStatus.unavailable.label, 'غير متوفر');
      expect({
        UserPresenceStatus.available.color,
        UserPresenceStatus.working.color,
        UserPresenceStatus.busy.color,
      }, hasLength(3));
    });
  });
}
