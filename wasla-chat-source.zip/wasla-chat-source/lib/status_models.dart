class StatusItem {
  const StatusItem({
    required this.id,
    required this.userId,
    required this.username,
    required this.displayName,
    required this.contentType,
    required this.backgroundColor,
    required this.createdAt,
    required this.expiresAt,
    required this.isMine,
    required this.isViewed,
    required this.viewsCount,
    this.avatarPath,
    this.body,
    this.mediaPath,
    this.privacy = 'friends',
  });

  final String id;
  final String userId;
  final String username;
  final String displayName;
  final String? avatarPath;
  final String contentType;
  final String? body;
  final String? mediaPath;
  final int backgroundColor;
  final String privacy;
  final DateTime createdAt;
  final DateTime expiresAt;
  final bool isMine;
  final bool isViewed;
  final int viewsCount;

  String get authorLabel => displayName.isNotEmpty ? displayName : '@$username';

  factory StatusItem.fromMap(Map<String, dynamic> map) => StatusItem(
    id: map['id']?.toString() ?? '',
    userId: map['user_id']?.toString() ?? '',
    username: map['username']?.toString() ?? '',
    displayName: map['display_name']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
    contentType: map['content_type']?.toString() ?? 'text',
    body: map['body']?.toString(),
    mediaPath: map['media_path']?.toString(),
    backgroundColor:
        int.tryParse(map['background_color']?.toString() ?? '') ?? 0xFF087F72,
    privacy: map['privacy']?.toString() ?? 'friends',
    createdAt: _statusDate(map['created_at']),
    expiresAt: _statusDate(map['expires_at']),
    isMine: map['is_mine'] == true,
    isViewed: map['is_viewed'] == true,
    viewsCount: int.tryParse(map['views_count']?.toString() ?? '') ?? 0,
  );
}

class StatusViewer {
  const StatusViewer({
    required this.userId,
    required this.username,
    required this.displayName,
    required this.viewedAt,
    this.avatarPath,
  });

  final String userId;
  final String username;
  final String displayName;
  final String? avatarPath;
  final DateTime viewedAt;

  String get label => displayName.isNotEmpty ? displayName : '@$username';

  factory StatusViewer.fromMap(Map<String, dynamic> map) => StatusViewer(
    userId: map['viewer_id']?.toString() ?? '',
    username: map['username']?.toString() ?? '',
    displayName: map['display_name']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
    viewedAt: _statusDate(map['viewed_at']),
  );
}

class StatusReply {
  const StatusReply({
    required this.id,
    required this.statusId,
    required this.senderId,
    required this.body,
    required this.createdAt,
    this.senderUsername = '',
    this.senderDisplayName = '',
    this.senderAvatarPath,
  });

  final String id;
  final String statusId;
  final String senderId;
  final String body;
  final DateTime createdAt;
  final String senderUsername;
  final String senderDisplayName;
  final String? senderAvatarPath;

  String get senderLabel => senderDisplayName.isNotEmpty
      ? senderDisplayName
      : senderUsername.isNotEmpty
      ? '@$senderUsername'
      : 'مستخدم وصال';

  factory StatusReply.fromMap(Map<String, dynamic> map) {
    final senderValue = map['sender'];
    final sender = senderValue is Map
        ? Map<String, dynamic>.from(senderValue)
        : const <String, dynamic>{};
    return StatusReply(
      id: map['id']?.toString() ?? '',
      statusId: map['status_id']?.toString() ?? '',
      senderId: map['sender_id']?.toString() ?? '',
      body: map['body']?.toString() ?? '',
      createdAt: _statusDate(map['created_at']),
      senderUsername: sender['username']?.toString() ?? '',
      senderDisplayName: sender['display_name']?.toString() ?? '',
      senderAvatarPath: sender['avatar_path']?.toString(),
    );
  }
}

DateTime _statusDate(dynamic value) =>
    DateTime.tryParse(value?.toString() ?? '')?.toLocal() ?? DateTime.now();
