import { Webhook } from "https://esm.sh/standardwebhooks@1.0.0";
import { buildAuthenticationTemplatePayload } from "./payload.ts";

type SendSmsHookPayload = {
  user?: { phone?: unknown };
  sms?: { otp?: unknown };
};

const jsonHeaders = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function hookError(httpCode: number, message: string): Response {
  return new Response(
    JSON.stringify({ error: { http_code: httpCode, message } }),
    { status: httpCode, headers: jsonHeaders },
  );
}

function requiredSetting(name: string): string {
  const value = Deno.env.get(name)?.trim();
  if (!value) throw new Error(`Missing setting: ${name}`);
  return value;
}

Deno.serve(async (request: Request): Promise<Response> => {
  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const rawBody = await request.text();
  const configuredHookSecret = Deno.env.get("SEND_SMS_HOOK_SECRET")?.trim();
  if (!configuredHookSecret) {
    console.error("WhatsApp auth hook signing secret is not configured");
    return hookError(500, "WhatsApp authentication is not configured.");
  }

  const webhookSecret = configuredHookSecret.replace(/^v1,whsec_/, "");
  let event: SendSmsHookPayload;
  try {
    const webhook = new Webhook(webhookSecret);
    event = webhook.verify(
      rawBody,
      Object.fromEntries(request.headers.entries()),
    ) as SendSmsHookPayload;
  } catch (_) {
    return hookError(401, "Invalid authentication hook signature.");
  }

  const phone = event.user?.phone;
  const otp = event.sms?.otp;
  if (typeof phone !== "string" || typeof otp !== "string") {
    return hookError(400, "Invalid authentication hook payload.");
  }

  let accessToken: string;
  let phoneNumberId: string;
  let templateName: string;
  let templateLanguage: string;
  let graphVersion: string;
  try {
    accessToken = requiredSetting("META_WHATSAPP_ACCESS_TOKEN");
    phoneNumberId = requiredSetting("META_WHATSAPP_PHONE_NUMBER_ID");
    templateName = requiredSetting("META_WHATSAPP_AUTH_TEMPLATE_NAME");
    templateLanguage = requiredSetting("META_WHATSAPP_AUTH_TEMPLATE_LANGUAGE");
    graphVersion = Deno.env.get("META_GRAPH_API_VERSION")?.trim() || "v26.0";
    if (!/^\d+$/.test(phoneNumberId) || !/^v\d+\.\d+$/.test(graphVersion)) {
      throw new Error("Invalid Meta WhatsApp API settings");
    }
  } catch (_) {
    console.error("WhatsApp auth hook Meta settings are incomplete or invalid");
    return hookError(500, "WhatsApp authentication is not configured.");
  }

  let message: ReturnType<typeof buildAuthenticationTemplatePayload>;
  try {
    message = buildAuthenticationTemplatePayload({
      phone,
      otp,
      templateName,
      language: templateLanguage,
    });
  } catch (_) {
    return hookError(
      400,
      "Invalid phone, code, or authentication template settings.",
    );
  }

  let metaResponse: Response;
  try {
    metaResponse = await fetch(
      `https://graph.facebook.com/${graphVersion}/${phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${accessToken}`,
          "content-type": "application/json",
        },
        body: JSON.stringify(message),
        // Supabase Auth HTTP Hooks have a five-second execution window.
        signal: AbortSignal.timeout(4000),
      },
    );
  } catch (_) {
    console.error("Meta WhatsApp Graph API request failed or timed out");
    return hookError(502, "Could not send the WhatsApp verification code.");
  }

  if (!metaResponse.ok) {
    // Do not log the phone number, OTP, access token, or Meta response body.
    console.error(
      `Meta WhatsApp Graph API returned HTTP ${metaResponse.status}`,
    );
    return hookError(502, "Could not send the WhatsApp verification code.");
  }

  return new Response("{}", { status: 200, headers: jsonHeaders });
});
