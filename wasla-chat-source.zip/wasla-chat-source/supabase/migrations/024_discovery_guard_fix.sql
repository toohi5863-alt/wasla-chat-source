-- Allow edits to an already-public listing while global discovery is paused;
-- only block new rows or false-to-true transitions in that state.
create or replace function private.wasla_guard_public_listing()
returns trigger
language plpgsql security definer
set search_path = public, private, pg_temp
as $$
begin
  if tg_op = 'INSERT' then
    if new.is_discoverable and not private.wasla_feature_enabled('public_discovery_enabled') then
      raise exception 'Public discovery is temporarily disabled.' using errcode = 'P0001';
    end if;
  elsif not old.is_discoverable and new.is_discoverable
    and not private.wasla_feature_enabled('public_discovery_enabled') then
    raise exception 'Public discovery is temporarily disabled.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
