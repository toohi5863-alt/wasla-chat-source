class GroupInfo {
  const GroupInfo({
    required this.conversationId,
    required this.name,
    required this.description,
    required this.ownerId,
    required this.inviteToken,
    this.avatarPath,
    this.isPrivate = false,
    this.membersCanMessage = true,
    this.membersCanAdd = false,
    this.membersCanEditInfo = false,
    this.adminsCanManageMembers = true,
    this.adminsCanPinMessages = true,
    this.adminsCanDeleteMessages = true,
    this.filesAllowed = true,
    this.voiceAllowed = true,
    this.callsAllowed = false,
    this.memberCount = 0,
    this.isDiscoverable = false,
    this.category = 'other',
    this.listingType = 'group',
    this.updatedAt,
  });

  final String conversationId;
  final String name;
  final String description;
  final String ownerId;
  final String inviteToken;
  final String? avatarPath;
  final bool isPrivate;
  final bool membersCanMessage;
  final bool membersCanAdd;
  final bool membersCanEditInfo;
  final bool adminsCanManageMembers;
  final bool adminsCanPinMessages;
  final bool adminsCanDeleteMessages;
  final bool filesAllowed;
  final bool voiceAllowed;
  final bool callsAllowed;
  final int memberCount;
  final bool isDiscoverable;
  final String category;
  final String listingType;
  final DateTime? updatedAt;

  factory GroupInfo.fromMap(Map<String, dynamic> map) => GroupInfo(
    conversationId: map['conversation_id'].toString(),
    name: map['name']?.toString() ?? '',
    description: map['description']?.toString() ?? '',
    ownerId: map['owner_id']?.toString() ?? '',
    inviteToken: map['invite_token']?.toString() ?? '',
    avatarPath: map['avatar_path']?.toString(),
    isPrivate: _bool(map['is_private'], false),
    membersCanMessage: _bool(map['members_can_message'], true),
    membersCanAdd: _bool(map['members_can_add'], false),
    membersCanEditInfo: _bool(map['members_can_edit_info'], false),
    adminsCanManageMembers: _bool(map['admins_can_manage_members'], true),
    adminsCanPinMessages: _bool(map['admins_can_pin_messages'], true),
    adminsCanDeleteMessages: _bool(map['admins_can_delete_messages'], true),
    filesAllowed: _bool(map['files_allowed'], true),
    voiceAllowed: _bool(map['voice_allowed'], true),
    callsAllowed: _bool(map['calls_allowed'], false),
    memberCount: _int(map['member_count']),
    isDiscoverable: _bool(map['is_discoverable'], false),
    category: map['category']?.toString() ?? 'other',
    listingType: map['listing_type']?.toString() ?? 'group',
    updatedAt: _date(map['updated_at']),
  );
}

class GroupMember {
  const GroupMember({
    required this.userId,
    required this.role,
    required this.username,
    required this.displayName,
    this.avatarPath,
    this.joinedAt,
  });

  final String userId;
  final String role;
  final String username;
  final String displayName;
  final String? avatarPath;
  final DateTime? joinedAt;

  String get displayLabel =>
      displayName.isNotEmpty ? displayName : '@$username';
}

class GroupJoinRequest {
  const GroupJoinRequest({
    required this.id,
    required this.userId,
    required this.username,
    required this.displayName,
    required this.message,
    required this.requestedAt,
  });

  final String id;
  final String userId;
  final String username;
  final String displayName;
  final String message;
  final DateTime? requestedAt;

  String get displayLabel =>
      displayName.isNotEmpty ? displayName : '@$username';
}

class GroupActivityEntry {
  const GroupActivityEntry({
    required this.action,
    required this.actorName,
    required this.targetName,
    required this.createdAt,
  });

  final String action;
  final String actorName;
  final String targetName;
  final DateTime? createdAt;
}

bool _bool(dynamic value, bool fallback) => value is bool
    ? value
    : value == null
    ? fallback
    : value.toString().toLowerCase() == 'true';

int _int(dynamic value) =>
    value is num ? value.toInt() : int.tryParse(value?.toString() ?? '') ?? 0;

DateTime? _date(dynamic value) =>
    value == null ? null : DateTime.tryParse(value.toString());
