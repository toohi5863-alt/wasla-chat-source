import 'package:chat/admin_identity.dart';
import 'package:chat/verification_badges.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  setUp(() => VerifiedMemberBadges.updateVerifiedUserIds(const <String>{}));

  test('the fixed administrator badge survives verified-member refreshes', () {
    VerifiedMemberBadges.updateVerifiedUserIds(const <String>{'member-1'});

    expect(VerifiedMemberBadges.isVerified('member-1'), isTrue);
    expect(VerifiedMemberBadges.isVerified(waslaAdminUserId), isTrue);
    expect(VerifiedMemberBadges.isVerified('member-2'), isFalse);
  });

  testWidgets('a positively verified member gets a badge beside their name', (
    tester,
  ) async {
    VerifiedMemberBadges.updateVerifiedUserIds(const <String>{'member-1'});
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: AdminIdentityText(userId: 'member-1', label: 'عضو وصال'),
        ),
      ),
    );

    expect(
      find.byWidgetPredicate(
        (widget) =>
            widget is RichText &&
            widget.text.toPlainText().contains('عضو وصال'),
      ),
      findsOneWidget,
    );
    expect(find.byIcon(Icons.verified_rounded), findsOneWidget);
  });

  testWidgets('ordinary members remain unbadged by default', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: AdminIdentityText(userId: 'member-2', label: 'عضو آخر'),
        ),
      ),
    );

    expect(find.byIcon(Icons.verified_rounded), findsNothing);
    expect(find.text('عضو آخر'), findsOneWidget);
  });

  testWidgets('the profile owner sees an explicit verified account status', (
    tester,
  ) async {
    VerifiedMemberBadges.updateVerifiedUserIds(const <String>{'member-1'});
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: VerifiedAccountStatus(userId: 'member-1')),
      ),
    );

    expect(find.text('حسابك موثّق'), findsOneWidget);
    expect(find.byIcon(Icons.verified_rounded), findsOneWidget);
  });

  testWidgets('an unverified profile has no verified account status', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: VerifiedAccountStatus(userId: 'member-2')),
      ),
    );

    expect(find.text('حسابك موثّق'), findsNothing);
    expect(find.byIcon(Icons.verified_rounded), findsNothing);
  });
}
