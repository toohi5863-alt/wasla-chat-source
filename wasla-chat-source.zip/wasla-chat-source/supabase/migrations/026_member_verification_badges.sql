-- Member verification is opt-in and defaults off for every existing and new account.
-- Adding this column does not change any account's identity, roles, or current admin badge.
alter table public.profiles
  add column if not exists is_verified boolean not null default false;

-- Authenticated profile owners may update their own public profile fields, but
-- verification status is server-controlled and can only be changed by the
-- admin-gated Edge Function using the private service-role credential.
create or replace function private.wasla_guard_profile_verification()
returns trigger
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
begin
  if new.is_verified is distinct from old.is_verified
     and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Only the Wasla administrator can change verification status.'
      using errcode = '42501';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_guard_profile_verification() from public, anon, authenticated;

drop trigger if exists wasla_guard_profile_verification on public.profiles;
create trigger wasla_guard_profile_verification
before update of is_verified on public.profiles
for each row execute function private.wasla_guard_profile_verification();
