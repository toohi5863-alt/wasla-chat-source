import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:audioplayers/audioplayers.dart';
import 'package:app_links/app_links.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:geolocator/geolocator.dart';

import 'dart:io';
import 'dart:ui' as ui;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';

import 'about_page.dart';
import 'admin_identity.dart';
import 'app_sections.dart';
import 'app_settings.dart';
import 'app_theme.dart';
import 'calls.dart';
import 'chat_conversation_settings.dart';
import 'chat_history.dart';
import 'chat_composer.dart';
import 'chat_info_panel.dart';
import 'chat_local_cache.dart';
import 'chat_models.dart';
import 'message_delivery.dart';
import 'chat_outbox_message.dart';
import 'chat_preferences.dart';
import 'incoming_chat_sound_gate.dart';
import 'friendship_models.dart';
import 'friendship_service.dart';
import 'friend_qr_code.dart';
import 'friend_qr_scanner.dart';
import 'group_screens.dart';
import 'incoming_call_ringtone.dart';
import 'nearby_friends.dart';
import 'public_discovery.dart';
import 'presence.dart';
import 'presence_status.dart';
import 'typing_presence.dart';
import 'signup_otp.dart';
import 'notification_settings_page.dart';
import 'push_notifications.dart';
import 'statuses.dart';
import 'media_save_options.dart';
import 'wasla_media.dart';
import 'wasla_runtime_settings.dart';
import 'verification_badges.dart';
import 'unread_chat_badge.dart';

const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabasePublishableKey = String.fromEnvironment(
  'SUPABASE_PUBLISHABLE_KEY',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final hasBackend =
      _supabaseUrl.isNotEmpty && _supabasePublishableKey.isNotEmpty;
  String? startupError;
  if (hasBackend) {
    try {
      await Supabase.initialize(
        url: _supabaseUrl,
        publishableKey: _supabasePublishableKey,
      );
    } catch (_) {
      startupError =
          'تعذر الاتصال بإعدادات الخادم. راجع عنوان المشروع والمفتاح.';
    }
  }
  if (hasBackend && startupError == null) {
    unawaited(VerifiedMemberBadges.initialize(Supabase.instance.client));
  }
  if (hasBackend && startupError == null) {
    await PushNotifications.instance.initialize(Supabase.instance.client);
  }
  var announcementEnabled = false;
  var announcementText = '';
  if (hasBackend && startupError == null) {
    try {
      final result = await Supabase.instance.client.functions
          .invoke('wasla-admin', body: const {'action': 'public_settings'})
          .timeout(const Duration(seconds: 3));
      if (result.data is Map) {
        final runtimeSettings = Map<String, dynamic>.from(result.data as Map);
        announcementEnabled = runtimeSettings['announcement_enabled'] == true;
        announcementText =
            runtimeSettings['announcement_text']?.toString() ?? '';
        WaslaRuntimeSettings.applyPublicSettings(runtimeSettings);
      }
    } catch (_) {
      // Keep the current app available if the optional admin settings endpoint is unavailable.
    }
  }
  runApp(
    WaslaApp(
      backendReady: hasBackend && startupError == null,
      startupError: startupError,
      announcementEnabled: announcementEnabled,
      announcementText: announcementText,
    ),
  );
}

SupabaseClient get _db => Supabase.instance.client;

final Set<String> _pendingSignupAvatarUploads = <String>{};

String _pendingSignupAvatarFilePath(String userId, String directory) =>
    '$directory/wasla_pending_signup_avatar_$userId.jpg';

Future<void> _savePendingSignupAvatar(String userId, Uint8List bytes) async {
  final directory = await getApplicationSupportDirectory();
  final file = File(_pendingSignupAvatarFilePath(userId, directory.path));
  await file.writeAsBytes(bytes, flush: true);
}

Future<void> _uploadSignupAvatar(String userId, Uint8List bytes) async {
  final path = '$userId/avatar_${DateTime.now().microsecondsSinceEpoch}.jpg';
  final storage = _db.storage.from('wasla-avatars');
  await storage.uploadBinary(
    path,
    bytes,
    fileOptions: const FileOptions(contentType: 'image/jpeg'),
  );
  try {
    await _db.from('profiles').update({'avatar_path': path}).eq('id', userId);
  } catch (_) {
    try {
      await storage.remove([path]);
    } catch (_) {}
    rethrow;
  }
}

Future<void> _uploadPendingSignupAvatar(String userId) async {
  if (!_pendingSignupAvatarUploads.add(userId)) return;
  try {
    final directory = await getApplicationSupportDirectory();
    final file = File(_pendingSignupAvatarFilePath(userId, directory.path));
    if (!await file.exists()) return;
    await _uploadSignupAvatar(userId, await file.readAsBytes());
    await file.delete();
  } catch (_) {
    // Keep the local copy so a later authenticated launch can retry the upload.
  } finally {
    _pendingSignupAvatarUploads.remove(userId);
  }
}

class WaslaApp extends StatefulWidget {
  const WaslaApp({
    required this.backendReady,
    this.startupError,
    this.announcementEnabled = false,
    this.announcementText = '',
    super.key,
  });
  final bool backendReady;
  final String? startupError;
  final bool announcementEnabled;
  final String announcementText;

  @override
  State<WaslaApp> createState() => _WaslaAppState();
}

class _WaslaAppState extends State<WaslaApp> {
  final _settingsStore = AppSettingsStore();
  AppSettings _appSettings = const AppSettings();
  String? _settingsUserId;
  StreamSubscription<AuthState>? _authSubscription;

  @override
  void initState() {
    super.initState();
    if (!widget.backendReady) return;
    _authSubscription = _db.auth.onAuthStateChange.listen((state) {
      final userId = state.session?.user.id;
      unawaited(_loadSettings(userId));
      if (userId != null) unawaited(_uploadPendingSignupAvatar(userId));
    });
    final currentUserId = _db.auth.currentUser?.id;
    unawaited(_loadSettings(currentUserId));
    if (currentUserId != null) {
      unawaited(_uploadPendingSignupAvatar(currentUserId));
    }
  }

  Future<void> _loadSettings(String? userId) async {
    if (_settingsUserId == userId) return;
    _settingsUserId = userId;
    if (userId == null) {
      if (mounted) setState(() => _appSettings = const AppSettings());
      return;
    }
    if (mounted) setState(() => _appSettings = const AppSettings());
    try {
      final settings = await _settingsStore.load(userId);
      if (mounted && _settingsUserId == userId) {
        setState(() => _appSettings = settings);
      }
    } catch (_) {
      // Keep default app settings if local preferences are unavailable.
    }
  }

  void _setThemeMode(ThemeMode themeMode) {
    _updateSettings(_appSettings.copyWith(themeMode: themeMode));
  }

  void _setThemeId(String themeId) {
    _updateSettings(_appSettings.copyWith(themeId: themeId));
  }

  void _addCustomTheme(AppThemeOption theme) {
    final themes = [..._appSettings.customThemes, theme];
    _updateSettings(
      _appSettings.copyWith(themeId: theme.id, customThemes: themes),
    );
  }

  void _setCustomThemes(List<AppThemeOption> themes) {
    final selectedId = appThemeById(_appSettings.themeId, themes).id;
    _updateSettings(
      _appSettings.copyWith(themeId: selectedId, customThemes: themes),
    );
  }

  void _setTextSize(AppTextSize textSize) {
    _updateSettings(_appSettings.copyWith(textSize: textSize));
  }

  void _setBubbleStyle(MessageBubbleStyle bubbleStyle) {
    _updateSettings(_appSettings.copyWith(bubbleStyle: bubbleStyle));
  }

  void _setReduceMotion(bool reduceMotion) {
    _updateSettings(_appSettings.copyWith(reduceMotion: reduceMotion));
  }

  void _setHighContrast(bool highContrast) {
    _updateSettings(_appSettings.copyWith(highContrast: highContrast));
  }

  void _setCompactLayout(bool compactLayout) {
    _updateSettings(_appSettings.copyWith(compactLayout: compactLayout));
  }

  void _setShowChatStatusHighlights(bool show) {
    _updateSettings(_appSettings.copyWith(showChatStatusHighlights: show));
  }

  void _updateSettings(AppSettings settings) {
    setState(() => _appSettings = settings);
    final userId = _db.auth.currentUser?.id;
    if (userId != null) {
      unawaited(
        _settingsStore.save(userId, settings).catchError((Object _) {}),
      );
    }
  }

  @override
  void dispose() {
    unawaited(_authSubscription?.cancel());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final selectedTheme = appThemeById(
      _appSettings.themeId,
      _appSettings.customThemes,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'وصال',
      themeMode: _appSettings.themeMode,
      theme: buildWaslaTheme(
        option: selectedTheme,
        brightness: Brightness.light,
        highContrast: _appSettings.highContrast,
        compactLayout: _appSettings.compactLayout,
      ),
      darkTheme: buildWaslaTheme(
        option: selectedTheme,
        brightness: Brightness.dark,
        highContrast: _appSettings.highContrast,
        compactLayout: _appSettings.compactLayout,
      ),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder: (context, child) {
        final mediaQuery = MediaQuery.of(context);
        final systemScale = mediaQuery.textScaler.scale(1);
        return MediaQuery(
          data: mediaQuery.copyWith(
            textScaler: TextScaler.linear(
              systemScale * _appSettings.textSize.scaleFactor,
            ),
            disableAnimations:
                mediaQuery.disableAnimations || _appSettings.reduceMotion,
          ),
          child: Directionality(
            textDirection: ui.TextDirection.rtl,
            child: Column(
              children: [
                if (widget.announcementEnabled &&
                    widget.announcementText.trim().isNotEmpty)
                  SafeArea(
                    bottom: false,
                    child: Material(
                      color: const Color(0xFFFFF5DD),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.campaign_outlined,
                              color: Color(0xFF926411),
                              size: 20,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                widget.announcementText,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Color(0xFF624B1D),
                                  height: 1.45,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                Expanded(child: child ?? const SizedBox.shrink()),
              ],
            ),
          ),
        );
      },
      home: !widget.backendReady
          ? BackendSetupScreen(message: widget.startupError)
          : AuthGate(
              themeMode: _appSettings.themeMode,
              onThemeModeChanged: _setThemeMode,
              themeId: _appSettings.themeId,
              customThemes: _appSettings.customThemes,
              onThemeIdChanged: _setThemeId,
              onCustomThemeCreated: _addCustomTheme,
              onCustomThemesChanged: _setCustomThemes,
              textSize: _appSettings.textSize,
              onTextSizeChanged: _setTextSize,
              bubbleStyle: _appSettings.bubbleStyle,
              onBubbleStyleChanged: _setBubbleStyle,
              reduceMotion: _appSettings.reduceMotion,
              onReduceMotionChanged: _setReduceMotion,
              highContrast: _appSettings.highContrast,
              onHighContrastChanged: _setHighContrast,
              compactLayout: _appSettings.compactLayout,
              onCompactLayoutChanged: _setCompactLayout,
              showChatStatusHighlights: _appSettings.showChatStatusHighlights,
              onShowChatStatusHighlightsChanged: _setShowChatStatusHighlights,
            ),
    );
  }
}

class BackendSetupScreen extends StatelessWidget {
  const BackendSetupScreen({this.message, super.key});
  final String? message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(24),
              shrinkWrap: true,
              children: [
                const _BrandMark(size: 68),
                const SizedBox(height: 24),
                Text(
                  'وصال جاهز للربط',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 10),
                Text(
                  message ?? 'لتحويل التطبيق إلى دردشة حقيقية، اربطه بمشروع Supabase مستقل ثم طبّق ملف قاعدة البيانات المرفق.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyLarge
                      ?.copyWith(color: const Color(0xFF60736E), height: 1.6),
                ),
                const SizedBox(height: 24),
                Card(
                  elevation: 0,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _SetupStep(
                          number: '١',
                          text: 'أنشئ مشروع Supabase مخصصًا للتطبيق.',
                        ),
                        SizedBox(height: 14),
                        _SetupStep(
                          number: '٢',
                          text: 'طبّق الملف supabase/migrations/001_chat_schema.sql.',
                        ),
                        SizedBox(height: 14),
                        _SetupStep(
                          number: '٣',
                          text: 'ابنِ التطبيق باستخدام SUPABASE_URL وSUPABASE_PUBLISHABLE_KEY.',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'ملاحظة أمان: مفتاح النشر فقط داخل التطبيق؛ لا تضع service_role key في APK.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF60736E), height: 1.5),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SetupStep extends StatelessWidget {
  const _SetupStep({required this.number, required this.text});
  final String number;
  final String text;
  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      CircleAvatar(
        radius: 15,
        backgroundColor: const Color(0xFFE4F3EF),
        child: Text(number, style: const TextStyle(color: Color(0xFF087F72))),
      ),
      const SizedBox(width: 12),
      Expanded(child: Text(text, style: const TextStyle(height: 1.5))),
    ],
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({
    required this.themeMode,
    required this.onThemeModeChanged,
    required this.themeId,
    required this.customThemes,
    required this.onThemeIdChanged,
    required this.onCustomThemeCreated,
    required this.onCustomThemesChanged,
    required this.textSize,
    required this.onTextSizeChanged,
    required this.bubbleStyle,
    required this.onBubbleStyleChanged,
    required this.reduceMotion,
    required this.onReduceMotionChanged,
    required this.highContrast,
    required this.onHighContrastChanged,
    required this.compactLayout,
    required this.onCompactLayoutChanged,
    required this.showChatStatusHighlights,
    required this.onShowChatStatusHighlightsChanged,
    super.key,
  });
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;
  final String themeId;
  final List<AppThemeOption> customThemes;
  final ValueChanged<String> onThemeIdChanged;
  final ValueChanged<AppThemeOption> onCustomThemeCreated;
  final ValueChanged<List<AppThemeOption>> onCustomThemesChanged;
  final AppTextSize textSize;
  final ValueChanged<AppTextSize> onTextSizeChanged;
  final MessageBubbleStyle bubbleStyle;
  final ValueChanged<MessageBubbleStyle> onBubbleStyleChanged;
  final bool reduceMotion;
  final ValueChanged<bool> onReduceMotionChanged;
  final bool highContrast;
  final ValueChanged<bool> onHighContrastChanged;
  final bool compactLayout;
  final ValueChanged<bool> onCompactLayoutChanged;
  final bool showChatStatusHighlights;
  final ValueChanged<bool> onShowChatStatusHighlightsChanged;

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: _db.auth.onAuthStateChange,
    builder: (context, snapshot) {
      final session = snapshot.data?.session ?? _db.auth.currentSession;
      return session == null
          ? const SignInScreen()
          : ChatHomeScreen(
              themeMode: themeMode,
              onThemeModeChanged: onThemeModeChanged,
              themeId: themeId,
              customThemes: customThemes,
              onThemeIdChanged: onThemeIdChanged,
              onCustomThemeCreated: onCustomThemeCreated,
              onCustomThemesChanged: onCustomThemesChanged,
              textSize: textSize,
              onTextSizeChanged: onTextSizeChanged,
              bubbleStyle: bubbleStyle,
              onBubbleStyleChanged: onBubbleStyleChanged,
              reduceMotion: reduceMotion,
              onReduceMotionChanged: onReduceMotionChanged,
              highContrast: highContrast,
              onHighContrastChanged: onHighContrastChanged,
              compactLayout: compactLayout,
              onCompactLayoutChanged: onCompactLayoutChanged,
              showChatStatusHighlights: showChatStatusHighlights,
              onShowChatStatusHighlightsChanged:
                  onShowChatStatusHighlightsChanged,
            );
    },
  );
}

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});
  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _username = TextEditingController();
  final _displayName = TextEditingController();
  final _otp = TextEditingController();
  Uint8List? _signupAvatarBytes;
  bool _registering = false;
  bool _signupOtpSent = false;
  bool _busy = false;
  bool _obscure = true;
  int _resendSeconds = 0;
  Timer? _resendTimer;
  String? _error;
  String? _notice;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _username.dispose();
    _displayName.dispose();
    _otp.dispose();
    _resendTimer?.cancel();
    super.dispose();
  }

  void _resetSignupOtp() {
    _resendTimer?.cancel();
    _resendTimer = null;
    _signupOtpSent = false;
    _resendSeconds = 0;
    _otp.clear();
  }

  void _startResendTimer() {
    _resendTimer?.cancel();
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_resendSeconds <= 1) {
        setState(() => _resendSeconds = 0);
        timer.cancel();
      } else {
        setState(() => _resendSeconds--);
      }
    });
  }

  Future<void> _resendSignupOtp() async {
    if (_busy || _resendSeconds > 0 || !_signupOtpSent) return;
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      await _db.auth.resend(type: OtpType.signup, email: _email.text.trim());
      if (!mounted) return;
      setState(() {
        _resendSeconds = 60;
        _notice = 'أرسلنا رمز تأكيد جديدًا إلى ${_email.text.trim()}.';
      });
      _startResendTimer();
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = _friendlyAuthError(e.message));
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'تعذر إعادة إرسال الرمز. حاول مجددًا.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickSignupAvatar() async {
    try {
      final image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 84,
        maxWidth: 1200,
      );
      if (image == null || !mounted) return;
      final bytes = await image.readAsBytes();
      if (!mounted) return;
      if (bytes.length > 5 * 1024 * 1024) {
        setState(() => _error = 'حجم الصورة أكبر من ٥ ميغابايت.');
        return;
      }
      setState(() {
        _signupAvatarBytes = bytes;
        _error = null;
      });
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر اختيار الصورة. حاول مجددًا.');
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      if (_registering && _signupOtpSent) {
        final response = await _db.auth.verifyOTP(
          type: OtpType.signup,
          email: _email.text.trim(),
          token: _otp.text,
        );
        final userId = response.user?.id;
        final avatarBytes = _signupAvatarBytes;
        if (userId != null && avatarBytes != null) {
          try {
            await _uploadSignupAvatar(userId, avatarBytes);
          } catch (_) {
            try {
              await _savePendingSignupAvatar(userId, avatarBytes);
            } catch (_) {
              // The verified account succeeds even if avatar storage is unavailable.
            }
          }
        }
      } else if (_registering) {
        final response = await _db.auth.signUp(
          email: _email.text.trim(),
          password: _password.text,
          data: {
            'username': _username.text.trim().toLowerCase(),
            'display_name': _displayName.text.trim(),
          },
        );
        var pendingAvatarSaved = false;
        var avatarUploadFailed = false;
        final userId = response.user?.id;
        final avatarBytes = _signupAvatarBytes;
        if (userId != null && avatarBytes != null) {
          if (response.session != null) {
            try {
              await _uploadSignupAvatar(userId, avatarBytes);
            } catch (_) {
              avatarUploadFailed = true;
            }
          } else {
            try {
              await _savePendingSignupAvatar(userId, avatarBytes);
              pendingAvatarSaved = true;
            } catch (_) {
              // Account creation still succeeds if local avatar caching fails.
            }
          }
        }
        if (response.session == null && mounted) {
          final confirmationNotice =
              'أرسلنا رمز تأكيد إلى ${_email.text.trim()}. أدخله هنا لإكمال إنشاء الحساب، وتحقق من الرسائل غير المرغوب فيها.';
          final avatarNotice = avatarBytes == null
              ? ''
              : pendingAvatarSaved
              ? ' ستُرفع الصورة الشخصية تلقائيًا بعد تأكيد البريد.'
              : ' تعذر حفظ الصورة على هذا الجهاز؛ يمكنك إضافتها لاحقًا من الملف الشخصي.';
          setState(() {
            _signupOtpSent = true;
            _resendSeconds = 60;
            _notice = '$confirmationNotice$avatarNotice';
          });
          _startResendTimer();
        } else if (avatarUploadFailed && mounted) {
          setState(
            () => _notice = 'تم إنشاء الحساب، لكن تعذر رفع الصورة. يمكنك إضافتها لاحقًا من الملف الشخصي.',
          );
        }
      } else {
        await _db.auth.signInWithPassword(
          email: _email.text.trim(),
          password: _password.text,
        );
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = _friendlyAuthError(e.message));
    } catch (_) {
      if (mounted) setState(() => _error = 'حدث خطأ غير متوقع. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resetPassword() async {
    final email = _email.text.trim();
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email)) {
      setState(() {
        _error = 'أدخل بريدك الإلكتروني الصحيح أولًا.';
        _notice = null;
      });
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _notice = null;
    });
    try {
      await _db.auth.resetPasswordForEmail(email);
      if (mounted) {
        setState(
          () => _notice = 'إذا كان البريد مسجلًا، فسيصلك رابط لاستعادة كلمة المرور. تحقق من صندوق الوارد والرسائل غير المرغوب فيها.',
        );
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = _friendlyAuthError(e.message));
    } catch (_) {
      if (mounted) {
        setState(
          () => _error =
              'تعذر إرسال رابط الاستعادة. تحقق من اتصالك وحاول مجددًا.',
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyAuthError(String message) {
    final lower = message.toLowerCase();
    if (lower.contains('invalid login credentials')) {
      return 'البريد أو كلمة المرور غير صحيحة.';
    }
    if (lower.contains('email not confirmed')) {
      return 'أكّد بريدك الإلكتروني أولًا.';
    }
    if (lower.contains('already registered') ||
        lower.contains('already been registered')) {
      return 'هذا البريد مسجل مسبقًا. سجّل الدخول بدلًا من إنشاء حساب.';
    }
    if (lower.contains('profiles_username_key') ||
        (lower.contains('username') &&
            (lower.contains('duplicate') ||
                lower.contains('unique') ||
                lower.contains('taken')))) {
      return 'اسم المستخدم مستخدم بالفعل. اختر اسمًا آخر.';
    }
    if (lower.contains('invalid username')) {
      return 'اسم المستخدم غير صالح. استخدم ٣–٢٤ حرفًا إنجليزيًا أو رقمًا أو _.';
    }
    if (lower.contains('invalid display name')) {
      return 'الاسم الظاهر يجب أن يكون بين حرفين و٦٠ حرفًا.';
    }
    if (lower.contains('database error saving new user')) {
      return 'تعذر حفظ الحساب. جرّب اسم مستخدم آخر وتأكد من صحة الاسم الظاهر.';
    }
    if (lower.contains('invalid otp') ||
        lower.contains('otp expired') ||
        lower.contains('token has expired')) {
      return 'رمز التحقق غير صحيح أو انتهت صلاحيته. اطلب رمزًا جديدًا.';
    }
    if (lower.contains('email rate limit') ||
        lower.contains('over_email_send_rate_limit') ||
        lower.contains('too many requests')) {
      return 'أُرسلت طلبات كثيرة. انتظر قليلًا قبل طلب رمز آخر.';
    }
    if (lower.contains('smtp') ||
        lower.contains('email provider') ||
        lower.contains('error sending confirmation email')) {
      return 'تعذر إرسال رمز البريد. تحقق من إعداد مزود SMTP في Supabase.';
    }
    if (lower.contains('signup is disabled') ||
        lower.contains('signups not allowed')) {
      return 'إنشاء الحسابات متوقف مؤقتًا على الخادم.';
    }
    return 'تعذر إتمام العملية. تحقق من البيانات وحاول مجددًا.';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: ListView(
              padding: const EdgeInsets.all(24),
              shrinkWrap: true,
              children: [
                const SizedBox(height: 16),
                const _BrandMark(size: 72),
                const SizedBox(height: 16),
                Text(
                  'وصال',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _registering
                      ? 'أنشئ حسابك وابدأ محادثة'
                      : 'رسائلك، أقرب إلى من تحب',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: const Color(0xFF60736E),
                  ),
                ),
                const SizedBox(height: 28),
                if (_registering && _signupOtpSent)
                  Text(
                    'أدخل رمز التأكيد الذي أرسلناه إلى بريدك الإلكتروني (من ٦ إلى ١٠ أرقام).',
                    textAlign: TextAlign.center,
                  ),
                const SizedBox(height: 8),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      if (_registering && !_signupOtpSent) ...[
                        Center(
                          child: Column(
                            children: [
                              CircleAvatar(
                                radius: 42,
                                backgroundColor: const Color(0xFFE4F3EF),
                                backgroundImage: _signupAvatarBytes == null
                                    ? null
                                    : MemoryImage(_signupAvatarBytes!),
                                child: _signupAvatarBytes == null
                                    ? const Icon(Icons.person_outline, size: 38)
                                    : null,
                              ),
                              TextButton.icon(
                                onPressed: _busy ? null : _pickSignupAvatar,
                                icon: const Icon(Icons.add_a_photo_outlined),
                                label: Text(
                                  _signupAvatarBytes == null
                                      ? 'إضافة صورة شخصية (اختياري)'
                                      : 'تغيير الصورة الشخصية',
                                ),
                              ),
                            ],
                          ),
                        ),
                        TextFormField(
                          controller: _displayName,
                          textInputAction: TextInputAction.next,
                          maxLength: 60,
                          decoration: const InputDecoration(
                            labelText: 'الاسم الظاهر',
                            prefixIcon: Icon(Icons.person_outline),
                            counterText: '',
                          ),
                          validator: (v) =>
                              (v == null ||
                                  v.trim().length < 2 ||
                                  v.trim().length > 60)
                              ? 'اكتب اسمًا من حرفين إلى ٦٠ حرفًا'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _username,
                          textInputAction: TextInputAction.next,
                          autocorrect: false,
                          decoration: const InputDecoration(
                            labelText: 'اسم المستخدم',
                            prefixIcon: Icon(Icons.alternate_email),
                            hintText: 'مثال: ahmed_22',
                          ),
                          validator: (v) =>
                              RegExp(r'^[a-z0-9_]{3,24}$')
                                  .hasMatch((v ?? '').trim().toLowerCase())
                              ? null
                              : 'استخدم ٣–٢٤ حرفًا إنجليزيًا أو رقمًا أو _',
                        ),
                        const SizedBox(height: 12),
                      ],
                      TextFormField(
                        controller: _email,
                        readOnly: _registering && _signupOtpSent,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: _signupOtpSent
                            ? TextInputAction.next
                            : TextInputAction.next,
                        autocorrect: false,
                        decoration: const InputDecoration(
                          labelText: 'البريد الإلكتروني',
                          prefixIcon: Icon(Icons.email_outlined),
                        ),
                        validator: (v) =>
                            (v == null ||
                                !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
                                    .hasMatch(v.trim()))
                            ? 'أدخل بريدًا إلكترونيًا صحيحًا'
                            : null,
                      ),
                      const SizedBox(height: 12),
                      if (_registering && _signupOtpSent) ...[
                        TextFormField(
                          controller: _otp,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.done,
                          textDirection: ui.TextDirection.ltr,
                          textAlign: TextAlign.center,
                          autofillHints: const [AutofillHints.oneTimeCode],
                          maxLength: 10,
                          onFieldSubmitted: (_) => _submit(),
                          decoration: const InputDecoration(
                            labelText: 'رمز التأكيد المرسل إلى البريد',
                            prefixIcon: Icon(Icons.password_outlined),
                            counterText: '',
                          ),
                          validator: (value) => isValidSignupOtp(value ?? '')
                              ? null
                              : 'أدخل رمزًا رقميًا من ٦ إلى ١٠ أرقام',
                        ),
                        const SizedBox(height: 12),
                      ],
                      if (!_registering || !_signupOtpSent)
                        TextFormField(
                          controller: _password,
                          obscureText: _obscure,
                          textInputAction: TextInputAction.done,
                          onFieldSubmitted: (_) => _submit(),
                          decoration: InputDecoration(
                            labelText: 'كلمة المرور',
                            prefixIcon: const Icon(Icons.lock_outline),
                            suffixIcon: IconButton(
                              tooltip: _obscure
                                  ? 'إظهار كلمة المرور'
                                  : 'إخفاء كلمة المرور',
                              onPressed: () =>
                                  setState(() => _obscure = !_obscure),
                              icon: Icon(
                                _obscure
                                    ? Icons.visibility_outlined
                                    : Icons.visibility_off_outlined,
                              ),
                            ),
                          ),
                          validator: (v) => (v == null || v.length < 6)
                              ? 'كلمة المرور ٦ أحرف على الأقل'
                              : null,
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                if (_error != null) _InlineNotice(text: _error!, error: true),
                if (_notice != null)
                  _InlineNotice(text: _notice!, error: false),
                const SizedBox(height: 8),
                SizedBox(
                  height: 54,
                  child: FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text(
                            _registering
                                ? _signupOtpSent
                                      ? 'تأكيد الرمز'
                                      : 'إنشاء الحساب'
                                : 'تسجيل الدخول',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                  ),
                ),
                if (_registering && _signupOtpSent)
                  Wrap(
                    alignment: WrapAlignment.center,
                    children: [
                      TextButton(
                        onPressed: _busy
                            ? null
                            : () => setState(() {
                                _resetSignupOtp();
                                _error = null;
                                _notice = null;
                              }),
                        child: const Text('تعديل البيانات'),
                      ),
                      TextButton.icon(
                        onPressed: _busy || _resendSeconds > 0
                            ? null
                            : _resendSignupOtp,
                        icon: const Icon(Icons.refresh),
                        label: Text(
                          _resendSeconds > 0
                              ? 'إعادة الإرسال بعد $_resendSeconds ث'
                              : 'إعادة إرسال الرمز',
                        ),
                      ),
                    ],
                  ),
                if (!_registering)
                  TextButton(
                    onPressed: _busy ? null : _resetPassword,
                    child: const Text('نسيت كلمة المرور؟'),
                  ),
                if (!_signupOtpSent)
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() {
                            _resetSignupOtp();
                            _registering = !_registering;
                            _error = null;
                            _notice = null;
                          }),
                    child: Text(
                      _registering
                          ? 'لديك حساب؟ سجّل الدخول'
                          : 'مستخدم جديد؟ أنشئ حسابًا',
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ChatHomeScreen extends StatefulWidget {
  const ChatHomeScreen({
    required this.themeMode,
    required this.onThemeModeChanged,
    required this.themeId,
    required this.customThemes,
    required this.onThemeIdChanged,
    required this.onCustomThemeCreated,
    required this.onCustomThemesChanged,
    required this.textSize,
    required this.onTextSizeChanged,
    required this.bubbleStyle,
    required this.onBubbleStyleChanged,
    required this.reduceMotion,
    required this.onReduceMotionChanged,
    required this.highContrast,
    required this.onHighContrastChanged,
    required this.compactLayout,
    required this.onCompactLayoutChanged,
    required this.showChatStatusHighlights,
    required this.onShowChatStatusHighlightsChanged,
    super.key,
  });

  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;
  final String themeId;
  final List<AppThemeOption> customThemes;
  final ValueChanged<String> onThemeIdChanged;
  final ValueChanged<AppThemeOption> onCustomThemeCreated;
  final ValueChanged<List<AppThemeOption>> onCustomThemesChanged;
  final AppTextSize textSize;
  final ValueChanged<AppTextSize> onTextSizeChanged;
  final MessageBubbleStyle bubbleStyle;
  final ValueChanged<MessageBubbleStyle> onBubbleStyleChanged;
  final bool reduceMotion;
  final ValueChanged<bool> onReduceMotionChanged;
  final bool highContrast;
  final ValueChanged<bool> onHighContrastChanged;
  final bool compactLayout;
  final ValueChanged<bool> onCompactLayoutChanged;
  final bool showChatStatusHighlights;
  final ValueChanged<bool> onShowChatStatusHighlightsChanged;

  @override
  State<ChatHomeScreen> createState() => _ChatHomeScreenState();
}

class _ChatHomeScreenState extends State<ChatHomeScreen>
    with WidgetsBindingObserver {
  late final String _userId;
  late final RealtimeChannel _channel;
  late final RealtimeChannel _presenceChannel;
  late final RealtimeChannel _presenceStatusChannel;
  late final RealtimeChannel _friendshipChannel;
  Timer? _presenceHeartbeatTimer;
  Timer? _internetCheckTimer;
  bool _presenceActive = true;
  bool _presenceHeartbeatInFlight = false;
  bool _internetCheckInFlight = false;
  bool _hasInternetConnection = true;
  UserPresenceStatus _myPresenceStatus = UserPresenceStatus.available;
  bool _savingPresenceStatus = false;
  late final CallService _callService;
  final AudioPlayer _incomingCallRingtonePlayer = AudioPlayer();
  late final IncomingCallRingtoneController _incomingCallRingtone =
      IncomingCallRingtoneController(
        play: _playIncomingCallRingtone,
        stop: _incomingCallRingtonePlayer.stop,
      );
  StreamSubscription<CallRecord>? _incomingCallSubscription;
  final IncomingCallPromptGate _incomingCallPrompts = IncomingCallPromptGate();
  final _searchController = TextEditingController();
  final _preferencesStore = ChatListPreferencesStore();
  final _localCache = ChatLocalCache();
  late final AppLinks _appLinks;
  StreamSubscription<Uri>? _appLinkSubscription;
  int _refreshKey = 0;
  int _selectedTab = 0;
  int _pendingFriendRequests = 0;
  bool _refreshingCachedChats = false;
  List<Friend> _friends = [];
  bool _friendsLoading = true;
  String? _friendsError;
  int _chatFilter = 0;
  late Future<List<ChatPreview>> _chatsFuture;
  ChatListPreferences _chatPreferences = const ChatListPreferences();
  Map<String, String> _chatDrafts = const {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _startInternetConnectionMonitor();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) unawaited(_requestNotificationPermission());
    });
    _userId = _db.auth.currentUser!.id;
    _callService = CallService(userId: _userId);
    _incomingCallSubscription = _callService.incomingCalls.listen(
      _handleIncomingCall,
    );
    unawaited(_callService.initialize());
    _chatsFuture = _loadChats();
    unawaited(_loadChatDrafts());
    PushNotifications.instance.setNotificationTapHandler(
      _openNotificationConversation,
    );
    unawaited(_loadChatPreferences());
    unawaited(_refreshFriendRequestCount());
    unawaited(_refreshFriends());
    _appLinks = AppLinks();
    _appLinkSubscription = _appLinks.uriLinkStream.listen(_handleAppLink);
    unawaited(
      _appLinks
          .getInitialLink()
          .then((uri) {
            if (uri != null) _handleAppLink(uri);
          })
          .catchError((_) {}),
    );
    _channel = _db.channel('wasla-inbox-$_userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'messages',
        callback: (payload) {
          final row = payload.newRecord;
          _restoreDeletedChat(row['conversation_id']?.toString());
          if (mounted) _refreshChats();
        },
      )
      ..subscribe();
    _friendshipChannel = _db.channel('wasla-friend-requests-$_userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'friend_requests',
        callback: (_) {
          unawaited(_refreshFriendRequestCount());
          unawaited(_refreshFriends());
        },
      )
      ..subscribe();
    _presenceChannel = _db.channel(
      'wasla-presence-v1',
      opts: RealtimeChannelConfig(key: _userId, private: true),
    );
    _presenceChannel
      ..onPresenceSync((_) {
        final ids = _presenceChannel
            .presenceState()
            .map((state) => state.key)
            .toSet();
        onlineUserIds.value = ids;
      })
      ..subscribe((status, _) {
        if (status == RealtimeSubscribeStatus.subscribed && _presenceActive) {
          _startPresenceHeartbeat();
        }
      });
    _presenceStatusChannel = _db.channel('wasla-presence-statuses-$_userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'user_presence_statuses',
        callback: (payload) {
          final row = payload.newRecord;
          final id = row['user_id']?.toString();
          if (id == null || id.isEmpty) return;
          final status = UserPresenceStatus.fromValue(row['status']);
          mergeUserPresenceStatuses({id: status});
          if (id == _userId && mounted) {
            setState(() => _myPresenceStatus = status);
          }
        },
      )
      ..subscribe();
    unawaited(_loadMyPresenceStatus());
    unawaited(_refreshPresenceStatuses());
  }

  Future<void> _requestNotificationPermission() async {
    if (!Platform.isAndroid) return;
    try {
      final permission = await Permission.notification.request();
      if (permission.isGranted) {
        await PushNotifications.instance.requestPermissionAndRegister();
        return;
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('يمكن تفعيل إشعارات وصال من إعدادات التطبيق.'),
          action: SnackBarAction(
            label: 'الإعدادات',
            onPressed: () {
              openAppSettings().then<void>((_) {});
            },
          ),
        ),
      );
    } catch (_) {
      // Notification permission support varies by Android version/device.
    }
  }

  void _startPresenceHeartbeat() {
    _presenceHeartbeatTimer?.cancel();
    unawaited(_trackPresence());
    unawaited(_sendPresenceHeartbeat());
    _presenceHeartbeatTimer = Timer.periodic(
      const Duration(seconds: 45),
      (_) => unawaited(_sendPresenceHeartbeat()),
    );
  }

  Future<void> _trackPresence() async {
    try {
      await _presenceChannel.track({'user_id': _userId});
    } catch (_) {
      // Realtime will retry when the connection is available again.
    }
  }

  Future<void> _sendPresenceHeartbeat() async {
    if (_presenceHeartbeatInFlight) return;
    _presenceHeartbeatInFlight = true;
    try {
      await _db.rpc('heartbeat_presence');
    } catch (_) {
      // Keep Realtime presence working if the timestamp RPC is unavailable.
    } finally {
      _presenceHeartbeatInFlight = false;
    }
  }

  void _startInternetConnectionMonitor() {
    _internetCheckTimer?.cancel();
    unawaited(_checkInternetConnection());
    _internetCheckTimer = Timer.periodic(
      const Duration(seconds: 12),
      (_) => unawaited(_checkInternetConnection()),
    );
  }

  Future<void> _checkInternetConnection() async {
    if (!_presenceActive || _internetCheckInFlight || _supabaseUrl.isEmpty) {
      return;
    }
    _internetCheckInFlight = true;
    var connected = false;
    try {
      final endpoint = Uri.parse(_supabaseUrl);
      final socket = await Socket.connect(
        endpoint.host,
        endpoint.hasPort
            ? endpoint.port
            : (endpoint.scheme == 'https' ? 443 : 80),
        timeout: const Duration(seconds: 4),
      );
      socket.destroy();
      connected = true;
    } catch (_) {
      connected = false;
    } finally {
      _internetCheckInFlight = false;
    }
    if (mounted && connected != _hasInternetConnection) {
      setState(() => _hasInternetConnection = connected);
    }
  }

  Future<void> _untrackPresence() async {
    try {
      await _presenceChannel.untrack();
    } catch (_) {
      // Removing the channel also clears its Realtime presence.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final active = state == AppLifecycleState.resumed;
    if (_presenceActive == active) return;
    _presenceActive = active;
    if (active) {
      unawaited(VerifiedMemberBadges.refresh(_db));
      _startPresenceHeartbeat();
      _startInternetConnectionMonitor();
      unawaited(_callService.refreshPendingIncoming());
    } else {
      _internetCheckTimer?.cancel();
      _internetCheckTimer = null;
      _presenceHeartbeatTimer?.cancel();
      _presenceHeartbeatTimer = null;
      unawaited(_sendPresenceHeartbeat());
      unawaited(_untrackPresence());
    }
  }

  @override
  void dispose() {
    _presenceHeartbeatTimer?.cancel();
    _internetCheckTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    unawaited(_sendPresenceHeartbeat());
    _db.removeChannel(_channel);
    _db.removeChannel(_presenceChannel);
    _db.removeChannel(_presenceStatusChannel);
    _db.removeChannel(_friendshipChannel);
    unawaited(_incomingCallSubscription?.cancel());
    unawaited(_disposeIncomingCallRingtone());
    _callService.dispose();
    unawaited(_appLinkSubscription?.cancel());
    PushNotifications.instance.setNotificationTapHandler(null);
    onlineUserIds.value = {...onlineUserIds.value}..remove(_userId);
    replaceUserPresenceStatuses({});
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadChatPreferences() async {
    try {
      final preferences = await _preferencesStore.load(_userId);
      if (mounted) {
        setState(() => _chatPreferences = preferences);
      }
    } catch (_) {}
  }

  Future<void> _refreshFriendRequestCount() async {
    try {
      final requests = await FriendshipService(_db).incomingRequests();
      if (mounted && requests.length != _pendingFriendRequests) {
        setState(() => _pendingFriendRequests = requests.length);
      }
    } catch (_) {
      // Friendship actions remain available in direct chats if count refresh fails.
    }
  }

  Future<void> _refreshFriends() async {
    try {
      final friends = await FriendshipService(_db).friends();
      if (!mounted) return;
      setState(() {
        _friends = friends;
        _friendsError = null;
        _friendsLoading = false;
      });
      unawaited(_refreshPresenceStatuses());
    } catch (_) {
      if (mounted) {
        setState(() {
          _friendsError = 'تعذر تحميل الأصدقاء. تحقق من الاتصال وحاول مجددًا.';
          _friendsLoading = false;
        });
      }
    }
  }

  Future<void> _loadMyPresenceStatus() async {
    try {
      final status = await UserPresenceService(_db).loadMine(_userId);
      if (!mounted) return;
      setState(() => _myPresenceStatus = status);
      mergeUserPresenceStatuses({_userId: status});
    } catch (_) {
      // Keep the default state if the additive database migration is not present.
    }
  }

  Future<void> _refreshPresenceStatuses() async {
    final ids = <String>{_userId, ..._friends.map((friend) => friend.userId)};
    try {
      final statuses = await UserPresenceService(_db).loadForUsers(ids);
      if (!mounted) return;
      statuses.putIfAbsent(_userId, () => _myPresenceStatus);
      replaceUserPresenceStatuses(statuses);
      final mine = statuses[_userId];
      if (mine != null && mine != _myPresenceStatus) {
        setState(() => _myPresenceStatus = mine);
      }
    } catch (_) {
      // Online/last-seen presence remains usable if status migration is pending.
    }
  }

  Future<void> _choosePresenceStatus() async {
    if (_savingPresenceStatus) return;
    final selected = await showModalBottomSheet<UserPresenceStatus>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'حالة التواجد',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text('هذه حالتك الشخصية، وليست الحالات المنشورة.'),
            ),
            for (final status in UserPresenceStatus.selectableStatuses)
              ListTile(
                leading: PresenceStatusDot(status: status, size: 16),
                title: Text(status.label),
                subtitle: Text(status.description),
                trailing: status == _myPresenceStatus
                    ? const Icon(Icons.check, color: Color(0xFF087F72))
                    : null,
                onTap: () => Navigator.pop(context, status),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected == null || selected == _myPresenceStatus || !mounted) return;
    setState(() => _savingPresenceStatus = true);
    try {
      await UserPresenceService(_db).setMine(selected);
      if (!mounted) return;
      setState(() => _myPresenceStatus = selected);
      mergeUserPresenceStatuses({_userId: selected});
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'تعذر تحديث الحالة. تحقق من الاتصال وتطبيق ترحيل 015 على الخادم.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _savingPresenceStatus = false);
    }
  }

  Future<void> _showFriendRequests() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => const FriendRequestsScreen()),
    );
    if (mounted) {
      await _refreshFriendRequestCount();
      await _refreshFriends();
    }
  }

  Future<void> _showNearbyFriends() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => const NearbyFriendsScreen()),
    );
  }

  Future<void> _openFriendChat(Friend friend) async {
    try {
      final conversationId = await _db.rpc(
        'create_direct_conversation',
        params: {'p_target_user': friend.userId},
      );
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => ChatScreen(
            callService: _callService,
            bubbleStyle: widget.bubbleStyle,
            target: ChatTarget(
              conversationId: conversationId.toString(),
              userId: friend.userId,
              username: friend.username,
              displayName: friend.displayName,
              avatarPath: friend.avatarPath,
            ),
          ),
        ),
      );
      if (mounted) {
        _refreshChats();
        unawaited(_refreshFriends());
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح المحادثة. حاول مرة أخرى.')),
        );
      }
    }
  }

  Future<void> _removeFriend(Friend friend) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('هل تريد إلغاء الصداقة؟'),
        content: Text('سيتم حذف ${friend.label} من قائمة الأصدقاء.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('تراجع'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إلغاء الصداقة'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await FriendshipService(_db).cancel(friend.userId);
      await _refreshFriends();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تم إلغاء الصداقة.')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر إلغاء الصداقة. أعد المحاولة.')),
        );
      }
    }
  }

  void _refreshChats() {
    if (!mounted) return;
    setState(() {
      _refreshKey++;
      _chatsFuture = _loadChats();
    });
    unawaited(_loadChatDrafts());
  }

  Future<void> _loadChatDrafts() async {
    try {
      final drafts = await _localCache.loadDrafts(_userId);
      if (mounted) setState(() => _chatDrafts = drafts);
    } catch (_) {
      // Draft previews are optional; a storage issue must not block the inbox.
    }
  }

  Future<void> _saveChatPreferences() async {
    try {
      await _preferencesStore.save(_userId, _chatPreferences);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر حفظ تفضيلات المحادثات على هذا الجهاز.'),
          ),
        );
      }
    }
  }

  void _updateChatPreferences(ChatListPreferences preferences) {
    setState(() => _chatPreferences = preferences);
    unawaited(_saveChatPreferences());
  }

  void _toggleChatPreference(String conversationId, String preference) {
    final current = switch (preference) {
      'pin' => _chatPreferences.pinned,
      'favorite' => _chatPreferences.favorites,
      'archive' => _chatPreferences.archived,
      'mute' => _chatPreferences.muted,
      'hide' => _chatPreferences.hidden,
      'delete' => _chatPreferences.deleted,
      _ => const <String>{},
    };
    final updated = Set<String>.from(current);
    if (!updated.add(conversationId)) updated.remove(conversationId);
    final next = switch (preference) {
      'pin' => _chatPreferences.copyWith(pinned: updated),
      'favorite' => _chatPreferences.copyWith(favorites: updated),
      'archive' => _chatPreferences.copyWith(archived: updated),
      'mute' => _chatPreferences.copyWith(muted: updated),
      'hide' => _chatPreferences.copyWith(hidden: updated),
      'delete' => _chatPreferences.copyWith(deleted: updated),
      _ => _chatPreferences,
    };
    _updateChatPreferences(next);
  }

  Future<List<ChatPreview>> _loadChats() async {
    try {
      final cachedChats = await _localCache.loadChats(_userId);
      if (cachedChats != null) {
        unawaited(_refreshCachedChatsFromServer());
        return cachedChats;
      }
    } catch (_) {
      // A cache failure must not prevent the normal server request.
    }
    return _fetchChatsFromServer();
  }

  Future<List<ChatPreview>> _fetchChatsFromServer() async {
    final data = await _db.rpc('get_my_conversations');
    final chats = (data as List<dynamic>)
        .map(
          (row) => ChatPreview.fromMap(Map<String, dynamic>.from(row as Map)),
        )
        .toList();
    try {
      final cachedChats = await _localCache.loadChats(_userId);
      if (cachedChats != null) {
        _restoreDeletedChatsWithNewMessages(chats, cachedChats);
      }
      await _localCache.saveChats(_userId, chats);
    } catch (_) {
      // Keep the inbox usable if the device cannot write its local cache.
    }
    return chats;
  }

  void _restoreDeletedChatsWithNewMessages(
    List<ChatPreview> currentChats,
    List<ChatPreview> cachedChats,
  ) {
    final deleted = _chatPreferences.deleted;
    if (deleted.isEmpty) return;
    final previousById = {
      for (final chat in cachedChats) chat.conversationId: chat,
    };
    final remaining = Set<String>.from(deleted);
    for (final chat in currentChats) {
      if (!remaining.contains(chat.conversationId)) continue;
      final previous = previousById[chat.conversationId];
      final latestAt = chat.lastMessageAt;
      if (latestAt == null) continue;
      final previousAt = previous?.lastMessageAt;
      final hasNewMessage =
          previous == null ||
          previousAt == null ||
          latestAt.isAfter(previousAt) ||
          (latestAt.isAtSameMomentAs(previousAt) &&
              (chat.lastMessage != previous.lastMessage ||
                  chat.lastMessageSenderId != previous.lastMessageSenderId));
      if (hasNewMessage) remaining.remove(chat.conversationId);
    }
    if (remaining.length != deleted.length) {
      _updateChatPreferences(_chatPreferences.copyWith(deleted: remaining));
    }
  }

  Future<void> _refreshCachedChatsFromServer() async {
    if (_refreshingCachedChats) return;
    _refreshingCachedChats = true;
    try {
      final chats = await _fetchChatsFromServer();
      if (!mounted) return;
      setState(() {
        _refreshKey++;
        _chatsFuture = Future<List<ChatPreview>>.value(chats);
      });
    } catch (_) {
      // Cached inbox remains visible when the service is offline.
    } finally {
      _refreshingCachedChats = false;
    }
  }

  Future<void> _startNewChat() async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(builder: (_) => const FindPeopleScreen()),
    );
    if (target == null || !mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          target: target,
          callService: _callService,
          bubbleStyle: widget.bubbleStyle,
        ),
      ),
    );
    if (mounted) _refreshChats();
  }

  Future<void> _openNotificationConversation(Map<String, String> data) async {
    if (data['type'] == 'account_verification') {
      await VerifiedMemberBadges.refresh(_db);
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
      );
      return;
    }
    final callId = data['call_id'];
    if (callId != null && callId.isNotEmpty) {
      await PushNotifications.instance.cancelIncomingCallNotification();
      await _callService.refreshIncomingCall(callId);
      return;
    }
    if (data['type'] == 'status' || (data['status_id'] ?? '').isNotEmpty) {
      if (mounted) setState(() => _selectedTab = 1);
      return;
    }
    final conversationId = data['conversation_id'];
    if (conversationId == null || conversationId.isEmpty) return;
    try {
      final chats = await _loadChats();
      ChatPreview? chat;
      for (final candidate in chats) {
        if (candidate.conversationId == conversationId) {
          chat = candidate;
          break;
        }
      }
      final selectedChat = chat;
      if (!mounted || selectedChat == null) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => ChatScreen(
            callService: _callService,
            bubbleStyle: widget.bubbleStyle,
            target: ChatTarget(
              conversationId: selectedChat.conversationId,
              userId: selectedChat.otherUserId,
              username: selectedChat.username,
              displayName: selectedChat.displayName,
              avatarPath: selectedChat.isGroup
                  ? selectedChat.groupAvatarPath
                  : selectedChat.avatarPath,
              isGroup: selectedChat.isGroup,
              groupDescription: selectedChat.groupDescription,
              memberCount: selectedChat.memberCount,
              groupRole: selectedChat.groupRole,
            ),
          ),
        ),
      );
      if (mounted) _refreshChats();
    } catch (_) {
      // A stale or removed conversation should not interrupt app navigation.
    }
  }

  void _openNotificationSettings() {
    unawaited(
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) =>
              NotificationSettingsPage(client: _db, userId: _userId),
        ),
      ),
    );
  }

  void _openMediaSaveOptions() {
    unawaited(
      Navigator.of(context).push<void>(
        MaterialPageRoute<void>(builder: (_) => const MediaSaveOptionsScreen()),
      ),
    );
  }

  void _openAboutPage() {
    unawaited(
      Navigator.of(
        context,
      ).push<void>(MaterialPageRoute<void>(builder: (_) => const AboutPage())),
    );
  }

  Future<void> _startCallFromPeople() async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(builder: (_) => const FindPeopleScreen()),
    );
    if (target == null || !mounted) return;
    final video = await showModalBottomSheet<bool>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text(
                'نوع المكالمة',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                'اختر طريقة الاتصال بـ ${target.displayName.isEmpty ? '@${target.username}' : target.displayName}',
              ),
            ),
            ListTile(
              leading: const Icon(Icons.call_outlined),
              title: const Text('مكالمة صوتية'),
              onTap: () => Navigator.pop(context, false),
            ),
            ListTile(
              leading: const Icon(Icons.videocam_outlined),
              title: const Text('مكالمة مرئية'),
              onTap: () => Navigator.pop(context, true),
            ),
          ],
        ),
      ),
    );
    if (video == null || !mounted) return;
    await _placeCall(target, video: video);
  }

  Future<void> _placeCall(ChatTarget target, {required bool video}) async {
    try {
      final call = await _callService.startCall(target, video: video);
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        callScreenRoute(
          service: _callService,
          call: call,
          ringtone: _incomingCallRingtone,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر بدء المكالمة. تحقق من ترحيل 006_calls.sql والاتصال ثم حاول مجددًا. ${error is PostgrestException ? error.message : ''}',
          ),
        ),
      );
    }
  }

  Future<void> _redialCall(CallRecord call) async {
    final peerId = call.callerId == _userId ? call.calleeId : call.callerId;
    final target = ChatTarget(
      conversationId: call.conversationId,
      userId: peerId,
      username: call.peerUsername,
      displayName: call.peerName,
      avatarPath: call.peerAvatarPath,
    );
    await _placeCall(target, video: call.isVideo);
  }

  Future<void> _handleIncomingCall(CallRecord call) async {
    if (!mounted || !_incomingCallPrompts.tryOpen(call.id)) return;
    try {
      await PushNotifications.instance.refreshPreferences();
      final latest = _callService.cachedCall(call.id) ?? call;
      if (!mounted || latest.status != 'ringing') return;
      final timeout = remainingIncomingCallDuration(latest);
      if (timeout <= Duration.zero) {
        await _callService.markMissed(latest);
        return;
      }
      await _incomingCallRingtone.startForIncoming(
        callId: latest.id,
        isIncoming: latest.calleeId == _userId && latest.callerId != _userId,
        alertsEnabled: PushNotifications.instance.preferences
            .allowsChatSoundFor('calls'),
        callScreenOpen: _callService.hasOpenCallScreen,
      );
      if (!mounted) return;
      await showIncomingCallDialog(
        context,
        call: latest,
        service: _callService,
        ringtone: _incomingCallRingtone,
        timeout: timeout,
      );
    } catch (_) {
      await _incomingCallRingtone.stopForCall(call.id);
    } finally {
      await _incomingCallRingtone.stopForCall(call.id);
      await PushNotifications.instance.cancelIncomingCallNotification();
      _incomingCallPrompts.close(call.id);
    }
  }

  Future<void> _playIncomingCallRingtone() async {
    await _incomingCallRingtonePlayer.setAudioContext(
      AudioContextConfig(respectSilence: true, stayAwake: true).build(),
    );
    await _incomingCallRingtonePlayer.setReleaseMode(ReleaseMode.loop);
    await _incomingCallRingtonePlayer.play(
      AssetSource('audio/incoming_call_ringtone.wav'),
      volume: 0.9,
    );
  }

  Future<void> _disposeIncomingCallRingtone() async {
    await _incomingCallRingtone.dispose();
    await _incomingCallRingtonePlayer.dispose();
  }

  void _handleAppLink(Uri uri) {
    if (uri.scheme != 'wasla' ||
        uri.host != 'join' ||
        uri.pathSegments.isEmpty) {
      return;
    }
    unawaited(_openGroupInvite(uri.pathSegments.first));
  }

  Future<void> _openGroupInvite(String token) async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(builder: (_) => JoinGroupScreen(initialToken: token)),
    );
    if (target != null && mounted) await _openGroupChat(target);
  }

  Future<void> _startNewGroup() async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(builder: (_) => const CreateGroupScreen()),
    );
    if (target != null && mounted) await _openGroupChat(target);
  }

  Future<void> _joinGroup() async {
    final target = await Navigator.of(context).push<ChatTarget>(
      MaterialPageRoute(builder: (_) => const JoinGroupScreen()),
    );
    if (target != null && mounted) await _openGroupChat(target);
  }

  Future<void> _openGroupChat(ChatTarget target) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          target: target,
          callService: _callService,
          bubbleStyle: widget.bubbleStyle,
        ),
      ),
    );
    if (mounted) _refreshChats();
  }

  Future<void> _showCreateMenu() async {
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'إنشاء جديد',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text('اختر ما تريد أن تبدأه'),
            ),
            _CreateActionTile(
              icon: Icons.chat_bubble_outline,
              title: 'محادثة جديدة',
              value: 'chat',
            ),
            _CreateActionTile(
              icon: Icons.groups_outlined,
              title: 'مجموعة جديدة',
              value: 'group',
            ),
            _CreateActionTile(
              icon: Icons.group_add_outlined,
              title: 'الانضمام إلى مجموعة',
              value: 'join_group',
            ),
            _CreateActionTile(
              icon: Icons.campaign_outlined,
              title: 'قناة جديدة',
              value: 'channel',
            ),
            _CreateActionTile(
              icon: Icons.add_circle_outline,
              title: 'حالة جديدة',
              value: 'status',
            ),
            _CreateActionTile(
              icon: Icons.call_outlined,
              title: 'مكالمة جديدة',
              value: 'call',
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
    if (!mounted || action == null) return;
    switch (action) {
      case 'chat':
        await _startNewChat();
      case 'group':
        await _startNewGroup();
      case 'join_group':
        await _joinGroup();
      case 'channel':
        await _showInfo(
          'القنوات غير مفعّلة بعد',
          'لا يحتوي خادم وصال الحالي على جداول أو صلاحيات للقنوات؛ لم ننشئ قناة وهمية أو نغيّر بيانات الخادم.',
        );
      case 'status':
        setState(() => _selectedTab = 1);
        await Navigator.of(context).push<bool>(
          MaterialPageRoute(builder: (_) => const StatusComposerScreen()),
        );
      case 'call':
        setState(() => _selectedTab = 3);
    }
  }

  Future<void> _showInfo(String title, String detail) async {
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(detail, style: const TextStyle(height: 1.55)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسنًا'),
          ),
        ],
      ),
    );
  }

  Future<void> _showProfile() async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const ProfileScreen()));
    if (mounted) _refreshChats();
  }

  Future<void> _showUserQr() => showDialog<void>(
    context: context,
    builder: (_) => UserQrDialog(
      userId: _db.auth.currentUser?.id ?? '',
      username:
          _db.auth.currentUser?.userMetadata?['username']?.toString() ?? '',
    ),
  );

  Future<void> _showQrOptions() async {
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.qr_code_2_rounded),
              title: const Text('عرض رمز QR الخاص بي'),
              onTap: () => Navigator.pop(sheetContext, 'show'),
            ),
            ListTile(
              leading: const Icon(Icons.qr_code_scanner_rounded),
              title: const Text('مسح رمز QR لإضافة صديق'),
              onTap: () => Navigator.pop(sheetContext, 'scan'),
            ),
          ],
        ),
      ),
    );
    if (!mounted) return;
    if (action == 'show') {
      await _showUserQr();
    } else if (action == 'scan') {
      await _scanFriendQr();
    }
  }

  Future<void> _scanFriendQr() async {
    final code = await Navigator.of(context).push<FriendQrCode>(
      MaterialPageRoute<FriendQrCode>(
        builder: (_) => const FriendQrScannerScreen(),
      ),
    );
    if (!mounted || code == null) return;

    final currentUser = _db.auth.currentUser;
    if (currentUser == null) {
      await _showInfo('يلزم تسجيل الدخول', 'سجّل الدخول قبل إضافة صديق.');
      return;
    }

    try {
      final columns = 'id, username, display_name, avatar_path, bio';
      final profile = code.userId != null
          ? await _db
                .from('profiles')
                .select(columns)
                .eq('id', code.userId!)
                .maybeSingle()
          : await _db
                .from('profiles')
                .select(columns)
                .eq('username', code.username!)
                .maybeSingle();

      if (!mounted) return;
      if (profile == null || profile['id'] == null) {
        await _showInfo(
          'رمز غير صالح',
          'لم نعثر على حساب وصال مرتبط بهذا الرمز. اطلب من صاحب الحساب عرض رمز جديد.',
        );
        return;
      }

      final targetUserId = profile['id'].toString();
      if (targetUserId == currentUser.id) {
        await _showInfo('هذا رمزك', 'امسح رمز صديق لإرسال طلب صداقة.');
        return;
      }

      final target = ChatTarget(
        conversationId: '',
        userId: targetUserId,
        username: profile['username']?.toString() ?? '',
        displayName: profile['display_name']?.toString() ?? '',
        avatarPath: profile['avatar_path']?.toString(),
        bio: profile['bio']?.toString() ?? '',
      );
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => FindPeopleScreen(initialPerson: target),
        ),
      );
      if (mounted) await _refreshFriends();
    } catch (_) {
      if (mounted) {
        await _showInfo(
          'تعذر فتح الملف',
          'تحقق من اتصالك بالإنترنت ثم حاول مسح الرمز مرة أخرى.',
        );
      }
    }
  }

  Future<void> _inviteFriend() async {
    final username =
        _db.auth.currentUser?.userMetadata?['username']?.toString() ?? '';
    await SharePlus.instance.share(
      ShareParams(text: 'انضم إلى وصال وابحث عن @$username لبدء محادثة.'),
    );
  }

  Future<void> _exportChatArchive() async {
    var loadingShown = true;
    unawaited(
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => const AlertDialog(
          content: Row(
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2.5),
              ),
              SizedBox(width: 16),
              Expanded(child: Text('جارٍ تجهيز أرشيف المحادثات…')),
            ],
          ),
        ),
      ),
    );

    void closeLoading() {
      if (!loadingShown || !mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      loadingShown = false;
    }

    File? archiveFile;
    IOSink? sink;
    var messageCount = 0;
    try {
      final response = await _db.rpc('get_my_conversations') as List<dynamic>;
      final conversations = response
          .map(
            (row) => ChatPreview.fromMap(Map<String, dynamic>.from(row as Map)),
          )
          .toList();
      final exportedAt = DateTime.now().toUtc();
      final directory = await getTemporaryDirectory();
      final stamp = DateFormat('yyyyMMdd-HHmmss').format(exportedAt);
      archiveFile = File('${directory.path}/wasla-chat-archive-$stamp.json');
      sink = archiveFile.openWrite();
      sink.write(
        '{"format":"wasla-chat-archive","version":1,'
        '"exported_at":${jsonEncode(exportedAt.toIso8601String())},'
        '"conversations":[',
      );

      const pageSize = 500;
      const messageColumns =
          'id,conversation_id,sender_id,content,message_type,media_path,'
          'media_duration_seconds,created_at,delivered_at,read_at,reply_to,edited_at';
      for (var chatIndex = 0; chatIndex < conversations.length; chatIndex++) {
        final chat = conversations[chatIndex];
        if (chatIndex > 0) sink.write(',');
        sink.write(
          '{"conversation_id":${jsonEncode(chat.conversationId)},'
          '"type":${jsonEncode(chat.isGroup ? 'group' : 'direct')},'
          '"name":${jsonEncode(chat.isGroup ? (chat.groupName ?? chat.displayName) : chat.displayName)},'
          '"username":${jsonEncode(chat.username)},"messages":[',
        );

        var firstMessage = true;
        for (var offset = 0; ; offset += pageSize) {
          final page = await _db
              .from('messages')
              .select(messageColumns)
              .eq('conversation_id', chat.conversationId)
              .order('created_at')
              .order('id')
              .range(offset, offset + pageSize - 1);
          final messages = page as List<dynamic>;
          for (final row in messages) {
            if (!firstMessage) sink.write(',');
            sink.write(jsonEncode(Map<String, dynamic>.from(row as Map)));
            firstMessage = false;
            messageCount++;
          }
          if (messages.length < pageSize) break;
        }
        sink.write(']}');
      }
      sink.write(']}');
      await sink.flush();
      await sink.close();
      sink = null;

      closeLoading();
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(archiveFile.path, mimeType: 'application/json')],
          text: 'أرشيف محادثات وصال بصيغة JSON',
        ),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'اكتمل إعداد الأرشيف: ${conversations.length} محادثة و$messageCount رسالة.',
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'تعذر تصدير الأرشيف. تحقق من الاتصال ثم حاول مجددًا.',
            ),
          ),
        );
      }
    } finally {
      closeLoading();
      if (sink != null) {
        try {
          await sink.close();
        } catch (_) {}
      }
      final file = archiveFile;
      if (file != null) {
        try {
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
    }
  }

  bool _isUnread(ChatPreview chat) =>
      chat.lastMessageAt != null &&
      chat.lastMessageSenderId != null &&
      chat.lastMessageSenderId != _userId &&
      chat.lastMessageReadAt == null;

  Future<void> _deleteChat(ChatPreview chat) async {
    final chatName = chat.isGroup
        ? (chat.groupName ?? chat.displayName)
        : chat.displayName;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المحادثة من القائمة؟'),
        content: Text(
          'ستُزال محادثة «$chatName» من قائمة هذا الجهاز فقط. لن تُحذف الرسائل من خادم وصال أو من جهاز الطرف الآخر${chat.isGroup ? '، ولن تغادر المجموعة' : ''}. وستظهر مجددًا عند وصول رسالة جديدة.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    _toggleChatPreference(chat.conversationId, 'delete');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('حُذفت المحادثة من قائمة هذا الجهاز.'),
        action: SnackBarAction(
          label: 'تراجع',
          onPressed: () => _toggleChatPreference(chat.conversationId, 'delete'),
        ),
      ),
    );
  }

  void _restoreDeletedChat(String? conversationId) {
    if (conversationId == null ||
        !_chatPreferences.deleted.contains(conversationId)) {
      return;
    }
    final deleted = Set<String>.from(_chatPreferences.deleted)
      ..remove(conversationId);
    _updateChatPreferences(_chatPreferences.copyWith(deleted: deleted));
  }

  Future<void> _showChatActions(ChatPreview chat) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      builder: (sheetContext) {
        final id = chat.conversationId;
        final pinned = _chatPreferences.pinned.contains(id);
        final favorite = _chatPreferences.favorites.contains(id);
        final muted = _chatPreferences.muted.contains(id);
        final archived = _chatPreferences.archived.contains(id);
        final name = chat.isGroup
            ? (chat.groupName ?? chat.displayName)
            : chat.displayName;
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: const Text('خيارات المحادثة'),
              ),
              ListTile(
                leading: Icon(
                  pinned ? Icons.push_pin : Icons.push_pin_outlined,
                ),
                title: Text(pinned ? 'إلغاء التثبيت' : 'تثبيت المحادثة'),
                onTap: () => Navigator.pop(sheetContext, 'pin'),
              ),
              ListTile(
                leading: Icon(favorite ? Icons.star : Icons.star_outline),
                title: Text(
                  favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة',
                ),
                onTap: () => Navigator.pop(sheetContext, 'favorite'),
              ),
              ListTile(
                leading: Icon(
                  muted ? Icons.notifications_off : Icons.notifications_none,
                ),
                title: Text(muted ? 'إلغاء الكتم' : 'كتم المحادثة'),
                onTap: () => Navigator.pop(sheetContext, 'mute'),
              ),
              ListTile(
                leading: Icon(
                  archived ? Icons.unarchive_outlined : Icons.archive_outlined,
                ),
                title: Text(archived ? 'إلغاء الأرشفة' : 'أرشفة المحادثة'),
                onTap: () => Navigator.pop(sheetContext, 'archive'),
              ),
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: const Text(
                  'حذف المحادثة',
                  style: TextStyle(color: Colors.red),
                ),
                onTap: () => Navigator.pop(sheetContext, 'delete'),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
    if (!mounted || action == null) return;
    if (action == 'delete') {
      await _deleteChat(chat);
    } else {
      _toggleChatPreference(chat.conversationId, action);
    }
  }

  Future<void> _signOut() async {
    await PushNotifications.instance.unregisterCurrentDevice();
    await _db.auth.signOut();
  }

  Widget _buildChatSection(
    String? username,
  ) => FutureBuilder<List<ChatPreview>>(
    key: ValueKey(_refreshKey),
    future: _chatsFuture,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return _LoadError(onRetry: _refreshChats);
      }
      if (!snapshot.hasData) {
        return const Center(child: CircularProgressIndicator());
      }

      final chats = snapshot.data!;
      final unreadChatCount = chats.where((chat) {
        final id = chat.conversationId;
        return !_chatPreferences.hidden.contains(id) &&
            !_chatPreferences.deleted.contains(id) &&
            !_chatPreferences.archived.contains(id) &&
            _isUnread(chat);
      }).length;
      final compactChatLayout = Theme.of(context).visualDensity.vertical < 0;
      final query = _searchController.text.trim().toLowerCase();
      final filteredChats =
          chats.where((chat) {
            if (_chatPreferences.hidden.contains(chat.conversationId) ||
                _chatPreferences.deleted.contains(chat.conversationId)) {
              return false;
            }
            final archived = _chatPreferences.archived.contains(
              chat.conversationId,
            );
            if (_chatFilter == 3 && !archived) return false;
            if (_chatFilter != 3 && archived) return false;
            if (_chatFilter == 1 && !_isUnread(chat)) return false;
            if (_chatFilter == 2 &&
                !_chatPreferences.favorites.contains(chat.conversationId)) {
              return false;
            }
            if (query.isEmpty) return true;
            return '${chat.displayName} @${chat.username} ${chat.lastMessage} '
                    '${_chatDrafts[chat.conversationId] ?? ''}'
                .toLowerCase()
                .contains(query);
          }).toList()..sort((a, b) {
            final aPinned = _chatPreferences.pinned.contains(a.conversationId);
            final bPinned = _chatPreferences.pinned.contains(b.conversationId);
            if (aPinned != bPinned) return aPinned ? -1 : 1;
            return 0;
          });
      final sectionTitle = switch (_chatFilter) {
        1 => 'غير المقروءة',
        2 => 'المفضلة',
        3 => 'المحادثات المؤرشفة',
        _ => 'أحدث المحادثات',
      };

      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => setState(() {}),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'ابحث عن شخص أو رسالة',
                prefixIcon: Icon(
                  Icons.search_rounded,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'مسح البحث',
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                      ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceContainerLow,
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.outlineVariant
                        .withValues(alpha: .58),
                    width: .8,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.outlineVariant
                        .withValues(alpha: .58),
                    width: .8,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.primary,
                    width: 1.4,
                  ),
                ),
              ),
            ),
          ),
          if (widget.showChatStatusHighlights)
            StatusHighlightsStrip(
              onSeeAll: () => setState(() => _selectedTab = 1),
            ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              children: [
                _ChatFilterChip(
                  label: 'الكل',
                  icon: Icons.forum_outlined,
                  selected: _chatFilter == 0,
                  onTap: () => setState(() => _chatFilter = 0),
                ),
                _ChatFilterChip(
                  label: 'غير المقروءة',
                  icon: Icons.mark_chat_unread_outlined,
                  count: unreadChatCount == 0 ? null : unreadChatCount,
                  selected: _chatFilter == 1,
                  onTap: () => setState(() => _chatFilter = 1),
                ),
                _ChatFilterChip(
                  label: 'المفضلة',
                  icon: Icons.star_outline_rounded,
                  selected: _chatFilter == 2,
                  onTap: () => setState(() => _chatFilter = 2),
                ),
                _ChatFilterChip(
                  label: 'المؤرشفة',
                  icon: Icons.archive_outlined,
                  selected: _chatFilter == 3,
                  onTap: () => setState(() => _chatFilter = 3),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(18, 10, 18, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    sectionTitle,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                ),
                Semantics(
                  container: true,
                  label: '${filteredChats.length} محادثة',
                  child: ExcludeSemantics(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .colorScheme
                            .surfaceContainerHigh,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: Theme.of(context).colorScheme.outlineVariant
                              .withValues(alpha: .55),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.forum_outlined,
                            size: 14,
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceVariant,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '${filteredChats.length}',
                            style: Theme.of(context).textTheme.labelMedium
                                ?.copyWith(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant,
                                  fontWeight: FontWeight.w700,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: chats.isEmpty
                ? _EmptyInbox(onStart: _showCreateMenu, username: username)
                : RefreshIndicator(
                    onRefresh: () async => _refreshChats(),
                    child: filteredChats.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            children: [
                              const SizedBox(height: 70),
                              Icon(
                                _chatFilter == 3
                                    ? Icons.archive_outlined
                                    : Icons.chat_bubble_outline,
                                size: 42,
                                color: Theme.of(context).colorScheme.primary
                                    .withValues(alpha: .55),
                              ),
                              const SizedBox(height: 12),
                              Center(
                                child: Text(
                                  query.isNotEmpty
                                      ? 'لا توجد محادثات مطابقة'
                                      : _chatFilter == 1
                                      ? 'لا توجد رسائل غير مقروءة'
                                      : _chatFilter == 2
                                      ? 'أضف محادثات إلى المفضلة من قائمة الخيارات'
                                      : _chatFilter == 3
                                      ? 'لا توجد محادثات مؤرشفة'
                                      : 'لا توجد محادثات هنا',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Color(0xFF71827D),
                                  ),
                                ),
                              ),
                            ],
                          )
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(14, 0, 14, 104),
                            itemCount: filteredChats.length,
                            separatorBuilder: (context, _) =>
                                SizedBox(height: compactChatLayout ? 0 : 2),
                            itemBuilder: (context, index) {
                              final chat = filteredChats[index];
                              final draft = _chatDrafts[chat.conversationId];
                              final previewText =
                                  switch (chat.lastMessageType) {
                                    'image' => 'صورة',
                                    'audio' => 'رسالة صوتية',
                                    'video' => 'فيديو',
                                    'file' => 'ملف',
                                    'location' => 'موقع',
                                    _ => chat.lastMessage,
                                  };
                              final lastMessageIsMine =
                                  !chat.isGroup &&
                                  chat.lastMessageSenderId == _userId;
                              final unread = _isUnread(chat);
                              final pinned = _chatPreferences.pinned.contains(
                                chat.conversationId,
                              );
                              final favorite = _chatPreferences.favorites
                                  .contains(chat.conversationId);
                              final muted = _chatPreferences.muted.contains(
                                chat.conversationId,
                              );
                              final isDark =
                                  Theme.of(context).brightness ==
                                  Brightness.dark;
                              final colors = Theme.of(context).colorScheme;
                              final tileColor = unread
                                  ? colors.primaryContainer
                                  : pinned
                                  ? colors.secondaryContainer.withValues(
                                      alpha: isDark ? .42 : .54,
                                    )
                                  : colors.surfaceContainerLow;
                              return Padding(
                                padding: EdgeInsets.symmetric(
                                  vertical: compactChatLayout ? 2 : 4,
                                ),
                                child: Material(
                                  color: tileColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(22),
                                    side: BorderSide(
                                      color: unread
                                          ? colors.primary
                                          : colors.outlineVariant.withValues(
                                              alpha: .50,
                                            ),
                                      width: unread ? 1.25 : .75,
                                    ),
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: Stack(
                                    children: [
                                      ListTile(
                                        tileColor: Colors.transparent,
                                        contentPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                              14,
                                              compactChatLayout ? 2 : 8,
                                              14,
                                              compactChatLayout ? 2 : 8,
                                            ),
                                        minVerticalPadding: compactChatLayout
                                            ? 2
                                            : 8,
                                        leading:
                                            ValueListenableBuilder<Set<String>>(
                                              valueListenable: onlineUserIds,
                                              builder:
                                                  (
                                                    context,
                                                    onlineIds,
                                                    _,
                                                  ) => _Avatar(
                                                    label:
                                                        chat
                                                            .displayName
                                                            .isNotEmpty
                                                        ? chat.displayName
                                                        : chat.username,
                                                    imageUrl: chat.isGroup
                                                        ? groupAvatarUrl(
                                                            chat.groupAvatarPath,
                                                          )
                                                        : avatarPublicUrl(
                                                            _db,
                                                            chat.avatarPath,
                                                          ),
                                                    online:
                                                        !chat.isGroup &&
                                                        onlineIds.contains(
                                                          chat.otherUserId,
                                                        ),
                                                    showConnectionStatus:
                                                        !chat.isGroup,
                                                  ),
                                            ),
                                        title: AdminIdentityText(
                                          userId: chat.isGroup
                                              ? null
                                              : chat.otherUserId,
                                          label: chat.isGroup
                                              ? (chat.groupName ??
                                                    chat.displayName)
                                              : chat.displayName.isNotEmpty
                                              ? chat.displayName
                                              : '@${chat.username}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 15.5,
                                            fontWeight: unread
                                                ? FontWeight.w800
                                                : FontWeight.w700,
                                            color: unread
                                                ? colors.onPrimaryContainer
                                                : colors.onSurface,
                                          ),
                                        ),
                                        subtitle: Row(
                                          children: [
                                            if (lastMessageIsMine &&
                                                chat
                                                    .lastMessage
                                                    .isNotEmpty) ...[
                                              Icon(
                                                chat.lastMessageReadAt !=
                                                            null ||
                                                        chat.lastMessageDeliveredAt !=
                                                            null
                                                    ? Icons.done_all
                                                    : Icons.done,
                                                size: 15,
                                                color:
                                                    chat.lastMessageReadAt !=
                                                        null
                                                    ? const Color(0xFF1683D8)
                                                    : const Color(0xFF71827D),
                                              ),
                                              const SizedBox(width: 4),
                                            ],
                                            if (unread)
                                              Padding(
                                                padding:
                                                    const EdgeInsetsDirectional.only(
                                                      end: 7,
                                                    ),
                                                child: const UnreadChatBadge(
                                                  label: 'غير مقروءة',
                                                  semanticLabel:
                                                      'آخر رسالة غير مقروءة',
                                                  compact: true,
                                                ),
                                              ),
                                            Expanded(
                                              child: Text(
                                                draft != null
                                                    ? 'مسودة: $draft'
                                                    : previewText.isEmpty
                                                    ? (chat.isGroup
                                                          ? '${chat.memberCount} أعضاء · ابدأ الحديث'
                                                          : 'ابدأ المحادثة الآن')
                                                    : previewText,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  color: draft != null
                                                      ? Theme.of(context)
                                                            .colorScheme
                                                            .primary
                                                      : unread
                                                      ? colors
                                                            .onPrimaryContainer
                                                      : colors.onSurfaceVariant,
                                                  fontSize: 13,
                                                  fontWeight: draft != null
                                                      ? FontWeight.w600
                                                      : FontWeight.normal,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        trailing: SizedBox(
                                          width: 86,
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.end,
                                            children: [
                                              if (chat.lastMessageAt != null)
                                                Text(
                                                  DateFormat('HH:mm').format(
                                                    chat.lastMessageAt!
                                                        .toLocal(),
                                                  ),
                                                  style: TextStyle(
                                                    fontSize: 11,
                                                    color: unread
                                                        ? colors
                                                              .onPrimaryContainer
                                                        : Theme.of(context)
                                                              .colorScheme
                                                              .onSurfaceVariant,
                                                  ),
                                                ),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  if (pinned)
                                                    Icon(
                                                      Icons.push_pin,
                                                      size: 15,
                                                      color: unread
                                                          ? colors
                                                                .onPrimaryContainer
                                                          : colors
                                                                .onSurfaceVariant,
                                                    ),
                                                  if (favorite)
                                                    Icon(
                                                      Icons.star,
                                                      size: 15,
                                                      color: unread
                                                          ? colors
                                                                .onPrimaryContainer
                                                          : colors.tertiary,
                                                    ),
                                                  if (muted)
                                                    Icon(
                                                      Icons
                                                          .notifications_off_outlined,
                                                      size: 15,
                                                      color: unread
                                                          ? colors
                                                                .onPrimaryContainer
                                                          : colors
                                                                .onSurfaceVariant,
                                                    ),
                                                  PopupMenuButton<String>(
                                                    tooltip: 'خيارات المحادثة',
                                                    padding: EdgeInsets.zero,
                                                    iconSize: 19,
                                                    constraints:
                                                        const BoxConstraints(
                                                          minWidth: 30,
                                                          minHeight: 30,
                                                        ),
                                                    onSelected: (value) {
                                                      if (value == 'delete') {
                                                        unawaited(
                                                          _deleteChat(chat),
                                                        );
                                                        return;
                                                      }
                                                      if (value == 'hide') {
                                                        _deleteChat(chat);
                                                      } else {
                                                        _toggleChatPreference(
                                                          chat.conversationId,
                                                          value,
                                                        );
                                                      }
                                                    },
                                                    itemBuilder: (_) => [
                                                      PopupMenuItem(
                                                        value: 'pin',
                                                        child: Text(
                                                          pinned
                                                              ? 'إلغاء التثبيت'
                                                              : 'تثبيت المحادثة',
                                                        ),
                                                      ),
                                                      PopupMenuItem(
                                                        value: 'favorite',
                                                        child: Text(
                                                          favorite
                                                              ? 'إزالة من المفضلة'
                                                              : 'إضافة إلى المفضلة',
                                                        ),
                                                      ),
                                                      PopupMenuItem(
                                                        value: 'mute',
                                                        child: Text(
                                                          muted
                                                              ? 'إلغاء الكتم'
                                                              : 'كتم المحادثة',
                                                        ),
                                                      ),
                                                      PopupMenuItem(
                                                        value: 'archive',
                                                        child: Text(
                                                          _chatPreferences
                                                                  .archived
                                                                  .contains(
                                                                    chat.conversationId,
                                                                  )
                                                              ? 'إلغاء الأرشفة'
                                                              : 'أرشفة المحادثة',
                                                        ),
                                                      ),
                                                      const PopupMenuDivider(),
                                                      const PopupMenuItem(
                                                        value: 'delete',
                                                        child: Text(
                                                          'حذف المحادثة',
                                                          style: TextStyle(
                                                            color: Colors.red,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        onLongPress: () =>
                                            unawaited(_showChatActions(chat)),
                                        onTap: () async {
                                          await Navigator.of(context).push(
                                            MaterialPageRoute(
                                              builder: (_) => ChatScreen(
                                                callService: _callService,
                                                bubbleStyle: widget.bubbleStyle,
                                                target: ChatTarget(
                                                  conversationId:
                                                      chat.conversationId,
                                                  userId: chat.otherUserId,
                                                  username: chat.username,
                                                  displayName: chat.displayName,
                                                  avatarPath: chat.isGroup
                                                      ? chat.groupAvatarPath
                                                      : chat.avatarPath,
                                                  isGroup: chat.isGroup,
                                                  groupDescription:
                                                      chat.groupDescription,
                                                  memberCount: chat.memberCount,
                                                  groupRole: chat.groupRole,
                                                ),
                                              ),
                                            ),
                                          );
                                          if (mounted) _refreshChats();
                                        },
                                      ),
                                      if (unread)
                                        PositionedDirectional(
                                          start: 0,
                                          top: 13,
                                          bottom: 13,
                                          child: IgnorePointer(
                                            child: Container(
                                              width: 4,
                                              decoration: BoxDecoration(
                                                color: colors.primary,
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
          ),
        ],
      );
    },
  );

  int get _navigationIndex => switch (_selectedTab) {
    0 => 0,
    3 => 1,
    1 => 2,
    _ => 3,
  };

  void _onHomeNavigationSelected(int index) {
    if (index == 3) {
      unawaited(_showMoreMenu());
      return;
    }
    final sectionIndex = switch (index) {
      0 => 0,
      1 => 3,
      2 => 1,
      _ => 0,
    };
    setState(() => _selectedTab = sectionIndex);
  }

  Future<void> _showMoreMenu() async {
    final selectedSection = await showModalBottomSheet<int>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (sheetContext) {
        final colors = Theme.of(sheetContext).colorScheme;
        return Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(12, 4, 12, 10),
                child: Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                    'المزيد',
                    style: Theme.of(sheetContext).textTheme.titleLarge
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              _MoreMenuTile(
                icon: Icons.groups_2_rounded,
                title: 'الأصدقاء',
                subtitle: 'قائمة الأصدقاء وطلبات الصداقة',
                selected: _selectedTab == 4,
                selectedColor: colors.primary,
                onTap: () => Navigator.pop(sheetContext, 4),
              ),
              _MoreMenuTile(
                icon: Icons.explore_rounded,
                title: 'الاستكشاف',
                subtitle: 'اكتشف المحادثات والمجموعات العامة',
                selected: _selectedTab == 2,
                selectedColor: colors.primary,
                onTap: () => Navigator.pop(sheetContext, 2),
              ),
              _MoreMenuTile(
                icon: Icons.settings_rounded,
                title: 'الإعدادات',
                subtitle: 'الحساب والمظهر والإشعارات',
                selected: _selectedTab == 5,
                selectedColor: colors.primary,
                onTap: () => Navigator.pop(sheetContext, 5),
              ),
            ],
          ),
        );
      },
    );
    if (selectedSection != null && mounted) {
      setState(() => _selectedTab = selectedSection);
    }
  }

  Widget _navigationIcon(
    IconData icon, {
    bool selected = false,
    bool badge = false,
  }) {
    final iconWidget = Transform.translate(
      offset: selected ? const Offset(0, -2) : Offset.zero,
      child: Icon(icon),
    );
    if (!badge) return iconWidget;
    return FutureBuilder<List<ChatPreview>>(
      future: _chatsFuture,
      builder: (context, snapshot) {
        final hasUnread = snapshot.data?.any(_isUnread) ?? false;
        return Stack(
          clipBehavior: Clip.none,
          children: [
            iconWidget,
            if (hasUnread)
              PositionedDirectional(
                top: -1,
                start: -1,
                child: Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.error,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Theme.of(context).colorScheme.surface,
                      width: 1.5,
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _db.auth.currentUser;
    final titles = const [
      'الدردشات',
      'الحالات',
      'الاستكشاف',
      'المكالمات',
      'الأصدقاء',
      'الإعدادات',
    ];
    return Scaffold(
      appBar: _selectedTab == 4
          ? null
          : AppBar(
              toolbarHeight: _selectedTab == 0 ? 78 : 82,
              titleSpacing: 20,
              title: _selectedTab == 0
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'الدردشات',
                          style: Theme.of(context).textTheme.titleLarge
                              ?.copyWith(
                                fontWeight: FontWeight.w800,
                                letterSpacing: -.2,
                                height: 1.15,
                              ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          'رسائلك ومجموعاتك في مكان واحد',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                      ],
                    )
                  : Text(
                      titles[_selectedTab],
                      style: Theme.of(context).textTheme.titleLarge
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
              actions: [
                if (_selectedTab == 0)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 16),
                    child: IconButton.filledTonal(
                      tooltip: 'محادثة جديدة',
                      onPressed: _startNewChat,
                      icon: const Icon(Icons.edit_square, size: 21),
                    ),
                  ),
              ],
            ),
      body: IndexedStack(
        index: _selectedTab,
        children: [
          _buildChatSection(user?.userMetadata?['username']?.toString()),
          const StatusSection(),
          PublicDiscoveryScreen(onOpenChat: _openGroupChat),
          CallsSection(
            service: _callService,
            onStartCall: _startCallFromPeople,
            onCallAgain: _redialCall,
          ),
          FriendsSection(
            friends: _friends,
            friendsLoading: _friendsLoading,
            friendsError: _friendsError,
            onRefreshFriends: () => unawaited(_refreshFriends()),
            onOpenFriend: (friend) => unawaited(_openFriendChat(friend)),
            onRemoveFriend: (friend) => unawaited(_removeFriend(friend)),
            onSearchUsers: _startNewChat,
            onNearbyFriends: () => unawaited(_showNearbyFriends()),
            onFriendRequests: _showFriendRequests,
            pendingFriendRequests: _pendingFriendRequests,
            onShowQr: _showQrOptions,
            onInvite: _inviteFriend,
            onOpenSettings: () => setState(() => _selectedTab = 5),
          ),
          SettingsSection(
            onProfile: _showProfile,
            onInfo: _showInfo,
            onNotifications: _openNotificationSettings,
            onSaveMediaOptions: _openMediaSaveOptions,
            onPresenceStatus: _choosePresenceStatus,
            presenceStatus: effectivePresenceStatus(
              _myPresenceStatus,
              online: _hasInternetConnection,
            ),
            onSignOut: _signOut,
            themeMode: widget.themeMode,
            onThemeModeChanged: widget.onThemeModeChanged,
            themeId: widget.themeId,
            customThemes: widget.customThemes,
            onThemeIdChanged: widget.onThemeIdChanged,
            onCustomThemeCreated: widget.onCustomThemeCreated,
            onCustomThemesChanged: widget.onCustomThemesChanged,
            textSize: widget.textSize,
            onTextSizeChanged: widget.onTextSizeChanged,
            bubbleStyle: widget.bubbleStyle,
            onBubbleStyleChanged: widget.onBubbleStyleChanged,
            reduceMotion: widget.reduceMotion,
            onReduceMotionChanged: widget.onReduceMotionChanged,
            highContrast: widget.highContrast,
            onHighContrastChanged: widget.onHighContrastChanged,
            compactLayout: widget.compactLayout,
            onCompactLayoutChanged: widget.onCompactLayoutChanged,
            showChatStatusHighlights: widget.showChatStatusHighlights,
            onShowChatStatusHighlightsChanged:
                widget.onShowChatStatusHighlightsChanged,
            onExportData: _exportChatArchive,
            onAbout: _openAboutPage,
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface
                  .withValues(alpha: .92),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant
                    .withValues(alpha: .65),
              ),
              boxShadow: [
                BoxShadow(
                  color: Theme.of(context).shadowColor.withValues(alpha: .12),
                  blurRadius: 24,
                  offset: const Offset(0, 7),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: NavigationBarTheme(
                data: NavigationBarThemeData(
                  height: 72,
                  backgroundColor: Colors.transparent,
                  surfaceTintColor: Colors.transparent,
                  indicatorColor: Theme.of(context).colorScheme.primary
                      .withValues(alpha: .13),
                  indicatorShape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                  labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
                  iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
                    (states) => IconThemeData(
                      size: 22,
                      color: states.contains(WidgetState.selected)
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
                    (states) => TextStyle(
                      fontSize: 12,
                      fontWeight: states.contains(WidgetState.selected)
                          ? FontWeight.w600
                          : FontWeight.w500,
                      color: states.contains(WidgetState.selected)
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                child: NavigationBar(
                  height: 72,
                  elevation: 0,
                  selectedIndex: _navigationIndex,
                  animationDuration: const Duration(milliseconds: 220),
                  onDestinationSelected: _onHomeNavigationSelected,
                  destinations: [
                    NavigationDestination(
                      icon: _navigationIcon(Icons.forum_outlined, badge: true),
                      selectedIcon: _navigationIcon(
                        Icons.forum_rounded,
                        selected: true,
                        badge: true,
                      ),
                      label: 'الدردشات',
                    ),
                    NavigationDestination(
                      icon: _navigationIcon(Icons.call_outlined),
                      selectedIcon: _navigationIcon(
                        Icons.call_rounded,
                        selected: true,
                      ),
                      label: 'المكالمات',
                    ),
                    NavigationDestination(
                      icon: _navigationIcon(Icons.auto_awesome_outlined),
                      selectedIcon: _navigationIcon(
                        Icons.auto_awesome_rounded,
                        selected: true,
                      ),
                      label: 'الحالات',
                    ),
                    NavigationDestination(
                      icon: _navigationIcon(Icons.apps_outlined),
                      selectedIcon: _navigationIcon(
                        Icons.apps_rounded,
                        selected: true,
                      ),
                      label: 'المزيد',
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: _selectedTab == 0
          ? FloatingActionButton(
              onPressed: _showCreateMenu,
              tooltip: 'إنشاء جديد',
              child: const Icon(Icons.add_rounded),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

class _MoreMenuTile extends StatelessWidget {
  const _MoreMenuTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.selectedColor,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool selected;
  final Color selectedColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListTile(
      selected: selected,
      selectedTileColor: colors.primaryContainer.withValues(alpha: .45),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      contentPadding: const EdgeInsetsDirectional.fromSTEB(14, 4, 10, 4),
      leading: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: selected
              ? selectedColor.withValues(alpha: .12)
              : colors.surfaceContainerHighest,
          shape: BoxShape.circle,
        ),
        child: Icon(
          icon,
          color: selected ? selectedColor : colors.onSurfaceVariant,
          size: 22,
        ),
      ),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
          color: selected ? selectedColor : null,
        ),
      ),
      subtitle: Text(subtitle),
      trailing: Icon(Icons.chevron_left, color: colors.onSurfaceVariant),
      onTap: onTap,
    );
  }
}

class _CreateActionTile extends StatelessWidget {
  const _CreateActionTile({
    required this.icon,
    required this.title,
    required this.value,
  });
  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) => ListTile(
    leading: Icon(icon),
    title: Text(title),
    onTap: () => Navigator.pop(context, value),
  );
}

class _ChatFilterChip extends StatelessWidget {
  const _ChatFilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
    this.count,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  final int? count;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: count == null
            ? Text(label)
            : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(label),
                  const SizedBox(width: 6),
                  Container(
                    constraints: const BoxConstraints(minWidth: 18),
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    decoration: BoxDecoration(
                      color: selected
                          ? colors.onPrimary.withValues(alpha: .20)
                          : colors.primaryContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '$count',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: selected
                            ? colors.onPrimary
                            : colors.onPrimaryContainer,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
        avatar: icon == null
            ? null
            : Icon(
                icon,
                size: 16,
                color: selected ? colors.onPrimary : colors.onSurfaceVariant,
              ),
        selected: selected,
        showCheckmark: false,
        onSelected: (_) => onTap(),
        selectedColor: colors.primary,
        backgroundColor: colors.surfaceContainerLow,
        visualDensity: VisualDensity.compact,
        materialTapTargetSize: MaterialTapTargetSize.padded,
        side: BorderSide(
          color: selected
              ? colors.primary.withValues(alpha: .12)
              : colors.outlineVariant.withValues(alpha: .72),
        ),
        shape: const StadiumBorder(),
        labelStyle: TextStyle(
          color: selected ? colors.onPrimary : colors.onSurfaceVariant,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _displayName = TextEditingController();
  final _bio = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  bool _avatarSaving = false;
  String? _avatarPath;
  String? _error;

  @override
  void initState() {
    super.initState();
    _displayName.text =
        _db.auth.currentUser?.userMetadata?['display_name']?.toString() ?? '';
    _loadProfile();
  }

  @override
  void dispose() {
    _displayName.dispose();
    _bio.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final user = _db.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      await VerifiedMemberBadges.refresh(_db);
      final row = await _db
          .from('profiles')
          .select('display_name, avatar_path, bio')
          .eq('id', user.id)
          .maybeSingle();
      if (mounted && row != null) {
        _displayName.text =
            row['display_name']?.toString() ?? _displayName.text;
        _bio.text = row['bio']?.toString() ?? '';
        _avatarPath = row['avatar_path']?.toString();
      }
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'تعذر تحميل بيانات الحساب؛ يمكنك المحاولة مجددًا.',
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final user = _db.auth.currentUser;
    if (user == null) return;
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await _db
          .from('profiles')
          .update({
            'display_name': _displayName.text.trim(),
            'bio': _bio.text.trim(),
          })
          .eq('id', user.id);
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'تعذر حفظ الاسم الآن. تحقق من الاتصال وحاول مجددًا.',
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _changeAvatar() async {
    final user = _db.auth.currentUser;
    if (user == null || _avatarSaving) return;
    try {
      final image = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 84,
        maxWidth: 1200,
      );
      if (image == null || !mounted) return;
      final bytes = await image.readAsBytes();
      if (!mounted) return;
      if (bytes.length > 5 * 1024 * 1024) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حجم الصورة أكبر من ٥ ميغابايت.')),
        );
        return;
      }
      setState(() {
        _avatarSaving = true;
        _error = null;
      });
      final path =
          '${user.id}/avatar_${DateTime.now().microsecondsSinceEpoch}.jpg';
      await _db.storage
          .from('wasla-avatars')
          .uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(contentType: 'image/jpeg'),
          );
      await _db
          .from('profiles')
          .update({'avatar_path': path})
          .eq('id', user.id);
      if (mounted) setState(() => _avatarPath = path);
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = 'تعذر تغيير الصورة. تحقق من الاتصال وحاول مجددًا.',
        );
      }
    } finally {
      if (mounted) setState(() => _avatarSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _db.auth.currentUser;
    final username = user?.userMetadata?['username']?.toString() ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Center(
                  child: Column(
                    children: [
                      _Avatar(
                        label: _displayName.text,
                        imageUrl: avatarPublicUrl(_db, _avatarPath),
                        radius: 48,
                      ),
                      const SizedBox(height: 10),
                      ValueListenableBuilder<TextEditingValue>(
                        valueListenable: _displayName,
                        builder: (context, value, _) => AdminIdentityText(
                          userId: user?.id,
                          label: value.text.trim().isEmpty
                              ? '@$username'
                              : value.text.trim(),
                          style: Theme.of(context).textTheme.titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                      ),
                      const SizedBox(height: 8),
                      VerifiedAccountStatus(userId: user?.id),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _avatarSaving ? null : _changeAvatar,
                        icon: _avatarSaving
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.add_a_photo_outlined),
                        label: Text(
                          _avatarSaving
                              ? 'جارٍ رفع الصورة'
                              : 'تغيير الصورة الشخصية',
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  user?.email ?? '',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 24),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        initialValue: '@$username',
                        readOnly: true,
                        decoration: const InputDecoration(
                          labelText: 'اسم المستخدم',
                          prefixIcon: Icon(Icons.alternate_email),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _displayName,
                        maxLength: 60,
                        decoration: const InputDecoration(
                          labelText: 'الاسم الظاهر',
                          prefixIcon: Icon(Icons.person_outline),
                          counterText: '',
                        ),
                        validator: (value) =>
                            (value == null ||
                                value.trim().length < 2 ||
                                value.trim().length > 60)
                            ? 'اكتب اسمًا من حرفين إلى ٦٠ حرفًا'
                            : null,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _bio,
                        maxLength: 160,
                        maxLines: 3,
                        minLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'نبذة عني',
                          hintText: 'اكتب نبذة قصيرة عنك',
                          prefixIcon: Icon(Icons.notes_outlined),
                          counterText: '',
                        ),
                      ),
                      const SizedBox(height: 18),
                      if (_error != null) ...[
                        _InlineNotice(text: _error!, error: true),
                        const SizedBox(height: 12),
                      ],
                      SizedBox(
                        height: 52,
                        child: FilledButton(
                          onPressed: _saving ? null : _save,
                          child: _saving
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Text('حفظ التغييرات'),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

enum _PeopleFilter { all, friends, requests, newPeople }

class FindPeopleScreen extends StatefulWidget {
  const FindPeopleScreen({this.initialPerson, super.key});
  final ChatTarget? initialPerson;
  @override
  State<FindPeopleScreen> createState() => _FindPeopleScreenState();
}

class _FindPeopleScreenState extends State<FindPeopleScreen> {
  final _controller = TextEditingController();
  List<ChatTarget> _people = [];
  bool _loading = false;
  String? _error;
  final Map<String, FriendshipStatus> _friendshipStatuses = {};
  final Set<String> _friendshipLoadingIds = {};
  final Set<String> _friendshipBusyIds = {};
  int _searchGeneration = 0;
  Timer? _searchDebounce;

  @override
  void initState() {
    super.initState();
    final person = widget.initialPerson;
    if (person != null) {
      _people = [person];
      _friendshipLoadingIds.add(person.userId);
      unawaited(_loadFriendshipStatuses([person], _searchGeneration));
    }
  }

  @override
  void dispose() {
    _searchDebounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  _PeopleFilter _selectedFilter = _PeopleFilter.all;

  List<ChatTarget> get _visiblePeople => _people
      .where((person) => _matchesFilter(person, _selectedFilter))
      .toList();

  bool _matchesFilter(ChatTarget person, _PeopleFilter filter) {
    final status = _friendshipStatuses[person.userId];
    switch (filter) {
      case _PeopleFilter.all:
        return true;
      case _PeopleFilter.friends:
        return status?.isAccepted == true;
      case _PeopleFilter.requests:
        return status?.isPending == true;
      case _PeopleFilter.newPeople:
        if (status == null) {
          return !_friendshipLoadingIds.contains(person.userId);
        }
        return !status.isAccepted && !status.isPending;
    }
  }

  int _countFor(_PeopleFilter filter) => filter == _PeopleFilter.all
      ? _people.length
      : _people.where((person) => _matchesFilter(person, filter)).length;

  String _filterLabel(_PeopleFilter filter) => switch (filter) {
    _PeopleFilter.all => 'الكل',
    _PeopleFilter.friends => 'الأصدقاء',
    _PeopleFilter.requests => 'الطلبات',
    _PeopleFilter.newPeople => 'أشخاص جدد',
  };

  void _searchChanged(String _) {
    _searchDebounce?.cancel();
    setState(() {});
    _searchDebounce = Timer(
      const Duration(milliseconds: 400),
      () => unawaited(_search()),
    );
  }

  Future<void> _search() async {
    _searchDebounce?.cancel();
    _searchDebounce = null;
    final generation = ++_searchGeneration;
    final query = _controller.text.trim();
    final usernameQuery = query.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '');
    final nameQuery = query
        .replaceAll(RegExp(r'[^a-zA-Z0-9\u0600-\u06FF ]'), '')
        .trim();
    if (usernameQuery.isEmpty && nameQuery.isEmpty) {
      setState(() {
        _people = [];
        _friendshipStatuses.clear();
        _friendshipLoadingIds.clear();
        _error = null;
        _loading = false;
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final queries = <Future<List<Map<String, dynamic>>>>[];
      if (usernameQuery.isNotEmpty) {
        queries.add(
          _db
              .from('profiles')
              .select('id, username, display_name, avatar_path, bio')
              .ilike('username', '$usernameQuery%')
              .neq('id', _db.auth.currentUser!.id)
              .order('username')
              .limit(25),
        );
      }
      if (nameQuery.isNotEmpty) {
        queries.add(
          _db
              .from('profiles')
              .select('id, username, display_name, avatar_path, bio')
              .ilike('display_name', '%$nameQuery%')
              .neq('id', _db.auth.currentUser!.id)
              .order('username')
              .limit(25),
        );
      }
      final resultSets = await Future.wait(queries);
      if (!mounted || generation != _searchGeneration) return;
      final uniqueRows = <String, Map<String, dynamic>>{};
      for (final rows in resultSets) {
        for (final row in rows) {
          uniqueRows[row['id'].toString()] = Map<String, dynamic>.from(row);
        }
      }
      try {
        mergeUserPresenceStatuses(
          await UserPresenceService(_db).loadForUsers(uniqueRows.keys),
        );
      } catch (_) {
        // Search remains available if presence-status migration is pending.
      }
      if (!mounted || generation != _searchGeneration) return;
      final people = uniqueRows.values
          .map(
            (row) => ChatTarget(
              conversationId: '',
              userId: row['id'].toString(),
              username: row['username']?.toString() ?? '',
              displayName: row['display_name']?.toString() ?? '',
              avatarPath: row['avatar_path']?.toString(),
              bio: row['bio']?.toString() ?? '',
            ),
          )
          .toList();
      setState(() {
        _people = people;
        _friendshipStatuses.clear();
        _friendshipLoadingIds
          ..clear()
          ..addAll(people.map((person) => person.userId));
      });
      unawaited(_loadFriendshipStatuses(people, generation));
    } catch (_) {
      if (mounted && generation == _searchGeneration) {
        setState(() => _error = 'تعذر البحث الآن. حاول مرة أخرى.');
      }
    } finally {
      if (mounted && generation == _searchGeneration) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _loadFriendshipStatuses(
    List<ChatTarget> people,
    int generation,
  ) async {
    final service = FriendshipService(_db);
    final statuses = <String, FriendshipStatus>{};
    await Future.wait(
      people.map((person) async {
        try {
          statuses[person.userId] = await service.statusFor(person.userId);
        } catch (_) {
          // Keep the add-friend action available if status lookup fails.
        }
      }),
    );
    if (!mounted || generation != _searchGeneration) return;
    setState(() {
      _friendshipStatuses.addAll(statuses);
      _friendshipLoadingIds.removeAll(people.map((person) => person.userId));
    });
  }

  Future<void> _updateFriendship(
    ChatTarget person, {
    required bool accept,
  }) async {
    if (_friendshipBusyIds.contains(person.userId)) return;
    setState(() => _friendshipBusyIds.add(person.userId));
    try {
      final service = FriendshipService(_db);
      if (accept) {
        await service.respond(person.userId, accept: true);
      } else {
        await service.sendRequest(person.userId);
      }
      final status = await service.statusFor(person.userId);
      if (!mounted) return;
      setState(() => _friendshipStatuses[person.userId] = status);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            status.isAccepted
                ? 'أصبحتما صديقين على وصال.'
                : 'تم إرسال طلب الصداقة.',
          ),
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر تحديث الصداقة. تحقق من الاتصال وحاول مجددًا.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _friendshipBusyIds.remove(person.userId));
    }
  }

  Widget _friendshipButton(ChatTarget person) {
    if (_friendshipLoadingIds.contains(person.userId) ||
        _friendshipBusyIds.contains(person.userId)) {
      return const SizedBox(
        width: 36,
        height: 36,
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }

    final status = _friendshipStatuses[person.userId];
    final currentUserId = _db.auth.currentUser?.id;
    if (status?.isAccepted == true) {
      return const Chip(
        avatar: Icon(Icons.check, size: 16),
        label: Text('صديق'),
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
      );
    }
    if (status?.isIncomingFor(currentUserId ?? '') == true) {
      return OutlinedButton.icon(
        onPressed: () => _updateFriendship(person, accept: true),
        icon: const Icon(Icons.check, size: 17),
        label: const Text('قبول الطلب'),
        style: OutlinedButton.styleFrom(
          visualDensity: VisualDensity.compact,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          minimumSize: const Size(0, 36),
        ),
      );
    }
    if (status?.isOutgoingFor(currentUserId ?? '') == true) {
      return const Chip(
        avatar: Icon(Icons.schedule, size: 16),
        label: Text('تم الإرسال'),
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
      );
    }
    return OutlinedButton.icon(
      onPressed: () => _updateFriendship(person, accept: false),
      icon: const Icon(Icons.person_add_alt_1, size: 17),
      label: const Text('إضافة صديق'),
      style: OutlinedButton.styleFrom(
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        minimumSize: const Size(0, 36),
      ),
    );
  }

  Widget _scannedPersonProfile(ChatTarget person) => Center(
    child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _Avatar(
                  label: person.displayName.isNotEmpty
                      ? person.displayName
                      : person.username,
                  imageUrl: avatarPublicUrl(_db, person.avatarPath),
                  radius: 48,
                ),
                const SizedBox(height: 16),
                AdminIdentityText(
                  userId: person.userId,
                  label: person.displayName.isNotEmpty
                      ? person.displayName
                      : '@${person.username}',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  '@${person.username}',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                if (person.bio.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(person.bio, textAlign: TextAlign.center),
                ],
                const SizedBox(height: 22),
                _friendshipButton(person),
              ],
            ),
          ),
        ),
      ),
    ),
  );

  Future<void> _openChat(ChatTarget person) async {
    setState(() => _loading = true);
    try {
      final id = await _db.rpc(
        'create_direct_conversation',
        params: {'p_target_user': person.userId},
      );
      if (!mounted) return;
      Navigator.of(context).pop(
        ChatTarget(
          conversationId: id.toString(),
          userId: person.userId,
          username: person.username,
          displayName: person.displayName,
          avatarPath: person.avatarPath,
          bio: person.bio,
        ),
      );
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'تعذر بدء المحادثة. تحقق من اتصالك ثم أعد المحاولة.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.initialPerson == null ? 'محادثة جديدة' : 'ملف صديق'),
    ),
    body: Column(
      children: [
        if (widget.initialPerson == null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              controller: _controller,
              textInputAction: TextInputAction.search,
              autocorrect: false,
              onChanged: _searchChanged,
              onSubmitted: (_) => _search(),
              decoration: InputDecoration(
                hintText: 'ابحث بالاسم أو اسم المستخدم',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  tooltip: _controller.text.isEmpty ? 'بحث' : 'مسح البحث',
                  onPressed: _controller.text.isEmpty
                      ? _search
                      : () {
                          _controller.clear();
                          _searchChanged('');
                        },
                  icon: Icon(
                    _controller.text.isEmpty
                        ? Icons.arrow_forward
                        : Icons.clear,
                  ),
                ),
              ),
            ),
          ),
        if (widget.initialPerson == null && _people.isNotEmpty)
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
              itemCount: _PeopleFilter.values.length,
              separatorBuilder: (_, _) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final filter = _PeopleFilter.values[index];
                return ChoiceChip(
                  label: Text('${_filterLabel(filter)} (${_countFor(filter)})'),
                  selected: _selectedFilter == filter,
                  onSelected: (selected) {
                    if (selected) setState(() => _selectedFilter = filter);
                  },
                );
              },
            ),
          ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: _InlineNotice(text: _error!, error: true),
          ),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: widget.initialPerson != null
              ? _scannedPersonProfile(widget.initialPerson!)
              : _people.isEmpty
              ? Center(
                  child: Text(
                    _controller.text.isEmpty
                        ? 'اكتب اسمًا أو اسم المستخدم للبحث عن شخص'
                        : 'لا توجد نتائج بعد',
                    style: const TextStyle(color: Color(0xFF71827D)),
                  ),
                )
              : _visiblePeople.isEmpty
              ? Center(
                  child: Text(
                    'لا توجد نتائج ضمن هذا التصنيف',
                    style: const TextStyle(color: Color(0xFF71827D)),
                  ),
                )
              : ListView.separated(
                  itemCount: _visiblePeople.length,
                  separatorBuilder: (_, _) =>
                      const Divider(height: 1, indent: 78),
                  itemBuilder: (context, index) {
                    final person = _visiblePeople[index];
                    return ListTile(
                      leading:
                          ValueListenableBuilder<
                            Map<String, UserPresenceStatus>
                          >(
                            valueListenable: userPresenceStatuses,
                            builder: (context, statuses, _) =>
                                ValueListenableBuilder<Set<String>>(
                                  valueListenable: onlineUserIds,
                                  builder: (context, onlineIds, _) => _Avatar(
                                    label: person.displayName.isNotEmpty
                                        ? person.displayName
                                        : person.username,
                                    imageUrl: avatarPublicUrl(
                                      _db,
                                      person.avatarPath,
                                    ),
                                    online: onlineIds.contains(person.userId),
                                    presenceStatus: statuses[person.userId],
                                  ),
                                ),
                          ),
                      title:
                          ValueListenableBuilder<
                            Map<String, UserPresenceStatus>
                          >(
                            valueListenable: userPresenceStatuses,
                            builder: (context, statuses, _) =>
                                ValueListenableBuilder<Set<String>>(
                                  valueListenable: onlineUserIds,
                                  builder: (context, onlineIds, _) => Row(
                                    children: [
                                      Expanded(
                                        child: AdminIdentityText(
                                          userId: person.userId,
                                          label: person.displayName.isNotEmpty
                                              ? person.displayName
                                              : '@${person.username}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                      if (statuses[person.userId] != null) ...[
                                        const SizedBox(width: 6),
                                        PresenceStatusLabel(
                                          status: effectivePresenceStatus(
                                            statuses[person.userId]!,
                                            online: onlineIds.contains(
                                              person.userId,
                                            ),
                                          ),
                                          fontSize: 10,
                                          dotSize: 7,
                                          userId: person.userId,
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                          ),
                      subtitle: Text(
                        person.bio.isEmpty
                            ? '@${person.username}'
                            : '@${person.username} · ${person.bio}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      trailing: _friendshipButton(person),
                      onTap: _loading ? null : () => _openChat(person),
                    );
                  },
                ),
        ),
      ],
    ),
  );
}

class FriendRequestsScreen extends StatefulWidget {
  const FriendRequestsScreen({super.key});

  @override
  State<FriendRequestsScreen> createState() => _FriendRequestsScreenState();
}

class _FriendRequestsScreenState extends State<FriendRequestsScreen> {
  final _service = FriendshipService(_db);
  late final RealtimeChannel _channel;
  List<FriendRequest> _requests = [];
  bool _loading = true;
  String? _error;
  String? _busyUserId;

  @override
  void initState() {
    super.initState();
    _channel =
        _db.channel('wasla-friend-requests-screen-${_db.auth.currentUser!.id}')
          ..onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'friend_requests',
            callback: (_) => unawaited(_loadRequests()),
          )
          ..subscribe();
    unawaited(_loadRequests());
  }

  @override
  void dispose() {
    _db.removeChannel(_channel);
    super.dispose();
  }

  Future<void> _loadRequests() async {
    try {
      final requests = await _service.incomingRequests();
      if (!mounted) return;
      setState(() {
        _requests = requests;
        _error = null;
        _loading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _error = 'تعذر تحميل طلبات الصداقة. تحقق من الاتصال وحاول مجددًا.';
          _loading = false;
        });
      }
    }
  }

  Future<void> _respond(FriendRequest request, {required bool accept}) async {
    if (_busyUserId != null) return;
    setState(() => _busyUserId = request.requesterId);
    try {
      await _service.respond(request.requesterId, accept: accept);
      await _loadRequests();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              accept ? 'أصبحتما صديقين على وصال.' : 'تم رفض طلب الصداقة.',
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث الطلب. أعد المحاولة.')),
        );
      }
    } finally {
      if (mounted) setState(() => _busyUserId = null);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('طلبات الصداقة'),
      actions: [
        IconButton(
          tooltip: 'تحديث',
          onPressed: _loading ? null : () => unawaited(_loadRequests()),
          icon: const Icon(Icons.refresh),
        ),
      ],
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
        ? _LoadError(
            onRetry: () => unawaited(_loadRequests()),
            message: _error!,
          )
        : _requests.isEmpty
        ? const Center(
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.person_add_disabled_outlined, size: 48),
                  SizedBox(height: 12),
                  Text(
                    'لا توجد طلبات صداقة جديدة',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 24),
            itemCount: _requests.length,
            itemBuilder: (context, index) {
              final request = _requests[index];
              final busy = _busyUserId == request.requesterId;
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          _Avatar(
                            label: request.label,
                            imageUrl: avatarPublicUrl(_db, request.avatarPath),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  request.label,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text('@${request.username}'),
                                const Text('يريد إضافتك إلى الأصدقاء'),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busyUserId == null
                                  ? () => _respond(request, accept: true)
                                  : null,
                              icon: busy
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    )
                                  : const Icon(Icons.check),
                              label: const Text('قبول'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _busyUserId == null
                                  ? () => _respond(request, accept: false)
                                  : null,
                              icon: const Icon(Icons.close),
                              label: const Text('رفض'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
  );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({
    required this.target,
    required this.callService,
    this.bubbleStyle = MessageBubbleStyle.classic,
    super.key,
  });
  final ChatTarget target;
  final CallService callService;
  final MessageBubbleStyle bubbleStyle;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  static const _initialMessagePageSize = 300;
  static const _olderMessagePageSize = 100;
  final _messageController = TextEditingController();
  final _messageFocusNode = FocusNode();
  final _searchController = TextEditingController();
  final _scrollController = ScrollController();
  final _localCache = ChatLocalCache();
  final _conversationSettings = ChatConversationSettingsStore();
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _incomingChatPlayer = AudioPlayer();
  final IncomingChatSoundGate _incomingChatSoundGate = IncomingChatSoundGate();
  final ChatListPreferencesStore _chatListPreferencesStore =
      ChatListPreferencesStore();
  Future<void> _incomingSoundQueue = Future<void>.value();
  Timer? _recordingTimer;
  Stopwatch? _recordingClock;
  String? _recordingPath;
  String? _failedRecordingPath;
  StreamSubscription<dynamic>? _recordingAmplitudeSubscription;
  List<double> _recordingWaveform = List<double>.filled(26, .12);
  Duration _recordingDuration = Duration.zero;
  late final RealtimeChannel _channel;
  RealtimeChannel? _groupActivityChannel;
  RealtimeChannel? _friendshipChannel;
  Timer? _roomPresenceTimer;
  Timer? _peerLastSeenTimer;
  Timer? _outboxRetryTimer;
  Timer? _runtimeSettingsTimer;
  Timer? _messageRefreshTimer;
  Timer? _draftSaveTimer;
  Timer? _typingStartTimer;
  Timer? _typingStopTimer;
  RealtimeChannel? _typingChannel;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  bool _outboxSyncInFlight = false;
  Future<void> _draftSaveTail = Future<void>.value();
  DateTime? _peerLastSeenAt;
  bool _typingChannelReady = false;
  bool _typingIsAnnounced = false;
  final Set<String> _peerTypingUserIds = {};
  final Map<String, Timer> _peerTypingTimers = {};
  bool _peerLastSeenLoaded = false;
  bool _peerLastSeenLoading = false;
  List<ChatMessage> _messages = [];
  bool _didCheckLocalMessages = false;
  bool _messageLoadInFlight = false;
  bool _messageReloadQueued = false;
  bool _loading = true;
  bool _loadingOlderMessages = false;
  bool _hasMoreMessages = true;
  bool _sending = false;
  bool _recording = false;
  bool _recordingLocked = false;
  bool _stoppingRecording = false;
  bool _searching = false;
  int? _chatBackgroundColor;
  String? _error;
  String? _myUserId;
  Set<String> _starredMessageIds = {};
  String? _groupName;
  String? _groupAvatarPath;
  String? _groupRole;
  int _groupMemberCount = 0;
  int _roomOnlineCount = 0;
  bool _groupCanSend = true;
  bool _friendshipLoading = true;
  bool _friendshipBusy = false;
  FriendshipStatus _friendshipStatus = const FriendshipStatus();
  bool _groupFilesAllowed = true;
  bool _groupVoiceAllowed = true;
  bool _groupAdminsCanPin = true;
  bool _groupAdminsCanDeleteMessages = true;
  Map<String, String> _groupSenderNames = {};
  Map<String, Map<String, int>> _messageReactions = {};
  Set<String> _pinnedMessageIds = {};
  ChatMessage? _replyingTo;

  bool get _isGroupAdmin => _groupRole == 'owner' || _groupRole == 'admin';
  bool get _canPinGroupMessages =>
      _groupRole == 'owner' || (_groupRole == 'admin' && _groupAdminsCanPin);
  bool get _canDeleteGroupMessages =>
      _groupRole == 'owner' ||
      (_groupRole == 'admin' && _groupAdminsCanDeleteMessages);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_refreshRuntimeSettings(force: true));
    _runtimeSettingsTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      unawaited(_refreshRuntimeSettings(force: true));
    });
    _myUserId = _db.auth.currentUser?.id;
    unawaited(_restoreStarredMessageIds());
    _messageController.addListener(_handleDraftTextChanged);
    unawaited(_restoreDraft());
    unawaited(_loadChatBackground());
    PushNotifications.instance.activeConversationId =
        widget.target.conversationId;
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((
      results,
    ) {
      if (results.any((result) => result != ConnectivityResult.none)) {
        unawaited(_syncPendingMessages());
      }
    }, onError: (_) {});
    _outboxRetryTimer = Timer.periodic(
      const Duration(seconds: 12),
      (_) => unawaited(_syncPendingMessages()),
    );
    if (!widget.target.isGroup && widget.target.userId.isNotEmpty) {
      unawaited(_loadPeerLastSeen());
      _peerLastSeenTimer = Timer.periodic(
        const Duration(seconds: 45),
        (_) => unawaited(_loadPeerLastSeen()),
      );
    }
    if (!widget.target.isGroup) {
      _friendshipChannel =
          _db.channel('wasla-friendship-${widget.target.conversationId}')
            ..onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: 'friend_requests',
              callback: (_) => unawaited(_loadFriendship()),
            )
            ..subscribe();
      unawaited(_loadFriendship());
    }
    _channel = _db.channel('wasla-chat-${widget.target.conversationId}')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'messages',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'conversation_id',
          value: widget.target.conversationId,
        ),
        callback: (payload) {
          if (payload.eventType == PostgresChangeEvent.delete) {
            final messageId = payload.oldRecord['id']?.toString();
            if (messageId != null && messageId.isNotEmpty && mounted) {
              setState(() {
                _messages = _messages
                    .where((message) => message.id != messageId)
                    .toList();
              });
            }
            _scheduleMessageRefresh();
            return;
          }

          final row = payload.newRecord;
          final messageId = row['id']?.toString();
          final senderId = row['sender_id']?.toString();
          if (messageId != null &&
              messageId.isNotEmpty &&
              senderId != null &&
              senderId.isNotEmpty &&
              row['created_at'] != null) {
            final incoming = ChatMessage.fromMap(row);
            final previous = _messages
                .where((message) => message.id == incoming.id)
                .firstOrNull;
            if (previous == null &&
                payload.eventType != PostgresChangeEvent.insert) {
              _scheduleMessageRefresh();
              return;
            }
            final payloadChanged =
                previous == null ||
                previous.content != incoming.content ||
                previous.messageType != incoming.messageType ||
                previous.mediaPath != incoming.mediaPath ||
                previous.mediaDurationSeconds !=
                    incoming.mediaDurationSeconds ||
                previous.editedAt != incoming.editedAt ||
                previous.payloadDeletedAt != incoming.payloadDeletedAt ||
                previous.isEphemeral != incoming.isEphemeral;
            if (mounted) {
              setState(() {
                _messages = mergeChatHistoryMessages(_messages, [incoming]);
                _loading = false;
                _error = null;
              });
            }
            if (payload.eventType == PostgresChangeEvent.insert ||
                payloadChanged) {
              _scheduleMessageRefresh();
            }
          } else {
            _scheduleMessageRefresh();
          }
          if (payload.eventType != PostgresChangeEvent.insert) return;
          _queueIncomingMessageSound(messageId: messageId, senderId: senderId);
          if (widget.target.isGroup &&
              senderId != null &&
              senderId != _myUserId) {
            final sender = _groupSenderNames[senderId] ?? 'أحد الأعضاء';
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('رسالة جديدة من $sender'),
                duration: const Duration(seconds: 3),
              ),
            );
          }
        },
      )
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'conversation_pinned_messages',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'conversation_id',
          value: widget.target.conversationId,
        ),
        callback: (_) => _scheduleMessageRefresh(),
      )
      ..subscribe();
    _setupTypingChannel();
    if (widget.target.isGroup) {
      _groupActivityChannel =
          _db.channel('wasla-group-events-${widget.target.conversationId}')
            ..onPostgresChanges(
              event: PostgresChangeEvent.insert,
              schema: 'public',
              table: 'group_activity',
              filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'conversation_id',
                value: widget.target.conversationId,
              ),
              callback: (payload) {
                final row = payload.newRecord;
                final actorId = row['actor_id']?.toString();
                if (actorId != null && actorId != _myUserId) {
                  final actor = _groupSenderNames[actorId] ?? 'أحد الأعضاء';
                  final notice = _groupActivityNotice(
                    row['action']?.toString() ?? '',
                    actor,
                  );
                  if (notice.isNotEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(notice),
                        duration: const Duration(seconds: 4),
                      ),
                    );
                  }
                  unawaited(_loadGroupHeader());
                }
              },
            )
            ..subscribe();
    }
    _loadMessages();
    unawaited(_syncPendingMessages());
    if (widget.target.isGroup) unawaited(_loadGroupHeader());
    if (widget.target.isPublicRoom) {
      unawaited(_refreshPublicRoomPresence());
      _roomPresenceTimer = Timer.periodic(
        const Duration(seconds: 30),
        (_) => unawaited(_refreshPublicRoomPresence()),
      );
    }
  }

  void _scheduleMessageRefresh() {
    _messageRefreshTimer?.cancel();
    _messageRefreshTimer = Timer(const Duration(milliseconds: 80), () {
      if (mounted) unawaited(_loadMessages());
    });
  }

  void _setupTypingChannel() {
    final userId = _myUserId;
    if (userId == null || widget.target.conversationId.isEmpty) return;
    _typingChannel =
        _db.channel(
            'wasla-typing-v1-${widget.target.conversationId}',
            opts: const RealtimeChannelConfig(private: true),
          )
          ..onBroadcast(event: 'typing', callback: _handleTypingEvent)
          ..subscribe((status, _) {
            _typingChannelReady = status == RealtimeSubscribeStatus.subscribed;
            if (_typingChannelReady &&
                _typingStopTimer?.isActive == true &&
                _messageController.text.trim().isNotEmpty) {
              unawaited(_broadcastTypingState(true));
            }
          });
  }

  void _handleTypingEvent(Map<String, dynamic> payload) {
    if (!mounted) return;
    final senderId = payload['user_id']?.toString();
    if (!isIncomingTypingSender(
      senderId: senderId,
      currentUserId: _myUserId,
      peerUserId: widget.target.userId,
      isGroup: widget.target.isGroup,
    )) {
      return;
    }
    final userId = senderId!;
    final isTyping = payload['is_typing'] == true;
    final wasTyping = _peerTypingUserIds.contains(userId);
    _peerTypingTimers.remove(userId)?.cancel();
    if (isTyping) {
      _peerTypingUserIds.add(userId);
      _peerTypingTimers[userId] = Timer(
        const Duration(seconds: 5),
        () => _clearPeerTyping(userId),
      );
    } else {
      _peerTypingUserIds.remove(userId);
    }
    if (wasTyping != isTyping) setState(() {});
  }

  void _clearPeerTyping(String userId) {
    _peerTypingTimers.remove(userId)?.cancel();
    if (_peerTypingUserIds.remove(userId) && mounted) setState(() {});
  }

  String get _typingStatusLabel {
    if (!widget.target.isGroup) return 'يكتب الآن…';
    if (_peerTypingUserIds.length > 1) return 'يكتب أكثر من عضو الآن…';
    final userId = _peerTypingUserIds.first;
    final name = _groupSenderNames[userId];
    return name == null || name.isEmpty
        ? 'أحد الأعضاء يكتب الآن…'
        : '$name يكتب الآن…';
  }

  void _handleTypingChanged(String text) {
    if (text.trim().isEmpty) {
      _stopTyping();
      return;
    }
    _typingStopTimer?.cancel();
    _typingStopTimer = Timer(const Duration(seconds: 2), _stopTyping);
    if (_typingIsAnnounced || _typingStartTimer?.isActive == true) return;
    _typingStartTimer = Timer(const Duration(milliseconds: 350), () {
      _typingStartTimer = null;
      unawaited(_broadcastTypingState(true));
    });
  }

  void _stopTyping() {
    _typingStartTimer?.cancel();
    _typingStartTimer = null;
    _typingStopTimer?.cancel();
    _typingStopTimer = null;
    unawaited(_broadcastTypingState(false));
  }

  Future<void> _broadcastTypingState(bool isTyping) async {
    final channel = _typingChannel;
    if (channel == null || (isTyping && !_typingChannelReady)) return;
    if (isTyping && !_isCurrentChatVisible) return;
    if (_typingIsAnnounced == isTyping) return;
    _typingIsAnnounced = isTyping;
    try {
      await channel.sendBroadcastMessage(
        event: 'typing',
        payload: {'user_id': _myUserId, 'is_typing': isTyping},
      );
    } catch (_) {
      if (isTyping && _typingIsAnnounced) _typingIsAnnounced = false;
    }
  }

  Future<void> _releaseTypingChannel() async {
    _typingStartTimer?.cancel();
    _typingStopTimer?.cancel();
    for (final timer in _peerTypingTimers.values) {
      timer.cancel();
    }
    _peerTypingTimers.clear();
    _peerTypingUserIds.clear();
    final channel = _typingChannel;
    _typingChannel = null;
    _typingChannelReady = false;
    if (channel == null) return;
    if (_typingIsAnnounced) {
      _typingIsAnnounced = false;
      try {
        await channel.sendBroadcastMessage(
          event: 'typing',
          payload: {'user_id': _myUserId, 'is_typing': false},
        );
      } catch (_) {}
    }
    await _db.removeChannel(channel);
  }

  bool get _isCurrentChatVisible =>
      mounted &&
      WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed &&
      PushNotifications.instance.activeConversationId ==
          widget.target.conversationId &&
      (ModalRoute.of(context)?.isCurrent ?? true);

  void _queueIncomingMessageSound({
    required String? messageId,
    required String? senderId,
  }) {
    if (!_incomingChatSoundGate.shouldPlay(
      isInsert: true,
      messageId: messageId,
      senderId: senderId,
      currentUserId: _myUserId,
    )) {
      return;
    }
    _incomingSoundQueue = _incomingSoundQueue.then(
      (_) => _playIncomingMessageSound(),
    );
  }

  Future<void> _playIncomingMessageSound() async {
    if (!_isCurrentChatVisible) return;
    final userId = _myUserId;
    if (userId == null || userId.isEmpty) return;
    try {
      final localPreferences = await _chatListPreferencesStore.load(userId);
      if (localPreferences.muted.contains(widget.target.conversationId)) return;
      final category = widget.target.isPublicRoom
          ? 'channels'
          : widget.target.isGroup
          ? 'groups'
          : 'messages';
      final allowed = await PushNotifications.instance
          .shouldPlayConversationSound(
            widget.target.conversationId,
            category: category,
          );
      if (!allowed || !_isCurrentChatVisible) return;
      await _incomingChatPlayer.play(
        AssetSource('audio/incoming_message.wav'),
        volume: 0.20,
      );
    } catch (_) {
      // Audio and preference failures must not affect message delivery.
    }
  }

  Future<void> _loadPeerLastSeen() async {
    if (_peerLastSeenLoading || widget.target.userId.isEmpty) return;
    _peerLastSeenLoading = true;
    try {
      final row = await _db
          .from('profiles')
          .select('last_seen_at')
          .eq('id', widget.target.userId)
          .maybeSingle();
      final value = row?['last_seen_at']?.toString();
      final lastSeenAt = value == null ? null : DateTime.tryParse(value);
      if (mounted) {
        setState(() {
          _peerLastSeenAt = lastSeenAt;
          _peerLastSeenLoaded = true;
        });
      }
    } catch (_) {
      if (mounted && !_peerLastSeenLoaded) {
        setState(() => _peerLastSeenLoaded = true);
      }
    } finally {
      _peerLastSeenLoading = false;
    }
  }

  Future<void> _loadFriendship() async {
    if (widget.target.isGroup || widget.target.userId.isEmpty) return;
    try {
      final status = await FriendshipService(_db)
          .statusFor(widget.target.userId);
      if (mounted) {
        setState(() {
          _friendshipStatus = status;
          _friendshipLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _friendshipLoading = false);
    }
  }

  Future<void> _performFriendshipAction(
    Future<String?> Function() action, {
    required String successMessage,
  }) async {
    if (_friendshipBusy) return;
    setState(() => _friendshipBusy = true);
    try {
      await action();
      await _loadFriendship();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(successMessage)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث الصداقة. تحقق من الاتصال.')),
        );
      }
    } finally {
      if (mounted) setState(() => _friendshipBusy = false);
    }
  }

  void _respondToFriendRequest(bool accept) => _performFriendshipAction(
    () => FriendshipService(_db).respond(widget.target.userId, accept: accept),
    successMessage: accept ? 'تم قبول طلب الصداقة.' : 'تم رفض طلب الصداقة.',
  );

  Widget _friendshipBanner() {
    final userId = _myUserId ?? '';
    final incoming = _friendshipStatus.isIncomingFor(userId);
    if (_friendshipLoading || !incoming) return const SizedBox.shrink();

    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      margin: const EdgeInsetsDirectional.fromSTEB(12, 8, 12, 4),
      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: .58),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  Icons.mark_chat_unread_outlined,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'لديك طلب صداقة من هذا المستخدم',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        'يمكنك قبول الطلب أو رفضه.',
                        style: theme.textTheme.bodySmall,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: _friendshipBusy
                        ? null
                        : () => _respondToFriendRequest(true),
                    child: _friendshipBusy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('قبول'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: _friendshipBusy
                        ? null
                        : () => _respondToFriendRequest(false),
                    child: const Text('رفض'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _refreshPublicRoomPresence() async {
    try {
      await _db.rpc(
        'set_public_room_presence',
        params: {
          'p_conversation_id': widget.target.conversationId,
          'p_active': true,
        },
      );
      final count = await _db.rpc(
        'get_public_room_online_count',
        params: {'p_conversation_id': widget.target.conversationId},
      );
      if (mounted) setState(() => _roomOnlineCount = (count as num).toInt());
    } catch (_) {
      // A short network interruption should not interrupt the chat.
    }
  }

  Future<void> _loadGroupHeader() async {
    try {
      final group = await _db
          .from('groups')
          .select(
            'name,avatar_path,members_can_message,files_allowed,voice_allowed,admins_can_pin_messages,admins_can_delete_messages',
          )
          .eq('conversation_id', widget.target.conversationId)
          .single();
      final memberRows = await _db
          .from('group_members')
          .select('user_id,role')
          .eq('conversation_id', widget.target.conversationId);
      final ids = memberRows.map((row) => row['user_id'].toString()).toList();
      try {
        mergeUserPresenceStatuses(
          await UserPresenceService(_db).loadForUsers(ids),
        );
      } catch (_) {
        // Group membership and chat keep working when status migration is pending.
      }
      final profiles = ids.isEmpty
          ? <Map<String, dynamic>>[]
          : await _db
                .from('profiles')
                .select('id,display_name,username')
                .inFilter('id', ids);
      final profileById = {
        for (final row in profiles) row['id'].toString(): row,
      };
      final names = <String, String>{};
      for (final row in memberRows) {
        final id = row['user_id'].toString();
        final profile = profileById[id];
        if (profile != null) {
          names[id] = profile['display_name']?.toString().isNotEmpty == true
              ? profile['display_name'].toString()
              : '@${profile['username']}';
        }
      }
      final mine = memberRows
          .where((row) => row['user_id'].toString() == _myUserId)
          .firstOrNull;
      if (!mounted) return;
      setState(() {
        _groupName = group['name']?.toString();
        _groupAvatarPath = group['avatar_path']?.toString();
        _groupRole = mine?['role']?.toString();
        _groupMemberCount = memberRows.length;
        _groupCanSend = group['members_can_message'] == true || _isGroupAdmin;
        _groupFilesAllowed = group['files_allowed'] == true;
        _groupVoiceAllowed = group['voice_allowed'] == true;
        _groupAdminsCanPin = group['admins_can_pin_messages'] == true;
        _groupAdminsCanDeleteMessages =
            group['admins_can_delete_messages'] == true;
        _groupSenderNames = names;
      });
    } catch (_) {
      // Group rows can become available after a realtime reconnect.
    }
  }

  String _groupActivityNotice(String action, String actor) => switch (action) {
    'member_added' ||
    'member_joined' => '$actor انضم إلى المجموعة أو أضاف عضوًا',
    'member_left' => '$actor غادر المجموعة',
    'member_removed' || 'member_banned' => 'تغيّرت عضوية أحد أعضاء المجموعة',
    'member_promoted' => 'تم تعيين مشرف جديد بواسطة $actor',
    'admin_demoted' => 'تم تغيير صلاحيات مشرف بواسطة $actor',
    'group_name_changed' => 'غيّر $actor اسم المجموعة',
    'group_avatar_changed' => 'غيّر $actor صورة المجموعة',
    'group_info_changed' => 'حدّث $actor معلومات المجموعة',
    'settings_changed' => 'عدّل $actor إعدادات المجموعة',
    'message_pinned' => 'ثبّت $actor رسالة في المجموعة',
    'message_unpinned' => 'ألغى $actor تثبيت رسالة',
    'join_requested' => 'هناك طلب جديد للانضمام',
    'join_request_accepted' => 'قُبل طلب انضمام',
    'join_request_rejected' => 'رُفض طلب انضمام',
    'ownership_transferred' => 'نُقلت ملكية المجموعة',
    _ => '',
  };

  Future<void> _openGroupInfo() async {
    final result = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) =>
            GroupInfoScreen(conversationId: widget.target.conversationId),
      ),
    );
    if (!mounted) return;
    if (result == 'left' || result == 'deleted') {
      Navigator.of(context).pop();
      return;
    }
    await _loadGroupHeader();
  }

  Future<void> _loadChatBackground() async {
    final userId = _myUserId;
    if (userId == null) return;
    try {
      final color = await _conversationSettings.backgroundColor(
        userId,
        widget.target.conversationId,
      );
      if (mounted) setState(() => _chatBackgroundColor = color);
    } catch (_) {
      // A local appearance preference must not prevent opening the chat.
    }
  }

  Future<void> _restoreDraft() async {
    final userId = _myUserId;
    if (userId == null) return;
    try {
      final draft = await _localCache.loadDraft(
        userId,
        widget.target.conversationId,
      );
      if (!mounted || draft == null || _messageController.text.isNotEmpty) {
        return;
      }
      _messageController.value = TextEditingValue(
        text: draft,
        selection: TextSelection.collapsed(offset: draft.length),
      );
    } catch (_) {
      // Opening the conversation should work even if the draft is unavailable.
    }
  }

  void _handleDraftTextChanged() {
    _draftSaveTimer?.cancel();
    _draftSaveTimer = Timer(const Duration(milliseconds: 350), () {
      unawaited(_persistDraft(_messageController.text));
    });
  }

  Future<void> _persistDraft(String draft) {
    final userId = _myUserId;
    if (userId == null) return Future<void>.value();
    final save = _draftSaveTail.then(
      (_) => _localCache.saveDraft(userId, widget.target.conversationId, draft),
    );
    _draftSaveTail = save.catchError((Object _) {});
    return _draftSaveTail;
  }

  Future<void> _flushDraft() {
    _draftSaveTimer?.cancel();
    _draftSaveTimer = null;
    return _persistDraft(_messageController.text);
  }

  Future<void> _setChatBackground(int? colorValue) async {
    final userId = _myUserId;
    if (userId == null) return;
    await _conversationSettings.setBackgroundColor(
      userId,
      widget.target.conversationId,
      colorValue,
    );
    if (mounted) setState(() => _chatBackgroundColor = colorValue);
  }

  Future<void> _openChatInfo() async {
    if (widget.target.isGroup || _searching) return;
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'إغلاق معلومات المحادثة',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (dialogContext, animation, secondaryAnimation) {
        final panelWidth = math
            .min(MediaQuery.sizeOf(dialogContext).width * .92, 440.0)
            .toDouble();
        return SafeArea(
          child: Align(
            alignment: Alignment.centerLeft,
            child: SizedBox(
              width: panelWidth,
              height: double.infinity,
              child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
                child: ChatInfoPanel(
                  target: widget.target,
                  messages: _messages,
                  client: _db,
                  userId: _myUserId ?? '',
                  lastSeenAt: _peerLastSeenAt,
                  lastSeenLoaded: _peerLastSeenLoaded,
                  backgroundColor: _chatBackgroundColor,
                  onCall: _startCall,
                  onSearch: () {
                    if (!mounted) return;
                    setState(() {
                      _searching = true;
                      _searchController.clear();
                    });
                  },
                  onBackgroundChanged: _setChatBackground,
                  onFriendshipChanged: () => unawaited(_loadFriendship()),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: const Cubic(.22, 1, .36, 1),
        );
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(-1, 0),
              end: Offset.zero,
            ).animate(curved),
            child: child,
          ),
        );
      },
    );
  }

  Future<void> _startCall({required bool video}) async {
    try {
      final call = await widget.callService.startCall(
        widget.target,
        video: video,
      );
      if (!mounted) return;
      await Navigator.of(context)
          .push<void>(callScreenRoute(service: widget.callService, call: call));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذر بدء المكالمة. تأكد من إعداد الخادم ثم حاول مجددًا. ${error is PostgrestException ? error.message : ''}',
          ),
        ),
      );
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_syncPendingMessages());
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _stopTyping();
      unawaited(_flushDraft());
      unawaited(_incomingChatPlayer.stop());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _draftSaveTimer?.cancel();
    _messageRefreshTimer?.cancel();
    unawaited(_releaseTypingChannel());
    unawaited(_persistDraft(_messageController.text));
    if (PushNotifications.instance.activeConversationId ==
        widget.target.conversationId) {
      PushNotifications.instance.activeConversationId = null;
    }
    unawaited(_connectivitySubscription?.cancel());
    _outboxRetryTimer?.cancel();
    _db.removeChannel(_channel);
    if (_friendshipChannel != null) {
      _db.removeChannel(_friendshipChannel!);
    }
    if (_groupActivityChannel != null) {
      _db.removeChannel(_groupActivityChannel!);
    }
    _roomPresenceTimer?.cancel();
    _peerLastSeenTimer?.cancel();
    _runtimeSettingsTimer?.cancel();
    if (widget.target.isPublicRoom) {
      unawaited(
        _db
            .rpc(
              'set_public_room_presence',
              params: {
                'p_conversation_id': widget.target.conversationId,
                'p_active': false,
              },
            )
            .then((_) {})
            .catchError((Object _) {}),
      );
    }
    _recordingTimer?.cancel();
    unawaited(_recordingAmplitudeSubscription?.cancel());
    _recordingAmplitudeSubscription = null;
    if (_recording) unawaited(_recorder.cancel());
    unawaited(_recorder.dispose());
    unawaited(_incomingChatPlayer.dispose());
    _messageController.removeListener(_handleDraftTextChanged);
    _messageController.dispose();
    _messageFocusNode.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _restoreStarredMessageIds() async {
    final userId = _myUserId;
    if (userId == null) return;
    try {
      final ids = await _localCache.loadStarredMessageIds(
        userId,
        widget.target.conversationId,
      );
      if (!mounted || userId != _myUserId) return;
      setState(() => _starredMessageIds = ids);
    } catch (_) {
      // Local preference failures must not block opening the conversation.
    }
  }

  Future<void> _loadMessages() async {
    if (_messageLoadInFlight || _loadingOlderMessages) {
      _messageReloadQueued = true;
      return;
    }
    final shouldStickToLatest =
        !_scrollController.hasClients ||
        _scrollController.position.extentBefore < 140;
    _messageLoadInFlight = true;
    try {
      if (!_didCheckLocalMessages) {
        _didCheckLocalMessages = true;
        final userId = _myUserId;
        if (userId != null) {
          try {
            final cachedMessages = await _localCache.loadMessages(
              userId,
              widget.target.conversationId,
            );
            final pendingMessages = await _localCache.loadPendingMessages(
              userId,
            );
            final localMessages = _mergePendingMessages(
              cachedMessages ?? const <ChatMessage>[],
              pendingMessages,
            );
            if ((cachedMessages != null || localMessages.isNotEmpty) &&
                mounted) {
              setState(() {
                _messages = localMessages;
                _loading = false;
                _error = null;
              });
            }
          } catch (_) {
            // Continue to try loading the current version from the server.
          }
        }
      }
      final rows = await _db
          .from('messages')
          .select(
            'id, sender_id, content, message_type, media_path, media_duration_seconds, created_at, delivered_at, read_at, reply_to, edited_at, ephemeral, payload_deleted_at',
          )
          .eq('conversation_id', widget.target.conversationId)
          .order('created_at', ascending: false)
          .limit(_initialMessagePageSize);
      if (!mounted) return;
      final serverMessages = rows
          .map((row) => ChatMessage.fromMap(Map<String, dynamic>.from(row)))
          .toList()
          .reversed
          .toList();
      final loadedMessages = preserveCachedEphemeralPayloads(
        _messages,
        serverMessages,
      );
      final pendingMessages = _myUserId == null
          ? const <PendingOutgoingMessage>[]
          : await _localCache.loadPendingMessages(_myUserId!);
      final priorOlderMessages = loadedMessages.isEmpty
          ? const <ChatMessage>[]
          : _messages
                .where(
                  (message) =>
                      !message.isPending &&
                      message.createdAt.isBefore(
                        loadedMessages.first.createdAt,
                      ),
                )
                .toList();
      final visibleMessages = mergeChatHistoryMessages(
        priorOlderMessages,
        _mergePendingMessages(
          loadedMessages,
          pendingMessages.where(
            (message) => message.conversationId == widget.target.conversationId,
          ),
        ),
      );
      final messageIds = loadedMessages.map((message) => message.id).toList();
      if (!mounted) return;
      setState(() {
        _messages = visibleMessages;
        _hasMoreMessages = rows.length == _initialMessagePageSize;
        _loading = false;
        _error = null;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (shouldStickToLatest && _scrollController.hasClients) {
          _scrollController.jumpTo(0);
        }
      });
      unawaited(_syncVisibleMessages(visibleMessages, loadedMessages));

      final reactions = <String, Map<String, int>>{};
      final pinnedIds = <String>{};
      if (messageIds.isNotEmpty) {
        try {
          final reactionRows = await _db
              .from('message_reactions')
              .select('message_id,emoji')
              .inFilter('message_id', messageIds);
          for (final row in reactionRows) {
            final messageId = row['message_id'].toString();
            final emoji = row['emoji'].toString();
            reactions.putIfAbsent(messageId, () => {})[emoji] =
                (reactions[messageId]?[emoji] ?? 0) + 1;
          }
        } catch (_) {}
        if (widget.target.isGroup) {
          try {
            final pinRows = await _db
                .from('group_pinned_messages')
                .select('message_id')
                .eq('conversation_id', widget.target.conversationId)
                .inFilter('message_id', messageIds);
            pinnedIds.addAll(
              pinRows.map((row) => row['message_id'].toString()),
            );
          } catch (_) {}
        }
      }
      try {
        final pinRows = await _db
            .from('conversation_pinned_messages')
            .select('message_id')
            .eq('conversation_id', widget.target.conversationId);
        pinnedIds.addAll(pinRows.map((row) => row['message_id'].toString()));
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _messageReactions = reactions;
        _pinnedMessageIds = pinnedIds;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = _messages.isEmpty ? 'تعذر تحميل الرسائل.' : null;
        });
      }
    } finally {
      _messageLoadInFlight = false;
      if (_messageReloadQueued && mounted) {
        _messageReloadQueued = false;
        unawaited(_loadMessages());
      }
    }
  }

  static final math.Random _messageIdRandom = math.Random.secure();

  String _newMessageId() {
    final bytes = List<int>.generate(16, (_) => _messageIdRandom.nextInt(256));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    final hex = bytes.map((byte) => byte.toRadixString(16).padLeft(2, '0'));
    final value = hex.join();
    return '${value.substring(0, 8)}-${value.substring(8, 12)}-'
        '${value.substring(12, 16)}-${value.substring(16, 20)}-'
        '${value.substring(20)}';
  }

  Future<void> _loadOlderMessages() async {
    if (_loadingOlderMessages || _messageLoadInFlight || !_hasMoreMessages) {
      return;
    }
    final oldestMessage = _messages
        .where((message) => !message.isPending)
        .firstOrNull;
    if (oldestMessage == null) {
      setState(() => _hasMoreMessages = false);
      return;
    }
    setState(() => _loadingOlderMessages = true);
    try {
      final rows = await _db
          .from('messages')
          .select(
            'id, sender_id, content, message_type, media_path, media_duration_seconds, created_at, delivered_at, read_at, reply_to, edited_at, ephemeral, payload_deleted_at',
          )
          .eq('conversation_id', widget.target.conversationId)
          .lt('created_at', oldestMessage.createdAt.toUtc().toIso8601String())
          .order('created_at', ascending: false)
          .limit(_olderMessagePageSize);
      final serverOlderMessages = rows
          .map((row) => ChatMessage.fromMap(Map<String, dynamic>.from(row)))
          .toList()
          .reversed
          .toList();
      final olderMessages = preserveCachedEphemeralPayloads(
        _messages,
        serverOlderMessages,
      );
      final combinedMessages = mergeChatHistoryMessages(
        _messages,
        olderMessages,
      );
      final messageIds = olderMessages.map((message) => message.id).toList();
      final reactions = <String, Map<String, int>>{
        for (final entry in _messageReactions.entries)
          entry.key: Map<String, int>.from(entry.value),
      };
      final pinnedIds = <String>{..._pinnedMessageIds};
      if (messageIds.isNotEmpty) {
        try {
          final reactionRows = await _db
              .from('message_reactions')
              .select('message_id,emoji')
              .inFilter('message_id', messageIds);
          for (final row in reactionRows) {
            final messageId = row['message_id'].toString();
            final emoji = row['emoji'].toString();
            reactions.putIfAbsent(messageId, () => {})[emoji] =
                (reactions[messageId]?[emoji] ?? 0) + 1;
          }
        } catch (_) {}
        if (widget.target.isGroup) {
          try {
            final pinRows = await _db
                .from('group_pinned_messages')
                .select('message_id')
                .eq('conversation_id', widget.target.conversationId)
                .inFilter('message_id', messageIds);
            pinnedIds.addAll(
              pinRows.map((row) => row['message_id'].toString()),
            );
          } catch (_) {}
        }
      }
      try {
        final pinRows = await _db
            .from('conversation_pinned_messages')
            .select('message_id')
            .eq('conversation_id', widget.target.conversationId);
        pinnedIds.addAll(pinRows.map((row) => row['message_id'].toString()));
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _messages = combinedMessages;
        _hasMoreMessages = rows.length == _olderMessagePageSize;
        _messageReactions = reactions;
        _pinnedMessageIds = pinnedIds;
      });
      final userId = _myUserId;
      if (userId != null) {
        try {
          await _retryDeletedMediaCleanup(olderMessages);
          await _persistAndAcknowledgeMessages(combinedMessages, olderMessages);
        } catch (_) {}
      }
      if (!widget.target.isGroup) {
        final unreadIds = olderMessages
            .where(
              (message) =>
                  message.senderId != _myUserId && message.readAt == null,
            )
            .map((message) => message.id)
            .toList();
        if (unreadIds.isNotEmpty) unawaited(_markIncomingRead(unreadIds));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر تحميل الرسائل الأقدم. حاول مجددًا.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loadingOlderMessages = false);
      if (_messageReloadQueued && mounted) {
        _messageReloadQueued = false;
        unawaited(_loadMessages());
      }
    }
  }

  Widget _olderMessagesControl() {
    if (!_hasMoreMessages && !_loadingOlderMessages) {
      return const SizedBox.shrink();
    }
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: TextButton.icon(
          onPressed: _loadingOlderMessages ? null : _loadOlderMessages,
          icon: _loadingOlderMessages
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.history_rounded, size: 18),
          label: Text(
            _loadingOlderMessages ? 'جارٍ تحميل الرسائل…' : 'تحميل رسائل أقدم',
          ),
        ),
      ),
    );
  }

  ChatMessage _chatMessageFromPending(PendingOutgoingMessage pending) =>
      ChatMessage(
        id: pending.id,
        senderId: pending.senderId,
        content: pending.content,
        createdAt: pending.createdAt,
        messageType: pending.messageType,
        mediaPath: pending.mediaPath,
        mediaDurationSeconds: pending.mediaDurationSeconds,
        replyTo: pending.replyTo,
        isPending: true,
        isEphemeral: pending.isEphemeral,
      );

  List<ChatMessage> _mergePendingMessages(
    Iterable<ChatMessage> existing,
    Iterable<PendingOutgoingMessage> pending,
  ) {
    final messages = <String, ChatMessage>{
      for (final message in existing) message.id: message,
    };
    for (final outgoing in pending) {
      if (outgoing.conversationId == widget.target.conversationId) {
        messages[outgoing.id] = _chatMessageFromPending(outgoing);
      }
    }
    return visibleChatHistoryMessages(messages.values)
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
  }

  Future<void> _queueOutgoingMessage({
    required String content,
    String messageType = 'text',
    String? mediaExtension,
    int? durationSeconds,
    Uint8List? attachmentBytes,
    String? conversationId,
  }) async {
    await WaslaRuntimeSettings.refresh(_db);
    if (!WaslaRuntimeSettings.messagesEnabled) {
      throw StateError('New message sending is temporarily disabled.');
    }
    if (attachmentBytes != null && !WaslaRuntimeSettings.mediaUploadsEnabled) {
      throw StateError('Conversation media uploads are temporarily disabled.');
    }
    if (attachmentBytes != null &&
        attachmentBytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
      throw StateError('Attachment exceeds the current Wasla upload limit.');
    }
    final userId = _myUserId;
    if (userId == null) throw StateError('Authentication required');
    final replyingTo = _replyingTo;
    final outgoing = PendingOutgoingMessage(
      id: _newMessageId(),
      conversationId: conversationId ?? widget.target.conversationId,
      senderId: userId,
      content: content,
      createdAt: DateTime.now().toUtc(),
      messageType: messageType,
      mediaExtension: mediaExtension,
      mediaDurationSeconds: durationSeconds,
      replyTo:
          (conversationId ?? widget.target.conversationId) ==
              widget.target.conversationId
          ? _replyingTo?.id
          : null,
      isEphemeral: true,
    );

    final visibleMessages = _mergePendingMessages(_messages, [outgoing]);
    if (mounted) {
      setState(() {
        _messages = visibleMessages;
        _replyingTo = null;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scrollController.hasClients) {
          _scrollController.animateTo(
            0,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
          );
        }
      });
    }

    try {
      await _localCache.enqueueOutgoingMessage(
        userId,
        outgoing,
        attachmentBytes: attachmentBytes,
      );
    } catch (_) {
      if (outgoing.conversationId == widget.target.conversationId && mounted) {
        setState(() {
          _messages = _messages
              .where((message) => message.id != outgoing.id)
              .toList();
          _replyingTo = replyingTo;
        });
      }
      rethrow;
    }
    if (outgoing.mediaPath != null && attachmentBytes != null) {
      try {
        await _localCache.saveMediaBytes(
          userId,
          outgoing.mediaPath!,
          attachmentBytes,
        );
      } catch (_) {}
    }
    unawaited(_syncPendingMessages());
  }

  Future<void> _syncPendingMessages() async {
    final userId = _myUserId;
    if (_outboxSyncInFlight || userId == null) return;
    _outboxSyncInFlight = true;
    var sentFromThisConversation = false;
    try {
      await WaslaRuntimeSettings.refresh(_db);
      if (!WaslaRuntimeSettings.messagesEnabled) return;
      final pendingMessages = await _localCache.loadPendingMessages(userId);
      for (var outgoing in pendingMessages) {
        try {
          final mediaPath = outgoing.mediaPath;
          if (mediaPath != null && !WaslaRuntimeSettings.mediaUploadsEnabled) {
            continue;
          }
          if (mediaPath != null && !outgoing.mediaUploaded) {
            final extension = outgoing.mediaExtension!;
            final remoteFolder =
                '${outgoing.conversationId}/${outgoing.senderId}';
            final storage = _db.storage.from('wasla-media');
            final existingFiles = await storage.list(path: remoteFolder);
            final remoteName = '${outgoing.id}.$extension';
            final alreadyUploaded = existingFiles.any(
              (file) => file.name == remoteName,
            );
            if (!alreadyUploaded) {
              final attachment = await _localCache.pendingAttachment(
                userId,
                outgoing,
              );
              if (attachment == null) {
                throw StateError('The queued attachment is unavailable');
              }
              await storage.uploadBinary(
                mediaPath,
                await attachment.readAsBytes(),
                fileOptions: FileOptions(
                  contentType: _mimeForMessage(outgoing.messageType, extension),
                ),
              );
            }
            outgoing = outgoing.copyWith(mediaUploaded: true);
            await _localCache.updatePendingMessage(userId, outgoing);
          }

          await _db
              .from('messages')
              .upsert(
                {
                  'id': outgoing.id,
                  'conversation_id': outgoing.conversationId,
                  'sender_id': outgoing.senderId,
                  'content': outgoing.content,
                  'message_type': outgoing.messageType,
                  'media_path': mediaPath,
                  'media_duration_seconds': outgoing.mediaDurationSeconds,
                  'reply_to': outgoing.replyTo,
                  'created_at': outgoing.createdAt.toUtc().toIso8601String(),
                  'ephemeral': outgoing.isEphemeral,
                },
                onConflict: 'id',
                ignoreDuplicates: true,
              );
          final acknowledged = _chatMessageFromPending(outgoing)
              .copyWith(isPending: false);
          try {
            final cachedMessages = await _localCache.loadMessages(
              userId,
              outgoing.conversationId,
            );
            final updatedCache = [...?cachedMessages]
              ..removeWhere((message) => message.id == outgoing.id)
              ..add(acknowledged)
              ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
            await _localCache.saveMessages(
              userId,
              outgoing.conversationId,
              updatedCache,
            );
          } catch (_) {}
          if (outgoing.conversationId == widget.target.conversationId) {
            sentFromThisConversation = true;
            final visibleMessages = [..._messages]
              ..removeWhere((message) => message.id == outgoing.id)
              ..add(acknowledged)
              ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
            if (mounted) {
              setState(() => _messages = visibleMessages);
              try {
                await _localCache.saveMessages(
                  userId,
                  widget.target.conversationId,
                  visibleMessages,
                );
              } catch (_) {}
            }
          }
          await _localCache.removePendingMessage(userId, outgoing.id);
        } catch (_) {
          // Leave the item queued; the connectivity listener or timer retries it.
        }
      }
    } catch (_) {
      // Keep the chat usable when local storage or the network is unavailable.
    } finally {
      _outboxSyncInFlight = false;
    }
    if (sentFromThisConversation && mounted) unawaited(_loadMessages());
  }

  Future<void> _showMessageActions(ChatMessage message) async {
    if (message.isPending) return;
    final mine = message.senderId == _myUserId;
    final canEdit =
        mine &&
        message.messageType == 'text' &&
        DateTime.now().difference(message.createdAt).inMinutes < 15;
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Wrap(
                alignment: WrapAlignment.center,
                children: ['👍', '❤️', '😂', '😮', '😢', '🙏']
                    .map(
                      (emoji) => IconButton(
                        tooltip: 'تفاعل $emoji',
                        icon: Text(emoji, style: const TextStyle(fontSize: 23)),
                        onPressed: () => Navigator.pop(context, 'react:$emoji'),
                      ),
                    )
                    .toList(),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('رد على الرسالة'),
              onTap: () => Navigator.pop(context, 'reply'),
            ),
            ListTile(
              leading: const Icon(Icons.copy),
              title: const Text('نسخ'),
              onTap: () => Navigator.pop(context, 'copy'),
            ),
            ListTile(
              leading: const Icon(Icons.forward),
              title: const Text('إعادة توجيه'),
              onTap: () => Navigator.pop(context, 'forward'),
            ),
            ListTile(
              leading: Icon(
                _starredMessageIds.contains(message.id)
                    ? Icons.star_rounded
                    : Icons.star_outline_rounded,
                color: _starredMessageIds.contains(message.id)
                    ? Colors.amber.shade700
                    : null,
              ),
              title: Text(
                _starredMessageIds.contains(message.id)
                    ? 'إزالة من الرسائل المميزة'
                    : 'تمييز بنجمة',
              ),
              onTap: () => Navigator.pop(context, 'star'),
            ),
            if (canEdit)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('تعديل'),
                onTap: () => Navigator.pop(context, 'edit'),
              ),
            if (!widget.target.isGroup || _canPinGroupMessages)
              ListTile(
                leading: Icon(
                  _pinnedMessageIds.contains(message.id)
                      ? Icons.push_pin
                      : Icons.push_pin_outlined,
                  color: _pinnedMessageIds.contains(message.id)
                      ? Theme.of(context).colorScheme.primary
                      : null,
                ),
                title: Text(
                  _pinnedMessageIds.contains(message.id)
                      ? 'إلغاء تثبيت'
                      : 'تثبيت الرسالة',
                ),
                onTap: () => Navigator.pop(context, 'pin'),
              ),
            if (mine || (widget.target.isGroup && _canDeleteGroupMessages))
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: const Text(
                  'حذف للجميع',
                  style: TextStyle(color: Colors.red),
                ),
                onTap: () => Navigator.pop(context, 'delete'),
              ),
          ],
        ),
      ),
    );
    if (!mounted || action == null) return;
    if (action.startsWith('react:')) {
      await _toggleReaction(message, action.substring(6));
    } else if (action == 'reply') {
      setState(() => _replyingTo = message);
    } else if (action == 'copy') {
      await Clipboard.setData(ClipboardData(text: message.content));
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تم نسخ الرسالة')));
      }
    } else if (action == 'edit') {
      await _editMessage(message);
    } else if (action == 'delete') {
      await _deleteMessage(message);
    } else if (action == 'star') {
      await _toggleStar(message);
    } else if (action == 'pin') {
      await _togglePin(message);
    } else if (action == 'forward') {
      await _forwardMessage(message);
    }
  }

  Future<void> _toggleReaction(ChatMessage message, String emoji) async {
    try {
      final existing = await _db
          .from('message_reactions')
          .select('emoji')
          .eq('message_id', message.id)
          .eq('user_id', _myUserId!)
          .eq('emoji', emoji)
          .maybeSingle();
      if (existing == null) {
        await _db.from('message_reactions').insert({
          'message_id': message.id,
          'user_id': _myUserId,
          'emoji': emoji,
        });
      } else {
        await _db
            .from('message_reactions')
            .delete()
            .eq('message_id', message.id)
            .eq('user_id', _myUserId!)
            .eq('emoji', emoji);
      }
      await _loadMessages();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر تسجيل التفاعل.')));
      }
    }
  }

  Future<void> _togglePin(ChatMessage message) async {
    try {
      final pin = !_pinnedMessageIds.contains(message.id);
      await _db.rpc(
        'set_conversation_message_pinned',
        params: {
          'p_conversation_id': widget.target.conversationId,
          'p_message_id': message.id,
          'p_pinned': pin,
        },
      );
      await _loadMessages();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تحديث الرسائل المثبتة.')),
        );
      }
    }
  }

  Future<void> _toggleStar(ChatMessage message) async {
    final userId = _myUserId;
    if (userId == null) return;
    final starred = !_starredMessageIds.contains(message.id);
    try {
      await _localCache.setMessageStarred(
        userId,
        widget.target.conversationId,
        message.id,
        starred,
      );
      if (!mounted) return;
      setState(() {
        if (starred) {
          _starredMessageIds.add(message.id);
        } else {
          _starredMessageIds.remove(message.id);
        }
      });
      HapticFeedback.selectionClick();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            starred ? 'أضيفت إلى الرسائل المميزة' : 'أزيلت من الرسائل المميزة',
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حفظ تمييز الرسالة محليًا.')),
        );
      }
    }
  }

  Future<void> _editMessage(ChatMessage message) async {
    final controller = TextEditingController(text: message.content);
    final accepted =
        await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('تعديل الرسالة'),
            content: TextField(
              controller: controller,
              maxLength: 5000,
              maxLines: 4,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('حفظ'),
              ),
            ],
          ),
        ) ??
        false;
    if (accepted && controller.text.trim().isNotEmpty) {
      try {
        await _db.rpc(
          'edit_message',
          params: {
            'p_message_id': message.id,
            'p_content': controller.text.trim(),
          },
        );
        await _loadMessages();
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(const SnackBar(content: Text('تعذر تعديل الرسالة.')));
        }
      }
    }
    controller.dispose();
  }

  Future<void> _deleteMessage(ChatMessage message) async {
    final accepted =
        await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('حذف الرسالة للجميع؟'),
            content: const Text('سيظهر لجميع الأعضاء أن الرسالة حُذفت.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('حذف'),
              ),
            ],
          ),
        ) ??
        false;
    if (!accepted) return;
    try {
      await _db.rpc('delete_message', params: {'p_message_id': message.id});
      await _loadMessages();
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('تعذر حذف الرسالة.')));
      }
    }
  }

  Future<void> _forwardMessage(ChatMessage message) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final rows = await _db.rpc('get_my_conversations') as List<dynamic>;
      final chats = rows
          .map(
            (row) => ChatPreview.fromMap(Map<String, dynamic>.from(row as Map)),
          )
          .toList();
      if (!mounted) return;
      final selected = await showModalBottomSheet<ChatPreview>(
        context: context,
        showDragHandle: true,
        builder: (context) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const ListTile(title: Text('إعادة توجيه إلى')),
              ...chats.map(
                (chat) => ListTile(
                  leading: Icon(
                    chat.isGroup ? Icons.groups_outlined : Icons.person_outline,
                  ),
                  title: Text(chat.displayName),
                  subtitle: Text(
                    chat.isGroup
                        ? '${chat.memberCount} أعضاء'
                        : '@${chat.username}',
                  ),
                  onTap: () => Navigator.pop(context, chat),
                ),
              ),
            ],
          ),
        ),
      );
      if (selected == null || !mounted) return;
      final userId = _myUserId;
      if (userId == null) throw StateError('Authentication required');
      Uint8List? attachmentBytes;
      String? mediaExtension;
      if (message.messageType == 'image' ||
          message.messageType == 'video' ||
          message.messageType == 'file' ||
          message.messageType == 'audio') {
        final sourcePath = message.mediaPath;
        if (sourcePath == null || sourcePath.isEmpty) {
          throw StateError('The source attachment is unavailable');
        }
        final localFile = await _localCache.findMedia(userId, sourcePath);
        attachmentBytes = localFile != null
            ? await localFile.readAsBytes()
            : await _db.storage.from('wasla-media').download(sourcePath);
        mediaExtension = sourcePath.split('.').last.toLowerCase();
      }
      await _queueOutgoingMessage(
        content: message.content,
        messageType: message.messageType,
        mediaExtension: mediaExtension,
        durationSeconds: message.mediaDurationSeconds,
        attachmentBytes: attachmentBytes,
        conversationId: selected.conversationId,
      );
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تمت إعادة توجيه الرسالة.')),
        );
      }
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذرت إعادة توجيه الرسالة.')),
        );
      }
    }
  }

  Future<void> _persistAndAcknowledgeMessages(
    List<ChatMessage> conversationMessages,
    Iterable<ChatMessage> incomingMessages,
  ) async {
    final userId = _myUserId;
    if (userId == null) return;
    final delivery = LocalMessageDelivery(
      localCache: _localCache,
      downloadMedia: (storagePath) =>
          _db.storage.from('wasla-media').download(storagePath),
      acknowledge: (messageId) async {
        final raw = await _db.rpc(
          'acknowledge_ephemeral_message',
          params: {'p_message_id': messageId},
        );
        if (raw is! Map) throw StateError('Invalid delivery acknowledgement');
        final receipt = Map<String, dynamic>.from(raw);
        if (receipt['payload_deleted'] != true) return null;
        final path = receipt['media_path']?.toString();
        return path == null || path.isEmpty ? null : path;
      },
      deleteRemoteMedia: _deleteRemoteMediaAndFinalize,
    );
    await delivery.cacheAndAcknowledge(
      userId: userId,
      conversationId: widget.target.conversationId,
      conversationMessages: conversationMessages,
      incomingMessages: incomingMessages,
    );
  }

  Future<void> _syncVisibleMessages(
    List<ChatMessage> conversationMessages,
    List<ChatMessage> incomingMessages,
  ) async {
    try {
      await _retryDeletedMediaCleanup(incomingMessages);
      final latestPending = _messages.where((message) => message.isPending);
      final latestSnapshot = mergeChatHistoryMessages(
        conversationMessages,
        latestPending,
      );
      await _persistAndAcknowledgeMessages(latestSnapshot, incomingMessages);
    } catch (_) {
      // A failed local write must leave ephemeral content available to retry.
      return;
    }
    if (!widget.target.isGroup) {
      final unreadIds = incomingMessages
          .where(
            (message) =>
                message.senderId != _myUserId && message.readAt == null,
          )
          .map((message) => message.id)
          .toList();
      if (unreadIds.isNotEmpty) await _markIncomingRead(unreadIds);
    }
  }

  Future<void> _deleteRemoteMediaAndFinalize(
    String messageId,
    String storagePath,
  ) async {
    await _db.storage.from('wasla-media').remove([storagePath]);
    await _db.rpc(
      'finalize_message_media_cleanup',
      params: {'p_message_id': messageId},
    );
  }

  Future<void> _retryDeletedMediaCleanup(Iterable<ChatMessage> messages) async {
    for (final message in messages) {
      final path = message.mediaPath;
      if (message.payloadDeletedAt == null || path == null || path.isEmpty) {
        continue;
      }
      try {
        await _deleteRemoteMediaAndFinalize(message.id, path);
      } catch (_) {
        // Repeated sync retries cleanup if Storage was temporarily unavailable.
      }
    }
  }

  Future<void> _markIncomingRead(List<String> ids) async {
    try {
      final now = DateTime.now().toUtc().toIso8601String();
      await _db
          .from('messages')
          .update({'delivered_at': now, 'read_at': now})
          .inFilter('id', ids)
          .neq('sender_id', _myUserId ?? '');
    } catch (_) {
      // Opening the thread again retries any receipt not accepted by the server.
    }
  }

  Future<void> _refreshRuntimeSettings({bool force = false}) async {
    final changed = await WaslaRuntimeSettings.refresh(_db, force: force);
    if (changed && mounted) setState(() {});
  }

  Future<void> _send() async {
    final content = _messageController.text.trim();
    if (content.isEmpty || _sending || _recording) return;
    await _refreshRuntimeSettings(force: true);
    if (!mounted) return;
    if (!WaslaRuntimeSettings.messagesEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('إرسال الرسائل متوقف مؤقتًا من الإدارة.')),
      );
      return;
    }
    if (content.characters.length > 3000) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يمكن أن تتجاوز الرسالة ٣٠٠٠ حرف.')),
      );
      return;
    }
    if (widget.target.isGroup && !_groupCanSend) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('الإرسال متاح للمشرفين فقط.')),
      );
      return;
    }
    setState(() => _sending = true);
    _messageController.clear();
    _draftSaveTimer?.cancel();
    _draftSaveTimer = null;
    unawaited(_persistDraft(''));
    _stopTyping();
    try {
      await _queueOutgoingMessage(content: content);
    } catch (_) {
      _messageController.text = content;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر حفظ الرسالة على الجهاز. حاول مجددًا.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickAndSendImage({
    ImageSource source = ImageSource.gallery,
  }) async {
    if (_sending || _recording) return;
    if (widget.target.isGroup && (!_groupCanSend || !_groupFilesAllowed)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('إرسال الملفات غير متاح في هذه المجموعة.'),
        ),
      );
      return;
    }
    try {
      final image = await ImagePicker().pickImage(
        source: source,
        imageQuality: 82,
        maxWidth: 1800,
      );
      if (image == null || !mounted) return;
      final bytes = await image.readAsBytes();
      if (!mounted) return;
      if (bytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'حجم الصورة يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      final approved = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('معاينة الصورة'),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 360, maxHeight: 360),
            child: Image.memory(bytes, fit: BoxFit.contain),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('إرسال الصورة'),
            ),
          ],
        ),
      );
      if (approved != true || !mounted) return;
      await _sendMediaBytes(
        bytes,
        messageType: 'image',
        content: 'صورة',
        extension: 'jpg',
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر اختيار الصورة أو إرسالها.')),
        );
      }
    }
  }

  Future<void> _pickAndSendVideo({
    ImageSource source = ImageSource.gallery,
  }) async {
    final messenger = ScaffoldMessenger.of(context);
    if (_sending || _recording) return;
    if (widget.target.isGroup && (!_groupCanSend || !_groupFilesAllowed)) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('إرسال الملفات غير متاح في هذه المجموعة.'),
        ),
      );
      return;
    }
    try {
      final video = await ImagePicker().pickVideo(
        source: source,
        maxDuration: const Duration(minutes: 3),
      );
      if (video == null || !mounted) return;
      final extension = video.name.split('.').last.toLowerCase();
      if (!const {'mp4', 'mov', 'webm'}.contains(extension)) {
        messenger.showSnackBar(
          const SnackBar(
            content: Text(
              'صيغة الفيديو غير مدعومة. استخدم MP4 أو MOV أو WebM.',
            ),
          ),
        );
        return;
      }
      final bytes = await video.readAsBytes();
      if (bytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'حجم الفيديو يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      final controller = VideoPlayerController.file(File(video.path));
      var previewReady = false;
      try {
        await controller.initialize();
        previewReady = controller.value.isInitialized;
      } catch (_) {}
      if (!mounted) {
        await controller.dispose();
        return;
      }
      final approved = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('معاينة الفيديو'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (previewReady)
                ConstrainedBox(
                  constraints: const BoxConstraints(
                    maxWidth: 360,
                    maxHeight: 240,
                  ),
                  child: AspectRatio(
                    aspectRatio: controller.value.aspectRatio,
                    child: VideoPlayer(controller),
                  ),
                )
              else
                const Icon(Icons.video_file_outlined, size: 56),
              const SizedBox(height: 8),
              Text(video.name, maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('إرسال الفيديو'),
            ),
          ],
        ),
      );
      await controller.dispose();
      if (approved != true || !mounted) return;
      await _sendMediaBytes(
        bytes,
        messageType: 'video',
        content: 'مقطع فيديو',
        extension: extension,
      );
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر اختيار الفيديو أو إرساله.')),
        );
      }
    }
  }

  Future<void> _pickAndSendFile() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_sending || _recording) return;
    if (widget.target.isGroup && (!_groupCanSend || !_groupFilesAllowed)) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('إرسال الملفات غير متاح في هذه المجموعة.'),
        ),
      );
      return;
    }
    try {
      final file = await FilePicker.pickFile(
        dialogTitle: 'اختر ملفًا لإرساله',
        type: FileType.any,
      );
      if (file == null || !mounted) return;
      final knownSize = file.lengthSync();
      if (knownSize != null &&
          knownSize > WaslaRuntimeSettings.maxMediaUploadBytes) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'حجم الملف يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      final bytes = await file.readAsBytes();
      if (bytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'حجم الملف يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      final extension = (file.extension ?? 'bin').toLowerCase();
      final confirmed = await _confirmFileBeforeSend(
        title: file.name,
        size: bytes.length,
        icon: Icons.insert_drive_file_outlined,
      );
      if (!confirmed || !mounted) return;
      await _sendMediaBytes(
        bytes,
        messageType: 'file',
        content: file.name,
        extension: extension,
      );
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر اختيار الملف أو إرساله.')),
        );
      }
    }
  }

  Future<bool> _confirmFileBeforeSend({
    required String title,
    required int size,
    required IconData icon,
    String? details,
  }) async {
    if (!mounted) return false;
    final megabytes = (size / (1024 * 1024)).toStringAsFixed(2);
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('مراجعة المرفق'),
        content: Row(
          children: [
            Icon(
              icon,
              size: 34,
              color: Theme.of(dialogContext).colorScheme.primary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(
                    '$megabytes ميغابايت',
                    style: Theme.of(dialogContext).textTheme.bodySmall,
                  ),
                  if (details != null)
                    Text(
                      details,
                      style: Theme.of(dialogContext).textTheme.bodySmall,
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('إرسال'),
          ),
        ],
      ),
    );
    return approved == true;
  }

  Future<void> _chooseMediaSource(ImageSource source) async {
    if (_sending || _recording) return;
    final fromCamera = source == ImageSource.camera;
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(
                fromCamera ? Icons.photo_camera_outlined : Icons.image_outlined,
              ),
              title: Text(fromCamera ? 'التقاط صورة' : 'اختيار صورة'),
              onTap: () => Navigator.pop(sheetContext, 'image'),
            ),
            ListTile(
              leading: Icon(
                fromCamera
                    ? Icons.videocam_outlined
                    : Icons.video_library_outlined,
              ),
              title: Text(fromCamera ? 'تسجيل فيديو' : 'اختيار فيديو'),
              onTap: () => Navigator.pop(sheetContext, 'video'),
            ),
          ],
        ),
      ),
    );
    if (!mounted || choice == null) return;
    if (choice == 'image') {
      await _pickAndSendImage(source: source);
    } else {
      await _pickAndSendVideo(source: source);
    }
  }

  Future<void> _handleAttachment(String option) async {
    switch (option) {
      case 'gallery':
        await _chooseMediaSource(ImageSource.gallery);
      case 'camera':
        await _chooseMediaSource(ImageSource.camera);
      case 'audio':
        await _pickAndSendAudioFile();
      case 'file':
        await _pickAndSendFile();
      case 'location':
        await _shareCurrentLocation();
      default:
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('هذه الوظيفة غير متاحة في إصدار وصال الحالي.'),
            ),
          );
        }
    }
  }

  Future<void> _pickAndSendAudioFile() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_sending || _recording) return;
    if (widget.target.isGroup && (!_groupCanSend || !_groupVoiceAllowed)) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text('الملفات الصوتية غير متاحة في هذه المجموعة.'),
        ),
      );
      return;
    }
    AudioPlayer? metadataPlayer;
    try {
      final file = await FilePicker.pickFile(
        dialogTitle: 'اختر ملفًا صوتيًا',
        type: FileType.audio,
      );
      if (file == null || !mounted) return;
      final filePath = file.path;
      if (filePath == null || filePath.isEmpty) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر الوصول إلى ملف الصوت المحدد.')),
        );
        return;
      }
      final extension = (file.extension ?? '').toLowerCase();
      if (!const {'m4a', 'mp3', 'aac', 'webm'}.contains(extension)) {
        messenger.showSnackBar(
          const SnackBar(
            content: Text(
              'صيغة الصوت غير مدعومة. استخدم M4A أو MP3 أو AAC أو WebM.',
            ),
          ),
        );
        return;
      }
      final knownSize = file.lengthSync();
      if (knownSize != null &&
          knownSize > WaslaRuntimeSettings.maxMediaUploadBytes) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'حجم الملف يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      metadataPlayer = AudioPlayer();
      await metadataPlayer.setSourceDeviceFile(
        filePath,
        mimeType: _mimeForMessage('audio', extension),
      );
      final duration = await metadataPlayer.getDuration();
      final seconds = duration?.inSeconds ?? 0;
      if (seconds < 1 || seconds > 180) {
        messenger.showSnackBar(
          const SnackBar(
            content: Text(
              'يجب أن تكون مدة الملف الصوتي بين ثانية واحدة و٣ دقائق.',
            ),
          ),
        );
        return;
      }
      final bytes = await file.readAsBytes();
      if (bytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
        messenger.showSnackBar(
          SnackBar(
            content: Text(
              'حجم الملف يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
            ),
          ),
        );
        return;
      }
      final confirmed = await _confirmFileBeforeSend(
        title: file.name,
        size: bytes.length,
        icon: Icons.graphic_eq_rounded,
        details:
            'المدة ${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}',
      );
      if (!confirmed || !mounted) return;
      await _sendMediaBytes(
        bytes,
        messageType: 'audio',
        content: 'ملف صوتي · ${file.name}',
        extension: extension,
        durationSeconds: seconds,
      );
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر قراءة الملف الصوتي أو إرساله.')),
        );
      }
    } finally {
      await metadataPlayer?.dispose();
    }
  }

  String _mimeForExtension(String extension) => switch (extension) {
    'jpg' || 'jpeg' => 'image/jpeg',
    'm4a' => 'audio/mp4',
    'aac' => 'audio/aac',
    'mp3' => 'audio/mpeg',
    'pdf' => 'application/pdf',
    'doc' => 'application/msword',
    'docx' =>
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls' => 'application/vnd.ms-excel',
    'xlsx' =>
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'ppt' => 'application/vnd.ms-powerpoint',
    'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'txt' => 'text/plain',
    'csv' => 'text/csv',
    'zip' => 'application/zip',
    'png' => 'image/png',
    'webp' => 'image/webp',
    'mp4' => 'video/mp4',
    'mov' => 'video/quicktime',
    'webm' => 'video/webm',
    _ => 'application/octet-stream',
  };

  String _mimeForMessage(String messageType, String extension) {
    if (messageType == 'audio' && extension == 'webm') return 'audio/webm';
    return _mimeForExtension(extension);
  }

  Future<void> _shareCurrentLocation() async {
    final messenger = ScaffoldMessenger.of(context);
    if (widget.target.isGroup && !_groupCanSend) {
      messenger.showSnackBar(
        const SnackBar(content: Text('الإرسال متاح للمشرفين فقط.')),
      );
      return;
    }
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(content: Text('فعّل خدمة الموقع أولًا.')),
          );
        }
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(
              content: Text('اسمح ل وصال بالوصول إلى موقعك لمشاركته.'),
            ),
          );
        }
        return;
      }
      if (mounted) setState(() => _sending = true);
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );
      if (!mounted) return;
      final coordinates =
          '${position.latitude.toStringAsFixed(6)},${position.longitude.toStringAsFixed(6)}';
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('مشاركة الموقع الحالي؟'),
          content: Text('سيُرسل هذا الموقع إلى المحادثة:\n$coordinates'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      await _queueOutgoingMessage(
        content: coordinates,
        messageType: 'location',
      );
    } catch (_) {
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('تعذر تحديد الموقع أو إرساله.')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<bool> _sendMediaBytes(
    Uint8List bytes, {
    required String messageType,
    required String content,
    required String extension,
    int? durationSeconds,
  }) async {
    final userId = _myUserId;
    if (userId == null || _sending) return false;
    await _refreshRuntimeSettings(force: true);
    if (!mounted) return false;
    if (!WaslaRuntimeSettings.messagesEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('إرسال الرسائل متوقف مؤقتًا من الإدارة.')),
      );
      return false;
    }
    if (!WaslaRuntimeSettings.mediaUploadsEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('رفع مرفقات المحادثات متوقف مؤقتًا من الإدارة.'),
        ),
      );
      return false;
    }
    if (bytes.length > WaslaRuntimeSettings.maxMediaUploadBytes) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'حجم المرفق يتجاوز الحد الحالي (${WaslaRuntimeSettings.maxMediaUploadMb} م.ب).',
          ),
        ),
      );
      return false;
    }
    if (widget.target.isGroup &&
        (!_groupCanSend ||
            (messageType == 'audio' && !_groupVoiceAllowed) ||
            (messageType != 'audio' && !_groupFilesAllowed))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('هذا النوع من الوسائط غير مسموح في المجموعة.'),
        ),
      );
      return false;
    }
    setState(() => _sending = true);
    try {
      await _queueOutgoingMessage(
        content: content,
        messageType: messageType,
        mediaExtension: extension,
        durationSeconds: durationSeconds,
        attachmentBytes: bytes,
      );
      return true;
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر حفظ الوسائط على الجهاز. حاول مجددًا.'),
          ),
        );
      }
      return false;
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _startRecording() async {
    if (_sending || _recording || _stoppingRecording) return;
    if (widget.target.isGroup && (!_groupCanSend || !_groupVoiceAllowed)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('الرسائل الصوتية غير متاحة في هذه المجموعة.'),
        ),
      );
      return;
    }
    try {
      if (!await _recorder.hasPermission()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'اسمح ل وصال باستخدام الميكروفون لإرسال رسالة صوتية.',
              ),
            ),
          );
        }
        return;
      }
      final directory = await getTemporaryDirectory();
      final path =
          '${directory.path}/wasla_${DateTime.now().microsecondsSinceEpoch}.m4a';
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
        ),
        path: path,
      );
      _recordingClock = Stopwatch()..start();
      _recordingPath = path;
      _failedRecordingPath = null;
      _recordingLocked = false;
      _recordingWaveform = List<double>.filled(26, .12);
      if (mounted) {
        setState(() {
          _recording = true;
          _recordingDuration = Duration.zero;
        });
      }
      await _recordingAmplitudeSubscription?.cancel();
      _recordingAmplitudeSubscription = _recorder
          .onAmplitudeChanged(const Duration(milliseconds: 100))
          .listen((amplitude) {
            if (!mounted || !_recording) return;
            final decibels = (amplitude.current as num).toDouble();
            final level = ((decibels + 60) / 60).clamp(.06, 1.0).toDouble();
            setState(() {
              _recordingWaveform = [..._recordingWaveform.skip(1), level];
            });
          }, onError: (Object _) {});
      _recordingTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(
          () => _recordingDuration = _recordingClock?.elapsed ?? Duration.zero,
        );
        if (_recordingDuration.inSeconds >= 180) unawaited(_stopRecording());
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر بدء التسجيل. تحقق من إذن الميكروفون.'),
          ),
        );
      }
    }
  }

  void _lockRecording() {
    if (!_recording || _recordingLocked) return;
    HapticFeedback.selectionClick();
    setState(() => _recordingLocked = true);
  }

  Future<void> _cancelRecording() async {
    if (!_recording || _stoppingRecording) return;
    _recordingTimer?.cancel();
    _recordingClock?.stop();
    await _recordingAmplitudeSubscription?.cancel();
    _recordingAmplitudeSubscription = null;
    final path = _recordingPath;
    if (mounted) {
      setState(() {
        _recording = false;
        _recordingLocked = false;
      });
    }
    try {
      await _recorder.cancel();
    } catch (_) {}
    if (path != null) {
      try {
        await File(path).delete();
      } catch (_) {}
    }
    _recordingPath = null;
    _recordingClock = null;
    _recordingDuration = Duration.zero;
    if (mounted) setState(() {});
  }

  Future<void> _stopRecording() async {
    if (!_recording || _stoppingRecording) return;
    _stoppingRecording = true;
    _recordingTimer?.cancel();
    _recordingClock?.stop();
    final seconds = _recordingClock?.elapsed.inSeconds ?? 0;
    final path = _recordingPath;
    await _recordingAmplitudeSubscription?.cancel();
    _recordingAmplitudeSubscription = null;
    if (mounted) {
      setState(() {
        _recording = false;
        _recordingLocked = false;
      });
    }
    try {
      final recordedPath = await _recorder.stop() ?? path;
      if (recordedPath == null || seconds < 1) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('التسجيل قصير جدًا لإرساله.')),
          );
        }
        if (recordedPath != null) {
          try {
            await File(recordedPath).delete();
          } catch (_) {}
        }
        _recordingPath = null;
        return;
      }
      final bytes = await File(recordedPath).readAsBytes();
      final stored = await _sendMediaBytes(
        bytes,
        messageType: 'audio',
        content: 'رسالة صوتية',
        extension: 'm4a',
        durationSeconds: seconds.clamp(1, 180),
      );
      if (stored) {
        try {
          await File(recordedPath).delete();
        } catch (_) {}
        _recordingPath = null;
        _failedRecordingPath = null;
      } else {
        _recordingPath = recordedPath;
        _failedRecordingPath = recordedPath;
      }
    } catch (_) {
      _failedRecordingPath = path;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حفظ التسجيل أو إرساله.')),
        );
      }
    } finally {
      _recordingClock = null;
      _stoppingRecording = false;
      if (mounted) setState(() {});
    }
  }

  Future<void> _retryFailedRecording() async {
    final path = _failedRecordingPath;
    if (path == null || _sending) return;
    try {
      final bytes = await File(path).readAsBytes();
      final seconds = _recordingDuration.inSeconds.clamp(1, 180);
      final stored = await _sendMediaBytes(
        bytes,
        messageType: 'audio',
        content: 'رسالة صوتية',
        extension: 'm4a',
        durationSeconds: seconds,
      );
      if (!stored) return;
      try {
        await File(path).delete();
      } catch (_) {}
      _failedRecordingPath = null;
      _recordingPath = null;
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر قراءة التسجيل المحفوظ.')),
        );
      }
    }
  }

  Future<void> _discardFailedRecording() async {
    final path = _failedRecordingPath;
    _failedRecordingPath = null;
    _recordingPath = null;
    if (path != null) {
      try {
        await File(path).delete();
      } catch (_) {}
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.target.isGroup
        ? (_groupName ?? widget.target.displayName)
        : widget.target.displayName.isNotEmpty
        ? widget.target.displayName
        : '@${widget.target.username}';
    final query = _searchController.text.trim().toLowerCase();
    final visibleMessages = query.isEmpty
        ? _messages
        : _messages
              .where((message) => message.content.toLowerCase().contains(query))
              .toList();
    return Scaffold(
      backgroundColor: _chatBackgroundColor == null
          ? null
          : Color(_chatBackgroundColor!),
      appBar: AppBar(
        title: _searching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontSize: 16),
                decoration: const InputDecoration(
                  hintText: 'ابحث في الرسائل المحمّلة',
                  border: InputBorder.none,
                  filled: false,
                  contentPadding: EdgeInsets.zero,
                ),
              )
            : GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: widget.target.isGroup ? _openGroupInfo : _openChatInfo,
                child: Row(
                  children: [
                    ValueListenableBuilder<Map<String, UserPresenceStatus>>(
                      valueListenable: userPresenceStatuses,
                      builder: (context, statuses, _) =>
                          ValueListenableBuilder<Set<String>>(
                            valueListenable: onlineUserIds,
                            builder: (context, onlineIds, _) => _Avatar(
                              label: title,
                              small: true,
                              imageUrl: widget.target.isGroup
                                  ? groupAvatarUrl(
                                      _groupAvatarPath ??
                                          widget.target.avatarPath,
                                    )
                                  : avatarPublicUrl(
                                      _db,
                                      widget.target.avatarPath,
                                    ),
                              online:
                                  !widget.target.isGroup &&
                                  onlineIds.contains(widget.target.userId),
                              presenceStatus: widget.target.isGroup
                                  ? null
                                  : statuses[widget.target.userId],
                            ),
                          ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AdminIdentityText(
                            userId: widget.target.isGroup
                                ? null
                                : widget.target.userId,
                            label: title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          if (_peerTypingUserIds.isNotEmpty)
                            Text(
                              _typingStatusLabel,
                              style: TextStyle(
                                fontSize: 11,
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w600,
                              ),
                            )
                          else if (widget.target.isGroup)
                            Text(
                              widget.target.isPublicRoom
                                  ? '$_groupMemberCount أعضاء · $_roomOnlineCount حاضرون الآن'
                                  : '$_groupMemberCount أعضاء',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color(0xFF71827D),
                              ),
                            )
                          else
                            ValueListenableBuilder<
                              Map<String, UserPresenceStatus>
                            >(
                              valueListenable: userPresenceStatuses,
                              builder: (context, statuses, _) =>
                                  ValueListenableBuilder<Set<String>>(
                                    valueListenable: onlineUserIds,
                                    builder: (context, onlineIds, _) => Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        if (statuses[widget.target.userId] !=
                                            null)
                                          PresenceStatusLabel(
                                            status: effectivePresenceStatus(
                                              statuses[widget.target.userId]!,
                                              online: onlineIds.contains(
                                                widget.target.userId,
                                              ),
                                            ),
                                            fontSize: 11,
                                            dotSize: 7,
                                            userId: widget.target.userId,
                                          ),
                                        ConnectionStatusLabel(
                                          online: onlineIds.contains(
                                            widget.target.userId,
                                          ),
                                          lastSeenAt: _peerLastSeenAt,
                                          lastSeenLoaded: _peerLastSeenLoaded,
                                          fontSize: 11,
                                        ),
                                      ],
                                    ),
                                  ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
        actions: [
          if (widget.target.isGroup)
            IconButton(
              tooltip: 'معلومات المجموعة',
              onPressed: _openGroupInfo,
              icon: const Icon(Icons.info_outline),
            ),
          if (!widget.target.isGroup && !_searching) ...[
            IconButton(
              tooltip: 'مكالمة صوتية',
              onPressed: () => _startCall(video: false),
              icon: const Icon(Icons.call_outlined),
            ),
            IconButton(
              tooltip: 'مكالمة مرئية',
              onPressed: () => _startCall(video: true),
              icon: const Icon(Icons.videocam_outlined),
            ),
          ],
          IconButton(
            tooltip: _searching ? 'إغلاق البحث' : 'بحث في الرسائل',
            icon: Icon(_searching ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                _searching = !_searching;
                _searchController.clear();
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          if (!widget.target.isGroup && !_searching) _friendshipBanner(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null && _messages.isEmpty
                ? _LoadError(onRetry: _loadMessages, message: _error!)
                : _messages.isEmpty
                ? const Center(
                    child: Text(
                      'أرسل أول رسالة وابدأ الحوار',
                      style: TextStyle(color: Color(0xFF71827D)),
                    ),
                  )
                : query.isNotEmpty && visibleMessages.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'لا توجد رسائل مطابقة في السجل المحمّل',
                          style: TextStyle(color: Color(0xFF71827D)),
                        ),
                        _olderMessagesControl(),
                      ],
                    ),
                  )
                : NotificationListener<ScrollNotification>(
                    onNotification: (notification) {
                      if (notification.metrics.axis == Axis.vertical &&
                          notification.metrics.extentAfter < 180 &&
                          _hasMoreMessages &&
                          !_loadingOlderMessages) {
                        unawaited(_loadOlderMessages());
                      }
                      return false;
                    },
                    child: ListView.builder(
                      controller: _scrollController,
                      reverse: true,
                      padding: const EdgeInsets.fromLTRB(14, 18, 14, 14),
                      itemCount: visibleMessages.length + 1,
                      itemBuilder: (context, index) {
                        if (index == visibleMessages.length) {
                          return _olderMessagesControl();
                        }
                        final message =
                            visibleMessages[visibleMessages.length - 1 - index];
                        final reply = message.replyTo == null
                            ? null
                            : _messages
                                  .where((item) => item.id == message.replyTo)
                                  .firstOrNull;
                        return _MessageBubble(
                          message: message,
                          mine: message.senderId == _myUserId,
                          bubbleStyle: widget.bubbleStyle,
                          userId: _myUserId ?? '',
                          isGroup: widget.target.isGroup,
                          senderName: widget.target.isGroup
                              ? _groupSenderNames[message.senderId]
                              : message.senderId == widget.target.userId
                              ? (widget.target.displayName.isNotEmpty
                                    ? widget.target.displayName
                                    : '@${widget.target.username}')
                              : (_db
                                            .auth
                                            .currentUser
                                            ?.userMetadata?['display_name']
                                            ?.toString()
                                            .trim()
                                            .isNotEmpty ==
                                        true
                                    ? _db
                                          .auth
                                          .currentUser!
                                          .userMetadata!['display_name']
                                          .toString()
                                    : '@${_db.auth.currentUser?.userMetadata?['username']?.toString() ?? ''}'),
                          replyMessage: reply,
                          reactions: _messageReactions[message.id] ?? const {},
                          starred: _starredMessageIds.contains(message.id),
                          pinned: _pinnedMessageIds.contains(message.id),
                          onDoubleTap: () {
                            if (!message.isPending && _myUserId != null) {
                              HapticFeedback.selectionClick();
                              unawaited(_toggleReaction(message, '❤️'));
                            }
                          },
                          onLongPress: () => _showMessageActions(message),
                        );
                      },
                    ),
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (widget.target.isGroup && !_groupCanSend)
                    const Padding(
                      padding: EdgeInsets.only(bottom: 6),
                      child: Text(
                        'الإرسال متاح للمشرفين فقط',
                        style: TextStyle(color: Color(0xFF71827D)),
                      ),
                    )
                  else if (!WaslaRuntimeSettings.messagesEnabled)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text(
                        'إرسال الرسائل متوقف مؤقتًا من الإدارة.',
                        style: TextStyle(color: Color(0xFF71827D)),
                      ),
                    )
                  else
                    ChatComposer(
                      controller: _messageController,
                      focusNode: _messageFocusNode,
                      onChanged: _handleTypingChanged,
                      onSubmitted: (_) => _send(),
                      onSend: _send,
                      onAttachmentSelected: _handleAttachment,
                      onStartRecording: _startRecording,
                      onStopRecording: _stopRecording,
                      onCancelRecording: _cancelRecording,
                      onLockRecording: _lockRecording,
                      onRetryFailedRecording: _retryFailedRecording,
                      onDiscardFailedRecording: _discardFailedRecording,
                      isSending: _sending || _stoppingRecording,
                      isRecording: _recording,
                      isRecordingLocked: _recordingLocked,
                      hasFailedRecording: _failedRecordingPath != null,
                      recordingDuration: _recordingDuration,
                      waveform: _recordingWaveform,
                      voiceAllowed:
                          WaslaRuntimeSettings.mediaUploadsEnabled &&
                          (!widget.target.isGroup || _groupVoiceAllowed),
                      filesAllowed:
                          WaslaRuntimeSettings.mediaUploadsEnabled &&
                          (!widget.target.isGroup || _groupFilesAllowed),
                      replySender: _replyingTo == null
                          ? null
                          : _replyingTo!.senderId == _myUserId
                          ? 'أنت'
                          : widget.target.isGroup
                          ? (_groupSenderNames[_replyingTo!.senderId] ?? 'عضو')
                          : widget.target.displayName,
                      replyText: _replyingTo?.content,
                      onCancelReply: _replyingTo == null
                          ? null
                          : () => setState(() => _replyingTo = null),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.message,
    required this.mine,
    required this.bubbleStyle,
    required this.userId,
    required this.isGroup,
    required this.onDoubleTap,
    required this.onLongPress,
    required this.starred,
    required this.pinned,
    this.senderName,
    this.replyMessage,
    this.reactions = const {},
  });
  final ChatMessage message;
  final bool mine;
  final MessageBubbleStyle bubbleStyle;
  final String userId;
  final bool isGroup;
  final bool starred;
  final bool pinned;
  final String? senderName;
  final ChatMessage? replyMessage;
  final Map<String, int> reactions;
  final VoidCallback onDoubleTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onDoubleTap: onDoubleTap,
    onLongPress: onLongPress,
    child: Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.sizeOf(context).width * .83,
        ),
        margin: const EdgeInsets.only(bottom: 8),
        padding: bubbleStyle == MessageBubbleStyle.compact
            ? const EdgeInsets.fromLTRB(12, 8, 12, 7)
            : const EdgeInsets.fromLTRB(14, 10, 14, 8),
        decoration: BoxDecoration(
          color: mine
              ? null
              : Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF202E2A)
              : Theme.of(context).colorScheme.surface,
          gradient: mine
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: Theme.of(context).brightness == Brightness.dark
                      ? const [Color(0xFF1B5145), Color(0xFF153D34)]
                      : const [Color(0xFFE2F6ED), Color(0xFFD1EFE2)],
                )
              : null,
          border: Border.all(
            color: mine
                ? Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xFF286455)
                      : const Color(0xFFC4E8D7)
                : Theme.of(context).colorScheme.outlineVariant
                      .withValues(alpha: .48),
            width: .8,
          ),
          borderRadius: bubbleStyle.borderRadiusFor(mine: mine),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(
                alpha: Theme.of(context).brightness == Brightness.dark
                    ? .16
                    : .055,
              ),
              blurRadius: 13,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (senderName != null &&
                ((isGroup && !mine) || isWaslaAdmin(message.senderId)))
              Align(
                alignment: Alignment.centerRight,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child:
                      ValueListenableBuilder<Map<String, UserPresenceStatus>>(
                        valueListenable: userPresenceStatuses,
                        builder: (context, statuses, _) => Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            AdminIdentityText(
                              userId: message.senderId,
                              label: senderName!,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                            if (statuses[message.senderId] != null) ...[
                              const SizedBox(width: 6),
                              PresenceStatusLabel(
                                status: statuses[message.senderId]!,
                                fontSize: 10,
                                dotSize: 7,
                                userId: message.senderId,
                              ),
                            ],
                          ],
                        ),
                      ),
                ),
              ),
            if (replyMessage != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary
                      .withValues(alpha: .08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border(
                    right: BorderSide(
                      color: Theme.of(context).colorScheme.primary
                          .withValues(alpha: .65),
                      width: 3,
                    ),
                  ),
                ),
                child: Text(
                  replyMessage!.content,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            Align(
              alignment: Alignment.centerRight,
              child: message.messageType == 'text'
                  ? Text(
                      message.content,
                      textAlign: TextAlign.start,
                      style: TextStyle(
                        fontSize: 15,
                        height: 1.48,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    )
                  : MessageMedia(client: _db, message: message, userId: userId),
            ),
            if (message.editedAt != null)
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'معدّلة',
                  style: TextStyle(
                    fontSize: 10,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            if (reactions.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Wrap(
                  spacing: 4,
                  children: reactions.entries
                      .map(
                        (entry) => Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Theme.of(context)
                                .colorScheme
                                .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: Theme.of(context)
                                  .colorScheme
                                  .outlineVariant
                                  .withValues(alpha: .55),
                            ),
                          ),
                          child: Text(
                            '${entry.key} ${entry.value}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      )
                      .toList(),
                ),
              ),
            const SizedBox(height: 4),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (pinned)
                  const Tooltip(
                    message: 'رسالة مثبتة في المحادثة',
                    child: Icon(Icons.push_pin_rounded, size: 13),
                  ),
                if (pinned && starred) const SizedBox(width: 3),
                if (starred)
                  Tooltip(
                    message: 'رسالة مميزة بنجمة لديك',
                    child: Icon(
                      Icons.star_rounded,
                      size: 15,
                      color: Colors.amber.shade700,
                    ),
                  ),
                if ((pinned || starred) && mine) const SizedBox(width: 4),
                if (mine)
                  Tooltip(
                    message: message.isPending
                        ? 'بانتظار الاتصال'
                        : message.readAt != null
                        ? 'تمت القراءة'
                        : message.deliveredAt != null
                        ? 'تم التسليم'
                        : 'تم الإرسال',
                    child: Icon(
                      message.isPending
                          ? Icons.schedule
                          : message.deliveredAt != null ||
                                message.readAt != null
                          ? Icons.done_all
                          : Icons.done,
                      size: 14,
                      color: message.isPending
                          ? Theme.of(context).colorScheme.onSurfaceVariant
                          : message.readAt != null
                          ? const Color(0xFF1683D8)
                          : Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                if (mine) const SizedBox(width: 4),
                Text(
                  DateFormat('HH:mm').format(message.createdAt.toLocal()),
                  style: TextStyle(
                    fontSize: 10,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

class _EmptyInbox extends StatelessWidget {
  const _EmptyInbox({required this.onStart, this.username});
  final VoidCallback onStart;
  final String? username;
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 104,
              height: 104,
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.forum_outlined,
                size: 48,
                color: colors.onPrimaryContainer,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              username == null ? 'لا توجد محادثات بعد' : 'مرحبًا بك في وصال',
              style: Theme.of(context).textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(
              'ابدأ محادثة مع شخص تعرف اسم المستخدم الخاص به.',
              textAlign: TextAlign.center,
              style: TextStyle(color: colors.onSurfaceVariant, height: 1.5),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: onStart,
              icon: const Icon(Icons.add),
              label: const Text('محادثة جديدة'),
            ),
          ],
        ),
      ),
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark({required this.size});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF087F72), Color(0xFF10A58E)],
      ),
      borderRadius: BorderRadius.circular(size * .3),
      boxShadow: [
        BoxShadow(
          color: const Color(0xFF087F72).withValues(alpha: .24),
          blurRadius: size * .32,
          offset: Offset(0, size * .12),
        ),
      ],
    ),
    child: Icon(Icons.chat_rounded, size: size * .52, color: Colors.white),
  );
}

class _Avatar extends StatelessWidget {
  const _Avatar({
    required this.label,
    this.small = false,
    this.imageUrl,
    this.online = false,
    this.showConnectionStatus = false,
    this.presenceStatus,
    this.radius,
  });
  final String label;
  final bool small;
  final String? imageUrl;
  final bool online;
  final bool showConnectionStatus;
  final UserPresenceStatus? presenceStatus;
  final double? radius;

  @override
  Widget build(BuildContext context) {
    const palette = [
      Color(0xFF087F72),
      Color(0xFF5676A9),
      Color(0xFFB16B4C),
      Color(0xFF8165A8),
    ];
    final color =
        palette[label.codeUnits.fold<int>(0, (sum, c) => sum + c) %
            palette.length];
    final initial = label.isEmpty ? '؟' : label[0].toUpperCase();
    final avatarRadius = radius ?? (small ? 19.0 : 27.0);
    return Stack(
      clipBehavior: Clip.none,
      children: [
        CircleAvatar(
          radius: avatarRadius,
          backgroundColor: color.withValues(alpha: .12),
          child: imageUrl == null
              ? Text(
                  initial,
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w800,
                    fontSize: small ? 15 : 20,
                  ),
                )
              : ClipOval(
                  child: CachedNetworkImage(
                    imageUrl: imageUrl!,
                    width: avatarRadius * 2,
                    height: avatarRadius * 2,
                    fit: BoxFit.cover,
                    placeholder: (_, _) => Center(
                      child: Text(
                        initial,
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.w800,
                          fontSize: small ? 15 : 20,
                        ),
                      ),
                    ),
                    errorWidget: (_, _, _) => Center(
                      child: Text(
                        initial,
                        style: TextStyle(
                          color: color,
                          fontWeight: FontWeight.w800,
                          fontSize: small ? 15 : 20,
                        ),
                      ),
                    ),
                  ),
                ),
        ),
        if (showConnectionStatus)
          Positioned(
            right: 0,
            bottom: 0,
            child: ConnectionStatusDot(online: online, size: small ? 11 : 14),
          )
        else if (presenceStatus != null)
          Positioned(
            right: 0,
            bottom: 0,
            child: PresenceStatusDot(
              status: effectivePresenceStatus(presenceStatus!, online: online),
              size: small ? 11 : 14,
            ),
          ),
        if (!showConnectionStatus && online)
          Positioned(
            left: presenceStatus == null ? null : 0,
            right: presenceStatus == null ? 0 : null,
            bottom: 0,
            child: ConnectionStatusDot(online: true, size: small ? 11 : 14),
          ),
      ],
    );
  }
}

class _InlineNotice extends StatelessWidget {
  const _InlineNotice({required this.text, required this.error});
  final String text;
  final bool error;
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: error ? const Color(0xFFFFEEEE) : const Color(0xFFE5F6EF),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text(
      text,
      style: TextStyle(
        color: error ? const Color(0xFF9A3434) : const Color(0xFF17664D),
        height: 1.4,
      ),
    ),
  );
}

class _LoadError extends StatelessWidget {
  const _LoadError({
    required this.onRetry,
    this.message = 'تعذر تحميل المحادثات.',
  });
  final VoidCallback onRetry;
  final String message;
  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(message),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.refresh),
          label: const Text('إعادة المحاولة'),
        ),
      ],
    ),
  );
}
