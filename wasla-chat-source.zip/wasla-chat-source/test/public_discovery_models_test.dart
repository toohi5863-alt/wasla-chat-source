import 'package:chat/public_discovery_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('maps public room metadata and builds its share link', () {
    final listing = PublicListing.fromMap({
      'conversation_id': 'room-123',
      'name': 'غرفة التقنية',
      'description': 'نقاشات تقنية',
      'category': 'technology',
      'listing_type': 'room',
      'invite_token': 'invite-token',
      'member_count': 12,
      'room_online_count': 4,
      'activity_7d': 25,
      'is_active': true,
      'is_member': false,
      'created_at': '2026-10-01T12:00:00Z',
    });

    expect(listing.isRoom, isTrue);
    expect(listing.isActive, isTrue);
    expect(listing.isMember, isFalse);
    expect(listing.memberCount, 12);
    expect(listing.roomOnlineCount, 4);
    expect(listing.categoryLabel, 'تقنية');
    expect(listing.publicLink, 'wasla://join/invite-token');
    expect(listing.toChatTarget().isPublicRoom, isTrue);
  });

  test('falls back safely for missing optional discovery values', () {
    final listing = PublicListing.fromMap({'conversation_id': 'group-1'});

    expect(listing.categoryLabel, 'أخرى');
    expect(listing.isRoom, isFalse);
    expect(listing.isActive, isFalse);
    expect(listing.memberCount, 0);
    expect(listing.toChatTarget().isGroup, isTrue);
  });
}
