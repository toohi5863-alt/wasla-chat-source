import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';

import 'admin_identity.dart';
import 'friendship_models.dart';
import 'status_models.dart';
import 'status_helpers.dart';
import 'status_service.dart';
import 'status_media_cache.dart';
import 'device_media_saver.dart';
import 'wasla_media.dart';

const _statusColors = <int>[
  0xFF087F72,
  0xFF355C9A,
  0xFF773E91,
  0xFFBA4C55,
  0xFFB46B16,
  0xFF355F56,
];

class StatusHighlightsStrip extends StatefulWidget {
  const StatusHighlightsStrip({required this.onSeeAll, super.key});

  final VoidCallback onSeeAll;

  @override
  State<StatusHighlightsStrip> createState() => _StatusHighlightsStripState();
}

class _StatusHighlightsStripState extends State<StatusHighlightsStrip> {
  late final SupabaseClient _client = Supabase.instance.client;
  late final StatusService _service = StatusService(_client);
  List<StatusItem> _items = const [];
  bool _loading = true;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    unawaited(_refresh());
    final userId = _client.auth.currentUser?.id;
    if (userId != null) {
      _channel = _client
          .channel('wasla-chat-status-highlights-$userId')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'status_posts',
            callback: (_) => unawaited(_refresh()),
          )
          .subscribe();
    }
  }

  @override
  void dispose() {
    final channel = _channel;
    if (channel != null) unawaited(_client.removeChannel(channel));
    super.dispose();
  }

  Future<void> _refresh() async {
    try {
      final items = await _service.loadFeed();
      if (mounted) setState(() => _items = items);
    } catch (_) {
      // Keep the chat list available if the status feed is temporarily offline.
    } finally {
      if (mounted && _loading) setState(() => _loading = false);
    }
  }

  Future<void> _openStatuses(List<StatusItem> statuses) async {
    if (statuses.isEmpty) {
      final created = await Navigator.of(context).push<bool>(
        MaterialPageRoute(builder: (_) => const StatusComposerScreen()),
      );
      if (created == true) await _refresh();
      return;
    }
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            StatusViewerScreen(statuses: statuses, service: _service),
      ),
    );
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final userId = _client.auth.currentUser?.id;
    final mine = _items.where((item) => item.userId == userId).toList();
    final groups = groupFriendStatuses(_items, currentUserId: userId);

    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(16, 4, 16, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'الحالات',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: colors.onSurface,
                  ),
                ),
              ),
              if (groups.isNotEmpty || mine.isNotEmpty)
                TextButton(
                  onPressed: widget.onSeeAll,
                  style: TextButton.styleFrom(
                    visualDensity: VisualDensity.compact,
                    padding: const EdgeInsetsDirectional.fromSTEB(8, 2, 4, 2),
                  ),
                  child: const Text('عرض الكل'),
                ),
            ],
          ),
          SizedBox(
            height: 94,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.zero,
              children: [
                _StatusHighlightTile(
                  label: 'حالتك',
                  imageUrl: avatarPublicUrl(
                    _client,
                    _client.auth.currentUser?.userMetadata?['avatar_path']
                        ?.toString(),
                  ),
                  unseen: false,
                  add: true,
                  onTap: () => unawaited(_openStatuses(mine)),
                  onAdd: () => unawaited(_openStatuses(const [])),
                ),
                for (final group in groups)
                  _StatusHighlightTile(
                    label: group.statuses.first.authorLabel,
                    userId: group.statuses.first.userId,
                    imageUrl: avatarPublicUrl(
                      _client,
                      group.statuses.first.avatarPath,
                    ),
                    unseen: group.hasUnseen,
                    onTap: () => unawaited(_openStatuses(group.statuses)),
                  ),
                if (_loading && _items.isEmpty)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(start: 8),
                    child: SizedBox(
                      width: 54,
                      height: 54,
                      child: Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: colors.primary,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusHighlightTile extends StatelessWidget {
  const _StatusHighlightTile({
    required this.label,
    required this.imageUrl,
    required this.unseen,
    required this.onTap,
    this.userId,
    this.add = false,
    this.onAdd,
  });

  final String label;
  final String? imageUrl;
  final bool unseen;
  final bool add;
  final String? userId;
  final VoidCallback onTap;
  final VoidCallback? onAdd;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final title = label.isEmpty ? 'مستخدم وصال' : label;
    return SizedBox(
      width: 76,
      child: Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: Semantics(
          button: true,
          label: add ? 'إضافة حالة' : 'حالة $title',
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onTap,
              borderRadius: BorderRadius.circular(18),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: unseen
                                ? LinearGradient(
                                    colors: [
                                      colors.primary,
                                      colors.tertiary,
                                      const Color(0xFF39B884),
                                    ],
                                  )
                                : null,
                            border: unseen
                                ? null
                                : Border.all(
                                    color: colors.outlineVariant,
                                    width: 1.5,
                                  ),
                          ),
                          padding: EdgeInsets.all(unseen ? 2.5 : 1.5),
                          child: Padding(
                            padding: const EdgeInsets.all(2),
                            child: CircleAvatar(
                              radius: 24,
                              backgroundColor: colors.primaryContainer,
                              foregroundImage: imageUrl == null
                                  ? null
                                  : NetworkImage(imageUrl!),
                              child: imageUrl == null
                                  ? Text(
                                      String.fromCharCode(title.runes.first),
                                      style: TextStyle(
                                        color: colors.onPrimaryContainer,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    )
                                  : null,
                            ),
                          ),
                        ),
                        if (add)
                          PositionedDirectional(
                            end: -1,
                            bottom: -1,
                            child: Material(
                              color: colors.primary,
                              shape: const CircleBorder(),
                              child: InkWell(
                                onTap: onAdd,
                                customBorder: const CircleBorder(),
                                child: const SizedBox(
                                  width: 23,
                                  height: 23,
                                  child: Icon(
                                    Icons.add_rounded,
                                    size: 17,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    AdminIdentityText(
                      userId: add ? null : userId,
                      label: add ? 'حالتك' : title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: colors.onSurface,
                        fontWeight: unseen ? FontWeight.w700 : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class StatusSection extends StatefulWidget {
  const StatusSection({super.key});

  @override
  State<StatusSection> createState() => _StatusSectionState();
}

class _StatusSectionState extends State<StatusSection> {
  late final SupabaseClient _client = Supabase.instance.client;
  late final StatusService _service = StatusService(_client);
  final StatusMediaCache _mediaCache = StatusMediaCache();
  List<StatusItem> _items = const [];
  bool _loading = true;
  bool _refreshing = false;
  bool _showUnseenOnly = false;
  bool _showGrid = false;
  bool _searchExpanded = false;
  final TextEditingController _searchController = TextEditingController();
  String? _error;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    unawaited(_refresh());
    final userId = _client.auth.currentUser?.id;
    if (userId != null) {
      _channel = _client
          .channel('wasla-status-feed-$userId')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'status_posts',
            callback: (_) => unawaited(_refresh(silent: true)),
          )
          .subscribe();
    }
  }

  @override
  void dispose() {
    final channel = _channel;
    if (channel != null) unawaited(_client.removeChannel(channel));
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _refresh({bool silent = false}) async {
    if (_refreshing) return;
    _refreshing = true;
    if (!silent && mounted) {
      setState(() {
        _loading = _items.isEmpty;
        _error = null;
      });
    }
    try {
      final accountId = _client.auth.currentUser?.id;
      if (accountId != null) {
        try {
          await _mediaCache.removeExpiredForAccount(accountId);
        } catch (_) {
          // Local cache cleanup must not prevent loading the current feed.
        }
      }
      final items = await _service.loadFeed();
      if (mounted) {
        setState(() {
          _items = items;
          _error = null;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _error = 'تعذر تحميل الحالات. تأكد من إعداد الخادم ثم أعد المحاولة.';
          _loading = false;
        });
      }
    } finally {
      _refreshing = false;
    }
  }

  Future<void> _createStatus() async {
    final created = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const StatusComposerScreen()),
    );
    if (created == true) await _refresh();
  }

  Future<void> _openStatuses(List<StatusItem> statuses) async {
    if (statuses.isEmpty) {
      await _createStatus();
      return;
    }
    await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) =>
            StatusViewerScreen(statuses: statuses, service: _service),
      ),
    );
    await _refresh(silent: true);
  }

  Future<void> _showPrivacyInfo() async {
    final createStatus = await showModalBottomSheet<bool>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        final colors = Theme.of(sheetContext).colorScheme;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(20, 4, 20, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.shield_outlined, color: colors.primary, size: 30),
                const SizedBox(height: 10),
                Text(
                  'خصوصية الحالات',
                  textAlign: TextAlign.center,
                  style: Theme.of(sheetContext).textTheme.titleLarge
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                Text(
                  'تختار جمهور كل حالة عند إنشائها: جميع الأصدقاء المقبولين أو أصدقاء تحددهم بنفسك. تنتهي الحالة تلقائيًا بعد ٢٤ ساعة.',
                  textAlign: TextAlign.center,
                  style: Theme.of(sheetContext).textTheme.bodyMedium
                      ?.copyWith(color: colors.onSurfaceVariant, height: 1.5),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => Navigator.pop(sheetContext, true),
                  icon: const Icon(Icons.add_a_photo_outlined),
                  label: const Text('إنشاء حالة واختيار جمهورها'),
                ),
              ],
            ),
          ),
        );
      },
    );
    if (createStatus == true && mounted) await _createStatus();
  }

  @override
  Widget build(BuildContext context) {
    final userId = _client.auth.currentUser?.id;
    final mine = _items.where((item) => item.userId == userId).toList();
    final groups = groupFriendStatuses(
      _items,
      currentUserId: userId,
      unseenOnly: _showUnseenOnly,
    );
    final query = _searchController.text.trim().toLowerCase();
    final visibleGroups = groups.where((group) {
      if (query.isEmpty) return true;
      final latest = group.statuses.first;
      return latest.authorLabel.toLowerCase().contains(query) ||
          latest.username.toLowerCase().contains(query);
    }).toList();
    final colors = Theme.of(context).colorScheme;

    Widget heroAction({
      required IconData icon,
      required String tooltip,
      required VoidCallback onPressed,
    }) => IconButton(
      tooltip: tooltip,
      onPressed: onPressed,
      style: IconButton.styleFrom(
        foregroundColor: colors.onPrimary,
        backgroundColor: colors.onPrimary.withValues(alpha: .14),
        minimumSize: const Size(42, 42),
      ),
      icon: Icon(icon, size: 20),
    );

    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 112),
        children: [
          Container(
            padding: const EdgeInsetsDirectional.fromSTEB(18, 17, 14, 17),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: AlignmentDirectional.topStart,
                end: AlignmentDirectional.bottomEnd,
                colors: [
                  colors.primary,
                  Color.lerp(colors.primary, const Color(0xFF102A28), .34)!,
                ],
              ),
              borderRadius: BorderRadius.circular(26),
              boxShadow: [
                BoxShadow(
                  color: colors.primary.withValues(alpha: .18),
                  blurRadius: 22,
                  offset: const Offset(0, 9),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'لحظاتك اليومية',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: colors.onPrimary,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'شارك يومك مع من تحب · تختفي بعد ٢٤ ساعة',
                        maxLines: 2,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colors.onPrimary.withValues(alpha: .84),
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 4),
                heroAction(
                  icon: _searchExpanded ? Icons.close_rounded : Icons.search,
                  tooltip: _searchExpanded ? 'إغلاق البحث' : 'البحث في الحالات',
                  onPressed: () => setState(() {
                    _searchExpanded = !_searchExpanded;
                    if (!_searchExpanded) _searchController.clear();
                  }),
                ),
                const SizedBox(width: 5),
                heroAction(
                  icon: Icons.add_rounded,
                  tooltip: 'إضافة حالة',
                  onPressed: () => unawaited(_createStatus()),
                ),
                const SizedBox(width: 5),
                heroAction(
                  icon: Icons.shield_outlined,
                  tooltip: 'خصوصية الحالات',
                  onPressed: () => unawaited(_showPrivacyInfo()),
                ),
              ],
            ),
          ),
          if (_searchExpanded) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _searchController,
              autofocus: true,
              textInputAction: TextInputAction.search,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'ابحث باسم الصديق',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _searchController.text.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'مسح البحث',
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.close_rounded),
                      ),
              ),
            ),
          ],
          const SizedBox(height: 16),
          _MyStatusTile(
            statuses: mine,
            onTap: () => unawaited(_openStatuses(mine)),
            onAdd: _createStatus,
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: Text(
                  'حالات الأصدقاء',
                  style: Theme.of(context).textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              if (visibleGroups.isNotEmpty)
                Text(
                  '${visibleGroups.length} أصدقاء',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: colors.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 11),
          SegmentedButton<bool>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(
                value: false,
                label: Text('الكل'),
                icon: Icon(Icons.groups_2_outlined),
              ),
              ButtonSegment(
                value: true,
                label: Text('غير مشاهدة'),
                icon: Icon(Icons.circle_notifications_outlined),
              ),
            ],
            selected: {_showUnseenOnly},
            onSelectionChanged: (selection) =>
                setState(() => _showUnseenOnly = selection.first),
          ),
          const SizedBox(height: 10),
          SegmentedButton<bool>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(
                value: false,
                label: Text('دوائر'),
                icon: Icon(Icons.radio_button_unchecked_rounded),
              ),
              ButtonSegment(
                value: true,
                label: Text('شبكة'),
                icon: Icon(Icons.grid_view_rounded),
              ),
            ],
            selected: {_showGrid},
            onSelectionChanged: (selection) =>
                setState(() => _showGrid = selection.first),
          ),
          const SizedBox(height: 12),
          if (_loading)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 30),
              child: Center(
                child: CircularProgressIndicator(color: colors.primary),
              ),
            )
          else if (_error != null)
            Card(
              clipBehavior: Clip.antiAlias,
              child: ListTile(
                leading: Icon(Icons.cloud_off_outlined, color: colors.error),
                title: Text(_error!),
                subtitle: TextButton.icon(
                  onPressed: () => unawaited(_refresh()),
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text('إعادة المحاولة'),
                ),
              ),
            )
          else if (visibleGroups.isEmpty)
            _StatusEmptyState(
              searching: query.isNotEmpty,
              unseenOnly: _showUnseenOnly,
            )
          else
            _showGrid
                ? GridView.builder(
                    shrinkWrap: true,
                    primary: false,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: visibleGroups.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.sizeOf(context).width >= 600
                          ? 3
                          : 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: .78,
                    ),
                    itemBuilder: (context, index) {
                      final group = visibleGroups[index];
                      return _StatusGridCard(
                        status: group.statuses.first,
                        count: group.statuses.length,
                        unseen: group.hasUnseen,
                        service: _service,
                        onTap: () => unawaited(_openStatuses(group.statuses)),
                      );
                    },
                  )
                : SizedBox(
                    height: 106,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      itemCount: visibleGroups.length,
                      separatorBuilder: (_, _) => const SizedBox(width: 5),
                      itemBuilder: (context, index) {
                        final group = visibleGroups[index];
                        final latest = group.statuses.first;
                        return _StatusHighlightTile(
                          label: latest.authorLabel,
                          userId: latest.userId,
                          imageUrl: avatarPublicUrl(_client, latest.avatarPath),
                          unseen: group.hasUnseen,
                          onTap: () => unawaited(_openStatuses(group.statuses)),
                        );
                      },
                    ),
                  ),
        ],
      ),
    );
  }
}

class _MyStatusTile extends StatelessWidget {
  const _MyStatusTile({
    required this.statuses,
    required this.onTap,
    required this.onAdd,
  });

  final List<StatusItem> statuses;
  final VoidCallback onTap;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    final name = user?.userMetadata?['display_name']?.toString() ?? 'أنت';
    final avatarPath = user?.userMetadata?['avatar_path']?.toString();
    final avatarUrl = avatarPublicUrl(Supabase.instance.client, avatarPath);
    final colors = Theme.of(context).colorScheme;
    final label = statuses.isEmpty
        ? 'أضف حالة نصية أو صورة أو فيديو'
        : '${statuses.length} حالة · ${statuses.fold<int>(0, (sum, s) => sum + s.viewsCount)} مشاهدة';

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(14, 13, 10, 13),
          child: Row(
            children: [
              _StatusAvatar(
                label: name,
                imageUrl: avatarUrl,
                hasStory: statuses.isNotEmpty,
                unseen: false,
                radius: 27,
                addButton: true,
                onAdd: onAdd,
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall
                          ?.copyWith(color: colors.onSurfaceVariant),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              FilledButton.tonalIcon(
                onPressed: onAdd,
                icon: Icon(
                  statuses.isEmpty
                      ? Icons.add_rounded
                      : Icons.add_circle_outline_rounded,
                  size: 18,
                ),
                label: Text(statuses.isEmpty ? 'أضف' : 'جديدة'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusEmptyState extends StatelessWidget {
  const _StatusEmptyState({required this.searching, required this.unseenOnly});

  final bool searching;
  final bool unseenOnly;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final title = searching
        ? 'لا توجد نتائج مطابقة'
        : unseenOnly
        ? 'أنت على اطلاع بكل جديد'
        : 'مساحتك للحظات الأصدقاء';
    final subtitle = searching
        ? 'جرّب اسمًا آخر أو امسح عبارة البحث.'
        : unseenOnly
        ? 'شاهدت كل الحالات المتاحة حاليًا.'
        : 'ستظهر هنا الحالات التي يشاركها أصدقاؤك خلال اليوم.';
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 26),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .7)),
      ),
      child: Column(
        children: [
          Container(
            width: 66,
            height: 66,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [
                  colors.primary.withValues(alpha: .18),
                  colors.tertiary.withValues(alpha: .10),
                ],
              ),
            ),
            child: Icon(
              searching
                  ? Icons.search_off_rounded
                  : unseenOnly
                  ? Icons.done_all_rounded
                  : Icons.auto_awesome_rounded,
              color: colors.primary,
              size: 29,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            title,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 5),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall
                ?.copyWith(color: colors.onSurfaceVariant, height: 1.45),
          ),
        ],
      ),
    );
  }
}

class _StatusGridCard extends StatefulWidget {
  const _StatusGridCard({
    required this.status,
    required this.count,
    required this.unseen,
    required this.service,
    required this.onTap,
  });

  final StatusItem status;
  final int count;
  final bool unseen;
  final StatusService service;
  final VoidCallback onTap;

  @override
  State<_StatusGridCard> createState() => _StatusGridCardState();
}

class _StatusGridCardState extends State<_StatusGridCard> {
  String? _imageUrl;

  @override
  void initState() {
    super.initState();
    _loadImagePreview();
  }

  @override
  void didUpdateWidget(covariant _StatusGridCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.status.id != widget.status.id ||
        oldWidget.status.mediaPath != widget.status.mediaPath) {
      _imageUrl = null;
      _loadImagePreview();
    }
  }

  Future<void> _loadImagePreview() async {
    final status = widget.status;
    final path = status.mediaPath;
    if (status.contentType != 'image' || path == null || path.isEmpty) return;
    try {
      final url = await widget.service.signedMediaUrl(path);
      if (mounted) setState(() => _imageUrl = url);
    } catch (_) {
      // Keep the rich color/author preview when a private thumbnail is offline.
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final status = widget.status;
    final avatar = avatarPublicUrl(Supabase.instance.client, status.avatarPath);
    final fallback = Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: AlignmentDirectional.topStart,
          end: AlignmentDirectional.bottomEnd,
          colors: [
            Color(status.backgroundColor),
            Color.lerp(Color(status.backgroundColor), Colors.black, .52)!,
          ],
        ),
      ),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(18),
      child: status.contentType == 'text'
          ? Text(
              status.body ?? '',
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                height: 1.4,
                fontWeight: FontWeight.w700,
              ),
            )
          : Icon(
              status.contentType == 'video'
                  ? Icons.play_circle_outline_rounded
                  : Icons.photo_outlined,
              color: Colors.white.withValues(alpha: .86),
              size: 44,
            ),
    );

    return Semantics(
      button: true,
      label: 'حالة ${status.authorLabel}',
      child: Material(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(23),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: widget.onTap,
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_imageUrl != null)
                Image.network(
                  _imageUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => fallback,
                )
              else
                fallback,
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black12,
                      Colors.transparent,
                      Colors.black87,
                    ],
                    stops: [0, .34, 1],
                  ),
                ),
              ),
              PositionedDirectional(
                top: 12,
                start: 11,
                end: 11,
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: widget.unseen
                              ? [colors.primary, colors.tertiary]
                              : [Colors.white70, Colors.white24],
                        ),
                      ),
                      child: CircleAvatar(
                        radius: 17,
                        backgroundColor: colors.surface,
                        foregroundImage: avatar == null
                            ? null
                            : NetworkImage(avatar),
                        child: avatar == null
                            ? Text(
                                status.authorLabel.isEmpty
                                    ? 'و'
                                    : String.fromCharCode(
                                        status.authorLabel.runes.first,
                                      ),
                                style: TextStyle(
                                  color: colors.onSurface,
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                            : null,
                      ),
                    ),
                    const Spacer(),
                    if (widget.count > 1)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 9,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .34),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${widget.count}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 11,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              PositionedDirectional(
                bottom: 13,
                start: 13,
                end: 13,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AdminIdentityText(
                      userId: status.userId,
                      label: status.authorLabel,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 8)],
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      _timeAgo(status.createdAt),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusAvatar extends StatelessWidget {
  const _StatusAvatar({
    required this.label,
    required this.imageUrl,
    required this.hasStory,
    required this.unseen,
    required this.radius,
    this.addButton = false,
    this.onAdd,
  });

  final String label;
  final String? imageUrl;
  final bool hasStory;
  final bool unseen;
  final double radius;
  final bool addButton;
  final VoidCallback? onAdd;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: hasStory
                ? LinearGradient(
                    colors: unseen
                        ? [theme.colorScheme.primary, const Color(0xFF36B783)]
                        : [
                            theme.colorScheme.outlineVariant,
                            theme.colorScheme.outlineVariant,
                          ],
                  )
                : null,
          ),
          child: CircleAvatar(
            radius: radius,
            backgroundColor: theme.colorScheme.primaryContainer,
            foregroundImage: imageUrl == null ? null : NetworkImage(imageUrl!),
            child: imageUrl == null
                ? Text(
                    label.isEmpty
                        ? 'و'
                        : String.fromCharCode(label.runes.first),
                    style: TextStyle(
                      color: theme.colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.w800,
                    ),
                  )
                : null,
          ),
        ),
        if (addButton)
          PositionedDirectional(
            end: -2,
            bottom: -1,
            child: GestureDetector(
              onTap: onAdd,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  shape: BoxShape.circle,
                ),
                child: CircleAvatar(
                  radius: 10,
                  backgroundColor: theme.colorScheme.primary,
                  child: const Icon(Icons.add, size: 15, color: Colors.white),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class StatusComposerScreen extends StatefulWidget {
  const StatusComposerScreen({super.key});

  @override
  State<StatusComposerScreen> createState() => _StatusComposerScreenState();
}

class _StatusComposerScreenState extends State<StatusComposerScreen> {
  final _body = TextEditingController();
  final _picker = ImagePicker();
  late final StatusService _service = StatusService(Supabase.instance.client);
  List<Friend> _friends = const [];
  final Set<String> _audience = {};
  XFile? _media;
  String _contentType = 'text';
  String _privacy = 'friends';
  int _backgroundColor = _statusColors.first;
  bool _loadingFriends = true;
  bool _publishing = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    unawaited(_loadFriends());
  }

  @override
  void dispose() {
    _body.dispose();
    super.dispose();
  }

  Future<void> _loadFriends() async {
    try {
      final friends = await _service.loadFriends();
      if (mounted) setState(() => _friends = friends);
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر تحميل قائمة الأصدقاء.');
    } finally {
      if (mounted) setState(() => _loadingFriends = false);
    }
  }

  Future<void> _pickImage() async {
    try {
      final file = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 84,
        maxWidth: 1600,
      );
      if (file != null && mounted) {
        setState(() {
          _media = file;
          _contentType = 'image';
          _error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'تعذر اختيار الصورة. تحقق من إذن الصور.');
      }
    }
  }

  Future<void> _pickVideo() async {
    try {
      final file = await _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(seconds: 30),
      );
      if (file != null && mounted) {
        setState(() {
          _media = file;
          _contentType = 'video';
          _error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'تعذر اختيار الفيديو. تحقق من إذن الصور.');
      }
    }
  }

  Future<void> _openPreview() async {
    final text = _body.text.trim();
    if (_media == null && text.isEmpty) {
      setState(() => _error = 'اكتب نص الحالة أو أضف صورة أو فيديو.');
      return;
    }
    if (_privacy == 'selected' && _audience.isEmpty) {
      setState(() => _error = 'اختر صديقًا واحدًا على الأقل لمشاهدة الحالة.');
      return;
    }

    final published = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => StatusDraftPreviewScreen(
          contentType: _contentType,
          body: text,
          media: _media,
          backgroundColor: _backgroundColor,
          privacyLabel: _privacy == 'selected'
              ? 'أصدقاء محددون (${_audience.length})'
              : 'كل الأصدقاء',
          onPublish: _publish,
        ),
      ),
    );
    if (published == true && mounted) Navigator.of(context).pop(true);
  }

  Future<String?> _publish() async {
    final text = _body.text.trim();
    setState(() {
      _publishing = true;
      _error = null;
    });
    try {
      Uint8List? bytes;
      String? contentType;
      if (_media != null) {
        bytes = await _media!.readAsBytes();
        if (bytes.length > 50 * 1024 * 1024) {
          throw const _StatusInputException('حجم الملف أكبر من ٥٠ ميغابايت.');
        }
        contentType =
            _media!.mimeType ?? _mimeTypeFor(_media!.name, _contentType);
      }
      await _service.publish(
        contentType: _contentType,
        body: text.isEmpty ? null : text,
        mediaBytes: bytes,
        fileName: _media?.name,
        mediaContentType: contentType,
        privacy: _privacy,
        audienceUserIds: _audience.toList(growable: false),
        backgroundColor: _backgroundColor,
      );
      return null;
    } on _StatusInputException catch (e) {
      if (mounted) setState(() => _error = e.message);
      return e.message;
    } catch (_) {
      const message = 'تعذر نشر الحالة. تحقق من الاتصال وإعدادات الخادم.';
      if (mounted) {
        setState(() => _error = message);
      }
      return message;
    } finally {
      if (mounted) setState(() => _publishing = false);
    }
  }

  String _mimeTypeFor(String name, String type) {
    final ext = name.toLowerCase().split('.').last;
    if (type == 'video') {
      return ext == 'mov'
          ? 'video/quicktime'
          : ext == 'webm'
          ? 'video/webm'
          : 'video/mp4';
    }
    return switch (ext) {
      'png' => 'image/png',
      'webp' => 'image/webp',
      'heic' || 'heif' => 'image/heic',
      _ => 'image/jpeg',
    };
  }

  @override
  Widget build(BuildContext context) {
    final isText = _media == null;
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('حالة جديدة'),
            Text(
              'اختر لحظتك وجمهورها قبل المشاركة',
              style: theme.textTheme.labelSmall?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 10),
            child: FilledButton.tonalIcon(
              onPressed: _publishing ? null : _openPreview,
              icon: const Icon(Icons.visibility_outlined),
              label: const Text('معاينة'),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          if (isText)
            AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              height: 232,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: AlignmentDirectional.topStart,
                  end: AlignmentDirectional.bottomEnd,
                  colors: [
                    Color(_backgroundColor),
                    Color.lerp(Color(_backgroundColor), Colors.black, .25)!,
                  ],
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Color(_backgroundColor).withValues(alpha: .18),
                    blurRadius: 18,
                    offset: const Offset(0, 7),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(18),
              child: TextField(
                controller: _body,
                maxLength: 500,
                autofocus: true,
                textAlign: TextAlign.center,
                textAlignVertical: TextAlignVertical.center,
                maxLines: null,
                expands: true,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 23,
                  height: 1.5,
                ),
                cursorColor: Colors.white,
                decoration: const InputDecoration(
                  counterStyle: TextStyle(color: Colors.white70),
                  hintText: 'اكتب ما تريد مشاركته…',
                  hintStyle: TextStyle(color: Colors.white70),
                  border: InputBorder.none,
                  filled: false,
                ),
              ),
            )
          else
            _MediaPreview(
              media: _media!,
              isVideo: _contentType == 'video',
              onRemove: () => setState(() {
                _media = null;
                _contentType = 'text';
              }),
            ),
          if (isText) ...[
            const SizedBox(height: 14),
            Text(
              'لون خلفية الحالة',
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 9),
            Wrap(
              spacing: 11,
              runSpacing: 8,
              children: [
                for (final color in _statusColors)
                  Semantics(
                    button: true,
                    selected: _backgroundColor == color,
                    label: 'اختيار لون الخلفية',
                    child: InkWell(
                      onTap: () => setState(() => _backgroundColor = color),
                      customBorder: const CircleBorder(),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _backgroundColor == color
                                ? theme.colorScheme.primary
                                : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: CircleAvatar(
                          radius: 17,
                          backgroundColor: Color(color),
                          child: _backgroundColor == color
                              ? const Icon(
                                  Icons.check_rounded,
                                  color: Colors.white,
                                  size: 18,
                                )
                              : null,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ] else ...[
            const SizedBox(height: 12),
            TextField(
              controller: _body,
              maxLength: 500,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'تعليق (اختياري)',
                hintText: 'أضف تعليقًا للصورة أو الفيديو',
                alignLabelWithHint: true,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _publishing ? null : _pickImage,
                  icon: const Icon(Icons.image_outlined),
                  label: const Text('إضافة صورة'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _publishing ? null : _pickVideo,
                  icon: const Icon(Icons.videocam_outlined),
                  label: const Text('فيديو · ٣٠ ث'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            'من يمكنه مشاهدة حالتك؟',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'لن يتغير جمهور الحالات التي نشرتها سابقًا.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 9),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                value: 'friends',
                label: Text('كل الأصدقاء'),
                icon: Icon(Icons.people_outline),
              ),
              ButtonSegment(
                value: 'selected',
                label: Text('أصدقاء محددون'),
                icon: Icon(Icons.person_outline),
              ),
            ],
            selected: {_privacy},
            onSelectionChanged: (selection) => setState(() {
              _privacy = selection.first;
              _error = null;
            }),
          ),
          if (_privacy == 'selected') ...[
            const SizedBox(height: 8),
            if (_loadingFriends)
              const LinearProgressIndicator()
            else if (_friends.isEmpty)
              const ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.info_outline),
                title: Text('لا يوجد أصدقاء مقبولون للاختيار.'),
              )
            else
              ..._friends.map(
                (friend) => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _audience.contains(friend.userId),
                  title: Text(friend.label),
                  subtitle: Text('@${friend.username}'),
                  onChanged: (selected) => setState(() {
                    if (selected == true) {
                      _audience.add(friend.userId);
                    } else {
                      _audience.remove(friend.userId);
                    }
                  }),
                ),
              ),
          ],
          const SizedBox(height: 10),
          const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.lock_clock_outlined),
            title: Text('خصوصية ومدة الحالة'),
            subtitle: Text(
              'الوسائط خاصة، وتُتاح للأصدقاء المحددين فقط، وتنتهي بعد ٢٤ ساعة.',
            ),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                _error!,
                style: TextStyle(color: theme.colorScheme.error),
              ),
            ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _publishing ? null : _openPreview,
            icon: const Icon(Icons.visibility_outlined),
            label: const Text('معاينة الحالة'),
          ),
        ],
      ),
    );
  }
}

class StatusDraftPreviewScreen extends StatefulWidget {
  const StatusDraftPreviewScreen({
    required this.contentType,
    required this.body,
    required this.media,
    required this.backgroundColor,
    required this.privacyLabel,
    required this.onPublish,
    this.imageProvider,
    super.key,
  });

  final String contentType;
  final String body;
  final XFile? media;
  final int backgroundColor;
  final String privacyLabel;
  final Future<String?> Function() onPublish;
  final ImageProvider? imageProvider;

  @override
  State<StatusDraftPreviewScreen> createState() =>
      _StatusDraftPreviewScreenState();
}

class _StatusDraftPreviewScreenState extends State<StatusDraftPreviewScreen> {
  bool _publishing = false;
  String? _error;

  Future<void> _publish() async {
    if (_publishing) return;
    setState(() {
      _publishing = true;
      _error = null;
    });
    final error = await widget.onPublish();
    if (!mounted) return;
    if (error == null) {
      Navigator.of(context).pop(true);
      return;
    }
    setState(() {
      _publishing = false;
      _error = error;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isText = widget.contentType == 'text';
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  if (isText)
                    DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: AlignmentDirectional.topStart,
                          end: AlignmentDirectional.bottomEnd,
                          colors: [
                            Color(widget.backgroundColor),
                            Color.lerp(
                              Color(widget.backgroundColor),
                              Colors.black,
                              .30,
                            )!,
                          ],
                        ),
                      ),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(28, 88, 28, 72),
                          child: Text(
                            widget.body,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              height: 1.45,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                    )
                  else if (widget.media != null &&
                      widget.contentType == 'video')
                    _DraftVideoPreview(media: widget.media!)
                  else if (widget.media != null)
                    ColoredBox(
                      color: Colors.black,
                      child: Center(
                        child: Image(
                          image:
                              widget.imageProvider ??
                              FileImage(File(widget.media!.path)),
                          fit: BoxFit.contain,
                          errorBuilder: (_, _, _) => const Text(
                            'تعذر عرض الصورة',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    )
                  else
                    const ColoredBox(color: Colors.black),
                  PositionedDirectional(
                    top: 8,
                    start: 8,
                    end: 8,
                    child: Container(
                      padding: const EdgeInsetsDirectional.fromSTEB(
                        7,
                        5,
                        14,
                        5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: .34),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .17),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton.filledTonal(
                            tooltip: 'العودة للتعديل',
                            onPressed: _publishing
                                ? null
                                : () => Navigator.of(context).pop(false),
                            icon: const Icon(Icons.arrow_back_rounded),
                          ),
                          const SizedBox(width: 9),
                          const Text(
                            'معاينة قبل النشر',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              shadows: [Shadow(blurRadius: 8)],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (!isText && widget.body.isNotEmpty)
                    PositionedDirectional(
                      start: 0,
                      end: 0,
                      bottom: 0,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(alpha: .82),
                            ],
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                            18,
                            14,
                            18,
                            18,
                          ),
                          child: Text(
                            widget.body,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              height: 1.4,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(16, 12, 16, 2),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 11,
                ),
                decoration: BoxDecoration(
                  color: colors.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: colors.outlineVariant),
                ),
                child: Row(
                  children: [
                    Icon(Icons.lock_outline, size: 18, color: colors.primary),
                    const SizedBox(width: 8),
                    Expanded(child: Text(widget.privacyLabel)),
                    const Icon(Icons.schedule_outlined, size: 17),
                    const SizedBox(width: 5),
                    const Text('٢٤ ساعة'),
                  ],
                ),
              ),
            ),
            if (_error != null)
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(16, 6, 16, 0),
                child: Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: colors.error),
                ),
              ),
            Padding(
              padding: const EdgeInsetsDirectional.fromSTEB(16, 10, 16, 12),
              child: Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: _publishing
                        ? null
                        : () => Navigator.of(context).pop(false),
                    icon: const Icon(Icons.edit_outlined),
                    label: const Text('تعديل'),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _publishing ? null : _publish,
                      icon: _publishing
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.send_outlined),
                      label: Text(_publishing ? 'جارٍ النشر…' : 'نشر الحالة'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DraftVideoPreview extends StatefulWidget {
  const _DraftVideoPreview({required this.media});

  final XFile media;

  @override
  State<_DraftVideoPreview> createState() => _DraftVideoPreviewState();
}

class _DraftVideoPreviewState extends State<_DraftVideoPreview> {
  late final VideoPlayerController _controller = VideoPlayerController.file(
    File(widget.media.path),
  );
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    try {
      await _controller.initialize();
      await _controller.setLooping(true);
      await _controller.setVolume(0);
      await _controller.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    unawaited(_controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.videocam_outlined, color: Colors.white, size: 56),
              SizedBox(height: 8),
              Text(
                'تعذر تشغيل معاينة الفيديو',
                style: TextStyle(color: Colors.white),
              ),
            ],
          ),
        ),
      );
    }
    if (!_controller.value.isInitialized) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator(color: Colors.white)),
      );
    }
    return ColoredBox(
      color: Colors.black,
      child: Center(
        child: AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: VideoPlayer(_controller),
        ),
      ),
    );
  }
}

class _MediaPreview extends StatelessWidget {
  const _MediaPreview({
    required this.media,
    required this.isVideo,
    required this.onRemove,
  });

  final XFile media;
  final bool isVideo;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          height: 270,
          width: double.infinity,
          child: isVideo
              ? Container(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  child: const Icon(Icons.play_circle_outline, size: 72),
                )
              : Image.file(File(media.path), fit: BoxFit.cover),
        ),
        PositionedDirectional(
          top: 8,
          end: 8,
          child: IconButton.filledTonal(
            tooltip: 'إزالة الوسيط',
            onPressed: onRemove,
            icon: const Icon(Icons.close),
          ),
        ),
        if (isVideo)
          Positioned(
            bottom: 8,
            left: 12,
            right: 12,
            child: Text(
              media.name,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                backgroundColor: Colors.black54,
              ),
            ),
          ),
      ],
    ),
  );
}

class StatusViewerScreen extends StatefulWidget {
  const StatusViewerScreen({
    required this.statuses,
    required this.service,
    super.key,
  });

  final List<StatusItem> statuses;
  final StatusService service;

  @override
  State<StatusViewerScreen> createState() => _StatusViewerScreenState();
}

class _StatusViewerScreenState extends State<StatusViewerScreen> {
  late final PageController _pages = PageController();
  final StatusMediaCache _mediaCache = StatusMediaCache();
  static const _stillStatusDuration = Duration(seconds: 7);
  int _index = 0;
  bool _deleting = false;
  bool _savingMedia = false;
  bool _sendingReply = false;
  final TextEditingController _replyController = TextEditingController();
  bool _paused = false;
  bool _advanceRequested = false;
  Timer? _playbackTimer;
  Duration _elapsed = Duration.zero;
  Duration _videoPosition = Duration.zero;
  Duration _videoDuration = Duration.zero;

  StatusItem get _current => widget.statuses[_index];

  @override
  void initState() {
    super.initState();
    _markViewed(widget.statuses.first);
    _startPlayback();
  }

  @override
  void dispose() {
    _playbackTimer?.cancel();
    _replyController.dispose();
    _pages.dispose();
    super.dispose();
  }

  void _startPlayback() {
    _playbackTimer?.cancel();
    _elapsed = Duration.zero;
    _videoPosition = Duration.zero;
    _videoDuration = Duration.zero;
    _advanceRequested = false;
    if (_current.contentType == 'video') return;

    _playbackTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (!mounted || _paused) return;
      _elapsed += const Duration(milliseconds: 100);
      if (_elapsed >= _stillStatusDuration) {
        _elapsed = _stillStatusDuration;
        setState(() {});
        timer.cancel();
        _advanceAutomatically();
      } else {
        setState(() {});
      }
    });
  }

  void _advanceAutomatically() {
    if (_advanceRequested || !mounted) return;
    _advanceRequested = true;
    if (_index < widget.statuses.length - 1) {
      unawaited(
        _pages.nextPage(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        ),
      );
    } else {
      Navigator.of(context).pop();
    }
  }

  void _setPaused(bool paused) {
    if (!mounted || paused == _paused) return;
    setState(() => _paused = paused);
  }

  void _handleViewerTap(TapUpDetails details) {
    final width = MediaQuery.sizeOf(context).width;
    final direction = Directionality.of(context);
    if (details.localPosition.dx < width * .34) {
      direction == TextDirection.rtl ? _goToNext() : _goToPrevious();
    } else if (details.localPosition.dx > width * .66) {
      direction == TextDirection.rtl ? _goToPrevious() : _goToNext();
    } else {
      _setPaused(!_paused);
    }
  }

  void _goToPrevious() {
    if (_index == 0 || !_pages.hasClients) return;
    unawaited(
      _pages.previousPage(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
      ),
    );
  }

  void _goToNext() {
    if (_index >= widget.statuses.length - 1) {
      Navigator.of(context).maybePop();
      return;
    }
    if (!_pages.hasClients) return;
    unawaited(
      _pages.nextPage(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
      ),
    );
  }

  void _onVideoProgress(int index, Duration position, Duration duration) {
    if (!mounted || index != _index) return;
    final decisecond = position.inMilliseconds ~/ 100;
    if (decisecond == _videoPosition.inMilliseconds ~/ 100 &&
        duration == _videoDuration) {
      return;
    }
    setState(() {
      _videoPosition = position;
      _videoDuration = duration;
    });
  }

  void _onVideoCompleted(int index) {
    if (index == _index) _advanceAutomatically();
  }

  double? get _currentProgress {
    if (_current.contentType == 'video') {
      if (_videoDuration <= Duration.zero) return null;
      return (_videoPosition.inMilliseconds / _videoDuration.inMilliseconds)
          .clamp(0.0, 1.0)
          .toDouble();
    }
    return (_elapsed.inMilliseconds / _stillStatusDuration.inMilliseconds)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  void _markViewed(StatusItem status) {
    if (!status.isMine && widget.service.client.auth.currentUser != null) {
      unawaited(widget.service.markViewed(status.id).catchError((_) => false));
    }
  }

  Future<void> _showViewers() async {
    final status = _current;
    if (!status.isMine) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: 420,
          child: FutureBuilder<List<StatusViewer>>(
            future: widget.service.loadViewers(status.id),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return const Center(child: Text('تعذر تحميل قائمة المشاهدين.'));
              }
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final viewers = snapshot.data!;
              if (viewers.isEmpty) {
                return const Center(
                  child: Text('لم يشاهد أحد هذه الحالة بعد.'),
                );
              }
              return ListView(
                children: [
                  ListTile(
                    title: const Text(
                      'مشاهدات الحالة',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text('${viewers.length} مشاهدة'),
                  ),
                  ...viewers.map(
                    (viewer) => ListTile(
                      leading: CircleAvatar(
                        child: Text(
                          viewer.label.isEmpty
                              ? 'و'
                              : String.fromCharCode(viewer.label.runes.first),
                        ),
                      ),
                      title: Text(viewer.label),
                      subtitle: Text(
                        '@${viewer.username} · ${_timeAgo(viewer.viewedAt)}',
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _showReplies() async {
    final status = _current;
    final wasPaused = _paused;
    _setPaused(true);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) =>
          _StatusRepliesSheet(status: status, service: widget.service),
    );
    if (mounted) _setPaused(wasPaused);
  }

  Future<void> _sendReply() async {
    final text = _replyController.text.trim();
    if (text.isEmpty || text.length > 1000 || _sendingReply) return;
    final status = _current;
    setState(() => _sendingReply = true);
    _setPaused(true);
    try {
      await widget.service.sendReply(statusId: status.id, body: text);
      _replyController.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أُرسل ردك الخاص إلى صاحب الحالة.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر إرسال الرد. حاول مرة أخرى.')),
        );
      }
    } finally {
      if (mounted) setState(() => _sendingReply = false);
    }
  }

  Future<void> _deleteCurrent() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الحالة؟'),
        content: const Text('سيتم حذف الحالة نهائيًا من حسابك.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;
    setState(() => _deleting = true);
    try {
      await widget.service.delete(_current);
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حذف الحالة. حاول مرة أخرى.')),
        );
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  Future<void> _saveCurrentMedia() async {
    final status = _current;
    final path = status.mediaPath;
    if (path == null || path.isEmpty || _savingMedia) return;

    if (!status.isMine) {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('حفظ نسخة من الحالة؟'),
          content: const Text(
            'ستُحفظ نسخة على هاتفك وقد تبقى بعد انتهاء الحالة تلقائيًا خلال 24 ساعة. لا يرسل وصال إشعارًا لصاحب الحالة عند الحفظ.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حفظ'),
            ),
          ],
        ),
      );
      if (confirm != true || !mounted) return;
    }

    setState(() => _savingMedia = true);
    try {
      final accountId = widget.service.client.auth.currentUser?.id;
      if (accountId == null) {
        throw const AuthException('Authentication required');
      }
      final file = await _mediaCache.fileFor(
        accountId: accountId,
        statusId: status.id,
        storagePath: path,
        expiresAt: status.expiresAt,
        download: () => widget.service.downloadMedia(path),
      );
      final fileName = path.replaceAll('\\', '/').split('/').last;
      final location = await DeviceMediaSaver().saveLocalFile(
        filePath: file.path,
        fileName: fileName,
        mimeType: mediaMimeTypeForFileName(fileName),
      );
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('تم حفظ الحالة في $location')));
      }
    } on DeviceMediaSaveException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حفظ الحالة. حاول مرة أخرى.')),
        );
      }
    } finally {
      if (mounted) setState(() => _savingMedia = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = _current;
    final avatarUrl = avatarPublicUrl(
      Supabase.instance.client,
      current.avatarPath,
    );
    return Scaffold(
      backgroundColor: const Color(0xFF101413),
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            PageView.builder(
              controller: _pages,
              itemCount: widget.statuses.length,
              onPageChanged: (index) {
                _replyController.clear();
                setState(() {
                  _index = index;
                  _paused = false;
                });
                _startPlayback();
                _markViewed(widget.statuses[index]);
              },
              itemBuilder: (context, index) => GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapUp: _handleViewerTap,
                onLongPressStart: (_) => _setPaused(true),
                onLongPressEnd: (_) => _setPaused(false),
                child: _StatusFrame(
                  status: widget.statuses[index],
                  service: widget.service,
                  mediaCache: _mediaCache,
                  accountId: widget.service.client.auth.currentUser?.id,
                  isActive: index == _index,
                  isPaused: _paused,
                  onVideoProgress: (position, duration) =>
                      _onVideoProgress(index, position, duration),
                  onVideoCompleted: () => _onVideoCompleted(index),
                ),
              ),
            ),
            Positioned.fill(
              child: IgnorePointer(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: .48),
                        Colors.transparent,
                        Colors.transparent,
                        Colors.black.withValues(alpha: .28),
                      ],
                      stops: const [0, .28, .72, 1],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 8,
              left: 12,
              right: 12,
              child: Column(
                children: [
                  Row(
                    children: [
                      for (var i = 0; i < widget.statuses.length; i++) ...[
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: LinearProgressIndicator(
                              value: i < _index
                                  ? 1
                                  : i == _index
                                  ? _currentProgress
                                  : 0,
                              minHeight: 3.5,
                              backgroundColor: Colors.white38,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        if (i < widget.statuses.length - 1)
                          const SizedBox(width: 4),
                      ],
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsetsDirectional.fromSTEB(7, 5, 6, 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .30),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: .12),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(2),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [Color(0xFF55D6A4), Color(0xFF56A4E8)],
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 19,
                            foregroundImage: avatarUrl == null
                                ? null
                                : NetworkImage(avatarUrl),
                            backgroundColor: const Color(0xFF27312E),
                            child: avatarUrl == null
                                ? Text(
                                    current.authorLabel.isEmpty
                                        ? 'و'
                                        : String.fromCharCode(
                                            current.authorLabel.runes.first,
                                          ),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                : null,
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AdminIdentityText(
                                userId: current.isMine ? null : current.userId,
                                label: current.isMine
                                    ? 'حالتي'
                                    : current.authorLabel,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              Text(
                                _timeAgo(current.createdAt),
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          tooltip: _paused ? 'استئناف العرض' : 'إيقاف العرض',
                          onPressed: () => _setPaused(!_paused),
                          icon: Icon(
                            _paused
                                ? Icons.play_arrow_rounded
                                : Icons.pause_rounded,
                            color: Colors.white,
                          ),
                        ),
                        if (current.isMine)
                          IconButton(
                            tooltip: 'الردود الخاصة',
                            onPressed: () => unawaited(_showReplies()),
                            icon: const Icon(
                              Icons.mark_chat_unread_outlined,
                              color: Colors.white,
                            ),
                          ),
                        PopupMenuButton<String>(
                          tooltip: 'خيارات الحالة',
                          icon: const Icon(
                            Icons.more_horiz_rounded,
                            color: Colors.white,
                          ),
                          onSelected: (action) {
                            if (action == 'viewers') {
                              unawaited(_showViewers());
                            } else if (action == 'save') {
                              unawaited(_saveCurrentMedia());
                            } else if (action == 'delete') {
                              unawaited(_deleteCurrent());
                            }
                          },
                          itemBuilder: (context) => [
                            if (current.isMine)
                              const PopupMenuItem(
                                value: 'viewers',
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(Icons.visibility_outlined),
                                  title: Text('المشاهدات'),
                                ),
                              ),
                            if (current.mediaPath != null)
                              PopupMenuItem(
                                value: 'save',
                                enabled: !_savingMedia,
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: const Icon(
                                    Icons.download_for_offline_outlined,
                                  ),
                                  title: Text(
                                    _savingMedia
                                        ? 'جارٍ الحفظ…'
                                        : 'حفظ في الهاتف',
                                  ),
                                ),
                              ),
                            if (current.isMine)
                              PopupMenuItem(
                                value: 'delete',
                                enabled: !_deleting,
                                child: ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(
                                    Icons.delete_outline,
                                    color: Theme.of(context).colorScheme.error,
                                  ),
                                  title: Text(
                                    'حذف الحالة',
                                    style: TextStyle(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .error,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                        IconButton(
                          tooltip: 'إغلاق',
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(Icons.close, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            if (!current.isMine)
              PositionedDirectional(
                bottom: widget.statuses.length > 1 ? 76 : 16,
                start: 14,
                end: 14,
                child: Container(
                  padding: const EdgeInsetsDirectional.fromSTEB(8, 5, 8, 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .58),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: .18),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'ردودي الخاصة',
                            onPressed: () => unawaited(_showReplies()),
                            color: Colors.white,
                            icon: const Icon(Icons.forum_outlined),
                          ),
                          Expanded(
                            child: TextField(
                              controller: _replyController,
                              maxLength: 1000,
                              maxLines: 1,
                              textInputAction: TextInputAction.send,
                              style: const TextStyle(color: Colors.white),
                              cursorColor: Colors.white,
                              decoration: const InputDecoration(
                                hintText: 'اكتب ردًا خاصًا على الحالة…',
                                hintStyle: TextStyle(color: Colors.white70),
                                counterText: '',
                                border: InputBorder.none,
                                isDense: true,
                              ),
                              onTap: () => _setPaused(true),
                              onSubmitted: (_) => unawaited(_sendReply()),
                            ),
                          ),
                          IconButton(
                            tooltip: 'إرسال رد خاص',
                            onPressed: _sendingReply
                                ? null
                                : () => unawaited(_sendReply()),
                            color: Colors.white,
                            icon: _sendingReply
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : const Icon(Icons.send_rounded),
                          ),
                        ],
                      ),
                      const Padding(
                        padding: EdgeInsetsDirectional.only(
                          start: 8,
                          end: 8,
                          bottom: 3,
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.lock_outline,
                              color: Colors.white70,
                              size: 13,
                            ),
                            SizedBox(width: 5),
                            Text(
                              'لا يراه إلا أنت وصاحب الحالة',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (widget.statuses.length > 1)
              PositionedDirectional(
                bottom: 16,
                start: 14,
                end: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .32),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: .12),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton.filledTonal(
                        onPressed: _index > 0
                            ? () => _pages.previousPage(
                                duration: const Duration(milliseconds: 180),
                                curve: Curves.easeOut,
                              )
                            : null,
                        icon: const Icon(Icons.chevron_right),
                      ),
                      Text(
                        '${_index + 1} / ${widget.statuses.length}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      IconButton.filledTonal(
                        onPressed: _index < widget.statuses.length - 1
                            ? () => _pages.nextPage(
                                duration: const Duration(milliseconds: 180),
                                curve: Curves.easeOut,
                              )
                            : null,
                        icon: const Icon(Icons.chevron_left),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _StatusRepliesSheet extends StatefulWidget {
  const _StatusRepliesSheet({required this.status, required this.service});

  final StatusItem status;
  final StatusService service;

  @override
  State<_StatusRepliesSheet> createState() => _StatusRepliesSheetState();
}

class _StatusRepliesSheetState extends State<_StatusRepliesSheet> {
  List<StatusReply> _replies = const [];
  bool _loading = true;
  String? _error;
  int _requestId = 0;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    final client = widget.service.client;
    if (client.auth.currentUser != null) {
      _channel = client
          .channel(
            'wasla-private-status-replies-${widget.status.id}-'
            '${DateTime.now().microsecondsSinceEpoch}',
          )
          .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'status_replies',
            filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'status_id',
              value: widget.status.id,
            ),
            callback: (_) => unawaited(_refresh()),
          )
          .subscribe();
    }
    unawaited(_refresh());
  }

  @override
  void dispose() {
    final channel = _channel;
    if (channel != null) {
      unawaited(widget.service.client.removeChannel(channel));
    }
    super.dispose();
  }

  Future<void> _refresh() async {
    final requestId = ++_requestId;
    try {
      final replies = await widget.service.loadReplies(widget.status.id);
      if (mounted && requestId == _requestId) {
        setState(() {
          _replies = replies;
          _loading = false;
          _error = null;
        });
      }
    } catch (_) {
      if (mounted && requestId == _requestId) {
        setState(() {
          _loading = false;
          _error = 'تعذر تحميل الردود الخاصة. تحقق من الاتصال ثم أعد المحاولة.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final height = (MediaQuery.sizeOf(context).height * .68)
        .clamp(320.0, 560.0)
        .toDouble();
    return SafeArea(
      top: false,
      child: SizedBox(
        height: height,
        child: Column(
          children: [
            ListTile(
              leading: const Icon(Icons.lock_outline),
              title: const Text(
                'الردود الخاصة',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                widget.status.isMine
                    ? 'كل رد يراه كاتبه وصاحب هذه الحالة فقط.'
                    : 'لا تظهر ردودك إلا لك ولصاحب الحالة.',
              ),
              trailing: IconButton(
                tooltip: 'تحديث الردود',
                onPressed: () => unawaited(_refresh()),
                icon: const Icon(Icons.refresh_rounded),
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(_error!, textAlign: TextAlign.center),
                      ),
                    )
                  : _replies.isEmpty
                  ? Center(
                      child: Text(
                        widget.status.isMine
                            ? 'لا توجد ردود على هذه الحالة بعد.'
                            : 'لم ترسل ردًا على هذه الحالة بعد.',
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: _replies.length,
                      separatorBuilder: (_, _) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final reply = _replies[index];
                        final label = widget.status.isMine
                            ? reply.senderLabel
                            : 'ردك الخاص';
                        return ListTile(
                          leading: CircleAvatar(
                            child: Text(
                              label.isEmpty
                                  ? 'و'
                                  : String.fromCharCode(label.runes.first),
                            ),
                          ),
                          title: AdminIdentityText(
                            userId: widget.status.isMine
                                ? reply.senderId
                                : null,
                            label: label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(reply.body),
                          trailing: Text(
                            _timeAgo(reply.createdAt),
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusFrame extends StatefulWidget {
  const _StatusFrame({
    required this.status,
    required this.service,
    required this.mediaCache,
    required this.accountId,
    required this.isActive,
    required this.isPaused,
    required this.onVideoProgress,
    required this.onVideoCompleted,
  });

  final StatusItem status;
  final StatusService service;
  final StatusMediaCache mediaCache;
  final String? accountId;
  final bool isActive;
  final bool isPaused;
  final void Function(Duration position, Duration duration) onVideoProgress;
  final VoidCallback onVideoCompleted;

  @override
  State<_StatusFrame> createState() => _StatusFrameState();
}

class _StatusFrameState extends State<_StatusFrame> {
  Future<File>? _mediaFile;
  Timer? _expiryTimer;
  bool _expired = false;

  @override
  void initState() {
    super.initState();
    _scheduleExpiry();
    _loadIfActive();
  }

  @override
  void didUpdateWidget(covariant _StatusFrame oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.status.id != oldWidget.status.id ||
        widget.status.mediaPath != oldWidget.status.mediaPath ||
        widget.accountId != oldWidget.accountId ||
        widget.status.expiresAt != oldWidget.status.expiresAt) {
      _expiryTimer?.cancel();
      _expired = false;
      _scheduleExpiry();
      _mediaFile = null;
      _loadIfActive();
    } else if (!oldWidget.isActive && widget.isActive) {
      _loadIfActive();
    }
  }

  void _scheduleExpiry() {
    final remaining = widget.status.expiresAt.difference(DateTime.now());
    if (remaining <= Duration.zero) {
      _expired = true;
      _removeExpiredFile();
      return;
    }
    _expiryTimer = Timer(remaining, () {
      if (!mounted) return;
      setState(() => _expired = true);
      _removeExpiredFile();
    });
  }

  void _removeExpiredFile() {
    final accountId = widget.accountId;
    if (accountId == null || widget.status.mediaPath == null) return;
    unawaited(
      widget.mediaCache.removeStatus(
        accountId: accountId,
        statusId: widget.status.id,
      ),
    );
  }

  @override
  void dispose() {
    _expiryTimer?.cancel();
    super.dispose();
  }

  void _loadIfActive() {
    final path = widget.status.mediaPath;
    final accountId = widget.accountId;
    if (!widget.isActive || path == null || path.isEmpty || accountId == null) {
      return;
    }
    _mediaFile = widget.mediaCache.fileFor(
      accountId: accountId,
      statusId: widget.status.id,
      storagePath: path,
      expiresAt: widget.status.expiresAt,
      download: () => widget.service.downloadMedia(path),
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = widget.status;
    if (_expired) {
      return const Center(
        child: Text(
          'انتهت صلاحية الحالة',
          style: TextStyle(color: Colors.white70),
        ),
      );
    }
    if (status.contentType == 'text') {
      return Container(
        color: Color(status.backgroundColor),
        alignment: Alignment.center,
        padding: const EdgeInsets.fromLTRB(32, 100, 32, 80),
        child: Text(
          status.body ?? '',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 30,
            height: 1.45,
            fontWeight: FontWeight.w800,
          ),
        ),
      );
    }
    final path = status.mediaPath;
    if (path == null) {
      return const Center(
        child: Text('تعذر تحميل الحالة', style: TextStyle(color: Colors.white)),
      );
    }
    if (!widget.isActive) return const ColoredBox(color: Colors.black);
    final mediaFile = _mediaFile;
    if (mediaFile == null) {
      return const Center(
        child: Text('تعذر تحميل الحالة', style: TextStyle(color: Colors.white)),
      );
    }
    return FutureBuilder<File>(
      future: mediaFile,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(
            child: Text(
              'تعذر تحميل الوسائط',
              style: TextStyle(color: Colors.white),
            ),
          );
        }
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(color: Colors.white),
          );
        }
        if (status.contentType == 'video') {
          return _StatusVideo(
            file: snapshot.data!,
            isActive: widget.isActive,
            isPaused: widget.isPaused,
            onProgress: widget.onVideoProgress,
            onCompleted: widget.onVideoCompleted,
          );
        }
        return ColoredBox(
          color: Colors.black,
          child: Center(
            child: Image.file(
              snapshot.data!,
              fit: BoxFit.contain,
              errorBuilder: (_, _, _) => const Text(
                'تعذر عرض الصورة',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _StatusVideo extends StatefulWidget {
  const _StatusVideo({
    required this.file,
    required this.isActive,
    required this.isPaused,
    required this.onProgress,
    required this.onCompleted,
  });

  final File file;
  final bool isActive;
  final bool isPaused;
  final void Function(Duration position, Duration duration) onProgress;
  final VoidCallback onCompleted;

  @override
  State<_StatusVideo> createState() => _StatusVideoState();
}

class _StatusVideoState extends State<_StatusVideo> {
  late final VideoPlayerController _controller = VideoPlayerController.file(
    widget.file,
  );
  bool _failed = false;
  bool _completionReported = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _controller.initialize();
      await _controller.setLooping(false);
      _controller.addListener(_onPlayerChanged);
      await _syncPlayback();
      _onPlayerChanged();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void didUpdateWidget(covariant _StatusVideo oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive != oldWidget.isActive ||
        widget.isPaused != oldWidget.isPaused) {
      unawaited(_syncPlayback());
    }
  }

  Future<void> _syncPlayback() async {
    if (!_controller.value.isInitialized) return;
    if (!widget.isActive || widget.isPaused) {
      await _controller.pause();
    } else if (!_controller.value.isCompleted) {
      await _controller.play();
    }
  }

  void _onPlayerChanged() {
    final value = _controller.value;
    if (!value.isInitialized || !widget.isActive) return;
    widget.onProgress(value.position, value.duration);
    if (value.isCompleted && !_completionReported) {
      _completionReported = true;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && widget.isActive) widget.onCompleted();
      });
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onPlayerChanged);
    unawaited(_controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const Center(
        child: Text(
          'تعذر تشغيل الفيديو',
          style: TextStyle(color: Colors.white),
        ),
      );
    }
    if (!_controller.value.isInitialized) {
      return const Center(
        child: CircularProgressIndicator(color: Colors.white),
      );
    }
    return ColoredBox(
      color: Colors.black,
      child: Center(
        child: AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: VideoPlayer(_controller),
        ),
      ),
    );
  }
}

class _StatusInputException implements Exception {
  const _StatusInputException(this.message);
  final String message;
}

String _timeAgo(DateTime date) {
  final elapsed = DateTime.now().difference(date);
  if (elapsed.isNegative || elapsed.inMinutes < 1) return 'الآن';
  if (elapsed.inHours < 1) return 'قبل ${elapsed.inMinutes} د';
  if (elapsed.inHours < 24) return 'قبل ${elapsed.inHours} س';
  return 'قبل يوم';
}
