import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'presence.dart';

enum UserPresenceStatus {
  available(
    value: 'available',
    label: 'متواجد',
    color: Color(0xFF24A46D),
    description: 'متاح للدردشة والتواصل',
  ),
  working(
    value: 'working',
    label: 'في العمل',
    color: Color(0xFFE58A1F),
    description: 'مشغول بالعمل وقد يتأخر في الرد',
  ),
  busy(
    value: 'busy',
    label: 'مشغول',
    color: Color(0xFFD94B4B),
    description: 'لا يرغب بالإزعاج حاليًا',
  ),
  unavailable(
    value: 'unavailable',
    label: 'غير متوفر',
    color: Color(0xFF8A9692),
    description: 'غير متصل بالإنترنت',
  );

  const UserPresenceStatus({
    required this.value,
    required this.label,
    required this.color,
    required this.description,
  });

  final String value;
  final String label;
  final Color color;
  final String description;

  static const selectableStatuses = [
    UserPresenceStatus.available,
    UserPresenceStatus.working,
    UserPresenceStatus.busy,
  ];

  static UserPresenceStatus fromValue(Object? value) =>
      switch (value?.toString()) {
        'working' => UserPresenceStatus.working,
        'busy' => UserPresenceStatus.busy,
        'unavailable' => UserPresenceStatus.unavailable,
        _ => UserPresenceStatus.available,
      };
}

/// Shows an automatic offline status without replacing the user's selection.
UserPresenceStatus effectivePresenceStatus(
  UserPresenceStatus selected, {
  required bool online,
}) => online ? selected : UserPresenceStatus.unavailable;

/// Current user/friend statuses visible under the server's friend-only RLS policy.
final ValueNotifier<Map<String, UserPresenceStatus>> userPresenceStatuses =
    ValueNotifier<Map<String, UserPresenceStatus>>({});

void mergeUserPresenceStatuses(Map<String, UserPresenceStatus> updates) {
  if (updates.isEmpty) return;
  userPresenceStatuses.value = {...userPresenceStatuses.value, ...updates};
}

void replaceUserPresenceStatuses(Map<String, UserPresenceStatus> statuses) {
  userPresenceStatuses.value = Map.unmodifiable(statuses);
}

class UserPresenceService {
  const UserPresenceService(this.client);

  final SupabaseClient client;

  Future<UserPresenceStatus> loadMine(String userId) async {
    final row = await client
        .from('user_presence_statuses')
        .select('status')
        .eq('user_id', userId)
        .maybeSingle();
    return UserPresenceStatus.fromValue(row?['status']);
  }

  Future<Map<String, UserPresenceStatus>> loadForUsers(
    Iterable<String> userIds,
  ) async {
    final ids = userIds.where((id) => id.isNotEmpty).toSet().toList();
    if (ids.isEmpty) return const {};
    final rows = await client
        .from('user_presence_statuses')
        .select('user_id,status')
        .inFilter('user_id', ids);
    return {
      for (final row in rows)
        row['user_id'].toString(): UserPresenceStatus.fromValue(row['status']),
    };
  }

  Future<void> setMine(UserPresenceStatus status) async {
    await client.rpc(
      'set_my_presence_status',
      params: {'p_status': status.value},
    );
  }
}

class PresenceStatusDot extends StatelessWidget {
  const PresenceStatusDot({
    required this.status,
    this.userId,
    this.size = 11,
    this.borderColor = Colors.white,
    super.key,
  });

  final UserPresenceStatus status;
  final String? userId;
  final double size;
  final Color borderColor;

  @override
  Widget build(BuildContext context) {
    final id = userId;
    if (id == null) return _buildDot(status);
    return ValueListenableBuilder<Set<String>>(
      valueListenable: onlineUserIds,
      builder: (context, onlineIds, _) => _buildDot(
        effectivePresenceStatus(status, online: onlineIds.contains(id)),
      ),
    );
  }

  Widget _buildDot(UserPresenceStatus displayedStatus) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: displayedStatus.color,
      shape: BoxShape.circle,
      border: Border.all(color: borderColor, width: size >= 10 ? 2 : 1),
    ),
  );
}

class PresenceStatusLabel extends StatelessWidget {
  const PresenceStatusLabel({
    required this.status,
    this.userId,
    this.fontSize = 11,
    this.dotSize = 8,
    super.key,
  });

  final UserPresenceStatus status;
  final String? userId;
  final double fontSize;
  final double dotSize;

  @override
  Widget build(BuildContext context) {
    final id = userId;
    if (id == null) return _buildLabel(status);
    return ValueListenableBuilder<Set<String>>(
      valueListenable: onlineUserIds,
      builder: (context, onlineIds, _) => _buildLabel(
        effectivePresenceStatus(status, online: onlineIds.contains(id)),
      ),
    );
  }

  Widget _buildLabel(UserPresenceStatus displayedStatus) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      PresenceStatusDot(status: displayedStatus, size: dotSize),
      const SizedBox(width: 4),
      Text(
        displayedStatus.label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: displayedStatus.color,
          fontSize: fontSize,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  );
}
