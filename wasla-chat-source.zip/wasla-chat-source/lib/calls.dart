import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin_identity.dart';
import 'call_history_preferences.dart';
import 'chat_models.dart';
import 'incoming_call_ringtone.dart';
import 'outgoing_call_ringback.dart';
import 'push_notifications.dart';

SupabaseClient get _callDb => Supabase.instance.client;

const incomingCallTimeout = Duration(seconds: 90);

class CallRecord {
  const CallRecord({
    required this.id,
    required this.conversationId,
    required this.callerId,
    required this.calleeId,
    required this.mediaType,
    required this.status,
    required this.createdAt,
    this.answeredAt,
    this.endedAt,
    this.peerName = '',
    this.peerUsername = '',
    this.peerAvatarPath,
  });

  final String id;
  final String conversationId;
  final String callerId;
  final String calleeId;
  final String mediaType;
  final String status;
  final DateTime createdAt;
  final DateTime? answeredAt;
  final DateTime? endedAt;
  final String peerName;
  final String peerUsername;
  final String? peerAvatarPath;

  bool get isVideo => mediaType == 'video';
  bool get isActive => status == 'ringing' || status == 'accepted';

  CallRecord withPeer({
    required String name,
    required String username,
    String? avatarPath,
  }) => CallRecord(
    id: id,
    conversationId: conversationId,
    callerId: callerId,
    calleeId: calleeId,
    mediaType: mediaType,
    status: status,
    createdAt: createdAt,
    answeredAt: answeredAt,
    endedAt: endedAt,
    peerName: name,
    peerUsername: username,
    peerAvatarPath: avatarPath,
  );

  factory CallRecord.fromRow(
    Map<String, dynamic> row, {
    String peerName = '',
    String peerUsername = '',
    String? peerAvatarPath,
  }) => CallRecord(
    id: row['id'].toString(),
    conversationId: row['conversation_id'].toString(),
    callerId: row['caller_id'].toString(),
    calleeId: row['callee_id'].toString(),
    mediaType: row['media_type']?.toString() ?? 'audio',
    status: row['status']?.toString() ?? 'ringing',
    createdAt:
        DateTime.tryParse(row['created_at']?.toString() ?? '') ??
        DateTime.now(),
    answeredAt: DateTime.tryParse(row['answered_at']?.toString() ?? ''),
    endedAt: DateTime.tryParse(row['ended_at']?.toString() ?? ''),
    peerName: peerName,
    peerUsername: peerUsername,
    peerAvatarPath: peerAvatarPath,
  );
}

List<CallRecord> filterCallHistoryForUser(
  Iterable<CallRecord> records,
  String userId,
  Set<String> hiddenCallIds,
) => records
    .where(
      (call) =>
          (call.callerId == userId || call.calleeId == userId) &&
          !hiddenCallIds.contains(call.id),
    )
    .toList(growable: false);

Duration remainingIncomingCallDuration(CallRecord call, {DateTime? now}) {
  final deadline = call.createdAt.toUtc().add(incomingCallTimeout);
  final remaining = deadline.difference((now ?? DateTime.now()).toUtc());
  return remaining.isNegative ? Duration.zero : remaining;
}

class CallSignal {
  const CallSignal({
    required this.id,
    required this.callId,
    required this.kind,
    required this.data,
  });

  final String id;
  final String callId;
  final String kind;
  final Map<String, dynamic> data;

  factory CallSignal.fromRow(Map<String, dynamic> row) {
    final rawData = row['data'];
    return CallSignal(
      id: row['id'].toString(),
      callId: row['call_id'].toString(),
      kind: row['signal_type']?.toString() ?? '',
      data: rawData is Map
          ? Map<String, dynamic>.from(rawData)
          : const <String, dynamic>{},
    );
  }
}

class CallService extends ChangeNotifier {
  CallService({
    required this.userId,
    SupabaseClient? client,
    CallHistoryPreferencesStore? historyPreferencesStore,
  }) : _client = client ?? _callDb,
       _historyPreferencesStore =
           historyPreferencesStore ?? CallHistoryPreferencesStore();

  final String userId;
  final SupabaseClient _client;
  final CallHistoryPreferencesStore _historyPreferencesStore;
  Set<String> _hiddenHistoryCallIds = <String>{};
  final StreamController<CallRecord> _incoming =
      StreamController<CallRecord>.broadcast();
  final Map<String, void Function(CallRecord)> _callHandlers = {};
  final Map<String, void Function(CallSignal)> _signalHandlers = {};
  final Map<String, List<CallSignal>> _signalBacklog = {};
  final Map<String, Set<String>> _seenSignalIdsByCall = {};
  final Set<String> _publishedIncomingIds = {};
  final Map<String, CallRecord> _callCache = {};
  final Set<String> _openCallScreenIds = <String>{};
  RealtimeChannel? _incomingChannel;
  RealtimeChannel? _outgoingChannel;
  RealtimeChannel? _signalChannel;
  List<CallRecord> _history = const [];
  bool _loadingHistory = false;
  String? _historyError;
  bool _disposed = false;

  Stream<CallRecord> get incomingCalls => _incoming.stream;
  List<CallRecord> get history =>
      filterCallHistoryForUser(_history, userId, _hiddenHistoryCallIds);
  bool get loadingHistory => _loadingHistory;
  String? get historyError => _historyError;
  bool get hasOpenCallScreen => _openCallScreenIds.isNotEmpty;

  CallRecord? cachedCall(String callId) => _callCache[callId];

  void registerCallScreen(String callId) => _openCallScreenIds.add(callId);

  void unregisterCallScreen(String callId) => _openCallScreenIds.remove(callId);

  Future<void> initialize() async {
    try {
      _hiddenHistoryCallIds = await _historyPreferencesStore.load(userId);
    } catch (_) {
      _hiddenHistoryCallIds = <String>{};
    }
    _incomingChannel = _client.channel('wasla-calls-incoming-$userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'calls',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'callee_id',
          value: userId,
        ),
        callback: (payload) {
          final row = payload.eventType == PostgresChangeEvent.delete
              ? payload.oldRecord
              : payload.newRecord;
          _dispatchCallRow(row);
          if (payload.eventType == PostgresChangeEvent.insert &&
              row['status'] == 'ringing') {
            unawaited(_publishIncoming(row));
          }
        },
      )
      ..subscribe();
    _outgoingChannel = _client.channel('wasla-calls-outgoing-$userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'calls',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'caller_id',
          value: userId,
        ),
        callback: (payload) {
          final row = payload.eventType == PostgresChangeEvent.delete
              ? payload.oldRecord
              : payload.newRecord;
          _dispatchCallRow(row);
        },
      )
      ..subscribe();
    _signalChannel = _client.channel('wasla-call-signals-$userId')
      ..onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'call_signals',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'receiver_id',
          value: userId,
        ),
        callback: (payload) => _dispatchSignal(payload.newRecord),
      )
      ..subscribe();
    await refreshHistory();
    await _loadPendingIncoming();
  }

  Future<void> _publishIncoming(Map<String, dynamic> row) async {
    final id = row['id']?.toString();
    final cached = id == null ? null : _callCache[id];
    if (id == null || (cached != null && cached.status != 'ringing')) return;
    if (!_publishedIncomingIds.add(id)) return;
    try {
      final record = await _withPeer(CallRecord.fromRow(row));
      final latest = _callCache[id] ?? record;
      if (!_disposed && latest.status == 'ringing') _incoming.add(latest);
    } catch (_) {
      final latest = _callCache[id] ?? CallRecord.fromRow(row);
      if (!_disposed && latest.status == 'ringing') _incoming.add(latest);
    }
    if (_publishedIncomingIds.length > 1000) _publishedIncomingIds.clear();
  }

  Future<void> _loadPendingIncoming() async {
    try {
      final pending = await _client
          .from('calls')
          .select(
            'id, conversation_id, caller_id, callee_id, media_type, status, '
            'created_at, answered_at, ended_at',
          )
          .eq('callee_id', userId)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(5);
      for (final row in pending) {
        final created = DateTime.tryParse(row['created_at']?.toString() ?? '');
        if (created != null &&
            DateTime.now().toUtc().difference(created.toUtc()) >=
                incomingCallTimeout) {
          await _client
              .from('calls')
              .update({
                'status': 'missed',
                'ended_at': DateTime.now().toUtc().toIso8601String(),
              })
              .eq('id', row['id'].toString())
              .eq('status', 'ringing');
          continue;
        }
        await _publishIncoming(Map<String, dynamic>.from(row));
      }
    } catch (_) {
      // The UI presents the migration/configuration error in the call history.
    }
  }

  Future<void> refreshPendingIncoming() => _loadPendingIncoming();

  Future<void> refreshIncomingCall(String callId) async {
    if (_disposed || callId.isEmpty) return;
    try {
      final row = await _client
          .from('calls')
          .select(
            'id, conversation_id, caller_id, callee_id, media_type, status, '
            'created_at, answered_at, ended_at',
          )
          .eq('id', callId)
          .eq('callee_id', userId)
          .maybeSingle();
      if (row == null) return;
      final call = CallRecord.fromRow(Map<String, dynamic>.from(row));
      if (call.status != 'ringing') return;
      if (remainingIncomingCallDuration(call) <= Duration.zero) {
        await markMissed(call);
        return;
      }
      await _publishIncoming(Map<String, dynamic>.from(row));
    } catch (_) {
      // The incoming-call Realtime subscription remains the fallback.
    }
  }

  void _dispatchCallRow(Map<String, dynamic> row) {
    final id = row['id']?.toString();
    if (id == null || id.isEmpty) return;
    final old = _callCache[id];
    final record = CallRecord.fromRow(
      row,
      peerName: old?.peerName ?? '',
      peerUsername: old?.peerUsername ?? '',
      peerAvatarPath: old?.peerAvatarPath,
    );
    _callCache[id] = record;
    _callHandlers[id]?.call(record);
    unawaited(refreshHistory());
  }

  void _dispatchSignal(Map<String, dynamic> row) {
    final id = row['id']?.toString();
    final callId = row['call_id']?.toString();
    if (id == null || callId == null) return;
    final seen = _seenSignalIdsByCall.putIfAbsent(callId, () => <String>{});
    if (!seen.add(id)) return;
    final signal = CallSignal.fromRow(row);
    final handler = _signalHandlers[callId];
    if (handler != null) {
      handler(signal);
    } else {
      _signalBacklog.putIfAbsent(callId, () => []).add(signal);
    }
    if (seen.length > 2000) seen.clear();
  }

  Future<CallRecord> _withPeer(CallRecord call) async {
    final cached = _callCache[call.id];
    if (cached != null && cached.peerName.isNotEmpty) return cached;
    final peerId = call.callerId == userId ? call.calleeId : call.callerId;
    final row = await _client
        .from('profiles')
        .select('username, display_name, avatar_path')
        .eq('id', peerId)
        .maybeSingle();
    final name = row?['display_name']?.toString() ?? '';
    final username = row?['username']?.toString() ?? '';
    final latest = _callCache[call.id] ?? call;
    final enriched = latest.withPeer(
      name: name,
      username: username,
      avatarPath: row?['avatar_path']?.toString(),
    );
    _callCache[call.id] = enriched;
    return enriched;
  }

  Future<void> refreshHistory() async {
    if (_disposed || _loadingHistory) return;
    _loadingHistory = true;
    _historyError = null;
    notifyListeners();
    try {
      final rows = await Future.wait([
        _client
            .from('calls')
            .select(
              'id, conversation_id, caller_id, callee_id, media_type, status, '
              'created_at, answered_at, ended_at',
            )
            .eq('caller_id', userId)
            .order('created_at', ascending: false)
            .limit(50),
        _client
            .from('calls')
            .select(
              'id, conversation_id, caller_id, callee_id, media_type, status, '
              'created_at, answered_at, ended_at',
            )
            .eq('callee_id', userId)
            .order('created_at', ascending: false)
            .limit(50),
      ]);
      final byId = <String, Map<String, dynamic>>{};
      for (final set in rows) {
        for (final item in set) {
          final row = Map<String, dynamic>.from(item);
          byId[row['id'].toString()] = row;
        }
      }
      final sorted = byId.values.toList()
        ..sort(
          (a, b) =>
              (DateTime.tryParse(b['created_at']?.toString() ?? '') ??
                      DateTime(2000))
                  .compareTo(
                    DateTime.tryParse(a['created_at']?.toString() ?? '') ??
                        DateTime(2000),
                  ),
        );
      final peerIds = sorted
          .map(
            (row) => row['caller_id'].toString() == userId
                ? row['callee_id'].toString()
                : row['caller_id'].toString(),
          )
          .toSet()
          .toList();
      final profiles = <String, Map<String, dynamic>>{};
      if (peerIds.isNotEmpty) {
        final people = await _client
            .from('profiles')
            .select('id, username, display_name, avatar_path')
            .inFilter('id', peerIds);
        for (final profile in people) {
          final value = Map<String, dynamic>.from(profile);
          profiles[value['id'].toString()] = value;
        }
      }
      _history = sorted.map((row) {
        final call = CallRecord.fromRow(row);
        final peerId = call.callerId == userId ? call.calleeId : call.callerId;
        final profile = profiles[peerId] ?? const <String, dynamic>{};
        final enriched = call.withPeer(
          name: profile['display_name']?.toString() ?? '',
          username: profile['username']?.toString() ?? '',
          avatarPath: profile['avatar_path']?.toString(),
        );
        _callCache[call.id] = enriched;
        return enriched;
      }).toList();
    } catch (error) {
      _historyError = error is PostgrestException
          ? error.message
          : 'تعذر تحميل سجل المكالمات. تحقق من ترحيل المكالمات على الخادم.';
    } finally {
      _loadingHistory = false;
      if (!_disposed) notifyListeners();
    }
  }

  Future<void> hideCallFromHistory(CallRecord call) async {
    final belongsToUser = call.callerId == userId || call.calleeId == userId;
    final isInUserHistory = _history.any(
      (record) =>
          record.id == call.id &&
          (record.callerId == userId || record.calleeId == userId),
    );
    if (!belongsToUser || !isInUserHistory) {
      throw StateError('لا يمكن إخفاء سجل لا يخص هذا الحساب.');
    }
    if (_hiddenHistoryCallIds.contains(call.id)) return;

    final updated = <String>{..._hiddenHistoryCallIds, call.id};
    await _historyPreferencesStore.save(userId, updated);
    _hiddenHistoryCallIds = updated;
    if (!_disposed) notifyListeners();
  }

  Future<CallRecord> startCall(ChatTarget target, {required bool video}) async {
    if (target.isGroup) {
      throw StateError('المكالمات الجماعية غير مفعّلة في هذه النسخة.');
    }
    final row = await _client
        .from('calls')
        .insert({
          'conversation_id': target.conversationId,
          'caller_id': userId,
          'callee_id': target.userId,
          'media_type': video ? 'video' : 'audio',
          'status': 'ringing',
        })
        .select(
          'id, conversation_id, caller_id, callee_id, media_type, status, '
          'created_at, answered_at, ended_at',
        )
        .single();
    final record = CallRecord.fromRow(Map<String, dynamic>.from(row)).withPeer(
      name: target.displayName,
      username: target.username,
      avatarPath: target.avatarPath,
    );
    _callCache[record.id] = record;
    unawaited(refreshHistory());
    return record;
  }

  Future<void> accept(String callId) async {
    final updated = await _client
        .from('calls')
        .update({
          'status': 'accepted',
          'answered_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', callId)
        .eq('status', 'ringing')
        .select('id')
        .maybeSingle();
    if (updated == null) {
      throw StateError('انتهت المكالمة أو تم الرد عليها من جهاز آخر.');
    }
    await refreshHistory();
  }

  Future<void> finish(CallRecord call) async {
    final latest = await _client
        .from('calls')
        .select('status')
        .eq('id', call.id)
        .maybeSingle();
    final currentStatus = latest?['status']?.toString() ?? call.status;
    final isCaller = call.callerId == userId;
    final next = currentStatus == 'accepted'
        ? 'ended'
        : isCaller
        ? 'cancelled'
        : 'rejected';
    await _client
        .from('calls')
        .update({
          'status': next,
          'ended_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', call.id)
        .inFilter('status', ['ringing', 'accepted']);
    await refreshHistory();
  }

  Future<void> markMissed(CallRecord call) async {
    await _client
        .from('calls')
        .update({
          'status': 'missed',
          'ended_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', call.id)
        .eq('status', 'ringing');
    await refreshHistory();
  }

  Future<void> sendSignal(
    CallRecord call,
    String kind,
    Map<String, dynamic> data,
  ) async {
    final receiver = call.callerId == userId ? call.calleeId : call.callerId;
    await _client.from('call_signals').insert({
      'call_id': call.id,
      'sender_id': userId,
      'receiver_id': receiver,
      'signal_type': kind,
      'data': data,
    });
  }

  Future<void> replaySignals(CallRecord call) async {
    try {
      final rows = await _client
          .from('call_signals')
          .select('id, call_id, signal_type, data')
          .eq('call_id', call.id)
          .eq('receiver_id', userId)
          .order('created_at');
      for (final row in rows) {
        _dispatchSignal(Map<String, dynamic>.from(row));
      }
    } catch (_) {
      // Realtime delivery remains available when there are no replayable rows.
    }
  }

  void watchCall(String callId, void Function(CallRecord) handler) {
    _callHandlers[callId] = handler;
    final existing = _callCache[callId];
    if (existing != null) handler(existing);
  }

  void unwatchCall(String callId) => _callHandlers.remove(callId);

  void watchSignals(String callId, void Function(CallSignal) handler) {
    _signalHandlers[callId] = handler;
    final waiting = _signalBacklog.remove(callId) ?? const <CallSignal>[];
    for (final signal in waiting) {
      handler(signal);
    }
  }

  void unwatchSignals(String callId) => _signalHandlers.remove(callId);

  void resetSignalReplay(String callId) {
    _seenSignalIdsByCall.remove(callId);
    _signalBacklog.remove(callId);
  }

  @override
  void dispose() {
    _disposed = true;
    if (_incomingChannel != null) {
      unawaited(_client.removeChannel(_incomingChannel!));
    }
    if (_outgoingChannel != null) {
      unawaited(_client.removeChannel(_outgoingChannel!));
    }
    if (_signalChannel != null) {
      unawaited(_client.removeChannel(_signalChannel!));
    }
    unawaited(_incoming.close());
    super.dispose();
  }
}

Future<bool> confirmHideCallHistory(BuildContext context) async =>
    await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حذف سجل المكالمة؟'),
        content: const Text(
          'سيختفي السجل من قائمتك على هذا الجهاز فقط. لن تُحذف المكالمة أو بيانات الطرف الآخر.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialogContext).colorScheme.error,
              foregroundColor: Theme.of(dialogContext).colorScheme.onError,
            ),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('حذف من قائمتي'),
          ),
        ],
      ),
    ) ??
    false;

class CallsSection extends StatelessWidget {
  const CallsSection({
    required this.service,
    required this.onStartCall,
    required this.onCallAgain,
    super.key,
  });

  final CallService service;
  final VoidCallback onStartCall;
  final ValueChanged<CallRecord> onCallAgain;

  String _statusLabel(CallRecord call, String me) {
    if (call.status == 'missed' ||
        (call.status == 'rejected' && call.callerId == me)) {
      return 'مكالمة فائتة';
    }
    if (call.status == 'rejected') return 'تم رفض المكالمة';
    if (call.status == 'cancelled') return 'أُلغيت قبل الرد';
    if (call.status == 'ended') return 'انتهت المكالمة';
    if (call.status == 'accepted') return 'جارية';
    return call.callerId == me ? 'صادرة · لم يُجب' : 'واردة · لم يُجب';
  }

  @override
  Widget build(BuildContext context) {
    final userId = service.userId;
    return AnimatedBuilder(
      animation: service,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 110),
        children: [
          Card(
            elevation: 0,
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'مكالمات صوتية ومرئية فردية',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'اتصل بمستخدم وصال. يجب أن يكون الطرفان متصلين بالتطبيق لقبول المكالمة.',
                    style: TextStyle(height: 1.5),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: onStartCall,
                    icon: const Icon(Icons.add_call),
                    label: const Text('مكالمة جديدة'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              'الأخيرة',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 8),
          if (service.loadingHistory && service.history.isEmpty)
            const Padding(
              padding: EdgeInsets.all(28),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (service.historyError != null && service.history.isEmpty)
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'تعذر تحميل سجل المكالمات. تأكد من تطبيق الترحيل 006_calls.sql.\n${service.historyError}',
                  style: const TextStyle(height: 1.5),
                ),
              ),
            )
          else if (service.history.isEmpty)
            const Card(
              elevation: 0,
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'لا توجد مكالمات بعد. ابدأ مكالمة فردية من هنا أو من شريط المحادثة.',
                  textAlign: TextAlign.center,
                  style: TextStyle(height: 1.5),
                ),
              ),
            )
          else
            for (final call in service.history)
              Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(call.isVideo ? Icons.videocam : Icons.call),
                  ),
                  title: AdminIdentityText(
                    userId: call.callerId == userId
                        ? call.calleeId
                        : call.callerId,
                    label: call.peerName.isNotEmpty
                        ? call.peerName
                        : '@${call.peerUsername}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    '${call.isVideo ? 'مرئية' : 'صوتية'} · ${_statusLabel(call, userId)} · ${_formatCallDate(call.createdAt)}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: call.isVideo
                            ? 'إعادة اتصال مرئي'
                            : 'إعادة اتصال صوتي',
                        onPressed: () => onCallAgain(call),
                        icon: Icon(
                          call.isVideo
                              ? Icons.videocam_outlined
                              : Icons.call_outlined,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                      PopupMenuButton<String>(
                        tooltip: 'خيارات سجل المكالمة',
                        onSelected: (action) async {
                          if (action != 'hide') return;
                          if (!await confirmHideCallHistory(context)) return;
                          try {
                            await service.hideCallFromHistory(call);
                          } catch (_) {
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'تعذر حفظ إخفاء السجل على هذا الجهاز. حاول مجددًا.',
                                ),
                              ),
                            );
                          }
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem<String>(
                            value: 'hide',
                            child: Row(
                              children: [
                                Icon(Icons.delete_outline_rounded),
                                SizedBox(width: 10),
                                Text('حذف من سجل المكالمات'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          if (service.historyError != null && service.history.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(8),
              child: Text(
                'تعذر تحديث السجل: ${service.historyError}',
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
        ],
      ),
    );
  }
}

String _formatCallDate(DateTime date) {
  final local = date.toLocal();
  final now = DateTime.now();
  if (local.year == now.year &&
      local.month == now.month &&
      local.day == now.day) {
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
  return '${local.day}/${local.month}/${local.year}';
}

enum CallWindowMode { expanded, minimized }

/// Presentation state only: changing the window mode never ends a call.
class CallWindowState {
  CallWindowState(this.callId);

  final String callId;
  CallWindowMode _mode = CallWindowMode.expanded;
  bool _ended = false;

  CallWindowMode get mode => _mode;
  bool get isMinimized => _mode == CallWindowMode.minimized;
  bool get isCallActive => !_ended;

  void minimize() {
    if (_ended || _mode == CallWindowMode.minimized) return;
    _mode = CallWindowMode.minimized;
  }

  void restore() {
    if (_ended || _mode == CallWindowMode.expanded) return;
    _mode = CallWindowMode.expanded;
  }

  void end() => _ended = true;
}

Route<void> callScreenRoute({
  required CallService service,
  required CallRecord call,
  IncomingCallRingtoneController? ringtone,
}) => PageRouteBuilder<void>(
  opaque: false,
  barrierDismissible: false,
  barrierColor: null,
  maintainState: true,
  fullscreenDialog: true,
  pageBuilder: (_, _, _) =>
      CallScreen(service: service, call: call, ringtone: ringtone),
  transitionsBuilder: (_, animation, _, child) =>
      FadeTransition(opacity: animation, child: child),
);

class CallScreen extends StatefulWidget {
  const CallScreen({
    required this.service,
    required this.call,
    this.ringtone,
    super.key,
  });

  final CallService service;
  final CallRecord call;
  final IncomingCallRingtoneController? ringtone;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final RTCVideoRenderer _localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer _remoteRenderer = RTCVideoRenderer();
  late final CallWindowState _windowState = CallWindowState(widget.call.id);
  Route<void>? _callRoute;
  OverlayEntry? _miniOverlayEntry;
  RTCPeerConnection? _peer;
  MediaStream? _localStream;
  MediaStream? _remoteStream;
  final List<RTCIceCandidate> _pendingCandidates = [];
  bool _localRendererInitialized = false;
  bool _remoteRendererInitialized = false;
  bool _mediaReady = false;
  bool _initializing = false;
  bool get _ending => !_windowState.isCallActive;
  bool get _minimized => _windowState.isMinimized;
  bool _confirmMiniHangUp = false;
  bool _muted = false;
  bool _cameraOff = false;
  bool _speakerOn = false;
  bool _remoteAccepted = false;
  bool _connected = false;
  String? _error;
  String? _finishedMessage;
  DateTime? _connectedAt;
  Timer? _durationTimer;
  Duration _duration = Duration.zero;
  final AudioPlayer _callerRingbackPlayer = AudioPlayer();
  late final OutgoingCallRingbackController _callerRingback =
      OutgoingCallRingbackController(
        play: _playCallerRingback,
        stop: _callerRingbackPlayer.stop,
      );
  late String _callStatus;
  bool get _isCaller => widget.call.callerId == widget.service.userId;
  bool get _isVideo => widget.call.isVideo;
  String get _peerLabel => widget.call.peerName.isNotEmpty
      ? widget.call.peerName
      : '@${widget.call.peerUsername}';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _callRoute ??= ModalRoute.of(context);
  }

  void _refreshMiniOverlay() => _miniOverlayEntry?.markNeedsBuild();

  void _minimizeCall() {
    if (_ending || _minimized) return;
    setState(() {
      _windowState.minimize();
      _confirmMiniHangUp = false;
    });
    final overlay = Overlay.of(context, rootOverlay: true);
    final entry = OverlayEntry(builder: _buildFloatingCallWindow);
    _miniOverlayEntry = entry;
    overlay.insert(entry);
  }

  void _restoreCall() {
    if (_ending || !_minimized) return;
    final callRoute = _callRoute ?? ModalRoute.of(context);
    _removeMiniOverlay();
    setState(_windowState.restore);
    if (callRoute != null) {
      Navigator.of(context).popUntil((route) => identical(route, callRoute));
    }
  }

  void _removeMiniOverlay() {
    final entry = _miniOverlayEntry;
    _miniOverlayEntry = null;
    _confirmMiniHangUp = false;
    if (entry != null) {
      entry.remove();
      entry.dispose();
    }
  }

  Widget _buildFloatingCallWindow(BuildContext context) => Positioned.fill(
    child: SafeArea(
      child: Align(
        alignment: Alignment.bottomRight,
        child: Padding(
          padding: const EdgeInsetsDirectional.only(end: 14, bottom: 16),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: _restoreCall,
              child: Container(
                width: 204,
                decoration: BoxDecoration(
                  color: const Color(0xFF10201C),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white24),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black38,
                      blurRadius: 18,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_isVideo)
                      SizedBox(
                        height: 124,
                        width: double.infinity,
                        child: _remoteStream == null
                            ? _miniCallAvatar()
                            : RTCVideoView(
                                _remoteRenderer,
                                objectFit: RTCVideoViewObjectFit
                                    .RTCVideoViewObjectFitCover,
                              ),
                      )
                    else
                      Padding(
                        padding: const EdgeInsetsDirectional.only(
                          start: 12,
                          end: 12,
                          top: 12,
                        ),
                        child: Row(
                          children: [
                            _miniCallAvatar(size: 38),
                            const SizedBox(width: 10),
                            Expanded(child: _miniCallTitle()),
                          ],
                        ),
                      ),
                    if (_isVideo)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(
                          start: 12,
                          end: 12,
                          top: 8,
                        ),
                        child: _miniCallTitle(),
                      ),
                    if (_confirmMiniHangUp)
                      const Padding(
                        padding: EdgeInsetsDirectional.only(
                          start: 12,
                          end: 12,
                          top: 7,
                        ),
                        child: Text(
                          'إنهاء المكالمة الآن؟',
                          style: TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ),
                    Padding(
                      padding: const EdgeInsetsDirectional.only(
                        start: 8,
                        end: 8,
                        top: 4,
                        bottom: 6,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: _confirmMiniHangUp
                            ? [
                                TextButton(
                                  onPressed: () {
                                    _confirmMiniHangUp = false;
                                    _refreshMiniOverlay();
                                  },
                                  child: const Text(
                                    'إلغاء',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ),
                                FilledButton.icon(
                                  style: FilledButton.styleFrom(
                                    backgroundColor: Colors.red.shade700,
                                  ),
                                  onPressed: _hangUp,
                                  icon: const Icon(Icons.call_end, size: 18),
                                  label: const Text('إنهاء'),
                                ),
                              ]
                            : [
                                IconButton.filledTonal(
                                  tooltip: 'العودة إلى المكالمة',
                                  onPressed: _restoreCall,
                                  icon: const Icon(Icons.open_in_full),
                                ),
                                IconButton.filled(
                                  tooltip: 'إنهاء المكالمة',
                                  style: IconButton.styleFrom(
                                    backgroundColor: Colors.red.shade700,
                                  ),
                                  onPressed: () {
                                    _confirmMiniHangUp = true;
                                    _refreshMiniOverlay();
                                  },
                                  icon: const Icon(Icons.call_end),
                                ),
                              ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  Widget _miniCallAvatar({double size = 124}) => ColoredBox(
    color: const Color(0xFF17483F),
    child: Center(
      child: CircleAvatar(
        radius: size / 2,
        backgroundColor: const Color(0xFF2B7165),
        child: Text(
          _peerLabel.isEmpty ? '?' : _peerLabel.characters.first,
          style: TextStyle(
            color: Colors.white,
            fontSize: size * .36,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    ),
  );

  Widget _miniCallTitle() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        _peerLabel,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700,
        ),
      ),
      const SizedBox(height: 2),
      Text(
        _connected ? _formatDuration(_duration) : 'المكالمة مستمرة',
        style: const TextStyle(color: Colors.white70, fontSize: 12),
      ),
    ],
  );

  @override
  void initState() {
    super.initState();
    _callStatus = widget.call.status;
    widget.service.registerCallScreen(widget.call.id);
    final ringtone = widget.ringtone;
    if (ringtone != null) unawaited(ringtone.stopAll());
    widget.service.watchCall(widget.call.id, _onCallUpdated);
    unawaited(_startCallerRingback());
    unawaited(_initializeCall());
  }

  Future<void> _startCallerRingback() async {
    if (!_isCaller || _ending || _callStatus != 'ringing') return;
    await PushNotifications.instance.refreshPreferences();
    if (!mounted || _ending || _callStatus != 'ringing') return;
    final call = widget.service.cachedCall(widget.call.id) ?? widget.call;
    if (call.status != 'ringing' || call.callerId != widget.service.userId) {
      return;
    }
    await _callerRingback.startForOutgoing(
      callId: call.id,
      isOutgoing: call.callerId == widget.service.userId,
      status: _callStatus,
      alertsEnabled: PushNotifications.instance.preferences.allowsChatSoundFor(
        'calls',
      ),
      timeout: remainingIncomingCallDuration(call),
    );
  }

  Future<void> _playCallerRingback() async {
    await _callerRingbackPlayer.setAudioContext(
      AudioContextConfig(respectSilence: true, stayAwake: false).build(),
    );
    await _callerRingbackPlayer.setReleaseMode(ReleaseMode.loop);
    await _callerRingbackPlayer.play(
      AssetSource('audio/caller_ringback.wav'),
      volume: 0.65,
    );
  }

  Future<void> _disposeCallerRingback() async {
    await _callerRingback.dispose();
    await _callerRingbackPlayer.dispose();
  }

  Future<void> _initializeCall() async {
    if (_initializing || _ending) return;
    if (mounted) {
      setState(() {
        _initializing = true;
        _error = null;
      });
    }
    try {
      if (_peer != null || _localStream != null || _remoteStream != null) {
        await _releaseMedia(unregisterCall: false, disposeRenderers: false);
      }
      if (!mounted || _ending) return;
      widget.service.resetSignalReplay(widget.call.id);
      widget.service.watchCall(widget.call.id, _onCallUpdated);
      _pendingCandidates.clear();
      _offerStarted = false;
      _answerStarted = false;
      _remoteDescriptionSet = false;
      _mediaReady = false;
      _remoteAccepted = false;
      _connected = false;
      _connectedAt = null;
      _duration = Duration.zero;
      _durationTimer?.cancel();
      final mic = await Permission.microphone.request();
      if (!mic.isGranted) {
        throw StateError(
          mic.isPermanentlyDenied
              ? 'اسمح لوصال بالوصول إلى الميكروفون من إعدادات الجهاز.'
              : 'يلزم السماح بالميكروفون لإجراء المكالمة.',
        );
      }
      if (_isVideo) {
        final camera = await Permission.camera.request();
        if (!camera.isGranted) {
          throw StateError(
            camera.isPermanentlyDenied
                ? 'اسمح لوصال بالوصول إلى الكاميرا من إعدادات الجهاز.'
                : 'يلزم السماح بالكاميرا لإجراء مكالمة مرئية.',
          );
        }
      }
      if (!_localRendererInitialized) {
        await _localRenderer.initialize();
        _localRendererInitialized = true;
      }
      if (!_remoteRendererInitialized) {
        await _remoteRenderer.initialize();
        _remoteRendererInitialized = true;
      }
      await Helper.setSpeakerphoneOn(_isVideo);
      _speakerOn = _isVideo;
      final peer = await createPeerConnection({
        'sdpSemantics': 'unified-plan',
        'iceServers': [
          {'urls': 'stun:stun.l.google.com:19302'},
          {'urls': 'stun:stun1.l.google.com:19302'},
        ],
      });
      _peer = peer;
      peer.onIceCandidate = (candidate) {
        if (_ending || _peer != peer) return;
        final candidateLine = candidate.candidate;
        if (candidateLine == null || candidateLine.isEmpty) return;
        unawaited(
          widget.service
              .sendSignal(widget.call, 'ice', {
                'candidate': candidateLine,
                'sdpMid': candidate.sdpMid,
                'sdpMLineIndex': candidate.sdpMLineIndex,
              })
              .catchError((Object _) {}),
        );
      };
      peer.onTrack = (event) {
        if (_ending || _peer != peer) return;
        if (event.streams.isNotEmpty) {
          _remoteStream = event.streams.first;
          _remoteRenderer.srcObject = _remoteStream;
          if (mounted) {
            setState(() {});
            _refreshMiniOverlay();
          }
        }
      };
      peer.onConnectionState = (state) {
        if (state != RTCPeerConnectionState.RTCPeerConnectionStateNew) {
          unawaited(_callerRingback.stopForCall(widget.call.id));
        }
        if (state == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
          _setConnected();
        } else if (state ==
                RTCPeerConnectionState.RTCPeerConnectionStateFailed &&
            mounted) {
          setState(() {
            _error = 'تعذر إنشاء اتصال مباشر. قد تمنع الشبكة الاتصال أو تحتاج إلى خادم TURN.';
          });
        }
      };
      _localStream = await navigator.mediaDevices.getUserMedia({
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        },
        'video': _isVideo
            ? {
                'facingMode': 'user',
                'width': {'ideal': 1280},
                'height': {'ideal': 720},
                'frameRate': {'ideal': 24},
              }
            : false,
      });
      _localRenderer.srcObject = _localStream;
      for (final track in _localStream!.getTracks()) {
        await peer.addTrack(track, _localStream!);
      }
      _mediaReady = true;
      widget.service.watchSignals(widget.call.id, (signal) {
        unawaited(_handleSignal(signal));
      });
      await widget.service.replaySignals(widget.call);
      final row = await _callDb
          .from('calls')
          .select('status')
          .eq('id', widget.call.id)
          .single();
      if (!mounted) return;
      _remoteAccepted = row['status'] == 'accepted';
      if (_isCaller && _remoteAccepted) await _createOffer();
      setState(() => _initializing = false);
    } catch (error) {
      await _releaseMedia(unregisterCall: false, disposeRenderers: false);
      if (!mounted) return;
      setState(() {
        _initializing = false;
        _error = error is StateError
            ? error.message.toString()
            : 'تعذر تهيئة المكالمة. تحقق من الأذونات والاتصال بالخادم.';
      });
    }
  }

  void _setConnected() {
    if (!mounted || _connected) return;
    unawaited(_callerRingback.stopForCall(widget.call.id));
    setState(() {
      _connected = true;
      _connectedAt = DateTime.now();
      _error = null;
    });
    _refreshMiniOverlay();
    _durationTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _connectedAt == null) return;
      setState(() => _duration = DateTime.now().difference(_connectedAt!));
      _refreshMiniOverlay();
    });
  }

  void _onCallUpdated(CallRecord call) {
    _callStatus = call.status;
    if (call.status != 'ringing') {
      unawaited(
        _callerRingback.updateCallStatus(
          callId: widget.call.id,
          status: call.status,
        ),
      );
    }
    if (call.status == 'accepted') {
      _remoteAccepted = true;
      if (_isCaller && _mediaReady) unawaited(_createOffer());
      if (mounted) {
        setState(() {});
        _refreshMiniOverlay();
      }
      return;
    }
    if (call.status == 'rejected') {
      _finishRemotely('تم رفض المكالمة');
    } else if (call.status == 'missed') {
      _finishRemotely('لم يتم الرد على المكالمة');
    } else if (call.status == 'cancelled') {
      _finishRemotely('ألغى الطرف الآخر المكالمة');
    } else if (call.status == 'ended') {
      _finishRemotely('أنهى الطرف الآخر المكالمة');
    }
  }

  void _finishRemotely(String message) {
    if (!mounted || _ending) return;
    unawaited(_callerRingback.stopForCall(widget.call.id));
    setState(() => _finishedMessage = message);
    _refreshMiniOverlay();
    Future<void>.delayed(const Duration(milliseconds: 1100), () {
      if (mounted && !_ending) unawaited(_closeScreen(updateServer: false));
    });
  }

  Future<void> _createOffer() async {
    if (_ending ||
        _peer == null ||
        !_mediaReady ||
        !_remoteAccepted ||
        _offerStarted) {
      return;
    }
    _offerStarted = true;
    try {
      final offer = await _peer!.createOffer({
        'offerToReceiveAudio': 1,
        'offerToReceiveVideo': _isVideo ? 1 : 0,
      });
      await _peer!.setLocalDescription(offer);
      await widget.service.sendSignal(widget.call, 'offer', {
        'sdp': offer.sdp,
        'type': offer.type,
      });
    } catch (_) {
      _offerStarted = false;
      unawaited(_callerRingback.stopForCall(widget.call.id));
      if (mounted) {
        setState(
          () =>
              _error = 'تعذر بدء الاتصال. حاول إنهاء المكالمة وإعادة المحاولة.',
        );
        _refreshMiniOverlay();
      }
    }
  }

  bool _offerStarted = false;
  bool _answerStarted = false;
  bool _remoteDescriptionSet = false;

  Future<void> _handleSignal(CallSignal signal) async {
    if (_ending || _peer == null) return;
    try {
      switch (signal.kind) {
        case 'offer':
          if (_isCaller || _answerStarted) return;
          _answerStarted = true;
          final sdp = signal.data['sdp']?.toString();
          final type = signal.data['type']?.toString();
          if (sdp == null || sdp.isEmpty || type != 'offer') {
            throw const FormatException('Invalid call offer');
          }
          await _peer!.setRemoteDescription(RTCSessionDescription(sdp, type));
          _remoteDescriptionSet = true;
          await _drainPendingCandidates();
          final answer = await _peer!.createAnswer({
            'offerToReceiveAudio': 1,
            'offerToReceiveVideo': _isVideo ? 1 : 0,
          });
          await _peer!.setLocalDescription(answer);
          await widget.service.sendSignal(widget.call, 'answer', {
            'sdp': answer.sdp,
            'type': answer.type,
          });
        case 'answer':
          if (!_isCaller || _remoteDescriptionSet) return;
          final sdp = signal.data['sdp']?.toString();
          final type = signal.data['type']?.toString();
          if (sdp == null || sdp.isEmpty || type != 'answer') {
            throw const FormatException('Invalid call answer');
          }
          await _peer!.setRemoteDescription(RTCSessionDescription(sdp, type));
          _remoteDescriptionSet = true;
          await _drainPendingCandidates();
        case 'ice':
          final candidateLine = signal.data['candidate']?.toString();
          if (candidateLine == null || candidateLine.isEmpty) return;
          final rawMLineIndex = signal.data['sdpMLineIndex'];
          final candidate = RTCIceCandidate(
            candidateLine,
            signal.data['sdpMid']?.toString(),
            rawMLineIndex is num
                ? rawMLineIndex.toInt()
                : int.tryParse(rawMLineIndex?.toString() ?? ''),
          );
          if (_remoteDescriptionSet) {
            await _peer!.addCandidate(candidate);
          } else {
            _pendingCandidates.add(candidate);
          }
      }
    } catch (_) {
      unawaited(_callerRingback.stopForCall(widget.call.id));
      if (mounted) {
        setState(
          () => _error =
              'تعذر تبادل بيانات الاتصال. تحقق من الشبكة ثم أعد المحاولة.',
        );
        _refreshMiniOverlay();
      }
    }
  }

  Future<void> _drainPendingCandidates() async {
    final candidates = List<RTCIceCandidate>.from(_pendingCandidates);
    _pendingCandidates.clear();
    for (final candidate in candidates) {
      await _peer?.addCandidate(candidate);
    }
  }

  String get _statusText {
    if (_finishedMessage != null) return _finishedMessage!;
    if (_connected) return _formatDuration(_duration);
    if (_error != null) return _error!;
    if (_isCaller && !_remoteAccepted) return 'جارٍ الاتصال بـ $_peerLabel…';
    if (_isCaller) return 'تم الرد · جارٍ توصيل الصوت والفيديو…';
    return 'جارٍ توصيل الصوت والفيديو…';
  }

  Future<void> _toggleMicrophone() async {
    _muted = !_muted;
    for (final track
        in _localStream?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      track.enabled = !_muted;
    }
    if (mounted) setState(() {});
    _refreshMiniOverlay();
  }

  Future<void> _toggleCamera() async {
    _cameraOff = !_cameraOff;
    for (final track
        in _localStream?.getVideoTracks() ?? <MediaStreamTrack>[]) {
      track.enabled = !_cameraOff;
    }
    if (mounted) setState(() {});
    _refreshMiniOverlay();
  }

  Future<void> _switchCamera() async {
    final tracks = _localStream?.getVideoTracks() ?? <MediaStreamTrack>[];
    if (tracks.isNotEmpty) await Helper.switchCamera(tracks.first);
  }

  Future<void> _toggleSpeaker() async {
    _speakerOn = !_speakerOn;
    await Helper.setSpeakerphoneOn(_speakerOn);
    if (mounted) setState(() {});
    _refreshMiniOverlay();
  }

  Future<void> _hangUp() => _closeScreen(updateServer: true);

  Future<void> _closeScreen({required bool updateServer}) async {
    if (_ending) return;
    _windowState.end();
    _removeMiniOverlay();
    _durationTimer?.cancel();
    await _callerRingback.stopForCall(widget.call.id);
    if (updateServer) {
      try {
        await widget.service.finish(widget.call);
      } catch (_) {
        // Always release the camera and microphone even when signaling fails.
      }
    }
    await _releaseMedia();
    final route = _callRoute;
    final navigator = route?.navigator;
    if (mounted && route != null && navigator != null) {
      navigator.removeRoute(route);
    }
  }

  Future<void> _releaseMedia({
    bool unregisterCall = true,
    bool disposeRenderers = true,
  }) async {
    _mediaReady = false;
    await _callerRingback.stopForCall(widget.call.id);
    if (unregisterCall) widget.service.unwatchCall(widget.call.id);
    widget.service.unwatchSignals(widget.call.id);
    final localStream = _localStream;
    final remoteStream = _remoteStream;
    final peer = _peer;
    _localStream = null;
    _remoteStream = null;
    _peer = null;
    if (_localRendererInitialized) _localRenderer.srcObject = null;
    if (_remoteRendererInitialized) _remoteRenderer.srcObject = null;
    for (final track in localStream?.getTracks() ?? <MediaStreamTrack>[]) {
      try {
        await track.stop();
      } catch (_) {}
    }
    for (final track in remoteStream?.getTracks() ?? <MediaStreamTrack>[]) {
      try {
        await track.stop();
      } catch (_) {}
    }
    try {
      await localStream?.dispose();
    } catch (_) {}
    try {
      await remoteStream?.dispose();
    } catch (_) {}
    try {
      await peer?.close();
    } catch (_) {}
    if (disposeRenderers) {
      if (_localRendererInitialized) {
        try {
          await _localRenderer.dispose();
        } catch (_) {}
        _localRendererInitialized = false;
      }
      if (_remoteRendererInitialized) {
        try {
          await _remoteRenderer.dispose();
        } catch (_) {}
        _remoteRendererInitialized = false;
      }
      try {
        await Helper.setSpeakerphoneOn(false);
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    _durationTimer?.cancel();
    unawaited(_disposeCallerRingback());
    widget.service.unregisterCallScreen(widget.call.id);
    if (!_ending) {
      _windowState.end();
      _removeMiniOverlay();
      unawaited(widget.service.finish(widget.call).catchError((Object _) {}));
      unawaited(_releaseMedia());
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_minimized) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) _restoreCall();
        },
        child: const IgnorePointer(child: SizedBox.expand()),
      );
    }
    final hasRemoteVideo = _isVideo && _remoteStream != null;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _minimizeCall();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF10201C),
        body: Stack(
          fit: StackFit.expand,
          children: [
            if (hasRemoteVideo)
              RTCVideoView(
                _remoteRenderer,
                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
              )
            else
              DecoratedBox(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF17483F), Color(0xFF10201C)],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 54,
                      backgroundColor: const Color(0xFF2B7165),
                      child: Text(
                        _peerLabel.isEmpty ? '?' : _peerLabel.characters.first,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 42,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      _peerLabel,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            if (_isVideo && _localStream != null && !_cameraOff)
              Positioned(
                top: MediaQuery.paddingOf(context).top + 16,
                left: 16,
                width: 116,
                height: 168,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: RTCVideoView(
                    _localRenderer,
                    mirror: true,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  ),
                ),
              ),
            Positioned(
              top: MediaQuery.paddingOf(context).top + 12,
              left: 16,
              child: IconButton.filledTonal(
                tooltip: 'تصغير نافذة المكالمة',
                onPressed: _minimizeCall,
                icon: const Icon(Icons.picture_in_picture_alt),
              ),
            ),
            Positioned(
              top: MediaQuery.paddingOf(context).top + 12,
              right: 16,
              child: IconButton.filledTonal(
                tooltip: 'إنهاء المكالمة',
                onPressed: _hangUp,
                icon: const Icon(Icons.close),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: MediaQuery.paddingOf(context).bottom + 28,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _statusText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      shadows: [Shadow(color: Colors.black54, blurRadius: 8)],
                    ),
                  ),
                  if (_error != null && !_initializing) ...[
                    const SizedBox(height: 8),
                    TextButton.icon(
                      onPressed: _initializeCall,
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                  const SizedBox(height: 22),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _CallControl(
                        icon: _muted ? Icons.mic_off : Icons.mic,
                        label: _muted ? 'تشغيل الميكروفون' : 'كتم الميكروفون',
                        onPressed: _toggleMicrophone,
                        selected: _muted,
                      ),
                      if (_isVideo) ...[
                        const SizedBox(width: 22),
                        _CallControl(
                          icon: _cameraOff
                              ? Icons.videocam_off
                              : Icons.videocam,
                          label: _cameraOff
                              ? 'تشغيل الكاميرا'
                              : 'إيقاف الكاميرا',
                          onPressed: _toggleCamera,
                          selected: _cameraOff,
                        ),
                        const SizedBox(width: 22),
                        _CallControl(
                          icon: Icons.flip_camera_android_outlined,
                          label: 'تبديل الكاميرا',
                          onPressed: _switchCamera,
                        ),
                      ] else ...[
                        const SizedBox(width: 22),
                        _CallControl(
                          icon: _speakerOn ? Icons.volume_up : Icons.hearing,
                          label: _speakerOn
                              ? 'إيقاف مكبر الصوت'
                              : 'تشغيل مكبر الصوت',
                          onPressed: _toggleSpeaker,
                          selected: _speakerOn,
                        ),
                      ],
                      const SizedBox(width: 22),
                      _CallControl(
                        icon: Icons.call_end,
                        label: 'إنهاء المكالمة',
                        onPressed: _hangUp,
                        destructive: true,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (_initializing)
              ColoredBox(
                color: Colors.black38,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(color: Colors.white),
                      const SizedBox(height: 12),
                      Text(
                        'جارٍ تهيئة ${_isVideo ? 'الكاميرا' : 'الصوت'}…',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _CallControl extends StatelessWidget {
  const _CallControl({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.selected = false,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final Future<void> Function() onPressed;
  final bool selected;
  final bool destructive;

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      IconButton.filled(
        tooltip: label,
        onPressed: () => unawaited(onPressed()),
        style: IconButton.styleFrom(
          backgroundColor: destructive
              ? Colors.red.shade700
              : selected
              ? Colors.white
              : Colors.white24,
          foregroundColor: selected && !destructive
              ? const Color(0xFF10201C)
              : Colors.white,
          fixedSize: const Size(58, 58),
        ),
        icon: Icon(icon),
      ),
      const SizedBox(height: 5),
      Text(
        label,
        textAlign: TextAlign.center,
        style: const TextStyle(color: Colors.white, fontSize: 11),
      ),
    ],
  );
}

String _formatDuration(Duration duration) =>
    '${duration.inMinutes.toString().padLeft(2, '0')}:${duration.inSeconds.remainder(60).toString().padLeft(2, '0')}';

enum IncomingCallDialogResult { answered, declined, unavailable, timedOut }

class IncomingCallPromptGate {
  final Set<String> _openCallIds = <String>{};
  final Set<String> _shownCallIds = <String>{};

  bool tryOpen(String callId) {
    if (callId.isEmpty ||
        _shownCallIds.contains(callId) ||
        !_openCallIds.add(callId)) {
      return false;
    }
    _shownCallIds.add(callId);
    return true;
  }

  void close(String callId) => _openCallIds.remove(callId);
}

class IncomingCallPromptFlow {
  bool _completed = false;
  IncomingCallDialogResult? result;

  bool get isCompleted => _completed;

  bool complete(IncomingCallDialogResult result) {
    if (_completed) return false;
    _completed = true;
    this.result = result;
    return true;
  }

  bool completeForCallStatus(String status) {
    if (status == 'ringing') return false;
    return complete(IncomingCallDialogResult.unavailable);
  }
}

class _IncomingCallDialog extends StatefulWidget {
  const _IncomingCallDialog({
    required this.call,
    required this.service,
    required this.ringtone,
    required this.timeout,
  });

  final CallRecord call;
  final CallService service;
  final IncomingCallRingtoneController ringtone;
  final Duration timeout;

  @override
  State<_IncomingCallDialog> createState() => _IncomingCallDialogState();
}

class _IncomingCallDialogState extends State<_IncomingCallDialog>
    with SingleTickerProviderStateMixin {
  Timer? _timeoutTimer;
  final IncomingCallPromptFlow _flow = IncomingCallPromptFlow();
  late final AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1450),
    )..repeat(reverse: true);
    widget.service.watchCall(widget.call.id, _onCallUpdated);
    final latest = widget.service.cachedCall(widget.call.id);
    if (latest != null && latest.status != 'ringing') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        unawaited(_complete(IncomingCallDialogResult.unavailable));
      });
    } else {
      _timeoutTimer = Timer(widget.timeout, () {
        unawaited(_complete(IncomingCallDialogResult.timedOut));
      });
    }
  }

  void _onCallUpdated(CallRecord call) {
    if (_flow.completeForCallStatus(call.status)) {
      unawaited(_finish(IncomingCallDialogResult.unavailable));
    }
  }

  Future<void> _complete(IncomingCallDialogResult result) async {
    if (!_flow.complete(result)) return;
    await _finish(result);
  }

  Future<void> _finish(IncomingCallDialogResult result) async {
    _timeoutTimer?.cancel();
    await widget.ringtone.stopForCall(widget.call.id);
    if (mounted) Navigator.of(context).pop(result);
  }

  @override
  void dispose() {
    _timeoutTimer?.cancel();
    _pulseController.dispose();
    widget.service.unwatchCall(widget.call.id);
    super.dispose();
  }

  String get _peerName {
    if (widget.call.peerName.isNotEmpty) return widget.call.peerName;
    if (widget.call.peerUsername.isNotEmpty) {
      return '@${widget.call.peerUsername}';
    }
    return 'جهة اتصال وصال';
  }

  String get _peerUserId => widget.call.callerId == widget.service.userId
      ? widget.call.calleeId
      : widget.call.callerId;

  String? get _peerAvatarUrl {
    final path = widget.call.peerAvatarPath;
    if (path == null || path.isEmpty) {
      return null;
    }
    try {
      return _callDb.storage.from('wasla-avatars').getPublicUrl(path);
    } catch (_) {
      return null;
    }
  }

  Widget _avatarFallback(double size) => Container(
    color: const Color(0xFF17333A),
    alignment: Alignment.center,
    child: Icon(
      Icons.person_rounded,
      color: Colors.white.withValues(alpha: .72),
      size: size * .44,
    ),
  );

  Widget _callerAvatar(double size) {
    final imageUrl = _peerAvatarUrl;
    final fallback = _avatarFallback(size);
    return SizedBox(
      width: size + 36,
      height: size + 36,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, _) {
              final pulse = _pulseController.value;
              final haloSize = size + 14 + pulse * 17;
              return Container(
                width: haloSize,
                height: haloSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFF49E6D1)
                        .withValues(alpha: .25 + pulse * .28),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF2DD4BF)
                          .withValues(alpha: .10 + pulse * .16),
                      blurRadius: 18 + pulse * 14,
                      spreadRadius: 2 + pulse * 3,
                    ),
                  ],
                ),
              );
            },
          ),
          Container(
            width: size,
            height: size,
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF42E6D0),
                  Color(0xFF168F82),
                  Color(0xFF56B6FF),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF28C8B1).withValues(alpha: .30),
                  blurRadius: 26,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ClipOval(
              child: imageUrl == null
                  ? fallback
                  : Image.network(
                      imageUrl,
                      fit: BoxFit.cover,
                      width: size,
                      height: size,
                      errorBuilder: (context, error, stackTrace) => fallback,
                      loadingBuilder: (context, child, progress) =>
                          progress == null
                          ? child
                          : ColoredBox(
                              color: const Color(0xFF17333A),
                              child: Center(
                                child: SizedBox(
                                  width: 24,
                                  height: 24,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: const Color(0xFF62E8D3)
                                        .withValues(alpha: .8),
                                  ),
                                ),
                              ),
                            ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ringWaves() => AnimatedBuilder(
    animation: _pulseController,
    builder: (context, _) => Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: List<Widget>.generate(9, (index) {
        final distance = (index - 4).abs();
        final phase = (_pulseController.value + index * .14) % 1;
        final height = 8 + (1 - distance / 5) * (8 + phase * 13);
        return Container(
          width: 3.5,
          height: height,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: const Color(0xFF5DE4D0).withValues(alpha: .42 + phase * .45),
            borderRadius: BorderRadius.circular(8),
          ),
        );
      }),
    ),
  );

  Widget _callAction({
    required IconData icon,
    required String label,
    required Color color,
    required IncomingCallDialogResult result,
  }) => Semantics(
    button: true,
    label: label,
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: color,
          shape: const CircleBorder(),
          elevation: 16,
          shadowColor: color.withValues(alpha: .38),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => unawaited(_complete(result)),
            child: SizedBox(
              width: 78,
              height: 78,
              child: Icon(icon, color: Colors.white, size: 34),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 15,
          ),
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) => Dialog.fullscreen(
    backgroundColor: const Color(0xFF071118),
    child: AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Color(0xFF071118),
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: const Color(0xFF071118),
          body: Stack(
            children: [
              const Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF102431),
                        Color(0xFF08151E),
                        Color(0xFF050B10),
                      ],
                      stops: [0, .48, 1],
                    ),
                  ),
                ),
              ),
              Positioned(
                top: -120,
                left: -80,
                child: IgnorePointer(
                  child: Container(
                    width: 300,
                    height: 300,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFF18B7A5).withValues(alpha: .22),
                          const Color(0xFF18B7A5).withValues(alpha: 0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: -150,
                right: -100,
                child: IgnorePointer(
                  child: Container(
                    width: 340,
                    height: 340,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFF1975A8).withValues(alpha: .18),
                          const Color(0xFF1975A8).withValues(alpha: 0),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SafeArea(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final avatarSize = (constraints.maxHeight * .30)
                        .clamp(142.0, 222.0)
                        .toDouble();
                    final compact = constraints.maxHeight < 620;
                    return Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: 26,
                        vertical: compact ? 12 : 20,
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(
                                Icons.call_received_rounded,
                                size: 17,
                                color: Color(0xFF70E8D8),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'مكالمة واردة',
                                style: TextStyle(
                                  color: Colors.white.withValues(alpha: .84),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: .2,
                                ),
                              ),
                            ],
                          ),
                          const Spacer(flex: 2),
                          _callerAvatar(avatarSize),
                          const SizedBox(height: 14),
                          AdminIdentityText(
                            userId: _peerUserId,
                            label: _peerName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                              height: 1.2,
                            ),
                          ),
                          if (widget.call.peerUsername.isNotEmpty &&
                              widget.call.peerName.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              '@${widget.call.peerUsername}',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: .55),
                                fontSize: 14,
                              ),
                            ),
                          ],
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 15,
                              vertical: 9,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: .07),
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: .08),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  widget.call.isVideo
                                      ? Icons.videocam_rounded
                                      : Icons.call_rounded,
                                  color: const Color(0xFF66DECE),
                                  size: 18,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  widget.call.isVideo
                                      ? 'مكالمة مرئية'
                                      : 'مكالمة صوتية',
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: .82),
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: compact ? 15 : 22),
                          _ringWaves(),
                          const Spacer(flex: 3),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _callAction(
                                icon: Icons.call_end_rounded,
                                label: 'رفض',
                                color: const Color(0xFFE44859),
                                result: IncomingCallDialogResult.declined,
                              ),
                              _callAction(
                                icon: Icons.call_rounded,
                                label: 'قبول',
                                color: const Color(0xFF18A873),
                                result: IncomingCallDialogResult.answered,
                              ),
                            ],
                          ),
                          SizedBox(height: compact ? 8 : 14),
                          Text(
                            'اختر قبول المكالمة أو رفضها',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: .40),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

Future<void> showIncomingCallDialog(
  BuildContext context, {
  required CallRecord call,
  required CallService service,
  required IncomingCallRingtoneController ringtone,
  required Duration timeout,
}) async {
  final result = await showGeneralDialog<IncomingCallDialogResult>(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'مكالمة واردة',
    barrierColor: Colors.transparent,
    transitionDuration: const Duration(milliseconds: 320),
    pageBuilder: (context, animation, secondaryAnimation) =>
        _IncomingCallDialog(
          call: call,
          service: service,
          ringtone: ringtone,
          timeout: timeout,
        ),
    transitionBuilder: (context, animation, secondaryAnimation, child) {
      final eased = CurvedAnimation(
        parent: animation,
        curve: Curves.easeOutCubic,
      );
      return FadeTransition(
        opacity: eased,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, .035),
            end: Offset.zero,
          ).animate(eased),
          child: child,
        ),
      );
    },
  );
  try {
    if (!context.mounted) return;
    if (result == IncomingCallDialogResult.answered) {
      await service.accept(call.id);
      await ringtone.stopForCall(call.id);
      if (!context.mounted) return;
      await Navigator.of(context).push<void>(
        callScreenRoute(service: service, call: call, ringtone: ringtone),
      );
    } else if (result == IncomingCallDialogResult.declined || result == null) {
      await ringtone.stopForCall(call.id);
      await service.finish(call);
    } else if (result == IncomingCallDialogResult.timedOut) {
      await ringtone.stopForCall(call.id);
      await service.markMissed(call);
    } else {
      await ringtone.stopForCall(call.id);
    }
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تعذر تنفيذ المكالمة. تحقق من الاتصال ثم حاول مجددًا.'),
        ),
      );
    }
  } finally {
    await ringtone.stopForCall(call.id);
  }
}
