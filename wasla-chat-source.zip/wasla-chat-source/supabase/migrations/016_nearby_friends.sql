-- Wasla 1.9.7: opt-in nearby people discovery.
-- Store only coarse coordinates, expose no direct table access, and require
-- both sides to opt in with a fresh foreground location before discovery.

create table if not exists public.nearby_user_locations (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  is_enabled boolean not null default false,
  latitude double precision,
  longitude double precision,
  updated_at timestamptz,
  constraint nearby_user_locations_coordinate_pair check (
    (latitude is null and longitude is null and updated_at is null)
    or (latitude is not null and longitude is not null and updated_at is not null)
  ),
  constraint nearby_user_locations_latitude_range check (
    latitude is null or latitude between -90 and 90
  ),
  constraint nearby_user_locations_longitude_range check (
    longitude is null or longitude between -180 and 180
  )
);

create index if not exists nearby_user_locations_recent_idx
  on public.nearby_user_locations (updated_at desc)
  where is_enabled and latitude is not null;

alter table public.nearby_user_locations enable row level security;
revoke all on public.nearby_user_locations from public, anon, authenticated;

create or replace function public.get_nearby_visibility()
returns boolean
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_enabled boolean;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  select n.is_enabled into v_enabled
  from public.nearby_user_locations n
  where n.user_id = v_me;
  return coalesce(v_enabled, false);
end;
$$;

create or replace function public.set_nearby_visibility(p_enabled boolean)
returns boolean
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if coalesce(p_enabled, false) then
    insert into public.nearby_user_locations(user_id, is_enabled)
    values (v_me, true)
    on conflict (user_id) do update set
      is_enabled = true,
      latitude = null,
      longitude = null,
      updated_at = null;
    return true;
  end if;

  delete from public.nearby_user_locations where user_id = v_me;
  return false;
end;
$$;

create or replace function public.publish_nearby_location(
  p_latitude double precision,
  p_longitude double precision
)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_latitude is null or p_longitude is null
    or p_latitude < -90 or p_latitude > 90
    or p_longitude < -180 or p_longitude > 180 then
    raise exception 'Invalid coordinates';
  end if;

  -- Keep an approximately kilometre-scale grid cell, never the supplied GPS fix.
  update public.nearby_user_locations
  set latitude = round(p_latitude::numeric, 2)::double precision,
      longitude = round(p_longitude::numeric, 2)::double precision,
      updated_at = now()
  where user_id = v_me and is_enabled;
  if not found then raise exception 'Nearby visibility is disabled'; end if;
end;
$$;

create or replace function public.clear_nearby_location()
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  update public.nearby_user_locations
  set latitude = null, longitude = null, updated_at = null
  where user_id = v_me;
end;
$$;

create or replace function public.find_nearby_people(p_limit integer default 50)
returns table (
  user_id uuid,
  username text,
  display_name text,
  avatar_path text,
  bio text,
  distance_label text,
  friendship_status text,
  requester_id uuid,
  addressee_id uuid
)
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;

  -- Discovery is reciprocal: the viewer must also opt in and have a fresh
  -- foreground location. No raw coordinates are returned by this function.
  if not exists (
    select 1 from public.nearby_user_locations mine
    where mine.user_id = v_me and mine.is_enabled
      and mine.latitude is not null
      and mine.updated_at >= now() - interval '2 minutes'
  ) then
    return;
  end if;

  return query
  with my_location as (
    select mine.latitude, mine.longitude
    from public.nearby_user_locations mine
    where mine.user_id = v_me and mine.is_enabled
      and mine.latitude is not null
      and mine.updated_at >= now() - interval '2 minutes'
  ), candidates as (
    select
      p.id as candidate_id,
      p.username as candidate_username,
      p.display_name as candidate_display_name,
      p.avatar_path as candidate_avatar_path,
      p.bio as candidate_bio,
      fr.status as candidate_friendship_status,
      fr.requester_id as candidate_requester_id,
      fr.addressee_id as candidate_addressee_id,
      6371.0088 * acos(least(1.0, greatest(-1.0,
        sin(radians(mine.latitude)) * sin(radians(other_location.latitude))
        + cos(radians(mine.latitude)) * cos(radians(other_location.latitude))
          * cos(radians(other_location.longitude - mine.longitude))
      ))) as distance_km
    from my_location mine
    join public.nearby_user_locations other_location
      on other_location.user_id <> v_me
      and other_location.is_enabled
      and other_location.latitude is not null
      and other_location.updated_at >= now() - interval '2 minutes'
    join public.profiles p on p.id = other_location.user_id
    left join public.friend_requests fr
      on fr.user_low_id = least(v_me, other_location.user_id)
      and fr.user_high_id = greatest(v_me, other_location.user_id)
    where fr.status is distinct from 'accepted'
  )
  select
    c.candidate_id,
    c.candidate_username,
    c.candidate_display_name,
    c.candidate_avatar_path,
    c.candidate_bio,
    case
      when c.distance_km < 2 then 'أقل من ٢ كم'
      when c.distance_km < 5 then '٢–٥ كم تقريبًا'
      when c.distance_km < 10 then '٥–١٠ كم تقريبًا'
      when c.distance_km < 25 then '١٠–٢٥ كم تقريبًا'
      else '٢٥–٥٠ كم تقريبًا'
    end,
    coalesce(c.candidate_friendship_status, 'none'),
    c.candidate_requester_id,
    c.candidate_addressee_id
  from candidates c
  where c.distance_km <= 50
  order by c.distance_km, lower(coalesce(nullif(c.candidate_display_name, ''), c.candidate_username))
  limit greatest(1, least(coalesce(p_limit, 50), 100));
end;
$$;

revoke all on function public.get_nearby_visibility() from public, anon;
revoke all on function public.set_nearby_visibility(boolean) from public, anon;
revoke all on function public.publish_nearby_location(double precision, double precision) from public, anon;
revoke all on function public.clear_nearby_location() from public, anon;
revoke all on function public.find_nearby_people(integer) from public, anon;
grant execute on function public.get_nearby_visibility() to authenticated;
grant execute on function public.set_nearby_visibility(boolean) to authenticated;
grant execute on function public.publish_nearby_location(double precision, double precision) to authenticated;
grant execute on function public.clear_nearby_location() to authenticated;
grant execute on function public.find_nearby_people(integer) to authenticated;
