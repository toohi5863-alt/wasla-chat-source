import 'package:flutter/material.dart';

class MediaSaveOptionsScreen extends StatelessWidget {
  const MediaSaveOptionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('حفظ الوسائط والحالات')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          Card(
            color: theme.colorScheme.primaryContainer,
            child: const Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.download_for_offline_outlined, size: 30),
                  SizedBox(height: 12),
                  Text(
                    'الحفظ باختيارك',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'لا يحفظ وصال أي وسائط أو حالات تلقائيًا. افتح الصورة أو الملف في المحادثة، أو افتح الحالة، ثم اضغط «حفظ في الهاتف».',
                    style: TextStyle(height: 1.55),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const _SaveDestinationTile(
            icon: Icons.photo_library_outlined,
            title: 'الصور والفيديو',
            detail: 'تظهر الصور في Pictures/Wasla والفيديو في Movies/Wasla داخل معرض الهاتف.',
          ),
          const _SaveDestinationTile(
            icon: Icons.folder_outlined,
            title: 'الصوت والملفات',
            detail: 'تُحفظ في مجلد Download/Wasla ويمكن فتحها من مدير الملفات.',
          ),
          const _SaveDestinationTile(
            icon: Icons.lock_outline_rounded,
            title: 'الخصوصية',
            detail: 'النسخة المحفوظة موجودة على جهازك ولا تُرفع إلى وصال. لا يرسل التطبيق إشعارًا لصاحب الحالة عند الحفظ. قد تبقى نسخة الحالة على الهاتف بعد انتهائها تلقائيًا خلال 24 ساعة؛ احذفها من المعرض أو التنزيلات إذا لم تعد تريد الاحتفاظ بها.',
          ),
          const _SaveDestinationTile(
            icon: Icons.admin_panel_settings_outlined,
            title: 'الأذونات والحدود',
            detail: 'على Android 10 أو أحدث لا يحتاج الحفظ إلى إذن تخزين عام. على Android 9 أو أقدم يطلب التطبيق إذن التخزين عند أول محاولة حفظ. يتطلب الحفظ اتصالًا لتنزيل نسخة الوسيط، ومساحة كافية على الهاتف؛ هذه الميزة متاحة حاليًا على Android.',
          ),
        ],
      ),
    );
  }
}

class _SaveDestinationTile extends StatelessWidget {
  const _SaveDestinationTile({
    required this.icon,
    required this.title,
    required this.detail,
  });

  final IconData icon;
  final String title;
  final String detail;

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 6),
        child: Text(detail, style: const TextStyle(height: 1.45)),
      ),
      isThreeLine: true,
    ),
  );
}
