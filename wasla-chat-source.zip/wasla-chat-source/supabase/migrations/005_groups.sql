-- Wasla 1.3: additive group-chat support. Existing direct conversations, messages,
-- profiles, and receipts are retained unchanged.

create table if not exists public.groups (
  conversation_id uuid primary key references public.conversations(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 2 and 80),
  description text not null default '' check (char_length(description) <= 500),
  avatar_path text,
  owner_id uuid not null references public.profiles(id),
  is_private boolean not null default false,
  members_can_message boolean not null default true,
  members_can_add boolean not null default false,
  members_can_edit_info boolean not null default false,
  admins_can_manage_members boolean not null default true,
  admins_can_pin_messages boolean not null default true,
  admins_can_delete_messages boolean not null default true,
  files_allowed boolean not null default true,
  voice_allowed boolean not null default true,
  calls_allowed boolean not null default false,
  invite_token text not null unique default encode(extensions.gen_random_bytes(18), 'hex'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.group_members (
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner', 'admin', 'member')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id),
  constraint group_members_conversation_member_fkey
    foreign key (conversation_id, user_id)
    references public.conversation_members(conversation_id, user_id) on delete cascade
);

create table if not exists public.group_banned_users (
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  banned_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.group_join_requests (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  message text not null default '' check (char_length(message) <= 300),
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected')),
  requested_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by uuid references public.profiles(id)
);
create unique index if not exists group_join_requests_pending_unique
  on public.group_join_requests(conversation_id, user_id) where status = 'pending';

create table if not exists public.group_pinned_messages (
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  pinned_by uuid not null references public.profiles(id),
  pinned_at timestamptz not null default now(),
  primary key (conversation_id, message_id)
);

create table if not exists public.group_activity (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.groups(conversation_id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_user_id uuid references public.profiles(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.message_reactions (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null check (char_length(emoji) between 1 and 12),
  created_at timestamptz not null default now(),
  primary key (message_id, user_id, emoji)
);

alter table public.messages
  add column if not exists reply_to uuid,
  add column if not exists edited_at timestamptz;
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.messages'::regclass
      and conname = 'messages_reply_to_fkey'
  ) then
    alter table public.messages add constraint messages_reply_to_fkey
      foreign key (reply_to) references public.messages(id) on delete set null;
  end if;
end;
$$;

-- The original media types remain valid; the additions are scoped to the same
-- member-only storage paths and are separately permission-checked below.
alter table public.messages drop constraint if exists messages_type_media_check;
alter table public.messages add constraint messages_type_media_check check (
  (message_type = 'text' and media_path is null and media_duration_seconds is null)
  or (message_type in ('image', 'video', 'file') and media_path is not null
      and media_duration_seconds is null)
  or (message_type = 'audio' and media_path is not null
      and media_duration_seconds between 1 and 180)
  or (message_type = 'location' and media_path is null
      and media_duration_seconds is null)
);

create index if not exists group_members_user_idx
  on public.group_members(user_id, conversation_id);
create index if not exists group_activity_recent_idx
  on public.group_activity(conversation_id, created_at desc);
create index if not exists group_pins_recent_idx
  on public.group_pinned_messages(conversation_id, pinned_at desc);
create index if not exists message_reactions_message_idx
  on public.message_reactions(message_id);

-- Keep private media private while allowing the supported video/document types.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('wasla-media', 'wasla-media', false, 15728640, array[
  'image/jpeg', 'image/png', 'image/webp', 'audio/mp4', 'audio/aac',
  'audio/x-m4a', 'audio/mpeg', 'audio/webm', 'video/mp4', 'video/quicktime',
  'video/webm', 'application/pdf', 'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain', 'text/csv', 'application/zip', 'application/octet-stream'
])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

alter table public.groups enable row level security;
alter table public.group_members enable row level security;
alter table public.group_banned_users enable row level security;
alter table public.group_join_requests enable row level security;
alter table public.group_pinned_messages enable row level security;
alter table public.group_activity enable row level security;
alter table public.message_reactions enable row level security;

create or replace function private.is_group_admin(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.conversation_id = p_conversation_id
      and gm.user_id = auth.uid()
      and gm.role in ('owner', 'admin')
  );
$$;
revoke all on function private.is_group_admin(uuid) from public, anon;
grant execute on function private.is_group_admin(uuid) to authenticated;

create or replace function private.is_group_owner(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.groups g
    where g.conversation_id = p_conversation_id and g.owner_id = auth.uid()
  );
$$;
revoke all on function private.is_group_owner(uuid) from public, anon;
grant execute on function private.is_group_owner(uuid) to authenticated;

create or replace function private.can_manage_group_members(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.groups g
    join public.group_members gm on gm.conversation_id = g.conversation_id
    where g.conversation_id = p_conversation_id and gm.user_id = auth.uid()
      and (gm.role = 'owner' or (gm.role = 'admin' and g.admins_can_manage_members))
  );
$$;
revoke all on function private.can_manage_group_members(uuid) from public, anon;
grant execute on function private.can_manage_group_members(uuid) to authenticated;

create or replace function private.can_pin_group_messages(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.groups g
    join public.group_members gm on gm.conversation_id = g.conversation_id
    where g.conversation_id = p_conversation_id and gm.user_id = auth.uid()
      and (gm.role = 'owner' or (gm.role = 'admin' and g.admins_can_pin_messages))
  );
$$;
revoke all on function private.can_pin_group_messages(uuid) from public, anon;
grant execute on function private.can_pin_group_messages(uuid) to authenticated;

create or replace function private.can_delete_group_messages(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.groups g
    join public.group_members gm on gm.conversation_id = g.conversation_id
    where g.conversation_id = p_conversation_id and gm.user_id = auth.uid()
      and (gm.role = 'owner' or (gm.role = 'admin' and g.admins_can_delete_messages))
  );
$$;
revoke all on function private.can_delete_group_messages(uuid) from public, anon;
grant execute on function private.can_delete_group_messages(uuid) to authenticated;

create policy groups_select_member on public.groups
  for select to authenticated using (private.is_conversation_member(conversation_id));
create policy group_members_select_member on public.group_members
  for select to authenticated using (private.is_conversation_member(conversation_id));
create policy group_banned_select_admin on public.group_banned_users
  for select to authenticated using (private.is_group_admin(conversation_id));
create policy group_join_requests_select_owner_or_admin on public.group_join_requests
  for select to authenticated using (
    user_id = (select auth.uid()) or private.is_group_admin(conversation_id)
  );
create policy group_pins_select_member on public.group_pinned_messages
  for select to authenticated using (private.is_conversation_member(conversation_id));
create policy group_activity_select_member on public.group_activity
  for select to authenticated using (private.is_conversation_member(conversation_id));
create policy message_reactions_select_member on public.message_reactions
  for select to authenticated using (
    exists (select 1 from public.messages m
      where m.id = message_id and private.is_conversation_member(m.conversation_id))
  );
create policy message_reactions_insert_self on public.message_reactions
  for insert to authenticated with check (
    user_id = (select auth.uid()) and exists (
      select 1 from public.messages m
      where m.id = message_id and private.is_conversation_member(m.conversation_id)
    )
  );
create policy message_reactions_delete_self on public.message_reactions
  for delete to authenticated using (user_id = (select auth.uid()));

revoke all on public.groups, public.group_members, public.group_banned_users,
  public.group_join_requests, public.group_pinned_messages, public.group_activity,
  public.message_reactions from anon, authenticated;
grant select on public.groups, public.group_members, public.group_join_requests,
  public.group_banned_users, public.group_pinned_messages, public.group_activity,
  public.message_reactions to authenticated;
grant insert, delete on public.message_reactions to authenticated;

-- Enforce group write settings inside Postgres, not just in the Flutter UI.
drop policy if exists messages_insert_as_member on public.messages;
create policy messages_insert_as_member on public.messages
  for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and private.is_conversation_member(conversation_id)
    and (
      not exists (select 1 from public.groups g where g.conversation_id = messages.conversation_id)
      or exists (
        select 1
        from public.groups g
        join public.group_members gm on gm.conversation_id = g.conversation_id
          and gm.user_id = (select auth.uid())
        where g.conversation_id = messages.conversation_id
          and (g.members_can_message or gm.role in ('owner', 'admin'))
          and (message_type not in ('image', 'video', 'file') or g.files_allowed)
          and (message_type <> 'audio' or g.voice_allowed)
      )
    )
  );

-- Atomic group creation; each group gets a regular conversations row so the
-- existing message, receipt, and private-media paths continue to work.
create or replace function public.create_group(
  p_name text,
  p_description text default '',
  p_member_ids uuid[] default '{}',
  p_is_private boolean default false
)
returns uuid
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_conversation_id uuid;
  v_count integer;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if char_length(trim(coalesce(p_name, ''))) not between 2 and 80 then
    raise exception 'Group name must be between 2 and 80 characters';
  end if;
  if char_length(coalesce(p_description, '')) > 500 then
    raise exception 'Group description is too long';
  end if;
  if coalesce(cardinality(p_member_ids), 0) > 99 then
    raise exception 'A group can include at most 100 people';
  end if;
  select count(distinct x) into v_count from unnest(coalesce(p_member_ids, '{}'::uuid[])) x;
  if v_count <> (select count(*) from public.profiles p where p.id = any(coalesce(p_member_ids, '{}'::uuid[]))) then
    raise exception 'One or more selected users do not exist';
  end if;
  if v_me = any(coalesce(p_member_ids, '{}'::uuid[])) then
    raise exception 'The group creator is added automatically';
  end if;

  insert into public.conversations default values returning id into v_conversation_id;
  insert into public.groups(conversation_id, name, description, owner_id, is_private)
    values (v_conversation_id, trim(p_name), coalesce(p_description, ''), v_me,
      coalesce(p_is_private, false));
  insert into public.conversation_members(conversation_id, user_id)
    values (v_conversation_id, v_me);
  insert into public.group_members(conversation_id, user_id, role)
    values (v_conversation_id, v_me, 'owner');
  insert into public.conversation_members(conversation_id, user_id)
    select v_conversation_id, p.id from public.profiles p
    where p.id = any(coalesce(p_member_ids, '{}'::uuid[]))
    on conflict do nothing;
  insert into public.group_members(conversation_id, user_id, role)
    select v_conversation_id, p.id, 'member' from public.profiles p
    where p.id = any(coalesce(p_member_ids, '{}'::uuid[]))
    on conflict do nothing;
  insert into public.group_activity(conversation_id, actor_id, action, details)
    values (v_conversation_id, v_me, 'group_created', jsonb_build_object('name', trim(p_name)));
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    select v_conversation_id, v_me, 'member_added', p.id from public.profiles p
    where p.id = any(coalesce(p_member_ids, '{}'::uuid[]));
  return v_conversation_id;
end;
$$;

create or replace function public.add_group_members(p_conversation_id uuid, p_user_ids uuid[])
returns integer
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_added integer;
begin
  if v_me is null or not private.is_conversation_member(p_conversation_id) then
    raise exception 'Not a group member';
  end if;
  if not exists (select 1 from public.groups g where g.conversation_id = p_conversation_id) then
    raise exception 'Group not found';
  end if;
  if not private.can_manage_group_members(p_conversation_id) and not exists (
    select 1 from public.groups g where g.conversation_id = p_conversation_id and g.members_can_add
  ) then raise exception 'You cannot add members'; end if;
  if coalesce(cardinality(p_user_ids), 0) > 99 then raise exception 'Too many members'; end if;
  if exists (select 1 from public.group_banned_users b where b.conversation_id = p_conversation_id
    and b.user_id = any(coalesce(p_user_ids, '{}'::uuid[]))) then
    raise exception 'A selected user is banned from this group';
  end if;
  if exists (select 1 from unnest(coalesce(p_user_ids, '{}'::uuid[])) x
    where not exists (select 1 from public.profiles p where p.id = x)) then
    raise exception 'One or more selected users do not exist';
  end if;
  insert into public.conversation_members(conversation_id, user_id)
    select p_conversation_id, p.id from public.profiles p
    where p.id = any(coalesce(p_user_ids, '{}'::uuid[]))
    on conflict do nothing;
  with added as (
    insert into public.group_members(conversation_id, user_id, role)
      select p_conversation_id, p.id, 'member' from public.profiles p
      where p.id = any(coalesce(p_user_ids, '{}'::uuid[]))
      on conflict do nothing returning user_id
  )
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    select p_conversation_id, v_me, 'member_added', a.user_id from added a;
  get diagnostics v_added = row_count;
  return v_added;
end;
$$;

create or replace function public.remove_group_member(p_conversation_id uuid, p_user_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_target_role text;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  select gm.role into v_target_role from public.group_members gm
    where gm.conversation_id = p_conversation_id and gm.user_id = p_user_id;
  if v_target_role is null then raise exception 'Member not found'; end if;
  if p_user_id = v_me then
    if v_target_role = 'owner' then raise exception 'Transfer ownership before leaving'; end if;
  elsif private.is_group_owner(p_conversation_id) then
    null;
  elsif not private.can_manage_group_members(p_conversation_id) then
    raise exception 'Only an authorized moderator can remove another member';
  elsif v_target_role in ('owner', 'admin') then
    raise exception 'Insufficient role';
  end if;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (p_conversation_id, v_me,
      case when p_user_id = v_me then 'member_left' else 'member_removed' end, p_user_id);
  delete from public.group_members where conversation_id = p_conversation_id and user_id = p_user_id;
  delete from public.conversation_members where conversation_id = p_conversation_id and user_id = p_user_id;
end;
$$;

create or replace function public.set_group_member_role(
  p_conversation_id uuid, p_user_id uuid, p_role text
)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid();
begin
  if v_me is null or not private.is_group_owner(p_conversation_id) then
    raise exception 'Only the owner can change administrator roles';
  end if;
  if p_role not in ('admin', 'member') then raise exception 'Invalid role'; end if;
  if p_user_id = v_me then raise exception 'The owner role cannot be changed'; end if;
  update public.group_members set role = p_role
    where conversation_id = p_conversation_id and user_id = p_user_id and role <> 'owner';
  if not found then raise exception 'Member not found'; end if;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id, details)
    values (p_conversation_id, v_me,
      case when p_role = 'admin' then 'member_promoted' else 'admin_demoted' end,
      p_user_id, jsonb_build_object('role', p_role));
end;
$$;

create or replace function public.ban_group_member(p_conversation_id uuid, p_user_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_target_role text;
begin
  if v_me is null or not private.can_manage_group_members(p_conversation_id) then
    raise exception 'Only an admin can ban members';
  end if;
  select role into v_target_role from public.group_members
    where conversation_id = p_conversation_id and user_id = p_user_id;
  if v_target_role is null then raise exception 'Member not found'; end if;
  if v_target_role = 'owner' or (v_target_role = 'admin' and not private.is_group_owner(p_conversation_id)) then
    raise exception 'Insufficient role';
  end if;
  insert into public.group_banned_users(conversation_id, user_id, banned_by)
    values (p_conversation_id, p_user_id, v_me) on conflict do nothing;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (p_conversation_id, v_me, 'member_banned', p_user_id);
  delete from public.group_members where conversation_id = p_conversation_id and user_id = p_user_id;
  delete from public.conversation_members where conversation_id = p_conversation_id and user_id = p_user_id;
end;
$$;

create or replace function public.update_group_info(
  p_conversation_id uuid, p_name text, p_description text, p_avatar_path text
)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_old_name text; v_old_avatar text;
begin
  select name, avatar_path into v_old_name, v_old_avatar from public.groups where conversation_id = p_conversation_id for update;
  if v_old_name is null then raise exception 'Group not found'; end if;
  if not private.is_group_admin(p_conversation_id) and not exists (
    select 1 from public.groups g where g.conversation_id = p_conversation_id and g.members_can_edit_info
  ) then raise exception 'You cannot edit group information'; end if;
  if char_length(trim(coalesce(p_name, ''))) not between 2 and 80 then raise exception 'Invalid group name'; end if;
  if char_length(coalesce(p_description, '')) > 500 then raise exception 'Description is too long'; end if;
  if p_avatar_path is not null and (split_part(p_avatar_path, '/', 1) <> p_conversation_id::text
    or split_part(p_avatar_path, '/', 3) = ''
    or not exists (select 1 from public.group_members gm
      where gm.conversation_id = p_conversation_id
        and gm.user_id::text = split_part(p_avatar_path, '/', 2))) then
    raise exception 'Invalid group avatar path';
  end if;
  update public.groups set name = trim(p_name), description = coalesce(p_description, ''),
    avatar_path = p_avatar_path, updated_at = now()
    where conversation_id = p_conversation_id;
  if v_old_name <> trim(p_name) then
    insert into public.group_activity(conversation_id, actor_id, action, details)
      values (p_conversation_id, v_me, 'group_name_changed', jsonb_build_object('name', trim(p_name)));
  end if;
  if v_old_avatar is distinct from p_avatar_path then
    insert into public.group_activity(conversation_id, actor_id, action)
      values (p_conversation_id, v_me, 'group_avatar_changed');
  end if;
  insert into public.group_activity(conversation_id, actor_id, action)
    values (p_conversation_id, v_me, 'group_info_changed');
end;
$$;

create or replace function public.update_group_settings(
  p_conversation_id uuid,
  p_members_can_message boolean,
  p_members_can_add boolean,
  p_members_can_edit_info boolean,
  p_admins_can_manage_members boolean,
  p_admins_can_pin_messages boolean,
  p_admins_can_delete_messages boolean,
  p_files_allowed boolean,
  p_voice_allowed boolean,
  p_calls_allowed boolean
)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid();
begin
  if v_me is null or not private.is_group_owner(p_conversation_id) then
    raise exception 'Only the owner can edit group settings';
  end if;
  update public.groups set
    members_can_message = p_members_can_message,
    members_can_add = p_members_can_add,
    members_can_edit_info = p_members_can_edit_info,
    admins_can_manage_members = p_admins_can_manage_members,
    admins_can_pin_messages = p_admins_can_pin_messages,
    admins_can_delete_messages = p_admins_can_delete_messages,
    files_allowed = p_files_allowed,
    voice_allowed = p_voice_allowed,
    calls_allowed = p_calls_allowed,
    updated_at = now()
  where conversation_id = p_conversation_id;
  if not found then raise exception 'Group not found'; end if;
  insert into public.group_activity(conversation_id, actor_id, action, details)
    values (p_conversation_id, v_me, 'settings_changed', jsonb_build_object(
      'members_can_message', p_members_can_message,
      'members_can_add', p_members_can_add,
      'members_can_edit_info', p_members_can_edit_info,
      'admins_can_manage_members', p_admins_can_manage_members,
      'admins_can_pin_messages', p_admins_can_pin_messages,
      'admins_can_delete_messages', p_admins_can_delete_messages,
      'files_allowed', p_files_allowed,
      'voice_allowed', p_voice_allowed,
      'calls_allowed', p_calls_allowed));
end;
$$;

create or replace function public.rotate_group_invite(p_conversation_id uuid)
returns text
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_token text;
begin
  if not private.can_manage_group_members(p_conversation_id) then raise exception 'Only admins can manage invite links'; end if;
  update public.groups set invite_token = encode(extensions.gen_random_bytes(18), 'hex'), updated_at = now()
    where conversation_id = p_conversation_id returning invite_token into v_token;
  if v_token is null then raise exception 'Group not found'; end if;
  insert into public.group_activity(conversation_id, actor_id, action)
    values (p_conversation_id, auth.uid(), 'invite_rotated');
  return v_token;
end;
$$;

create or replace function public.join_group_by_invite(p_token text, p_message text default '')
returns jsonb
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_group public.groups%rowtype; v_request_id uuid;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if char_length(coalesce(p_message, '')) > 300 then raise exception 'Message is too long'; end if;
  select * into v_group from public.groups where invite_token = trim(coalesce(p_token, ''));
  if not found then raise exception 'Invite link is invalid or expired'; end if;
  if exists (select 1 from public.group_banned_users b where b.conversation_id = v_group.conversation_id and b.user_id = v_me) then
    raise exception 'You cannot join this group';
  end if;
  if exists (select 1 from public.group_members gm where gm.conversation_id = v_group.conversation_id and gm.user_id = v_me) then
    return jsonb_build_object('status', 'already_member', 'conversation_id', v_group.conversation_id, 'group_name', v_group.name);
  end if;
  if v_group.is_private then
    select id into v_request_id from public.group_join_requests
      where conversation_id = v_group.conversation_id and user_id = v_me and status = 'pending';
    if v_request_id is null then
      insert into public.group_join_requests(conversation_id, user_id, message)
        values (v_group.conversation_id, v_me, coalesce(p_message, '')) returning id into v_request_id;
      insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
        values (v_group.conversation_id, v_me, 'join_requested', v_me);
    end if;
    return jsonb_build_object('status', 'request_pending', 'conversation_id', v_group.conversation_id,
      'group_name', v_group.name, 'request_id', v_request_id);
  end if;
  insert into public.conversation_members(conversation_id, user_id) values (v_group.conversation_id, v_me)
    on conflict do nothing;
  insert into public.group_members(conversation_id, user_id, role) values (v_group.conversation_id, v_me, 'member')
    on conflict do nothing;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (v_group.conversation_id, v_me, 'member_joined', v_me);
  return jsonb_build_object('status', 'joined', 'conversation_id', v_group.conversation_id, 'group_name', v_group.name);
end;
$$;

create or replace function public.resolve_group_join_request(p_request_id uuid, p_accept boolean)
returns uuid
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid(); v_req public.group_join_requests%rowtype;
begin
  select * into v_req from public.group_join_requests where id = p_request_id for update;
  if not found or not private.is_group_admin(v_req.conversation_id) then raise exception 'Request not found or insufficient permission'; end if;
  if v_req.status <> 'pending' then raise exception 'Request has already been resolved'; end if;
  if p_accept then
    if exists (select 1 from public.group_banned_users b where b.conversation_id = v_req.conversation_id and b.user_id = v_req.user_id) then
      raise exception 'This user is banned';
    end if;
    insert into public.conversation_members(conversation_id, user_id) values (v_req.conversation_id, v_req.user_id)
      on conflict do nothing;
    insert into public.group_members(conversation_id, user_id, role) values (v_req.conversation_id, v_req.user_id, 'member')
      on conflict do nothing;
  end if;
  update public.group_join_requests set status = case when p_accept then 'accepted' else 'rejected' end,
    resolved_at = now(), resolved_by = v_me where id = p_request_id;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (v_req.conversation_id, v_me, case when p_accept then 'join_request_accepted' else 'join_request_rejected' end, v_req.user_id);
  return v_req.conversation_id;
end;
$$;

create or replace function public.transfer_group_owner(p_conversation_id uuid, p_user_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid();
begin
  if v_me is null or not private.is_group_owner(p_conversation_id) then raise exception 'Only the current owner can transfer ownership'; end if;
  if p_user_id = v_me or not exists (select 1 from public.group_members gm
    where gm.conversation_id = p_conversation_id and gm.user_id = p_user_id) then
    raise exception 'Choose another current member';
  end if;
  update public.group_members set role = 'admin' where conversation_id = p_conversation_id and user_id = v_me;
  update public.group_members set role = 'owner' where conversation_id = p_conversation_id and user_id = p_user_id;
  update public.groups set owner_id = p_user_id, updated_at = now() where conversation_id = p_conversation_id;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (p_conversation_id, v_me, 'ownership_transferred', p_user_id);
end;
$$;

create or replace function public.leave_group(p_conversation_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_me uuid := auth.uid();
begin
  if v_me is null or not private.is_conversation_member(p_conversation_id) then raise exception 'Not a group member'; end if;
  if private.is_group_owner(p_conversation_id) then raise exception 'Transfer ownership before leaving'; end if;
  insert into public.group_activity(conversation_id, actor_id, action, target_user_id)
    values (p_conversation_id, v_me, 'member_left', v_me);
  delete from public.group_members where conversation_id = p_conversation_id and user_id = v_me;
  delete from public.conversation_members where conversation_id = p_conversation_id and user_id = v_me;
end;
$$;

create or replace function public.delete_group(p_conversation_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
begin
  if not private.is_group_owner(p_conversation_id) then raise exception 'Only the owner can delete the group'; end if;
  delete from public.conversations where id = p_conversation_id;
end;
$$;

create or replace function public.set_group_message_pinned(
  p_conversation_id uuid, p_message_id uuid, p_pinned boolean
)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
begin
  if not private.can_pin_group_messages(p_conversation_id) then raise exception 'Only admins can pin messages'; end if;
  if not exists (select 1 from public.messages m where m.id = p_message_id and m.conversation_id = p_conversation_id) then
    raise exception 'Message does not belong to this group';
  end if;
  if p_pinned then
    insert into public.group_pinned_messages(conversation_id, message_id, pinned_by)
      values (p_conversation_id, p_message_id, auth.uid()) on conflict do nothing;
  else
    delete from public.group_pinned_messages where conversation_id = p_conversation_id and message_id = p_message_id;
  end if;
  insert into public.group_activity(conversation_id, actor_id, action, details)
    values (p_conversation_id, auth.uid(), case when p_pinned then 'message_pinned' else 'message_unpinned' end,
      jsonb_build_object('message_id', p_message_id));
end;
$$;

create or replace function public.edit_message(p_message_id uuid, p_content text)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_message public.messages%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if char_length(trim(coalesce(p_content, ''))) not between 1 and 5000 then raise exception 'Invalid message'; end if;
  select * into v_message from public.messages where id = p_message_id for update;
  if not found or v_message.sender_id <> auth.uid() then raise exception 'Only the sender can edit this message'; end if;
  if v_message.message_type <> 'text' or v_message.created_at < now() - interval '15 minutes' then raise exception 'This message can no longer be edited'; end if;
  if not private.is_conversation_member(v_message.conversation_id) then raise exception 'Not a conversation member'; end if;
  update public.messages set content = trim(p_content), edited_at = now() where id = p_message_id;
end;
$$;

create or replace function public.delete_message(p_message_id uuid)
returns void
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare v_message public.messages%rowtype;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select * into v_message from public.messages where id = p_message_id for update;
  if not found or not private.is_conversation_member(v_message.conversation_id) then raise exception 'Message not found'; end if;
  if v_message.sender_id <> auth.uid() and not private.can_delete_group_messages(v_message.conversation_id) then raise exception 'Insufficient permission'; end if;
  update public.messages set content = 'تم حذف هذه الرسالة', message_type = 'text', media_path = null,
    media_duration_seconds = null, edited_at = now() where id = p_message_id;
end;
$$;

-- Preserve the original direct-message rows, while returning group conversations
-- in the same inbox RPC for a minimal and backwards-compatible Flutter client.
drop function if exists public.get_my_conversations();
create function public.get_my_conversations()
returns table (
  conversation_id uuid,
  other_user_id uuid,
  username text,
  display_name text,
  avatar_path text,
  bio text,
  last_message text,
  last_message_type text,
  last_message_at timestamptz,
  last_message_sender_id uuid,
  last_message_delivered_at timestamptz,
  last_message_read_at timestamptz,
  is_group boolean,
  group_name text,
  group_avatar_path text,
  group_description text,
  member_count integer,
  group_role text
)
language sql stable security invoker
set search_path = public, pg_temp
as $$
  with inbox as (
    select c.id as conversation_id, peer.user_id as other_user_id, p.username, p.display_name,
      p.avatar_path, p.bio, latest.content as last_message, latest.message_type as last_message_type,
      latest.created_at as last_message_at, latest.sender_id as last_message_sender_id,
      latest.delivered_at as last_message_delivered_at, latest.read_at as last_message_read_at,
      false as is_group, null::text as group_name, null::text as group_avatar_path,
      null::text as group_description, null::integer as member_count, null::text as group_role,
      coalesce(latest.created_at, c.created_at) as sort_at
    from public.conversations c
    join public.conversation_members mine on mine.conversation_id = c.id and mine.user_id = auth.uid()
    join public.conversation_members peer on peer.conversation_id = c.id and peer.user_id <> auth.uid()
    join public.profiles p on p.id = peer.user_id
    left join lateral (
      select m.content, m.message_type, m.created_at, m.sender_id, m.delivered_at, m.read_at
      from public.messages m where m.conversation_id = c.id order by m.created_at desc limit 1
    ) latest on true
    where not exists (select 1 from public.groups g where g.conversation_id = c.id)
    union all
    select c.id, null::uuid, null::text, g.name, null::text, g.description,
      latest.content, latest.message_type, latest.created_at, latest.sender_id,
      latest.delivered_at, latest.read_at, true, g.name, g.avatar_path, g.description,
      (select count(*)::integer from public.group_members count_members where count_members.conversation_id = c.id),
      my_role.role, coalesce(latest.created_at, c.created_at)
    from public.conversations c
    join public.groups g on g.conversation_id = c.id
    join public.group_members mine on mine.conversation_id = c.id and mine.user_id = auth.uid()
    join lateral (select mine.role) my_role on true
    left join lateral (
      select m.content, m.message_type, m.created_at, m.sender_id, m.delivered_at, m.read_at
      from public.messages m where m.conversation_id = c.id order by m.created_at desc limit 1
    ) latest on true
  )
  select conversation_id, other_user_id, username, display_name, avatar_path, bio,
    last_message, last_message_type, last_message_at, last_message_sender_id,
    last_message_delivered_at, last_message_read_at, is_group, group_name,
    group_avatar_path, group_description, member_count, group_role
  from inbox order by sort_at desc;
$$;
revoke all on function public.get_my_conversations() from public, anon;
grant execute on function public.get_my_conversations() to authenticated;

-- RPCs are the only write path for memberships, roles, settings, invitations,
-- group lifecycle, message moderation, and pins.
revoke all on function public.create_group(text,text,uuid[],boolean) from public, anon;
grant execute on function public.create_group(text,text,uuid[],boolean) to authenticated;
revoke all on function public.add_group_members(uuid,uuid[]) from public, anon;
grant execute on function public.add_group_members(uuid,uuid[]) to authenticated;
revoke all on function public.remove_group_member(uuid,uuid) from public, anon;
grant execute on function public.remove_group_member(uuid,uuid) to authenticated;
revoke all on function public.set_group_member_role(uuid,uuid,text) from public, anon;
grant execute on function public.set_group_member_role(uuid,uuid,text) to authenticated;
revoke all on function public.ban_group_member(uuid,uuid) from public, anon;
grant execute on function public.ban_group_member(uuid,uuid) to authenticated;
revoke all on function public.update_group_info(uuid,text,text,text) from public, anon;
grant execute on function public.update_group_info(uuid,text,text,text) to authenticated;
revoke all on function public.update_group_settings(uuid,boolean,boolean,boolean,boolean,boolean,boolean,boolean,boolean,boolean) from public, anon;
grant execute on function public.update_group_settings(uuid,boolean,boolean,boolean,boolean,boolean,boolean,boolean,boolean,boolean) to authenticated;
revoke all on function public.rotate_group_invite(uuid) from public, anon;
grant execute on function public.rotate_group_invite(uuid) to authenticated;
revoke all on function public.join_group_by_invite(text,text) from public, anon;
grant execute on function public.join_group_by_invite(text,text) to authenticated;
revoke all on function public.resolve_group_join_request(uuid,boolean) from public, anon;
grant execute on function public.resolve_group_join_request(uuid,boolean) to authenticated;
revoke all on function public.transfer_group_owner(uuid,uuid) from public, anon;
grant execute on function public.transfer_group_owner(uuid,uuid) to authenticated;
revoke all on function public.leave_group(uuid) from public, anon;
grant execute on function public.leave_group(uuid) to authenticated;
revoke all on function public.delete_group(uuid) from public, anon;
grant execute on function public.delete_group(uuid) to authenticated;
revoke all on function public.set_group_message_pinned(uuid,uuid,boolean) from public, anon;
grant execute on function public.set_group_message_pinned(uuid,uuid,boolean) to authenticated;
revoke all on function public.edit_message(uuid,text) from public, anon;
grant execute on function public.edit_message(uuid,text) to authenticated;
revoke all on function public.delete_message(uuid) from public, anon;
grant execute on function public.delete_message(uuid) to authenticated;

-- Apply group send/file/voice settings to object uploads as well as message rows.
drop policy if exists wasla_media_insert_member on storage.objects;
create policy wasla_media_insert_member on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'wasla-media'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and private.is_conversation_member(((storage.foldername(name))[1])::uuid)
    and (
      not exists (select 1 from public.groups g
        where g.conversation_id = ((storage.foldername(name))[1])::uuid)
      or exists (
        select 1 from public.groups g
        join public.group_members gm on gm.conversation_id = g.conversation_id
        where g.conversation_id = ((storage.foldername(name))[1])::uuid
          and gm.user_id = (select auth.uid())
          and (g.members_can_message or gm.role in ('owner', 'admin'))
          and (case when lower(name) like '%.m4a' then g.voice_allowed else g.files_allowed end)
      )
    )
  );

-- Owners may remove the private media owned by all group members when deleting a group.
drop policy if exists wasla_media_delete_own on storage.objects;
create policy wasla_media_delete_own on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'wasla-media'
    and private.is_conversation_member(((storage.foldername(name))[1])::uuid)
    and (
      (storage.foldername(name))[2] = (select auth.uid())::text
      or private.is_group_owner(((storage.foldername(name))[1])::uuid)
    )
  );

-- Publicly readable group avatars, but only group admins (or members allowed to
-- edit group info) may upload/replace/delete their own image object.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('wasla-group-avatars', 'wasla-group-avatars', true, 5242880,
  array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set public = excluded.public,
  file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;
drop policy if exists wasla_group_avatar_insert on storage.objects;
create policy wasla_group_avatar_insert on storage.objects for insert to authenticated
with check (bucket_id = 'wasla-group-avatars'
  and (storage.foldername(name))[2] = (select auth.uid())::text
  and exists (select 1 from public.groups g where g.conversation_id = ((storage.foldername(name))[1])::uuid
    and private.is_conversation_member(g.conversation_id)
    and (private.is_group_admin(g.conversation_id) or g.members_can_edit_info)));
drop policy if exists wasla_group_avatar_update on storage.objects;
create policy wasla_group_avatar_update on storage.objects for update to authenticated
using (bucket_id = 'wasla-group-avatars'
  and (storage.foldername(name))[2] = (select auth.uid())::text
  and exists (select 1 from public.groups g where g.conversation_id = ((storage.foldername(name))[1])::uuid
    and private.is_conversation_member(g.conversation_id)
    and (private.is_group_admin(g.conversation_id) or g.members_can_edit_info)))
with check (bucket_id = 'wasla-group-avatars'
  and (storage.foldername(name))[2] = (select auth.uid())::text
  and exists (select 1 from public.groups g where g.conversation_id = ((storage.foldername(name))[1])::uuid
    and private.is_conversation_member(g.conversation_id)
    and (private.is_group_admin(g.conversation_id) or g.members_can_edit_info)));
drop policy if exists wasla_group_avatar_delete on storage.objects;
create policy wasla_group_avatar_delete on storage.objects for delete to authenticated
using (bucket_id = 'wasla-group-avatars'
  and exists (select 1 from public.groups g where g.conversation_id = ((storage.foldername(name))[1])::uuid
    and private.is_conversation_member(g.conversation_id)
    and ((storage.foldername(name))[2] = (select auth.uid())::text or private.is_group_owner(g.conversation_id))));

-- Enable realtime for group metadata and member/activity changes.
do $$
declare v_table text;
begin
  foreach v_table in array array['groups', 'group_members', 'group_activity', 'group_pinned_messages'] loop
    if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime'
      and schemaname = 'public' and tablename = v_table) then
      execute format('alter publication supabase_realtime add table public.%I', v_table);
    end if;
  end loop;
exception when undefined_object then
  raise notice 'Publication supabase_realtime is unavailable; enable realtime for group tables in Supabase.';
end;
$$;
