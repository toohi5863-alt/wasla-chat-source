import 'package:chat/unread_chat_badge.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('unread badge exposes a clear label and theme-aware contrast', (
    tester,
  ) async {
    final colors = ColorScheme.fromSeed(seedColor: Colors.teal);
    final semantics = tester.ensureSemantics();

    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(useMaterial3: true, colorScheme: colors),
        home: const Scaffold(
          body: Center(
            child: UnreadChatBadge(
              label: 'غير مقروءة',
              semanticLabel: 'رسالة غير مقروءة',
            ),
          ),
        ),
      ),
    );

    expect(find.text('غير مقروءة'), findsOneWidget);
    expect(find.bySemanticsLabel('رسالة غير مقروءة'), findsOneWidget);
    final text = tester.widget<Text>(find.text('غير مقروءة'));
    expect(text.style?.color, colors.onPrimary);
    semantics.dispose();
  });
}
