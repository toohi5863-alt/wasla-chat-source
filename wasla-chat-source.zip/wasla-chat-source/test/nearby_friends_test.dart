import 'package:chat/nearby_friends.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parses a nearby profile without exposing coordinates', () {
    final person = NearbyPerson.fromMap({
      'user_id': 'user-123',
      'username': 'sara',
      'display_name': 'سارة',
      'avatar_path': 'avatars/sara.jpg',
      'bio': 'أحب القراءة',
      'distance_label': '٢–٥ كم تقريبًا',
      'friendship_status': 'pending',
      'requester_id': 'viewer-1',
      'addressee_id': 'user-123',
    });

    expect(person.userId, 'user-123');
    expect(person.label, 'سارة');
    expect(person.distanceLabel, '٢–٥ كم تقريبًا');
    expect(person.friendshipStatus.isOutgoingFor('viewer-1'), isTrue);
    expect(person.avatarPath, 'avatars/sara.jpg');
  });

  test('uses safe defaults for optional nearby profile values', () {
    final person = NearbyPerson.fromMap({'user_id': 'user-456'});

    expect(person.label, '@');
    expect(person.distanceLabel, 'قريب منك');
    expect(person.friendshipStatus.status, 'none');
    expect(person.friendshipStatus.isAccepted, isFalse);
  });
}
