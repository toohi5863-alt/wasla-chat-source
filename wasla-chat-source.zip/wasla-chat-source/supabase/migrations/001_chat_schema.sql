-- Wasla: dedicated one-to-one messaging schema for Supabase.
-- Apply only to a project dedicated to this application.
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-z0-9_]{3,24}$'),
  display_name text not null check (char_length(trim(display_name)) between 2 and 60),
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(trim(content)) between 1 and 5000),
  created_at timestamptz not null default now()
);

create index if not exists conversation_members_user_idx
  on public.conversation_members(user_id, conversation_id);
create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- Profile details (no email address) are discoverable only to signed-in users.
drop policy if exists profiles_select_authenticated on public.profiles;
create policy profiles_select_authenticated on public.profiles
  for select to authenticated using (auth.uid() is not null);
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create or replace function public.is_conversation_member(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = p_conversation_id and cm.user_id = auth.uid()
  );
$$;
revoke all on function public.is_conversation_member(uuid) from public, anon;
grant execute on function public.is_conversation_member(uuid) to authenticated;

drop policy if exists conversations_select_member on public.conversations;
create policy conversations_select_member on public.conversations
  for select to authenticated using (public.is_conversation_member(id));
drop policy if exists conversation_members_select_member on public.conversation_members;
create policy conversation_members_select_member on public.conversation_members
  for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists messages_select_member on public.messages;
create policy messages_select_member on public.messages
  for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists messages_insert_as_member on public.messages;
create policy messages_insert_as_member on public.messages
  for insert to authenticated
  with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id));

-- Create exactly one direct thread for a user pair, even if the RPC is called repeatedly.
create or replace function public.create_direct_conversation(p_target_user uuid)
returns uuid
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_conversation_id uuid;
begin
  if v_me is null then
    raise exception 'Authentication required';
  end if;
  if p_target_user is null or p_target_user = v_me then
    raise exception 'Choose another user';
  end if;
  if not exists (select 1 from public.profiles p where p.id = p_target_user) then
    raise exception 'User not found';
  end if;

  -- Serialize creation for this pair to prevent duplicate direct threads.
  perform pg_advisory_xact_lock(hashtextextended(
    least(v_me::text, p_target_user::text) || ':' || greatest(v_me::text, p_target_user::text), 0
  ));

  select c.id into v_conversation_id
  from public.conversations c
  join public.conversation_members cm1 on cm1.conversation_id = c.id and cm1.user_id = v_me
  join public.conversation_members cm2 on cm2.conversation_id = c.id and cm2.user_id = p_target_user
  where (select count(*) from public.conversation_members cmx where cmx.conversation_id = c.id) = 2
  order by c.created_at
  limit 1;

  if v_conversation_id is null then
    insert into public.conversations default values returning id into v_conversation_id;
    insert into public.conversation_members(conversation_id, user_id)
      values (v_conversation_id, v_me), (v_conversation_id, p_target_user);
  end if;
  return v_conversation_id;
end;
$$;
revoke all on function public.create_direct_conversation(uuid) from public, anon;
grant execute on function public.create_direct_conversation(uuid) to authenticated;

create or replace function public.get_my_conversations()
returns table (
  conversation_id uuid,
  other_user_id uuid,
  username text,
  display_name text,
  last_message text,
  last_message_at timestamptz
)
language sql stable security invoker
set search_path = public, pg_temp
as $$
  select c.id, peer.user_id, p.username, p.display_name, latest.content, latest.created_at
  from public.conversations c
  join public.conversation_members mine
    on mine.conversation_id = c.id and mine.user_id = auth.uid()
  join public.conversation_members peer
    on peer.conversation_id = c.id and peer.user_id <> auth.uid()
  join public.profiles p on p.id = peer.user_id
  left join lateral (
    select m.content, m.created_at
    from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc
    limit 1
  ) latest on true
  order by coalesce(latest.created_at, c.created_at) desc;
$$;
revoke all on function public.get_my_conversations() from public, anon;
grant execute on function public.get_my_conversations() to authenticated;

-- Create a profile at signup. The app sends username and display_name as auth metadata.
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_username text := lower(coalesce(new.raw_user_meta_data ->> 'username', ''));
  v_display_name text := trim(coalesce(new.raw_user_meta_data ->> 'display_name', ''));
begin
  if v_username !~ '^[a-z0-9_]{3,24}$' then
    raise exception 'Invalid username';
  end if;
  if char_length(v_display_name) < 2 or char_length(v_display_name) > 60 then
    raise exception 'Invalid display name';
  end if;
  insert into public.profiles(id, username, display_name)
  values (new.id, v_username, v_display_name);
  return new;
end;
$$;
revoke all on function public.handle_new_user() from public, anon, authenticated;

drop trigger if exists on_auth_user_created_wasla on auth.users;
create trigger on_auth_user_created_wasla
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- The publishable client key receives only the minimum operations needed by the app.
revoke all on public.profiles, public.conversations, public.conversation_members, public.messages from anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select on public.conversations, public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;

-- Enable Postgres Changes for live incoming messages, without duplicating membership.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
exception when undefined_object then
  raise notice 'Publication supabase_realtime is unavailable; enable Realtime for public.messages in Supabase dashboard.';
end;
$$;
