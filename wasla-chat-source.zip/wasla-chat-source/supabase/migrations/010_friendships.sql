-- Wasla 1.8: friendship requests are separate from direct conversations.
-- A conversation can still start before either party accepts a friend request.
create table if not exists public.friend_requests (
  user_low_id uuid not null references public.profiles(id) on delete cascade,
  user_high_id uuid not null references public.profiles(id) on delete cascade,
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending', 'accepted', 'rejected', 'cancelled', 'removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  responded_at timestamptz,
  primary key (user_low_id, user_high_id),
  constraint friend_requests_distinct_users check (user_low_id < user_high_id),
  constraint friend_requests_participants_check check (
    requester_id <> addressee_id
    and ((requester_id = user_low_id and addressee_id = user_high_id)
      or (requester_id = user_high_id and addressee_id = user_low_id))
  )
);

create index if not exists friend_requests_incoming_pending_idx
  on public.friend_requests (addressee_id, created_at desc)
  where status = 'pending';

alter table public.friend_requests enable row level security;
revoke all on public.friend_requests from public, anon, authenticated;
grant select on public.friend_requests to authenticated;
drop policy if exists friend_requests_select_participant on public.friend_requests;
create policy friend_requests_select_participant on public.friend_requests
  for select to authenticated
  using (
    requester_id = (select auth.uid())
    or addressee_id = (select auth.uid())
  );

create or replace function public.get_friendship_status(p_peer_user_id uuid)
returns jsonb
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_result jsonb;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_peer_user_id is null or p_peer_user_id = v_me then
    raise exception 'Choose another user';
  end if;
  select jsonb_build_object(
    'status', fr.status,
    'requester_id', fr.requester_id,
    'addressee_id', fr.addressee_id,
    'created_at', fr.created_at
  ) into v_result
  from public.friend_requests fr
  where fr.user_low_id = least(v_me, p_peer_user_id)
    and fr.user_high_id = greatest(v_me, p_peer_user_id);
  return coalesce(v_result, jsonb_build_object('status', 'none'));
end;
$$;

create or replace function public.send_friend_request(p_target_user_id uuid)
returns text
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_status text;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_target_user_id is null or p_target_user_id = v_me then
    raise exception 'Choose another user';
  end if;
  if not exists (select 1 from public.profiles p where p.id = p_target_user_id) then
    raise exception 'User not found';
  end if;

  insert into public.friend_requests (
    user_low_id, user_high_id, requester_id, addressee_id, status
  ) values (
    least(v_me, p_target_user_id), greatest(v_me, p_target_user_id),
    v_me, p_target_user_id, 'pending'
  )
  on conflict (user_low_id, user_high_id) do update set
    requester_id = case
      when public.friend_requests.status = 'accepted'
        or (public.friend_requests.status = 'pending'
          and public.friend_requests.requester_id <> v_me)
        then public.friend_requests.requester_id
      else excluded.requester_id
    end,
    addressee_id = case
      when public.friend_requests.status = 'accepted'
        or (public.friend_requests.status = 'pending'
          and public.friend_requests.requester_id <> v_me)
        then public.friend_requests.addressee_id
      else excluded.addressee_id
    end,
    status = case
      when public.friend_requests.status = 'accepted' then 'accepted'
      when public.friend_requests.status = 'pending'
        and public.friend_requests.requester_id <> v_me then 'accepted'
      else 'pending'
    end,
    created_at = case
      when public.friend_requests.status in ('rejected', 'cancelled', 'removed')
        then now()
      else public.friend_requests.created_at
    end,
    updated_at = now(),
    responded_at = case
      when public.friend_requests.status = 'accepted' then public.friend_requests.responded_at
      when public.friend_requests.status = 'pending'
        and public.friend_requests.requester_id <> v_me then now()
      else null
    end;

  select fr.status into v_status
  from public.friend_requests fr
  where fr.user_low_id = least(v_me, p_target_user_id)
    and fr.user_high_id = greatest(v_me, p_target_user_id);
  return v_status;
end;
$$;

create or replace function public.respond_friend_request(
  p_requester_user_id uuid,
  p_accept boolean
)
returns text
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_status text := case when coalesce(p_accept, false) then 'accepted' else 'rejected' end;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_requester_user_id is null or p_requester_user_id = v_me then
    raise exception 'Choose another user';
  end if;
  update public.friend_requests set
    status = v_status,
    updated_at = now(),
    responded_at = now()
  where user_low_id = least(v_me, p_requester_user_id)
    and user_high_id = greatest(v_me, p_requester_user_id)
    and requester_id = p_requester_user_id
    and addressee_id = v_me
    and status = 'pending';
  if not found then raise exception 'Friend request is no longer pending'; end if;
  return v_status;
end;
$$;

create or replace function public.cancel_friendship(p_peer_user_id uuid)
returns text
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
  v_status text;
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if p_peer_user_id is null or p_peer_user_id = v_me then
    raise exception 'Choose another user';
  end if;
  update public.friend_requests set
    status = case
      when status = 'pending' and requester_id = v_me then 'cancelled'
      when status = 'accepted' then 'removed'
      else status
    end,
    updated_at = now(),
    responded_at = now()
  where user_low_id = least(v_me, p_peer_user_id)
    and user_high_id = greatest(v_me, p_peer_user_id)
    and ((status = 'pending' and requester_id = v_me) or status = 'accepted');
  if not found then raise exception 'No outgoing request or friendship to cancel'; end if;
  select fr.status into v_status
  from public.friend_requests fr
  where fr.user_low_id = least(v_me, p_peer_user_id)
    and fr.user_high_id = greatest(v_me, p_peer_user_id);
  return v_status;
end;
$$;

create or replace function public.list_incoming_friend_requests()
returns table (
  requester_id uuid,
  username text,
  display_name text,
  avatar_path text,
  created_at timestamptz
)
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  return query
  select fr.requester_id, p.username, p.display_name, p.avatar_path, fr.created_at
  from public.friend_requests fr
  join public.profiles p on p.id = fr.requester_id
  where fr.addressee_id = auth.uid() and fr.status = 'pending'
  order by fr.created_at desc
  limit 100;
end;
$$;

revoke all on function public.get_friendship_status(uuid) from public, anon;
revoke all on function public.send_friend_request(uuid) from public, anon;
revoke all on function public.respond_friend_request(uuid, boolean) from public, anon;
revoke all on function public.cancel_friendship(uuid) from public, anon;
revoke all on function public.list_incoming_friend_requests() from public, anon;
grant execute on function public.get_friendship_status(uuid) to authenticated;
grant execute on function public.send_friend_request(uuid) to authenticated;
grant execute on function public.respond_friend_request(uuid, boolean) to authenticated;
grant execute on function public.cancel_friendship(uuid) to authenticated;
grant execute on function public.list_incoming_friend_requests() to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'friend_requests'
  ) then
    alter publication supabase_realtime add table public.friend_requests;
  end if;
exception when undefined_object then
  raise notice 'Publication supabase_realtime is unavailable; enable Realtime for public.friend_requests in Supabase dashboard.';
end;
$$;
