-- Wasla 1.9: expiring stories with friend-only or selected-friend audiences.
create table if not exists public.status_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content_type text not null check (content_type in ('text', 'image', 'video')),
  body text,
  media_path text,
  privacy text not null default 'friends' check (privacy in ('friends', 'selected')),
  audience_user_ids uuid[] not null default '{}'::uuid[],
  background_color bigint not null default 4278712178
    check (background_color between 0 and 4294967295),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours'),
  constraint status_posts_body_length check (body is null or char_length(body) <= 500),
  constraint status_posts_content_shape check (
    (content_type = 'text' and nullif(btrim(body), '') is not null and media_path is null)
    or (content_type in ('image', 'video') and media_path is not null)
  ),
  constraint status_posts_privacy_audience check (
    (privacy = 'friends' and cardinality(audience_user_ids) = 0)
    or (privacy = 'selected' and cardinality(audience_user_ids) between 1 and 200)
  )
);

create index if not exists status_posts_user_created_idx
  on public.status_posts (user_id, created_at desc);
create index if not exists status_posts_expiry_idx
  on public.status_posts (expires_at);

create table if not exists public.status_views (
  status_id uuid not null references public.status_posts(id) on delete cascade,
  viewer_id uuid not null references public.profiles(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (status_id, viewer_id)
);
create index if not exists status_views_viewer_idx
  on public.status_views (viewer_id, viewed_at desc);

alter table public.status_posts enable row level security;
alter table public.status_views enable row level security;
revoke all on public.status_posts, public.status_views from public, anon, authenticated;
grant select, insert, delete on public.status_posts to authenticated;
grant select on public.status_views to authenticated;

create or replace function public.status_audience_are_friends(
  p_user_id uuid,
  p_audience_user_ids uuid[]
)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select p_user_id = auth.uid()
    and not exists (
      select 1
      from unnest(coalesce(p_audience_user_ids, '{}'::uuid[])) as audience(friend_id)
      where audience.friend_id = p_user_id
        or not exists (
          select 1 from public.friend_requests fr
          where fr.status = 'accepted'
            and ((fr.requester_id = p_user_id and fr.addressee_id = audience.friend_id)
              or (fr.addressee_id = p_user_id and fr.requester_id = audience.friend_id))
        )
    );
$$;

create or replace function public.status_can_view_status(
  p_status_id uuid,
  p_viewer_id uuid
)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select p_viewer_id = auth.uid() and exists (
    select 1 from public.status_posts sp
    where sp.id = p_status_id
      and sp.expires_at > now()
      and (
        sp.user_id = p_viewer_id
        or (
          exists (
            select 1 from public.friend_requests fr
            where fr.status = 'accepted'
              and ((fr.requester_id = sp.user_id and fr.addressee_id = p_viewer_id)
                or (fr.addressee_id = sp.user_id and fr.requester_id = p_viewer_id))
          )
          and (sp.privacy = 'friends' or p_viewer_id = any(sp.audience_user_ids))
        )
      )
  );
$$;

revoke all on function public.status_audience_are_friends(uuid, uuid[]) from public, anon;
revoke all on function public.status_can_view_status(uuid, uuid) from public, anon;
grant execute on function public.status_audience_are_friends(uuid, uuid[]) to authenticated;
grant execute on function public.status_can_view_status(uuid, uuid) to authenticated;

drop policy if exists status_posts_visible_to_author_or_audience on public.status_posts;
create policy status_posts_visible_to_author_or_audience on public.status_posts
  for select to authenticated
  using (user_id = (select auth.uid()) or public.status_can_view_status(id, (select auth.uid())));
drop policy if exists status_posts_insert_own on public.status_posts;
create policy status_posts_insert_own on public.status_posts
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and public.status_audience_are_friends(user_id, audience_user_ids)
  );
drop policy if exists status_posts_delete_own on public.status_posts;
create policy status_posts_delete_own on public.status_posts
  for delete to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists status_views_visible_to_viewer_or_owner on public.status_views;
create policy status_views_visible_to_viewer_or_owner on public.status_views
  for select to authenticated
  using (
    viewer_id = (select auth.uid())
    or exists (
      select 1 from public.status_posts sp
      where sp.id = status_id and sp.user_id = (select auth.uid())
    )
  );

create or replace function public.list_status_feed()
returns table (
  id uuid,
  user_id uuid,
  username text,
  display_name text,
  avatar_path text,
  content_type text,
  body text,
  media_path text,
  background_color bigint,
  privacy text,
  created_at timestamptz,
  expires_at timestamptz,
  is_mine boolean,
  is_viewed boolean,
  views_count bigint
)
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  return query
  select sp.id, sp.user_id, p.username, p.display_name, p.avatar_path,
    sp.content_type, sp.body, sp.media_path, sp.background_color, sp.privacy,
    sp.created_at, sp.expires_at, (sp.user_id = v_me),
    exists (select 1 from public.status_views sv
      where sv.status_id = sp.id and sv.viewer_id = v_me),
    case when sp.user_id = v_me then
      (select count(*) from public.status_views sv where sv.status_id = sp.id)
      else 0::bigint end
  from public.status_posts sp
  join public.profiles p on p.id = sp.user_id
  where sp.expires_at > now()
    and public.status_can_view_status(sp.id, v_me)
  order by (sp.user_id = v_me) desc, sp.created_at desc
  limit 500;
end;
$$;

create or replace function public.mark_status_viewed(p_status_id uuid)
returns boolean
language plpgsql volatile security definer
set search_path = public, pg_temp
as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.status_posts sp
    where sp.id = p_status_id and sp.user_id <> v_me)
    or not public.status_can_view_status(p_status_id, v_me) then
    return false;
  end if;
  insert into public.status_views(status_id, viewer_id)
  values (p_status_id, v_me)
  on conflict (status_id, viewer_id) do nothing;
  return true;
end;
$$;

create or replace function public.list_status_viewers(p_status_id uuid)
returns table (
  viewer_id uuid,
  username text,
  display_name text,
  avatar_path text,
  viewed_at timestamptz
)
language plpgsql stable security definer
set search_path = public, pg_temp
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.status_posts sp
    where sp.id = p_status_id and sp.user_id = auth.uid()) then
    raise exception 'Only the status owner can view its viewers';
  end if;
  return query
  select sv.viewer_id, p.username, p.display_name, p.avatar_path, sv.viewed_at
  from public.status_views sv
  join public.profiles p on p.id = sv.viewer_id
  where sv.status_id = p_status_id
  order by sv.viewed_at desc
  limit 500;
end;
$$;

revoke all on function public.list_status_feed() from public, anon;
revoke all on function public.mark_status_viewed(uuid) from public, anon;
revoke all on function public.list_status_viewers(uuid) from public, anon;
grant execute on function public.list_status_feed() to authenticated;
grant execute on function public.mark_status_viewed(uuid) to authenticated;
grant execute on function public.list_status_viewers(uuid) to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'wasla-statuses', 'wasla-statuses', false, 52428800,
  array['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'video/mp4', 'video/quicktime', 'video/webm']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists wasla_status_media_select_visible on storage.objects;
create policy wasla_status_media_select_visible on storage.objects
  for select to authenticated
  using (
    bucket_id = 'wasla-statuses'
    and exists (
      select 1 from public.status_posts sp
      where sp.media_path = name
        and public.status_can_view_status(sp.id, (select auth.uid()))
    )
  );
drop policy if exists wasla_status_media_insert_own on storage.objects;
create policy wasla_status_media_insert_own on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'wasla-statuses'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );
drop policy if exists wasla_status_media_delete_own on storage.objects;
create policy wasla_status_media_delete_own on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'wasla-statuses'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'status_posts'
  ) then
    alter publication supabase_realtime add table public.status_posts;
  end if;
exception when undefined_object then
  raise notice 'Supabase Realtime publication unavailable; enable it for public.status_posts.';
end;
$$;
