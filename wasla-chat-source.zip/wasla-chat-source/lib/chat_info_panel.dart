import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin_identity.dart';
import 'chat_models.dart';
import 'friendship_service.dart';
import 'group_screens.dart';
import 'presence.dart';
import 'presence_status.dart';
import 'push_notifications.dart';
import 'wasla_media.dart';

class ChatInfoPanel extends StatefulWidget {
  const ChatInfoPanel({
    required this.target,
    required this.messages,
    required this.client,
    required this.userId,
    required this.lastSeenAt,
    required this.lastSeenLoaded,
    required this.backgroundColor,
    required this.onCall,
    required this.onSearch,
    required this.onBackgroundChanged,
    required this.onFriendshipChanged,
    super.key,
  });

  final ChatTarget target;
  final List<ChatMessage> messages;
  final SupabaseClient client;
  final String userId;
  final DateTime? lastSeenAt;
  final bool lastSeenLoaded;
  final int? backgroundColor;
  final Future<void> Function({required bool video}) onCall;
  final VoidCallback onSearch;
  final Future<void> Function(int? colorValue) onBackgroundChanged;
  final VoidCallback onFriendshipChanged;

  @override
  State<ChatInfoPanel> createState() => _ChatInfoPanelState();
}

class _ChatInfoPanelState extends State<ChatInfoPanel> {
  static const _mediaTypes = {'image', 'video', 'audio', 'file'};
  static const _backgroundPalette = <Color>[
    Color(0xFFF5F8F7),
    Color(0xFFFFF3E6),
    Color(0xFFEAF1FF),
    Color(0xFFFCEBF3),
    Color(0xFFE8F5E9),
    Color(0xFFEDE7F6),
  ];

  bool _muted = false;
  bool _muteLoaded = false;
  bool _savingMute = false;
  bool _friendshipLoaded = false;
  bool _isFriend = false;
  bool _removingFriend = false;
  bool _sharedGroupsLoaded = false;
  bool _sharedGroupsFailed = false;
  List<_SharedGroup> _sharedGroups = const [];
  bool _storageLoaded = false;
  int? _knownMediaBytes;
  int _sizedMediaCount = 0;
  bool _savingBackground = false;

  List<ChatMessage> get _mediaMessages =>
      widget.messages
          .where(
            (message) =>
                _mediaTypes.contains(message.messageType) &&
                (message.mediaPath?.isNotEmpty ?? false),
          )
          .toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  List<ChatMessage> get _visualMessages => _mediaMessages
      .where(
        (message) =>
            message.messageType == 'image' || message.messageType == 'video',
      )
      .toList();

  @override
  void initState() {
    super.initState();
    unawaited(_loadMutePreference());
    unawaited(_loadFriendship());
    unawaited(_loadSharedGroups());
    unawaited(_loadStorageUsage());
  }

  Future<void> _loadMutePreference() async {
    try {
      final row = await widget.client
          .from('conversation_notification_preferences')
          .select('notifications_enabled,muted_until')
          .eq('user_id', widget.userId)
          .eq('conversation_id', widget.target.conversationId)
          .maybeSingle();
      final enabled = row?['notifications_enabled'] != false;
      final until = DateTime.tryParse(row?['muted_until']?.toString() ?? '');
      if (!mounted) return;
      setState(() {
        _muted = !enabled || (until != null && until.isAfter(DateTime.now()));
        _muteLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _muteLoaded = true);
    }
  }

  Future<void> _loadFriendship() async {
    try {
      final status = await FriendshipService(widget.client)
          .statusFor(widget.target.userId);
      if (!mounted) return;
      setState(() {
        _isFriend = status.isAccepted;
        _friendshipLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _friendshipLoaded = true);
    }
  }

  Future<void> _loadSharedGroups() async {
    try {
      final memberships = await Future.wait([
        widget.client
            .from('group_members')
            .select('conversation_id')
            .eq('user_id', widget.userId),
        widget.client
            .from('group_members')
            .select('conversation_id')
            .eq('user_id', widget.target.userId),
      ]);
      final myIds = memberships[0]
          .map((row) => row['conversation_id']?.toString() ?? '')
          .where((id) => id.isNotEmpty)
          .toSet();
      final sharedIds = memberships[1]
          .map((row) => row['conversation_id']?.toString() ?? '')
          .where((id) => id.isNotEmpty && myIds.contains(id))
          .toSet()
          .toList();
      if (sharedIds.isEmpty) {
        if (mounted) setState(() => _sharedGroupsLoaded = true);
        return;
      }
      final rows = await widget.client
          .from('groups')
          .select('conversation_id,name,avatar_path')
          .inFilter('conversation_id', sharedIds);
      final groups = rows
          .map(
            (row) => _SharedGroup(
              id: row['conversation_id'].toString(),
              name: row['name']?.toString() ?? 'مجموعة',
              avatarPath: row['avatar_path']?.toString(),
            ),
          )
          .toList();
      if (mounted) {
        setState(() {
          _sharedGroups = groups;
          _sharedGroupsLoaded = true;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _sharedGroupsFailed = true;
          _sharedGroupsLoaded = true;
        });
      }
    }
  }

  Future<void> _loadStorageUsage() async {
    final media = _mediaMessages;
    if (media.isEmpty) {
      if (mounted) setState(() => _storageLoaded = true);
      return;
    }
    final pathsBySender = <String, Set<String>>{};
    for (final message in media) {
      final path = message.mediaPath;
      if (path == null) continue;
      final parts = path.split('/');
      if (parts.length < 3) continue;
      pathsBySender.putIfAbsent(message.senderId, () => <String>{}).add(path);
    }

    var totalBytes = 0;
    var sizedCount = 0;
    try {
      for (final entry in pathsBySender.entries) {
        final folder = '${widget.target.conversationId}/${entry.key}';
        final objects = await widget.client.storage
            .from('wasla-media')
            .list(
              path: folder,
              searchOptions: const SearchOptions(limit: 1000),
            );
        final objectsByName = {
          for (final object in objects) object.name: object,
        };
        for (final path in entry.value) {
          final name = path.split('/').last;
          final sizeValue = objectsByName[name]?.metadata?['size'];
          final size = sizeValue is num
              ? sizeValue.toInt()
              : int.tryParse(sizeValue?.toString() ?? '');
          if (size != null && size >= 0) {
            totalBytes += size;
            sizedCount++;
          }
        }
      }
      if (mounted) {
        setState(() {
          _knownMediaBytes = sizedCount == 0 ? null : totalBytes;
          _sizedMediaCount = sizedCount;
          _storageLoaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _storageLoaded = true);
    }
  }

  Future<void> _chooseMuteDuration() async {
    if (_savingMute) return;
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'كتم إشعارات هذه المحادثة',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            _muteChoice('تشغيل الإشعارات', 'on'),
            _muteChoice('كتم دائم', 'off'),
            _muteChoice('كتم ساعة', '1h'),
            _muteChoice('كتم 8 ساعات', '8h'),
            _muteChoice('كتم 24 ساعة', '24h'),
            _muteChoice('كتم أسبوع', '7d'),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;

    final enabled = selected != 'off';
    final duration = switch (selected) {
      '1h' => const Duration(hours: 1),
      '8h' => const Duration(hours: 8),
      '24h' => const Duration(hours: 24),
      '7d' => const Duration(days: 7),
      _ => null,
    };
    setState(() => _savingMute = true);
    try {
      await widget.client.from('conversation_notification_preferences').upsert({
        'user_id': widget.userId,
        'conversation_id': widget.target.conversationId,
        'notifications_enabled': enabled,
        'muted_until': duration == null
            ? null
            : DateTime.now().toUtc().add(duration).toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,conversation_id');
      await PushNotifications.instance.refreshPreferences();
      if (!mounted) return;
      setState(() {
        _muted = !enabled || duration != null;
        _muteLoaded = true;
      });
      _showNotice(_muted ? 'تم كتم إشعارات المحادثة.' : 'تم تشغيل الإشعارات.');
    } catch (_) {
      _showNotice('تعذر تحديث الكتم. تحقق من الاتصال وترحيل الإشعارات 018.');
    } finally {
      if (mounted) setState(() => _savingMute = false);
    }
  }

  ListTile _muteChoice(String title, String value) =>
      ListTile(title: Text(title), onTap: () => Navigator.pop(context, value));

  Future<void> _removeFriend() async {
    if (_removingFriend) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إزالة الصداقة؟'),
        content: Text(
          'سيُزال $_displayName من قائمة أصدقائك. ستبقى هذه المحادثة ورسائلها كما هي.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إزالة الصداقة'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _removingFriend = true);
    try {
      await FriendshipService(widget.client).cancel(widget.target.userId);
      widget.onFriendshipChanged();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت إزالة الصداقة وبقيت المحادثة.')),
      );
      Navigator.of(context).pop();
    } catch (_) {
      _showNotice('تعذر إزالة الصداقة. أعد المحاولة.');
    } finally {
      if (mounted) setState(() => _removingFriend = false);
    }
  }

  Future<void> _setBackground(int? colorValue) async {
    if (_savingBackground) return;
    setState(() => _savingBackground = true);
    try {
      await widget.onBackgroundChanged(colorValue);
      if (mounted) {
        _showNotice(
          colorValue == null
              ? 'أُعيدت خلفية المحادثة إلى المظهر الافتراضي.'
              : 'حُفظ لون الخلفية على هذا الجهاز.',
        );
      }
    } catch (_) {
      _showNotice('تعذر حفظ خلفية المحادثة.');
    } finally {
      if (mounted) setState(() => _savingBackground = false);
    }
  }

  void _showNotice(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 3)),
    );
  }

  String get _displayName {
    final name = widget.target.displayName.trim();
    return name.isNotEmpty ? name : '@${widget.target.username}';
  }

  void _openGallery({String? initialType}) {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => ChatMediaGallery(
          client: widget.client,
          userId: widget.userId,
          messages: _mediaMessages,
          initialType: initialType,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final media = _mediaMessages;
    final visibleMedia = _visualMessages.take(9).toList();
    final counts = <String, int>{
      for (final type in _mediaTypes)
        type: media.where((message) => message.messageType == type).length,
    };

    return Material(
      color: scheme.surface,
      child: Column(
        children: [
          _header(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsetsDirectional.fromSTEB(16, 4, 16, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _profileCard(theme),
                  const SizedBox(height: 12),
                  _quickActions(),
                  const SizedBox(height: 12),
                  _sectionCard(
                    title: 'الوسائط والملفات',
                    trailing: TextButton(
                      onPressed: media.isEmpty ? null : () => _openGallery(),
                      child: const Text('عرض الكل'),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (media.isEmpty)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Text(
                              'لا توجد وسائط أو ملفات في الرسائل المحمّلة.',
                            ),
                          )
                        else ...[
                          Text(
                            'ضمن الرسائل المحمّلة: صور ${counts['image']}  ·  فيديو ${counts['video']}  ·  صوت ${counts['audio']}  ·  ملفات ${counts['file']}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: scheme.onSurfaceVariant,
                            ),
                          ),
                          const SizedBox(height: 12),
                          if (visibleMedia.isNotEmpty)
                            GridView.builder(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: visibleMedia.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 3,
                                    crossAxisSpacing: 7,
                                    mainAxisSpacing: 7,
                                  ),
                              itemBuilder: (context, index) {
                                final message = visibleMedia[index];
                                return _MediaThumbnail(
                                  client: widget.client,
                                  message: message,
                                  onTap: () => _openGallery(
                                    initialType: message.messageType,
                                  ),
                                );
                              },
                            ),
                          if (visibleMedia.isEmpty)
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Text('تظهر معاينات الصور والفيديو هنا.'),
                            ),
                          const SizedBox(height: 12),
                          _storageSummary(theme, media.length),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  _sectionCard(
                    title: 'المجموعات المشتركة',
                    child: _sharedGroupsBody(theme),
                  ),
                  const SizedBox(height: 12),
                  _sectionCard(
                    title: 'إعدادات المحادثة',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.wallpaper_outlined,
                              color: scheme.primary,
                            ),
                            const SizedBox(width: 10),
                            const Expanded(
                              child: Text(
                                'خلفية المحادثة',
                                style: TextStyle(fontWeight: FontWeight.w700),
                              ),
                            ),
                            if (_savingBackground)
                              const SizedBox(
                                width: 17,
                                height: 17,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            else if (widget.backgroundColor != null)
                              TextButton(
                                onPressed: () => _setBackground(null),
                                child: const Text('إعادة ضبط'),
                              ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: [
                            for (final color in _backgroundPalette)
                              _BackgroundColorChoice(
                                color: color,
                                selected:
                                    widget.backgroundColor == color.toARGB32(),
                                enabled: !_savingBackground,
                                onTap: () => _setBackground(color.toARGB32()),
                              ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'يُحفظ الاختيار محليًا لهذا الحساب على هذا الجهاز.',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 8),
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(
                            _muted
                                ? Icons.notifications_off_outlined
                                : Icons.notifications_active_outlined,
                            color: scheme.primary,
                          ),
                          title: const Text('إشعارات المحادثة'),
                          subtitle: Text(
                            !_muteLoaded
                                ? 'جارٍ تحميل الحالة…'
                                : _muted
                                ? 'مكتومة'
                                : 'مفعّلة',
                          ),
                          trailing: const Icon(Icons.chevron_left),
                          onTap: _savingMute ? null : _chooseMuteDuration,
                        ),
                      ],
                    ),
                  ),
                  if (_friendshipLoaded && _isFriend) ...[
                    const SizedBox(height: 12),
                    _dangerZone(theme),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(8, 4, 12, 4),
      child: Row(
        children: [
          IconButton(
            tooltip: 'إغلاق لوحة معلومات المحادثة',
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              'معلومات المحادثة',
              style: Theme.of(context).textTheme.titleMedium
                  ?.copyWith(fontWeight: FontWeight.w800),
            ),
          ),
          Icon(Icons.info_outline, color: scheme.onSurfaceVariant, size: 20),
        ],
      ),
    );
  }

  Widget _profileCard(ThemeData theme) {
    final scheme = theme.colorScheme;
    final imageUrl = avatarPublicUrl(widget.client, widget.target.avatarPath);
    return _card(
      child: Column(
        children: [
          CircleAvatar(
            radius: 42,
            backgroundColor: scheme.primaryContainer,
            backgroundImage: imageUrl == null ? null : NetworkImage(imageUrl),
            child: imageUrl == null
                ? Text(
                    _displayName.characters.firstOrNull ?? '?',
                    style: TextStyle(
                      color: scheme.onPrimaryContainer,
                      fontWeight: FontWeight.w800,
                      fontSize: 28,
                    ),
                  )
                : null,
          ),
          const SizedBox(height: 12),
          AdminIdentityText(
            userId: widget.target.userId,
            label: _displayName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w800,
            ),
          ),
          if (widget.target.username.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(
              '@${widget.target.username}',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ],
          const SizedBox(height: 9),
          ValueListenableBuilder<Map<String, UserPresenceStatus>>(
            valueListenable: userPresenceStatuses,
            builder: (context, statuses, _) =>
                ValueListenableBuilder<Set<String>>(
                  valueListenable: onlineUserIds,
                  builder: (context, onlineIds, _) {
                    final online = onlineIds.contains(widget.target.userId);
                    final selected =
                        statuses[widget.target.userId] ??
                        UserPresenceStatus.available;
                    final displayed = effectivePresenceStatus(
                      selected,
                      online: online,
                    );
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        PresenceStatusDot(
                          status: displayed,
                          size: 9,
                          borderColor: scheme.surfaceContainerLow,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          displayed.label,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: displayed.color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    );
                  },
                ),
          ),
          const SizedBox(height: 3),
          ValueListenableBuilder<Set<String>>(
            valueListenable: onlineUserIds,
            builder: (context, onlineIds, _) => Text(
              _lastSeenLabel(online: onlineIds.contains(widget.target.userId)),
              style: theme.textTheme.bodySmall?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _lastSeenLabel({required bool online}) {
    if (online) return 'متصل الآن';
    final lastSeen = widget.lastSeenAt?.toLocal();
    if (lastSeen != null) {
      final difference = DateTime.now().difference(lastSeen);
      if (difference.inMinutes < 1) return 'آخر ظهور منذ لحظات';
      if (difference.inHours < 1) {
        return 'آخر ظهور منذ ${difference.inMinutes} د';
      }
      if (difference.inDays < 1) return 'آخر ظهور منذ ${difference.inHours} س';
      return 'آخر ظهور ${lastSeen.day}/${lastSeen.month}/${lastSeen.year}';
    }
    return widget.lastSeenLoaded ? 'آخر ظهور غير متاح' : 'جارٍ تحديث آخر ظهور…';
  }

  Widget _quickActions() => _card(
    child: Row(
      children: [
        Expanded(
          child: _QuickAction(
            icon: Icons.call_outlined,
            label: 'اتصال',
            onTap: () {
              Navigator.of(context).pop();
              unawaited(widget.onCall(video: false));
            },
          ),
        ),
        Expanded(
          child: _QuickAction(
            icon: Icons.videocam_outlined,
            label: 'فيديو',
            onTap: () {
              Navigator.of(context).pop();
              unawaited(widget.onCall(video: true));
            },
          ),
        ),
        Expanded(
          child: _QuickAction(
            icon: Icons.search,
            label: 'بحث',
            onTap: () {
              Navigator.of(context).pop();
              widget.onSearch();
            },
          ),
        ),
        Expanded(
          child: _QuickAction(
            icon: _muted
                ? Icons.notifications_active_outlined
                : Icons.notifications_off_outlined,
            label: _muted ? 'إلغاء الكتم' : 'كتم',
            busy: _savingMute,
            onTap: _chooseMuteDuration,
          ),
        ),
      ],
    ),
  );

  Widget _storageSummary(ThemeData theme, int mediaCount) {
    final scheme = theme.colorScheme;
    final knownBytes = _knownMediaBytes;
    final detail = !_storageLoaded
        ? 'جارٍ احتساب حجم المرفقات…'
        : knownBytes == null
        ? 'تعذّر قياس حجم الملفات من التخزين؛ العدد ${_arabicNumber(mediaCount)}.'
        : 'الحجم المعروف ${_formatBytes(knownBytes)} · ${_arabicNumber(_sizedMediaCount)} من ${_arabicNumber(mediaCount)} مرفق';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: .55),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(Icons.storage_outlined, size: 20, color: scheme.primary),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'مساحة الوسائط',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                Text(
                  detail,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sharedGroupsBody(ThemeData theme) {
    if (!_sharedGroupsLoaded) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: LinearProgressIndicator(),
      );
    }
    if (_sharedGroupsFailed) {
      return const Text('تعذر تحميل المجموعات المشتركة.');
    }
    if (_sharedGroups.isEmpty) {
      return const Text('لا توجد مجموعات مشتركة.');
    }
    return Column(
      children: [
        for (final group in _sharedGroups)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundColor: theme.colorScheme.primaryContainer,
              backgroundImage: groupAvatarUrl(group.avatarPath) == null
                  ? null
                  : NetworkImage(groupAvatarUrl(group.avatarPath)!),
              child: groupAvatarUrl(group.avatarPath) == null
                  ? Icon(
                      Icons.groups_outlined,
                      color: theme.colorScheme.onPrimaryContainer,
                    )
                  : null,
            ),
            title: Text(
              group.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: const Text('مجموعة مشتركة'),
            dense: true,
          ),
      ],
    );
  }

  Widget _dangerZone(ThemeData theme) {
    final scheme = theme.colorScheme;
    return _sectionCard(
      title: 'إدارة جهة الاتصال',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          OutlinedButton.icon(
            onPressed: _removingFriend ? null : _removeFriend,
            style: OutlinedButton.styleFrom(
              foregroundColor: scheme.error,
              side: BorderSide(color: scheme.error.withValues(alpha: .45)),
            ),
            icon: _removingFriend
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.person_remove_outlined),
            label: const Text('إزالة الصداقة'),
          ),
          const SizedBox(height: 5),
          Text(
            'لن تُحذف الرسائل أو المحادثة.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required String title,
    required Widget child,
    Widget? trailing,
  }) => _card(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: Theme.of(context).textTheme.titleSmall
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
            ),
            ?trailing,
          ],
        ),
        const SizedBox(height: 8),
        child,
      ],
    ),
  );

  Widget _card({required Widget child}) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerLow,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: scheme.outlineVariant.withValues(alpha: .45)),
      ),
      child: child,
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes بايت';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(1)} كيلوبايت';
    }
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} ميغابايت';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} غيغابايت';
  }

  String _arabicNumber(int value) => value.toString().replaceAllMapped(
    RegExp(r'\d'),
    (match) => '٠١٢٣٤٥٦٧٨٩'[int.parse(match.group(0)!)],
  );
}

class _SharedGroup {
  const _SharedGroup({required this.id, required this.name, this.avatarPath});

  final String id;
  final String name;
  final String? avatarPath;
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.busy = false,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: busy ? null : onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Column(
          children: [
            CircleAvatar(
              radius: 23,
              backgroundColor: scheme.primaryContainer,
              child: busy
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(icon, color: scheme.onPrimaryContainer, size: 21),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _BackgroundColorChoice extends StatelessWidget {
  const _BackgroundColorChoice({
    required this.color,
    required this.selected,
    required this.enabled,
    required this.onTap,
  });

  final Color color;
  final bool selected;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final outline = Theme.of(context).colorScheme.outline;
    return Semantics(
      button: true,
      selected: selected,
      label: 'لون خلفية المحادثة',
      child: InkWell(
        onTap: enabled ? onTap : null,
        customBorder: const CircleBorder(),
        child: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(
              color: selected ? Theme.of(context).colorScheme.primary : outline,
              width: selected ? 3 : 1,
            ),
          ),
          child: selected
              ? Icon(
                  Icons.check,
                  size: 18,
                  color:
                      ThemeData.estimateBrightnessForColor(color) ==
                          Brightness.dark
                      ? Colors.white
                      : Colors.black87,
                )
              : null,
        ),
      ),
    );
  }
}

class _MediaThumbnail extends StatelessWidget {
  const _MediaThumbnail({
    required this.client,
    required this.message,
    required this.onTap,
  });

  final SupabaseClient client;
  final ChatMessage message;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final path = message.mediaPath;
    final isImage = message.messageType == 'image';
    final background = scheme.surfaceContainerHighest;
    return Material(
      color: background,
      borderRadius: BorderRadius.circular(12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (isImage && path != null)
              FutureBuilder<String>(
                future: client.storage
                    .from('wasla-media')
                    .createSignedUrl(path, 3600),
                builder: (context, snapshot) => snapshot.hasData
                    ? Image.network(
                        snapshot.data!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, _, _) => _icon(scheme),
                        loadingBuilder: (context, child, progress) =>
                            progress == null
                            ? child
                            : Center(
                                child: SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    value: progress.expectedTotalBytes == null
                                        ? null
                                        : progress.cumulativeBytesLoaded /
                                              progress.expectedTotalBytes!,
                                  ),
                                ),
                              ),
                      )
                    : _icon(scheme),
              )
            else
              _icon(scheme),
            if (message.messageType == 'video')
              const Center(
                child: CircleAvatar(
                  backgroundColor: Colors.black54,
                  child: Icon(Icons.play_arrow, color: Colors.white),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _icon(ColorScheme scheme) => Center(
    child: Icon(
      switch (message.messageType) {
        'video' => Icons.videocam_outlined,
        'audio' => Icons.graphic_eq,
        _ => Icons.insert_drive_file_outlined,
      },
      color: scheme.primary,
      size: 28,
    ),
  );
}

class ChatMediaGallery extends StatelessWidget {
  const ChatMediaGallery({
    required this.client,
    required this.userId,
    required this.messages,
    this.initialType,
    super.key,
  });

  final SupabaseClient client;
  final String userId;
  final List<ChatMessage> messages;
  final String? initialType;

  @override
  Widget build(BuildContext context) {
    const types = ['image', 'video', 'audio', 'file'];
    final initialIndex = math.max(0, types.indexOf(initialType ?? 'image'));
    final labels = {
      'image': 'الصور',
      'video': 'الفيديو',
      'audio': 'الصوت',
      'file': 'الملفات',
    };
    return DefaultTabController(
      length: types.length,
      initialIndex: initialIndex,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الوسائط والملفات'),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              for (final type in types)
                Tab(
                  text:
                      '${labels[type]} (${messages.where((message) => message.messageType == type).length})',
                ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            for (final type in types)
              _MediaList(
                client: client,
                userId: userId,
                messages: messages
                    .where((message) => message.messageType == type)
                    .toList(),
              ),
          ],
        ),
      ),
    );
  }
}

class _MediaList extends StatelessWidget {
  const _MediaList({
    required this.client,
    required this.userId,
    required this.messages,
  });

  final SupabaseClient client;
  final String userId;
  final List<ChatMessage> messages;

  @override
  Widget build(BuildContext context) {
    if (messages.isEmpty) {
      return const Center(child: Text('لا توجد عناصر في هذا القسم.'));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(14),
      itemCount: messages.length,
      separatorBuilder: (_, _) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final message = messages[index];
        final typeName = switch (message.messageType) {
          'image' => 'صورة',
          'video' => 'فيديو',
          'audio' => 'رسالة صوتية',
          _ => message.content.isEmpty ? 'ملف' : message.content,
        };
        return Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        typeName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                    Text(
                      '${message.createdAt.toLocal().day}/${message.createdAt.toLocal().month}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                MessageMedia(client: client, message: message, userId: userId),
              ],
            ),
          ),
        );
      },
    );
  }
}
