import 'package:chat/calls.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('call record parses audio/video and timestamps', () {
    final call = CallRecord.fromRow({
      'id': 'call-1',
      'conversation_id': 'conversation-1',
      'caller_id': 'user-a',
      'callee_id': 'user-b',
      'media_type': 'video',
      'status': 'accepted',
      'created_at': '2026-10-07T18:00:00Z',
      'answered_at': '2026-10-07T18:00:03Z',
      'ended_at': null,
    });

    expect(call.isVideo, isTrue);
    expect(call.isActive, isTrue);
    expect(call.status, 'accepted');
    expect(call.answeredAt, DateTime.parse('2026-10-07T18:00:03Z'));
  });

  test('history hides only selected rows belonging to the signed-in user', () {
    CallRecord call(String id, String caller, String callee) => CallRecord(
      id: id,
      conversationId: 'conversation-1',
      callerId: caller,
      calleeId: callee,
      mediaType: 'audio',
      status: 'ended',
      createdAt: DateTime.utc(2026, 10, 7),
    );
    final visible = filterCallHistoryForUser(
      [
        call('call-owned-1', 'user-a', 'user-b'),
        call('call-owned-2', 'user-c', 'user-a'),
        call('call-other', 'user-b', 'user-c'),
      ],
      'user-a',
      {'call-owned-1'},
    );

    expect(visible.map((record) => record.id), ['call-owned-2']);
  });

  test('incoming call timeout uses the original creation time', () {
    final now = DateTime.utc(2026, 10, 10, 9, 0);
    CallRecord callAtStart(int secondsAgo) => CallRecord(
      id: 'call-timeout-$secondsAgo',
      conversationId: 'conversation-1',
      callerId: 'user-a',
      calleeId: 'user-b',
      mediaType: 'audio',
      status: 'ringing',
      createdAt: now.subtract(Duration(seconds: secondsAgo)),
    );

    expect(
      remainingIncomingCallDuration(callAtStart(30), now: now),
      const Duration(seconds: 60),
    );
    expect(
      remainingIncomingCallDuration(callAtStart(90), now: now),
      Duration.zero,
    );
    expect(
      remainingIncomingCallDuration(callAtStart(100), now: now),
      Duration.zero,
    );
  });

  test('call signal parses JSON payload safely', () {
    final signal = CallSignal.fromRow({
      'id': 'signal-1',
      'call_id': 'call-1',
      'signal_type': 'ice',
      'data': {
        'candidate': 'candidate:1 1 UDP 2122260223 192.0.2.1 5000 typ host',
        'sdpMid': '0',
        'sdpMLineIndex': 0,
      },
    });

    expect(signal.kind, 'ice');
    expect(signal.data['sdpMid'], '0');
    expect(signal.data['sdpMLineIndex'], 0);
  });

  test('incoming-call prompt accepts or declines only once', () {
    final accepted = IncomingCallPromptFlow();
    expect(accepted.complete(IncomingCallDialogResult.answered), isTrue);
    expect(accepted.result, IncomingCallDialogResult.answered);
    expect(accepted.complete(IncomingCallDialogResult.declined), isFalse);

    final declined = IncomingCallPromptFlow();
    expect(declined.complete(IncomingCallDialogResult.declined), isTrue);
    expect(declined.result, IncomingCallDialogResult.declined);
  });

  test('terminal call updates dismiss one prompt exactly once', () {
    for (final status in [
      'accepted',
      'rejected',
      'cancelled',
      'missed',
      'ended',
    ]) {
      final prompt = IncomingCallPromptFlow();
      expect(prompt.completeForCallStatus('ringing'), isFalse);
      expect(prompt.completeForCallStatus(status), isTrue, reason: status);
      expect(prompt.result, IncomingCallDialogResult.unavailable);
      expect(prompt.completeForCallStatus(status), isFalse);
    }
  });

  test('incoming-call prompt gate never opens a duplicate call screen', () {
    final gate = IncomingCallPromptGate();
    expect(gate.tryOpen('call-1'), isTrue);
    expect(gate.tryOpen('call-1'), isFalse);
    gate.close('call-1');
    expect(gate.tryOpen('call-1'), isFalse);
    expect(gate.tryOpen('call-2'), isTrue);
    gate.close('call-2');
  });
}
