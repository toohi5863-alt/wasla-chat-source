import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

import 'chat_local_cache.dart';
import 'chat_image_cache.dart';
import 'chat_models.dart';
import 'device_media_saver.dart';

String? avatarPublicUrl(SupabaseClient client, String? path) {
  if (path == null || path.isEmpty) return null;
  return client.storage.from('wasla-avatars').getPublicUrl(path);
}

class MessageMedia extends StatelessWidget {
  const MessageMedia({
    required this.client,
    required this.message,
    required this.userId,
    super.key,
  });

  final SupabaseClient client;
  final ChatMessage message;
  final String userId;

  Widget _withSaveAction(String path, Widget media) {
    if (message.isPending) return media;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        media,
        _MediaSaveButton(
          client: client,
          path: path,
          bucket: 'wasla-media',
          userId: userId,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (message.isPending && message.messageType != 'image') {
      return _PendingMessageMedia(message: message);
    }
    if (message.messageType == 'location') {
      return _LocationMessage(content: message.content);
    }
    final path = message.mediaPath;
    if (path == null || path.isEmpty) return const Text('تعذر تحميل الوسائط');
    if (message.messageType == 'image') {
      return _withSaveAction(
        path,
        _PrivateMessageImage(
          key: ValueKey('${message.id}:${message.isPending}:$path'),
          client: client,
          path: path,
          userId: userId,
        ),
      );
    }
    if (message.messageType == 'video') {
      return _withSaveAction(
        path,
        _PrivateVideoMessage(client: client, path: path, userId: userId),
      );
    }
    if (message.messageType == 'file') {
      return _withSaveAction(
        path,
        _PrivateFileMessage(
          client: client,
          path: path,
          name: message.content,
          userId: userId,
        ),
      );
    }
    if (message.messageType == 'audio') {
      return _withSaveAction(
        path,
        _VoiceMessagePlayer(
          client: client,
          path: path,
          userId: userId,
          durationSeconds: message.mediaDurationSeconds ?? 0,
        ),
      );
    }
    return Text(message.content);
  }
}

class _MediaSaveButton extends StatefulWidget {
  const _MediaSaveButton({
    required this.client,
    required this.path,
    required this.bucket,
    required this.userId,
  });

  final SupabaseClient client;
  final String path;
  final String bucket;
  final String userId;

  @override
  State<_MediaSaveButton> createState() => _MediaSaveButtonState();
}

class _MediaSaveButtonState extends State<_MediaSaveButton> {
  bool _saving = false;

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final fileName = widget.path.replaceAll('\\', '/').split('/').last;
      final localFile = await ChatLocalCache().findMedia(
        widget.userId,
        widget.path,
      );
      final saver = DeviceMediaSaver();
      final location = localFile != null
          ? await saver.saveLocalFile(
              filePath: localFile.path,
              fileName: fileName,
              mimeType: mediaMimeTypeForFileName(fileName),
            )
          : await saver.saveFromUrl(
              url: await widget.client.storage
                  .from(widget.bucket)
                  .createSignedUrl(widget.path, 900),
              fileName: fileName,
              mimeType: mediaMimeTypeForFileName(fileName),
            );
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('تم الحفظ في $location')));
      }
    } on DeviceMediaSaveException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message)));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر حفظ الملف. حاول مرة أخرى.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => TextButton.icon(
    onPressed: _saving ? null : _save,
    icon: _saving
        ? const SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(strokeWidth: 2),
          )
        : const Icon(Icons.download_for_offline_outlined, size: 18),
    label: const Text('حفظ في الهاتف'),
  );
}

class _PendingMessageMedia extends StatelessWidget {
  const _PendingMessageMedia({required this.message});

  final ChatMessage message;

  @override
  Widget build(BuildContext context) => Container(
    width: 220,
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(
      color: const Color(0x10087F72),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          message.messageType == 'location'
              ? Icons.location_on_outlined
              : message.messageType == 'audio'
              ? Icons.graphic_eq
              : message.messageType == 'video'
              ? Icons.videocam_outlined
              : Icons.insert_drive_file_outlined,
          size: 20,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                message.messageType == 'location' ? 'موقعك' : message.content,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const Text(
                'بانتظار الاتصال للإرسال',
                style: TextStyle(fontSize: 11, color: Color(0xFF71827D)),
              ),
            ],
          ),
        ),
        const SizedBox(width: 5),
        const Icon(Icons.schedule, size: 15, color: Color(0xFF71827D)),
      ],
    ),
  );
}

class _PrivateMessageImage extends StatefulWidget {
  const _PrivateMessageImage({
    super.key,
    required this.client,
    required this.path,
    required this.userId,
  });
  final SupabaseClient client;
  final String path;
  final String userId;

  @override
  State<_PrivateMessageImage> createState() => _PrivateMessageImageState();
}

class _PrivateMessageImageState extends State<_PrivateMessageImage> {
  final _cache = ChatLocalCache();
  late Future<({File? file, String? url})> _imageSource;

  @override
  void initState() {
    super.initState();
    _imageSource = _loadImage();
  }

  @override
  void didUpdateWidget(covariant _PrivateMessageImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.path != widget.path || oldWidget.userId != widget.userId) {
      _imageSource = _loadImage();
    }
  }

  Future<({File? file, String? url})> _loadImage() async {
    try {
      final cachedFile = await _cache.findMedia(widget.userId, widget.path);
      if (cachedFile != null) return (file: cachedFile, url: null);
      final imageFile = await ChatImageCache.findCachedFile(
        widget.userId,
        widget.path,
      );
      if (imageFile != null) {
        try {
          final persistentFile = await _cache.saveMediaBytes(
            widget.userId,
            widget.path,
            await imageFile.readAsBytes(),
          );
          return (file: persistentFile, url: null);
        } catch (_) {
          // Keep rendering images cached by older app versions if migration
          // cannot write to the persistent media directory.
          return (file: imageFile, url: null);
        }
      }
      final signedUrl = await widget.client.storage
          .from('wasla-media')
          .createSignedUrl(widget.path, 3600);
      final downloadedFile = await _cache.cacheMediaFromUrl(
        widget.userId,
        widget.path,
        signedUrl,
      );
      if (downloadedFile != null) return (file: downloadedFile, url: null);
      return (file: null, url: signedUrl);
    } catch (_) {
      return (file: null, url: null);
    }
  }

  Widget _imagePresentation(
    BuildContext context,
    ImageProvider<Object> imageProvider,
  ) => GestureDetector(
    onTap: () => showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(14),
        child: InteractiveViewer(
          child: Image(
            image: imageProvider,
            fit: BoxFit.contain,
            errorBuilder: (_, _, _) => const Padding(
              padding: EdgeInsets.all(24),
              child: Text('تعذر عرض الصورة'),
            ),
          ),
        ),
      ),
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image(
        image: imageProvider,
        width: 230,
        height: 190,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => const SizedBox(
          width: 230,
          height: 120,
          child: Center(child: Text('تعذر عرض الصورة')),
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) =>
      FutureBuilder<({File? file, String? url})>(
        future: _imageSource,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const SizedBox(
              width: 210,
              height: 120,
              child: Center(child: Text('تعذر تحميل الصورة')),
            );
          }
          if (snapshot.connectionState != ConnectionState.done) {
            return const SizedBox(
              width: 210,
              height: 140,
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            );
          }
          final source = snapshot.data;
          if (source == null) {
            return const SizedBox(
              width: 210,
              height: 120,
              child: Center(child: Text('تعذر تحميل الصورة')),
            );
          }
          final imageFile = source.file;
          if (imageFile != null) {
            return _imagePresentation(context, FileImage(imageFile));
          }
          final signedUrl = source.url;
          if (signedUrl == null) {
            return const SizedBox(
              width: 210,
              height: 120,
              child: Center(child: Text('تعذر تحميل الصورة')),
            );
          }
          final userId = widget.userId;
          final path = widget.path;
          return CachedNetworkImage(
            imageUrl: signedUrl,
            cacheKey: ChatImageCache.cacheKeyFor(userId, path),
            cacheManager: ChatImageCache.managerFor(userId),
            width: 230,
            height: 190,
            fit: BoxFit.cover,
            imageBuilder: (context, imageProvider) =>
                _imagePresentation(context, imageProvider),
            placeholder: (_, _) => const SizedBox(
              width: 210,
              height: 140,
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            ),
            errorWidget: (_, _, _) => const SizedBox(
              width: 210,
              height: 120,
              child: Center(child: Text('تعذر تحميل الصورة')),
            ),
          );
        },
      );
}

class _PrivateVideoMessage extends StatefulWidget {
  const _PrivateVideoMessage({
    required this.client,
    required this.path,
    required this.userId,
  });
  final SupabaseClient client;
  final String path;
  final String userId;

  @override
  State<_PrivateVideoMessage> createState() => _PrivateVideoMessageState();
}

class _PrivateVideoMessageState extends State<_PrivateVideoMessage> {
  final ChatLocalCache _cache = ChatLocalCache();
  VideoPlayerController? _controller;
  String? _error;
  bool _loading = true;
  int _loadGeneration = 0;

  @override
  void initState() {
    super.initState();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    final generation = ++_loadGeneration;
    final client = widget.client;
    final path = widget.path;
    final userId = widget.userId;
    VideoPlayerController? controller;
    try {
      var file = await _cache.findMedia(userId, path);
      String? signedUrl;
      if (file == null) {
        signedUrl = await client.storage
            .from('wasla-media')
            .createSignedUrl(path, 3600);
        file = await _cache.cacheMediaFromUrl(userId, path, signedUrl);
      }
      controller = file != null
          ? VideoPlayerController.file(file)
          : VideoPlayerController.networkUrl(Uri.parse(signedUrl!));
      await controller.initialize();
      if (!mounted || generation != _loadGeneration) {
        await controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || generation != _loadGeneration) {
        await controller?.dispose();
        return;
      }
      if (controller != null) await controller.dispose();
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'تعذر تحميل الفيديو';
        });
      }
    }
  }

  @override
  void didUpdateWidget(covariant _PrivateVideoMessage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.path == widget.path && oldWidget.userId == widget.userId) {
      return;
    }
    _loadGeneration++;
    final previousController = _controller;
    _controller = null;
    unawaited(previousController?.dispose());
    setState(() {
      _loading = true;
      _error = null;
    });
    unawaited(_initialize());
  }

  @override
  void dispose() {
    _loadGeneration++;
    unawaited(_controller?.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (_loading) {
      return const SizedBox(
        width: 230,
        height: 140,
        child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    if (controller == null || _error != null) {
      return SizedBox(
        width: 230,
        height: 120,
        child: Center(child: Text(_error ?? 'تعذر تحميل الفيديو')),
      );
    }
    return SizedBox(
      width: 230,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: controller.value.aspectRatio > 0
                  ? controller.value.aspectRatio
                  : 16 / 9,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  VideoPlayer(controller),
                  IconButton.filledTonal(
                    tooltip: controller.value.isPlaying
                        ? 'إيقاف مؤقت'
                        : 'تشغيل الفيديو',
                    onPressed: () => setState(() {
                      controller.value.isPlaying
                          ? controller.pause()
                          : controller.play();
                    }),
                    icon: Icon(
                      controller.value.isPlaying
                          ? Icons.pause
                          : Icons.play_arrow,
                    ),
                  ),
                ],
              ),
            ),
          ),
          VideoProgressIndicator(
            controller,
            allowScrubbing: true,
            padding: const EdgeInsets.symmetric(vertical: 6),
          ),
        ],
      ),
    );
  }
}

class _PrivateFileMessage extends StatefulWidget {
  const _PrivateFileMessage({
    required this.client,
    required this.path,
    required this.name,
    required this.userId,
  });
  final SupabaseClient client;
  final String path;
  final String name;
  final String userId;

  @override
  State<_PrivateFileMessage> createState() => _PrivateFileMessageState();
}

class _PrivateFileMessageState extends State<_PrivateFileMessage> {
  final ChatLocalCache _cache = ChatLocalCache();
  bool _loading = false;

  Future<void> _openFile() async {
    if (_loading) return;
    setState(() => _loading = true);
    try {
      var file = await _cache.findMedia(widget.userId, widget.path);
      if (file == null) {
        final signedUrl = await widget.client.storage
            .from('wasla-media')
            .createSignedUrl(widget.path, 3600);
        file = await _cache.cacheMediaFromUrl(
          widget.userId,
          widget.path,
          signedUrl,
        );
      }
      if (file == null) throw StateError('Media cache failed');
      if (!mounted) return;
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          text: widget.name.isEmpty ? 'ملف من وصال' : widget.name,
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر تجهيز الملف. حاول مرة أخرى.')),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 230,
    child: OutlinedButton.icon(
      onPressed: _loading ? null : _openFile,
      icon: _loading
          ? const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          : const Icon(Icons.insert_drive_file_outlined),
      label: Text(
        widget.name.isEmpty ? 'فتح الملف' : widget.name,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      ),
    ),
  );
}

class _LocationMessage extends StatelessWidget {
  const _LocationMessage({required this.content});
  final String content;

  @override
  Widget build(BuildContext context) {
    final parts = content.split(',');
    final lat = parts.isEmpty ? null : double.tryParse(parts[0]);
    final lon = parts.length < 2 ? null : double.tryParse(parts[1]);
    if (lat == null ||
        lon == null ||
        lat < -90 ||
        lat > 90 ||
        lon < -180 ||
        lon > 180) {
      return const Text('موقع غير صالح');
    }
    final url = Uri.https('maps.google.com', '/maps', {'q': '$lat,$lon'});
    return OutlinedButton.icon(
      onPressed: () => launchUrl(url, mode: LaunchMode.externalApplication),
      icon: const Icon(Icons.location_on_outlined),
      label: const Text('عرض الموقع على الخريطة'),
    );
  }
}

class _VoiceMessagePlayer extends StatefulWidget {
  const _VoiceMessagePlayer({
    required this.client,
    required this.path,
    required this.userId,
    required this.durationSeconds,
  });

  final SupabaseClient client;
  final String path;
  final String userId;
  final int durationSeconds;

  @override
  State<_VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<_VoiceMessagePlayer> {
  final ChatLocalCache _cache = ChatLocalCache();
  final AudioPlayer _player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _subscriptions = [];
  bool _playing = false;
  bool _loading = false;
  String? _error;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();
    _subscriptions.add(
      _player.onPlayerStateChanged.listen((state) {
        if (mounted) setState(() => _playing = state == PlayerState.playing);
      }),
    );
    _subscriptions.add(
      _player.onPositionChanged.listen((position) {
        if (mounted) setState(() => _position = position);
      }),
    );
    _subscriptions.add(
      _player.onPlayerComplete.listen((_) {
        if (mounted) setState(() => _position = Duration.zero);
      }),
    );
  }

  Future<void> _toggle() async {
    if (_loading) return;
    if (_playing) {
      await _player.pause();
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      var file = await _cache.findMedia(widget.userId, widget.path);
      if (file != null) {
        await _player.play(DeviceFileSource(file.path));
      } else {
        final url = await widget.client.storage
            .from('wasla-media')
            .createSignedUrl(widget.path, 3600);
        file = await _cache.cacheMediaFromUrl(widget.userId, widget.path, url);
        if (file == null) {
          await _player.play(UrlSource(url));
        } else {
          await _player.play(DeviceFileSource(file.path));
        }
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذر تشغيل الصوت');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    for (final subscription in _subscriptions) {
      unawaited(subscription.cancel());
    }
    unawaited(_player.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final total = Duration(seconds: widget.durationSeconds);
    final progress = total.inMilliseconds == 0
        ? 0.0
        : (_position.inMilliseconds / total.inMilliseconds).clamp(0.0, 1.0);
    return SizedBox(
      width: 220,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            visualDensity: VisualDensity.compact,
            tooltip: _playing ? 'إيقاف مؤقت' : 'تشغيل الرسالة الصوتية',
            onPressed: _toggle,
            icon: _loading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Icon(
                    _playing
                        ? Icons.pause_circle_filled
                        : Icons.play_circle_fill,
                  ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LinearProgressIndicator(value: progress),
                const SizedBox(height: 4),
                Text(
                  _error ?? _formatDuration(_playing ? _position : total),
                  style: TextStyle(
                    fontSize: 11,
                    color: _error == null
                        ? const Color(0xFF71827D)
                        : Colors.red,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          const Icon(Icons.graphic_eq, size: 20),
        ],
      ),
    );
  }
}

String _formatDuration(Duration duration) {
  final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
  final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}
