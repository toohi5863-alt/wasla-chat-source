import 'package:chat/status_models.dart';
import 'package:chat/status_service.dart';
import 'package:chat/statuses.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/shared_preferences'),
          (call) async => <String, Object?>{},
        );
    await Supabase.initialize(
      url: 'https://example.supabase.co',
      publishableKey: 'test-publishable-key',
    );
  });

  final now = DateTime.now().toUtc();
  StatusItem makeStatus(String id, String body, {bool isMine = true}) =>
      StatusItem(
        id: id,
        userId: isMine ? 'me' : 'friend',
        username: isMine ? 'me' : 'friend',
        displayName: isMine ? 'درويش' : 'صديق',
        contentType: 'text',
        body: body,
        backgroundColor: 0xFF087F72,
        createdAt: now,
        expiresAt: now.add(const Duration(hours: 24)),
        isMine: isMine,
        isViewed: true,
        viewsCount: 0,
      );

  Widget screen() => MaterialApp(
    home: StatusViewerScreen(
      statuses: [
        makeStatus('first', 'الحالة الأولى'),
        makeStatus('second', 'الحالة الثانية'),
      ],
      service: StatusService(Supabase.instance.client),
    ),
  );

  testWidgets('automatically advances from a text status after its duration', (
    tester,
  ) async {
    await tester.pumpWidget(screen());
    expect(find.text('الحالة الأولى'), findsOneWidget);

    await tester.pump(const Duration(seconds: 7));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('الحالة الثانية'), findsOneWidget);

    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('long press pauses automatic advancement', (tester) async {
    await tester.pumpWidget(screen());
    expect(find.text('الحالة الأولى'), findsOneWidget);

    final gesture = await tester.startGesture(
      tester.getCenter(find.byType(PageView)),
    );
    await tester.pump(const Duration(milliseconds: 600));
    expect(find.byIcon(Icons.play_arrow_rounded), findsOneWidget);
    expect(find.byTooltip('استئناف العرض'), findsOneWidget);

    await tester.pump(const Duration(seconds: 8));
    expect(find.text('الحالة الأولى'), findsOneWidget);
    await gesture.up();
    await tester.pump();
    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('top-bar control pauses and resumes status playback', (
    tester,
  ) async {
    await tester.pumpWidget(screen());
    expect(find.byTooltip('إيقاف العرض'), findsOneWidget);

    await tester.tap(find.byTooltip('إيقاف العرض'));
    await tester.pump();
    expect(find.byTooltip('استئناف العرض'), findsOneWidget);

    await tester.pump(const Duration(seconds: 8));
    expect(find.text('الحالة الأولى'), findsOneWidget);

    await tester.tap(find.byTooltip('استئناف العرض'));
    await tester.pump();
    expect(find.byTooltip('إيقاف العرض'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
  });

  testWidgets('another person’s status exposes a private reply composer', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: StatusViewerScreen(
          statuses: [makeStatus('friend-status', 'حالة صديق', isMine: false)],
          service: StatusService(Supabase.instance.client),
        ),
      ),
    );
    await tester.pump();

    expect(find.text('اكتب ردًا خاصًا على الحالة…'), findsOneWidget);
    expect(find.byTooltip('إرسال رد خاص'), findsOneWidget);
    expect(find.text('لا يراه إلا أنت وصاحب الحالة'), findsOneWidget);

    await tester.pumpWidget(const SizedBox.shrink());
  });
}
