import 'package:flutter_test/flutter_test.dart';
import 'package:chat/main.dart';

void main() {
  testWidgets('shows a setup screen instead of fake chats without a backend', (
    tester,
  ) async {
    await tester.pumpWidget(const WaslaApp(backendReady: false));
    expect(find.text('وصال جاهز للربط'), findsOneWidget);
    expect(find.textContaining('مشروع Supabase مستقل'), findsOneWidget);
    expect(find.textContaining('service_role key'), findsOneWidget);
  });
}
