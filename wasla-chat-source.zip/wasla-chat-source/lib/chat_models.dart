class ChatTarget {
  const ChatTarget({
    required this.conversationId,
    required this.userId,
    required this.username,
    required this.displayName,
    this.avatarPath,
    this.bio = '',
    this.isGroup = false,
    this.groupDescription = '',
    this.memberCount = 0,
    this.groupRole,
    this.isPublicRoom = false,
  });

  final String conversationId;
  final String userId;
  final String username;
  final String displayName;
  final String? avatarPath;
  final String bio;
  final bool isGroup;
  final String groupDescription;
  final int memberCount;
  final String? groupRole;
  final bool isPublicRoom;
}

class ChatPreview {
  const ChatPreview({
    required this.conversationId,
    required this.otherUserId,
    required this.username,
    required this.displayName,
    required this.lastMessage,
    this.avatarPath,
    this.lastMessageType = 'text',
    this.lastMessageAt,
    this.lastMessageSenderId,
    this.lastMessageDeliveredAt,
    this.lastMessageReadAt,
    this.isGroup = false,
    this.groupName,
    this.groupAvatarPath,
    this.groupDescription = '',
    this.memberCount = 0,
    this.groupRole,
  });

  final String conversationId;
  final String otherUserId;
  final String username;
  final String displayName;
  final String? avatarPath;
  final String lastMessage;
  final String lastMessageType;
  final DateTime? lastMessageAt;
  final String? lastMessageSenderId;
  final DateTime? lastMessageDeliveredAt;
  final DateTime? lastMessageReadAt;
  final bool isGroup;
  final String? groupName;
  final String? groupAvatarPath;
  final String groupDescription;
  final int memberCount;
  final String? groupRole;

  Map<String, dynamic> toMap() => {
    'conversation_id': conversationId,
    'other_user_id': otherUserId,
    'username': username,
    'display_name': displayName,
    'avatar_path': avatarPath,
    'last_message': lastMessage,
    'last_message_type': lastMessageType,
    'last_message_at': lastMessageAt?.toIso8601String(),
    'last_message_sender_id': lastMessageSenderId,
    'last_message_delivered_at': lastMessageDeliveredAt?.toIso8601String(),
    'last_message_read_at': lastMessageReadAt?.toIso8601String(),
    'is_group': isGroup,
    'group_name': groupName,
    'group_avatar_path': groupAvatarPath,
    'group_description': groupDescription,
    'member_count': memberCount,
    'group_role': groupRole,
  };

  factory ChatPreview.fromMap(Map<String, dynamic> map) {
    final group =
        map['is_group'] == true || map['is_group']?.toString() == 'true';
    return ChatPreview(
      conversationId: map['conversation_id'].toString(),
      otherUserId: map['other_user_id']?.toString() ?? '',
      username: map['username']?.toString() ?? '',
      displayName: group
          ? (map['group_name']?.toString() ??
                map['display_name']?.toString() ??
                '')
          : (map['display_name']?.toString() ?? ''),
      avatarPath: map['avatar_path']?.toString(),
      lastMessage: map['last_message']?.toString() ?? '',
      lastMessageType: map['last_message_type']?.toString() ?? 'text',
      lastMessageAt: _date(map['last_message_at']),
      lastMessageSenderId: map['last_message_sender_id']?.toString(),
      lastMessageDeliveredAt: _date(map['last_message_delivered_at']),
      lastMessageReadAt: _date(map['last_message_read_at']),
      isGroup: group,
      groupName: map['group_name']?.toString(),
      groupAvatarPath: map['group_avatar_path']?.toString(),
      groupDescription: map['group_description']?.toString() ?? '',
      memberCount: _integer(map['member_count']),
      groupRole: map['group_role']?.toString(),
    );
  }
}

class ChatMessage {
  const ChatMessage({
    required this.id,
    required this.senderId,
    required this.content,
    required this.createdAt,
    this.messageType = 'text',
    this.mediaPath,
    this.mediaDurationSeconds,
    this.deliveredAt,
    this.readAt,
    this.replyTo,
    this.editedAt,
    this.isPending = false,
    this.isEphemeral = false,
    this.payloadDeletedAt,
    this.hasLocalPayload = false,
  });

  final String id;
  final String senderId;
  final String content;
  final DateTime createdAt;
  final String messageType;
  final String? mediaPath;
  final int? mediaDurationSeconds;
  final DateTime? deliveredAt;
  final DateTime? readAt;
  final String? replyTo;
  final DateTime? editedAt;
  final bool isPending;
  final bool isEphemeral;
  final DateTime? payloadDeletedAt;
  final bool hasLocalPayload;

  ChatMessage copyWith({
    bool? isPending,
    bool? isEphemeral,
    DateTime? payloadDeletedAt,
    bool? hasLocalPayload,
  }) => ChatMessage(
    id: id,
    senderId: senderId,
    content: content,
    createdAt: createdAt,
    messageType: messageType,
    mediaPath: mediaPath,
    mediaDurationSeconds: mediaDurationSeconds,
    deliveredAt: deliveredAt,
    readAt: readAt,
    replyTo: replyTo,
    editedAt: editedAt,
    isPending: isPending ?? this.isPending,
    isEphemeral: isEphemeral ?? this.isEphemeral,
    payloadDeletedAt: payloadDeletedAt ?? this.payloadDeletedAt,
    hasLocalPayload: hasLocalPayload ?? this.hasLocalPayload,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'sender_id': senderId,
    'content': content,
    'created_at': createdAt.toIso8601String(),
    'message_type': messageType,
    'media_path': mediaPath,
    'media_duration_seconds': mediaDurationSeconds,
    'delivered_at': deliveredAt?.toIso8601String(),
    'read_at': readAt?.toIso8601String(),
    'reply_to': replyTo,
    'edited_at': editedAt?.toIso8601String(),
    'is_pending': isPending,
    'ephemeral': isEphemeral,
    'payload_deleted_at': payloadDeletedAt?.toIso8601String(),
    'has_local_payload': hasLocalPayload,
  };

  factory ChatMessage.fromMap(Map<String, dynamic> map) => ChatMessage(
    id: map['id'].toString(),
    senderId: map['sender_id'].toString(),
    content: map['content']?.toString() ?? '',
    createdAt: _date(map['created_at']) ?? DateTime.now(),
    messageType: map['message_type']?.toString() ?? 'text',
    mediaPath: map['media_path']?.toString(),
    mediaDurationSeconds: _integer(map['media_duration_seconds']),
    deliveredAt: _date(map['delivered_at']),
    readAt: _date(map['read_at']),
    replyTo: map['reply_to']?.toString(),
    editedAt: _date(map['edited_at']),
    isPending:
        map['is_pending'] == true || map['is_pending']?.toString() == 'true',
    isEphemeral:
        map['ephemeral'] == true || map['ephemeral']?.toString() == 'true',
    payloadDeletedAt: _date(map['payload_deleted_at']),
    hasLocalPayload:
        map['has_local_payload'] == true ||
        map['has_local_payload']?.toString() == 'true',
  );
}

DateTime? _date(dynamic value) =>
    value == null ? null : DateTime.tryParse(value.toString());

int _integer(dynamic value) =>
    value is num ? value.toInt() : int.tryParse(value?.toString() ?? '') ?? 0;
