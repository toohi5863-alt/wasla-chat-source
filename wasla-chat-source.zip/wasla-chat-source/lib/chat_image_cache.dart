import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

/// Disk cache for private message images, isolated by signed-in account.
///
/// Cache keys do not contain expiring signed URLs, so a locally cached image is
/// still discoverable after the URL expires or the device goes offline.
class ChatImageCache {
  ChatImageCache._();

  static final Map<String, CacheManager> _managers = {};

  static CacheManager managerFor(String userId) => _managers.putIfAbsent(
    userId,
    () => CacheManager(
      Config(
        'wasla_images_${_safeKey(userId)}',
        stalePeriod: const Duration(days: 365),
        maxNrOfCacheObjects: 500,
      ),
    ),
  );

  @visibleForTesting
  static void registerManagerForTesting(String userId, CacheManager manager) {
    _managers[userId] = manager;
  }

  static String cacheKeyFor(String userId, String storagePath) {
    final encodedPath = base64Url
        .encode(utf8.encode(storagePath))
        .replaceAll('=', '');
    return 'account_${_safeKey(userId)}_media_$encodedPath';
  }

  static Future<File?> findCachedFile(String userId, String storagePath) async {
    final cached = await managerFor(userId)
        .getFileFromCache(cacheKeyFor(userId, storagePath));
    if (cached == null) return null;
    try {
      if (await cached.file.exists() && await cached.file.length() > 0) {
        return cached.file;
      }
    } on FileSystemException {
      return null;
    }
    return null;
  }

  static Future<File> download(
    String userId,
    String storagePath,
    String signedUrl,
  ) =>
      managerFor(userId)
          .getSingleFile(signedUrl, key: cacheKeyFor(userId, storagePath));

  /// Test cleanup; production caches remain available across app restarts.
  static Future<void> disposeForTesting() async {
    final managers = _managers.values.toList();
    _managers.clear();
    await Future.wait(managers.map((manager) => manager.dispose()));
  }
}

String _safeKey(String value) => utf8
    .encode(value)
    .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
    .join();
