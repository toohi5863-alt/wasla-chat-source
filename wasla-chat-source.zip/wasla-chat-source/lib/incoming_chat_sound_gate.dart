/// Allows a sound only for a unique, newly inserted message from another user.
///
/// History loads and updates must not be passed as inserts; the gate also
/// remembers handled message IDs for the lifetime of an open conversation.
class IncomingChatSoundGate {
  final Set<String> _handledMessageIds = <String>{};

  bool shouldPlay({
    required bool isInsert,
    required String? messageId,
    required String? senderId,
    required String? currentUserId,
  }) {
    if (!isInsert ||
        messageId == null ||
        messageId.isEmpty ||
        senderId == null ||
        senderId.isEmpty ||
        currentUserId == null ||
        currentUserId.isEmpty ||
        senderId == currentUserId ||
        !_handledMessageIds.add(messageId)) {
      return false;
    }
    return true;
  }
}
