import 'package:supabase_flutter/supabase_flutter.dart';

import 'friendship_models.dart';

class FriendshipService {
  const FriendshipService(this._client);

  final SupabaseClient _client;

  Future<FriendshipStatus> statusFor(String peerUserId) async {
    final result = await _client.rpc(
      'get_friendship_status',
      params: {'p_peer_user_id': peerUserId},
    );
    if (result is Map) {
      return FriendshipStatus.fromMap(Map<String, dynamic>.from(result));
    }
    return const FriendshipStatus();
  }

  Future<String> sendRequest(String peerUserId) async => (await _client.rpc(
    'send_friend_request',
    params: {'p_target_user_id': peerUserId},
  )).toString();

  Future<String> respond(
    String requesterUserId, {
    required bool accept,
  }) async => (await _client.rpc(
    'respond_friend_request',
    params: {'p_requester_user_id': requesterUserId, 'p_accept': accept},
  )).toString();

  Future<String> cancel(String peerUserId) async => (await _client.rpc(
    'cancel_friendship',
    params: {'p_peer_user_id': peerUserId},
  )).toString();

  Future<List<Friend>> friends() async {
    final rows = await _client.rpc('list_friends');
    return (rows as List<dynamic>)
        .map((row) => Friend.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList();
  }

  Future<List<FriendRequest>> incomingRequests() async {
    final rows = await _client.rpc('list_incoming_friend_requests');
    return (rows as List<dynamic>)
        .map(
          (row) => FriendRequest.fromMap(Map<String, dynamic>.from(row as Map)),
        )
        .toList();
  }
}
