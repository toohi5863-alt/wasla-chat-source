import 'status_models.dart';

class StatusGroup {
  const StatusGroup({required this.userId, required this.statuses});

  final String userId;
  final List<StatusItem> statuses;

  bool get hasUnseen => statuses.any((status) => !status.isViewed);
}

/// Groups friends' statuses, optionally keeping only unseen items, and sorts
/// authors with unseen statuses ahead of fully viewed authors.
List<StatusGroup> groupFriendStatuses(
  Iterable<StatusItem> items, {
  required String? currentUserId,
  bool unseenOnly = false,
}) {
  final grouped = <String, List<StatusItem>>{};
  for (final item in items) {
    if (item.userId == currentUserId || (unseenOnly && item.isViewed)) continue;
    grouped.putIfAbsent(item.userId, () => <StatusItem>[]).add(item);
  }

  final groups = grouped.entries.map((entry) {
    final statuses = entry.value
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return StatusGroup(
      userId: entry.key,
      statuses: List<StatusItem>.unmodifiable(statuses),
    );
  }).toList();
  groups.sort((a, b) {
    final unseenOrder = (b.hasUnseen ? 1 : 0).compareTo(a.hasUnseen ? 1 : 0);
    if (unseenOrder != 0) return unseenOrder;
    return b.statuses.first.createdAt.compareTo(a.statuses.first.createdAt);
  });
  return List<StatusGroup>.unmodifiable(groups);
}
