-- PROPOSAL ONLY — NOT APPLIED.
-- This side table lets a user hide a call from their own history without
-- deleting or changing public.calls, call_signals, or the other participant's view.
-- Review and explicitly apply as a future migration before enabling server sync.

create table if not exists public.call_history_hidden (
  user_id uuid not null references auth.users(id) on delete cascade,
  call_id uuid not null references public.calls(id) on delete cascade,
  hidden_at timestamptz not null default now(),
  primary key (user_id, call_id)
);

alter table public.call_history_hidden enable row level security;
revoke all on public.call_history_hidden from anon, authenticated;
grant select, insert, delete on public.call_history_hidden to authenticated;

drop policy if exists call_history_hidden_select_own
  on public.call_history_hidden;
create policy call_history_hidden_select_own
  on public.call_history_hidden
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists call_history_hidden_insert_own_participant
  on public.call_history_hidden;
create policy call_history_hidden_insert_own_participant
  on public.call_history_hidden
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1
      from public.calls c
      where c.id = call_history_hidden.call_id
        and (c.caller_id = (select auth.uid()) or c.callee_id = (select auth.uid()))
    )
  );

drop policy if exists call_history_hidden_delete_own
  on public.call_history_hidden;
create policy call_history_hidden_delete_own
  on public.call_history_hidden
  for delete to authenticated
  using (user_id = (select auth.uid()));

-- Intentionally no UPDATE grant/policy and no DELETE grant/policy on public.calls.
