-- Wasla 1.2 additive migration: retain all profiles, conversations, and messages.
-- Adds profile customization, delivery/read receipts, and access-controlled media.

alter table public.profiles
  add column if not exists avatar_path text,
  add column if not exists bio text not null default '';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.profiles'::regclass
      and conname = 'profiles_bio_length_check'
  ) then
    alter table public.profiles
      add constraint profiles_bio_length_check
      check (char_length(bio) <= 160);
  end if;
end;
$$;

alter table public.messages
  add column if not exists message_type text not null default 'text',
  add column if not exists media_path text,
  add column if not exists media_duration_seconds integer,
  add column if not exists delivered_at timestamptz,
  add column if not exists read_at timestamptz;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.messages'::regclass
      and conname = 'messages_type_media_check'
  ) then
    alter table public.messages
      add constraint messages_type_media_check
      check (
        (message_type = 'text' and media_path is null and media_duration_seconds is null)
        or (message_type = 'image' and media_path is not null and media_duration_seconds is null)
        or (message_type = 'audio' and media_path is not null
            and media_duration_seconds between 1 and 180)
      );
  end if;
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.messages'::regclass
      and conname = 'messages_media_path_scope_check'
  ) then
    alter table public.messages
      add constraint messages_media_path_scope_check
      check (
        media_path is null
        or (
          split_part(media_path, '/', 1) = conversation_id::text
          and split_part(media_path, '/', 2) = sender_id::text
        )
      );
  end if;
end;
$$;

create index if not exists messages_unread_conversation_idx
  on public.messages (conversation_id, read_at)
  where read_at is null;

-- Keep profile edits limited to fields intentionally exposed by the client.
revoke update on public.profiles from authenticated;
grant update (display_name, avatar_path, bio) on public.profiles to authenticated;

-- A recipient can set delivery/read timestamps on messages from the other member.
-- Column-level privileges prevent clients from editing message text or ownership.
drop policy if exists messages_mark_received on public.messages;
create policy messages_mark_received on public.messages
  for update to authenticated
  using (
    sender_id <> (select auth.uid())
    and private.is_conversation_member(conversation_id)
  )
  with check (
    sender_id <> (select auth.uid())
    and private.is_conversation_member(conversation_id)
  );
revoke update on public.messages from authenticated;
grant update (delivered_at, read_at) on public.messages to authenticated;

-- Expand the inbox RPC while keeping its original name and all existing rows.
drop function if exists public.get_my_conversations();
create function public.get_my_conversations()
returns table (
  conversation_id uuid,
  other_user_id uuid,
  username text,
  display_name text,
  avatar_path text,
  bio text,
  last_message text,
  last_message_type text,
  last_message_at timestamptz,
  last_message_sender_id uuid,
  last_message_delivered_at timestamptz,
  last_message_read_at timestamptz
)
language sql stable security invoker
set search_path = public, pg_temp
as $$
  select c.id, peer.user_id, p.username, p.display_name, p.avatar_path, p.bio,
         latest.content, latest.message_type, latest.created_at, latest.sender_id,
         latest.delivered_at, latest.read_at
  from public.conversations c
  join public.conversation_members mine
    on mine.conversation_id = c.id and mine.user_id = auth.uid()
  join public.conversation_members peer
    on peer.conversation_id = c.id and peer.user_id <> auth.uid()
  join public.profiles p on p.id = peer.user_id
  left join lateral (
    select m.content, m.message_type, m.created_at, m.sender_id,
           m.delivered_at, m.read_at
    from public.messages m
    where m.conversation_id = c.id
    order by m.created_at desc
    limit 1
  ) latest on true
  order by coalesce(latest.created_at, c.created_at) desc;
$$;
revoke all on function public.get_my_conversations() from public, anon;
grant execute on function public.get_my_conversations() to authenticated;

-- Public profile pictures, strictly scoped uploads, and private conversation media.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('wasla-avatars', 'wasla-avatars', true, 5242880,
   array['image/jpeg', 'image/png', 'image/webp']),
  ('wasla-media', 'wasla-media', false, 15728640,
   array['image/jpeg', 'image/png', 'image/webp', 'audio/mp4', 'audio/aac', 'audio/x-m4a', 'audio/mpeg', 'audio/webm'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- The avatar bucket is public for image display; only owners may upload, replace, or remove.
drop policy if exists wasla_avatar_insert_own on storage.objects;
create policy wasla_avatar_insert_own on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'wasla-avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );
drop policy if exists wasla_avatar_update_own on storage.objects;
create policy wasla_avatar_update_own on storage.objects
  for update to authenticated
  using (
    bucket_id = 'wasla-avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  )
  with check (
    bucket_id = 'wasla-avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );
drop policy if exists wasla_avatar_delete_own on storage.objects;
create policy wasla_avatar_delete_own on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'wasla-avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

-- Media object paths are conversation-id/user-id/file; both levels are checked.
drop policy if exists wasla_media_select_member on storage.objects;
create policy wasla_media_select_member on storage.objects
  for select to authenticated
  using (
    bucket_id = 'wasla-media'
    and private.is_conversation_member(((storage.foldername(name))[1])::uuid)
  );
drop policy if exists wasla_media_insert_member on storage.objects;
create policy wasla_media_insert_member on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'wasla-media'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and private.is_conversation_member(((storage.foldername(name))[1])::uuid)
  );
drop policy if exists wasla_media_delete_own on storage.objects;
create policy wasla_media_delete_own on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'wasla-media'
    and (storage.foldername(name))[2] = (select auth.uid())::text
    and private.is_conversation_member(((storage.foldername(name))[1])::uuid)
  );
