-- Wasla 1.9.2: persistent, user-selected presence statuses (separate from stories
-- and from transient Realtime online/last-seen presence).
create table if not exists public.user_presence_statuses (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  status text not null default 'available'
    check (status in ('available', 'working', 'busy')),
  updated_at timestamptz not null default now()
);

-- Existing accounts receive the default state; future profiles are initialized below.
insert into public.user_presence_statuses (user_id)
select p.id from public.profiles p
on conflict (user_id) do nothing;

alter table public.user_presence_statuses enable row level security;
revoke all on public.user_presence_statuses from public, anon, authenticated;
grant select on public.user_presence_statuses to authenticated;

drop policy if exists user_presence_statuses_select_self_or_friend
  on public.user_presence_statuses;
create policy user_presence_statuses_select_self_or_friend
  on public.user_presence_statuses
  for select to authenticated
  using (
    user_id = (select auth.uid())
    or exists (
      select 1
      from public.friend_requests fr
      where fr.status = 'accepted'
        and (
          (fr.requester_id = (select auth.uid()) and fr.addressee_id = user_presence_statuses.user_id)
          or
          (fr.addressee_id = (select auth.uid()) and fr.requester_id = user_presence_statuses.user_id)
        )
    )
  );

-- Clients cannot write arbitrary rows; this RPC only changes the caller's own state.
create or replace function public.set_my_presence_status(p_status text)
returns text
language plpgsql
volatile
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;
  if p_status not in ('available', 'working', 'busy') then
    raise exception 'Invalid presence status';
  end if;

  insert into public.user_presence_statuses (user_id, status, updated_at)
  values (v_user_id, p_status, now())
  on conflict (user_id) do update
    set status = excluded.status, updated_at = excluded.updated_at;
  return p_status;
end;
$$;
revoke all on function public.set_my_presence_status(text) from public, anon;
grant execute on function public.set_my_presence_status(text) to authenticated;

create or replace function public.initialize_user_presence_status()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.user_presence_statuses (user_id)
  values (new.id)
  on conflict (user_id) do nothing;
  return new;
end;
$$;
revoke all on function public.initialize_user_presence_status() from public, anon, authenticated;
drop trigger if exists on_profile_created_presence_status on public.profiles;
create trigger on_profile_created_presence_status
after insert on public.profiles
for each row execute function public.initialize_user_presence_status();

-- Publish status updates so friends see changes immediately in active app sessions.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'user_presence_statuses'
  ) then
    alter publication supabase_realtime add table public.user_presence_statuses;
  end if;
exception when undefined_object then
  raise notice 'Publication supabase_realtime is unavailable; enable Realtime for public.user_presence_statuses in Supabase dashboard.';
end;
$$;
