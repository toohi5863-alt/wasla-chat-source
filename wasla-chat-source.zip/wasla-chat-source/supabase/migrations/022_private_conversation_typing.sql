-- Allow ephemeral typing broadcasts only inside authenticated conversations.
-- Typing events are sent over private Realtime channels and are never stored in application tables.
create or replace function private.is_wasla_typing_conversation_member()
returns boolean
language plpgsql stable security definer
set search_path = pg_catalog, private, realtime, pg_temp
as $$
declare
  v_topic text := realtime.topic();
  v_conversation_id uuid;
begin
  if v_topic !~ '^wasla-typing-v1-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then
    return false;
  end if;
  v_conversation_id := regexp_replace(v_topic, '^wasla-typing-v1-', '')::uuid;
  return private.is_conversation_member(v_conversation_id);
exception when invalid_text_representation then
  return false;
end;
$$;

revoke all on function private.is_wasla_typing_conversation_member() from public, anon;
grant execute on function private.is_wasla_typing_conversation_member() to authenticated;

drop policy if exists wasla_typing_read_conversation_members on realtime.messages;
create policy wasla_typing_read_conversation_members on realtime.messages
  for select to authenticated
  using (private.is_wasla_typing_conversation_member());

drop policy if exists wasla_typing_send_conversation_members on realtime.messages;
create policy wasla_typing_send_conversation_members on realtime.messages
  for insert to authenticated
  with check (private.is_wasla_typing_conversation_member());
