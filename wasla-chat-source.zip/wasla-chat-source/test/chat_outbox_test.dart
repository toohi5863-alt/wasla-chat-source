import 'package:flutter_test/flutter_test.dart';
import 'package:chat/chat_outbox_message.dart';
import 'package:chat/chat_models.dart';

void main() {
  test('restores an offline text message from its durable JSON map', () {
    final message = PendingOutgoingMessage(
      id: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
      conversationId: 'conversation-1',
      senderId: 'user-1',
      content: 'أصل بعد قليل',
      createdAt: DateTime.utc(2026, 10, 8, 10, 30),
      messageType: 'text',
      replyTo: 'reply-1',
    );

    final restored = PendingOutgoingMessage.fromMap(message.toMap());

    expect(restored.id, message.id);
    expect(restored.conversationId, message.conversationId);
    expect(restored.senderId, message.senderId);
    expect(restored.content, message.content);
    expect(restored.createdAt, message.createdAt);
    expect(restored.replyTo, message.replyTo);
    expect(restored.mediaPath, isNull);
    expect(restored.mediaUploaded, isFalse);
    expect(restored.isEphemeral, isFalse);
  });

  test(
    'marks newly queued messages explicitly and defaults old maps to legacy',
    () {
      final newMessage = PendingOutgoingMessage(
        id: 'new-message',
        conversationId: 'conversation-1',
        senderId: 'user-1',
        content: 'يحفظ محليًا قبل الإقرار',
        createdAt: DateTime.utc(2026, 10, 9, 10),
        messageType: 'text',
        isEphemeral: true,
      );

      final restoredNew = PendingOutgoingMessage.fromMap(newMessage.toMap());
      final restoredLegacy = PendingOutgoingMessage.fromMap({
        'id': 'old-message',
        'conversation_id': 'conversation-1',
        'sender_id': 'user-1',
        'content': 'طابور قبل التحديث',
        'created_at': '2026-10-08T10:00:00Z',
        'message_type': 'text',
      });

      expect(restoredNew.isEphemeral, isTrue);
      expect(restoredLegacy.isEphemeral, isFalse);
    },
  );

  test('derives the scoped remote path and preserves upload state', () {
    final message = PendingOutgoingMessage(
      id: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
      conversationId: 'conversation-1',
      senderId: 'user-1',
      content: 'صورة',
      createdAt: DateTime.utc(2026, 10, 8, 10, 30),
      messageType: 'image',
      mediaExtension: 'jpg',
    );

    final uploading = message.copyWith(mediaUploaded: true);
    final restored = PendingOutgoingMessage.fromMap(uploading.toMap());

    expect(
      restored.mediaPath,
      'conversation-1/user-1/f47ac10b-58cc-4372-a567-0e02b2c3d479.jpg',
    );
    expect(restored.mediaUploaded, isTrue);
  });

  test('persists and clears the optimistic pending state locally', () {
    final message = ChatMessage(
      id: 'f47ac10b-58cc-4372-a567-0e02b2c3d479',
      senderId: 'user-1',
      content: 'ستظهر فورًا',
      createdAt: DateTime.utc(2026, 10, 8, 10, 30),
      isPending: true,
    );

    final restored = ChatMessage.fromMap(message.toMap());

    expect(restored.isPending, isTrue);
    expect(restored.copyWith(isPending: false).isPending, isFalse);
  });
}
