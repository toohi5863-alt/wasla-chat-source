final _signupOtpPattern = RegExp(r'^[0-9]{6,10}$');

/// Returns whether [value] is a complete numeric signup OTP (6–10 digits).
/// The caller should pass the original, unmodified input to Supabase.
bool isValidSignupOtp(String value) => _signupOtpPattern.hasMatch(value);
