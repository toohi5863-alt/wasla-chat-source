-- Keep the RLS helper outside PostgREST's exposed public schema.
create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;

create or replace function private.is_conversation_member(p_conversation_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = p_conversation_id and cm.user_id = auth.uid()
  );
$$;
revoke all on function private.is_conversation_member(uuid) from public, anon;
grant execute on function private.is_conversation_member(uuid) to authenticated;

-- Rebind each policy to the private helper before removing the public RPC.
drop policy if exists conversations_select_member on public.conversations;
create policy conversations_select_member on public.conversations
  for select to authenticated using (private.is_conversation_member(id));
drop policy if exists conversation_members_select_member on public.conversation_members;
create policy conversation_members_select_member on public.conversation_members
  for select to authenticated using (private.is_conversation_member(conversation_id));
drop policy if exists messages_select_member on public.messages;
create policy messages_select_member on public.messages
  for select to authenticated using (private.is_conversation_member(conversation_id));
drop policy if exists messages_insert_as_member on public.messages;
create policy messages_insert_as_member on public.messages
  for insert to authenticated
  with check (sender_id = (select auth.uid()) and private.is_conversation_member(conversation_id));

revoke all on function public.is_conversation_member(uuid) from public, anon, authenticated;
drop function public.is_conversation_member(uuid);

-- Evaluate auth.uid() once per statement for these policies.
drop policy if exists profiles_select_authenticated on public.profiles;
create policy profiles_select_authenticated on public.profiles
  for select to authenticated using ((select auth.uid()) is not null);
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create index if not exists messages_sender_id_idx on public.messages(sender_id);
