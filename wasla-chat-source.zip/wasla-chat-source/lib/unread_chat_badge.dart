import 'package:flutter/material.dart';

/// A compact, high-contrast label for an unread conversation or message.
class UnreadChatBadge extends StatelessWidget {
  const UnreadChatBadge({
    required this.label,
    this.semanticLabel,
    this.compact = false,
    super.key,
  });

  final String label;
  final String? semanticLabel;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textStyle = Theme.of(context).textTheme.labelSmall;

    return Semantics(
      container: true,
      label: semanticLabel ?? label,
      child: ExcludeSemantics(
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 7 : 9,
            vertical: compact ? 3 : 4,
          ),
          decoration: BoxDecoration(
            color: colors.primary,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style:
                textStyle?.copyWith(
                  color: colors.onPrimary,
                  fontWeight: FontWeight.w700,
                  height: 1.2,
                ) ??
                TextStyle(
                  color: colors.onPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
          ),
        ),
      ),
    );
  }
}
