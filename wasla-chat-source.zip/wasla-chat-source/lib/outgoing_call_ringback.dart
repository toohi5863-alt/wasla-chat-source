import 'dart:async';

typedef CallerRingbackAction = Future<void> Function();

/// Coordinates one local ringback loop for an outgoing call.
///
/// Playback is serialized so a queued start cannot outlive a stop, duplicate
/// realtime updates cannot start another player, and the original call timeout
/// always stops the local tone.
class OutgoingCallRingbackController {
  OutgoingCallRingbackController({required this.play, required this.stop});

  final CallerRingbackAction play;
  final CallerRingbackAction stop;
  final Set<String> _handledCallIds = <String>{};
  Future<void> _playerQueue = Future<void>.value();
  Timer? _timeoutTimer;
  String? _activeCallId;
  bool _disposed = false;

  String? get activeCallId => _activeCallId;
  bool get isRinging => _activeCallId != null;

  Future<bool> startForOutgoing({
    required String callId,
    required bool isOutgoing,
    required String status,
    required bool alertsEnabled,
    required Duration timeout,
  }) async {
    if (_disposed ||
        callId.isEmpty ||
        !isOutgoing ||
        status != 'ringing' ||
        !alertsEnabled ||
        timeout <= Duration.zero ||
        _activeCallId != null ||
        !_handledCallIds.add(callId)) {
      return false;
    }

    _activeCallId = callId;
    _timeoutTimer = Timer(timeout, () => unawaited(stopForCall(callId)));
    try {
      await _enqueue(() async {
        // The call may have changed state while playback was queued.
        if (!_disposed && _activeCallId == callId) await play();
      });
      return _activeCallId == callId;
    } catch (_) {
      if (_activeCallId == callId) {
        _activeCallId = null;
        _cancelTimeout();
      }
      await _enqueue(stop).catchError((Object _) {});
      return false;
    }
  }

  Future<void> updateCallStatus({
    required String callId,
    required String status,
  }) async {
    if (status != 'ringing') await stopForCall(callId);
  }

  Future<void> stopForCall(String callId) async {
    if (_activeCallId != callId) return;
    _activeCallId = null;
    _cancelTimeout();
    await _enqueue(stop).catchError((Object _) {});
  }

  Future<void> stopAll() async {
    final activeCallId = _activeCallId;
    if (activeCallId == null) return;
    await stopForCall(activeCallId);
  }

  Future<void> dispose() async {
    if (_disposed) return;
    await stopAll();
    // A concurrent stop may already have cleared the active id while its
    // player operation is still queued. Drain it before the player is disposed.
    await _playerQueue.catchError((Object _) {});
    _disposed = true;
  }

  void _cancelTimeout() {
    _timeoutTimer?.cancel();
    _timeoutTimer = null;
  }

  Future<void> _enqueue(CallerRingbackAction action) {
    final operation = _playerQueue.then((_) => action());
    _playerQueue = operation.catchError((Object _) {});
    return operation;
  }
}
