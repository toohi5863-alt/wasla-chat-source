import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:chat/chat_local_cache.dart';
import 'package:chat/chat_models.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive_ce/hive_ce.dart';

void main() {
  late Directory temporaryDirectory;
  late ChatLocalCache cache;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp(
      'wasla-local-cache-test-',
    );
    cache = ChatLocalCache(
      supportDirectoryProvider: () async => temporaryDirectory,
    );
  });

  tearDown(() async {
    await Hive.close();
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  test('restores messages from local storage and isolates accounts', () async {
    final message = ChatMessage(
      id: 'message-1',
      senderId: 'user-a',
      content: 'رسالة محفوظة',
      createdAt: DateTime.utc(2026, 10, 8, 10),
    );
    await cache.saveMessages('user-a', 'conversation-1', [message]);

    final restored = await cache.loadMessages('user-a', 'conversation-1');
    final otherAccount = await cache.loadMessages('user-b', 'conversation-1');

    expect(restored, hasLength(1));
    expect(restored!.single.content, 'رسالة محفوظة');
    expect(restored.single.createdAt, message.createdAt);
    expect(otherAccount, isNull);
  });

  test(
    'stores starred message IDs locally per account and conversation',
    () async {
      await cache.setMessageStarred(
        'user-a',
        'conversation-1',
        'message-1',
        true,
      );
      await cache.setMessageStarred(
        'user-a',
        'conversation-1',
        'message-2',
        true,
      );

      expect(await cache.loadStarredMessageIds('user-a', 'conversation-1'), {
        'message-1',
        'message-2',
      });
      expect(
        await cache.loadStarredMessageIds('user-b', 'conversation-1'),
        isEmpty,
      );
      expect(
        await cache.loadStarredMessageIds('user-a', 'conversation-2'),
        isEmpty,
      );

      await cache.setMessageStarred(
        'user-a',
        'conversation-1',
        'message-1',
        false,
      );
      expect(await cache.loadStarredMessageIds('user-a', 'conversation-1'), {
        'message-2',
      });
    },
  );

  test('saves, lists, clears and isolates conversation drafts', () async {
    await cache.saveDraft('user-a', 'conversation-1', '  أعود بعد قليل  ');
    await cache.saveDraft('user-a', 'conversation/2', 'مسودة مجموعة');

    expect(
      await cache.loadDraft('user-a', 'conversation-1'),
      '  أعود بعد قليل  ',
    );
    expect(await cache.loadDrafts('user-a'), {
      'conversation-1': '  أعود بعد قليل  ',
      'conversation/2': 'مسودة مجموعة',
    });
    expect(await cache.loadDraft('user-b', 'conversation-1'), isNull);

    await cache.saveDraft('user-a', 'conversation-1', '   ');

    expect(await cache.loadDraft('user-a', 'conversation-1'), isNull);
    expect(await cache.loadDrafts('user-a'), {
      'conversation/2': 'مسودة مجموعة',
    });
  });

  test(
    'migrates legacy message JSON into Hive without deleting the source',
    () async {
      final legacyMessage = ChatMessage(
        id: 'legacy-message',
        senderId: 'user-a',
        content: 'رسالة من الإصدار السابق',
        createdAt: DateTime.utc(2026, 10, 8, 11),
      );
      final accountDirectory = await _legacyAccountDirectory(
        temporaryDirectory,
        'user-a',
      );
      final conversationDirectory = Directory(
        '${accountDirectory.path}${Platform.pathSeparator}conversations',
      )..createSync(recursive: true);
      final legacyFile = File(
        '${conversationDirectory.path}${Platform.pathSeparator}'
        '${_encodePathPart('conversation-legacy')}.json',
      );
      await legacyFile.writeAsString(jsonEncode([legacyMessage.toMap()]));

      final migrated = await cache.loadMessages(
        'user-a',
        'conversation-legacy',
      );
      await legacyFile.writeAsString('[]');
      final loadedFromHive = await cache.loadMessages(
        'user-a',
        'conversation-legacy',
      );

      expect(migrated!.single.content, 'رسالة من الإصدار السابق');
      expect(loadedFromHive!.single.id, 'legacy-message');
      expect(await legacyFile.exists(), isTrue);
    },
  );

  test(
    'migrates legacy chat-list JSON into Hive and keeps account isolation',
    () async {
      final accountDirectory = await _legacyAccountDirectory(
        temporaryDirectory,
        'user-a',
      );
      final legacyFile = File(
        '${accountDirectory.path}${Platform.pathSeparator}chats.json',
      );
      final legacyChat = ChatPreview(
        conversationId: 'conversation-legacy',
        otherUserId: 'user-b',
        username: 'friend',
        displayName: 'صديق',
        lastMessage: 'آخر رسالة قديمة',
      );
      await legacyFile.writeAsString(jsonEncode([legacyChat.toMap()]));

      final migrated = await cache.loadChats('user-a');
      await legacyFile.writeAsString('[]');
      final loadedFromHive = await cache.loadChats('user-a');
      final otherAccount = await cache.loadChats('user-b');

      expect(migrated!.single.lastMessage, 'آخر رسالة قديمة');
      expect(loadedFromHive!.single.conversationId, 'conversation-legacy');
      expect(otherAccount, isNull);
      expect(await legacyFile.exists(), isTrue);
    },
  );

  test(
    'keeps a downloaded media file available locally for its account',
    () async {
      final bytes = Uint8List.fromList([0, 1, 2, 3, 250, 255]);
      await cache.saveMediaBytes('user-a', 'conversation-1/photo.jpg', bytes);

      final cachedFile = await cache.findMedia(
        'user-a',
        'conversation-1/photo.jpg',
      );
      final otherAccountFile = await cache.findMedia(
        'user-b',
        'conversation-1/photo.jpg',
      );

      expect(cachedFile, isNotNull);
      expect(await cachedFile!.readAsBytes(), bytes);
      expect(cachedFile.path, endsWith('.jpg'));
      expect(otherAccountFile, isNull);
    },
  );

  test(
    'downloads image, video, audio and document once and reopens local copies',
    () async {
      var requestCount = 0;
      final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      final serverSubscription = server.listen((request) async {
        requestCount++;
        request.response
          ..statusCode = HttpStatus.ok
          ..add([10, 20, 30]);
        await request.response.close();
      });
      addTearDown(() async {
        await serverSubscription.cancel();
        await server.close(force: true);
      });

      final reopenedCache = ChatLocalCache(
        supportDirectoryProvider: () async => temporaryDirectory,
      );
      final paths = [
        'conversation-1/photo.jpg',
        'conversation-1/clip.mp4',
        'conversation-1/voice.m4a',
        'conversation-1/report.pdf',
      ];
      for (var index = 0; index < paths.length; index++) {
        final path = paths[index];
        final url =
            'http://${server.address.address}:${server.port}/media/$index';
        final first = await cache.cacheMediaFromUrl('user-a', path, url);
        final restored = await reopenedCache.findMedia('user-a', path);
        final second = await reopenedCache.cacheMediaFromUrl(
          'user-a',
          path,
          'http://127.0.0.1:1/expired-signed-url',
        );

        expect(first, isNotNull, reason: 'initial download: $path');
        expect(restored?.path, first?.path, reason: 'persistent file: $path');
        expect(second?.path, first?.path, reason: 'offline reopen: $path');
        expect(await second!.readAsBytes(), [10, 20, 30]);
        expect(second.path, endsWith('.${path.split('.').last}'));
      }
      expect(requestCount, paths.length);
    },
  );
}

Future<Directory> _legacyAccountDirectory(Directory root, String userId) async {
  final directory = Directory(
    '${root.path}${Platform.pathSeparator}wasla_offline_cache'
    '${Platform.pathSeparator}${_encodePathPart(userId)}',
  );
  await directory.create(recursive: true);
  return directory;
}

String _encodePathPart(String value) =>
    base64Url.encode(utf8.encode(value)).replaceAll('=', '');
