import 'dart:convert';

import 'package:chat/statuses.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<void> openPreview(
    WidgetTester tester,
    StatusDraftPreviewScreen preview, {
    void Function(bool?)? onResult,
  }) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => Scaffold(
            body: Center(
              child: ElevatedButton(
                onPressed: () async {
                  final result = await Navigator.of(context)
                      .push<bool>(MaterialPageRoute(builder: (_) => preview));
                  onResult?.call(result);
                },
                child: const Text('فتح المعاينة'),
              ),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('فتح المعاينة'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
  }

  testWidgets('text status stays a draft until explicit publish', (
    tester,
  ) async {
    var publishCalls = 0;
    bool? result;
    await openPreview(
      tester,
      StatusDraftPreviewScreen(
        contentType: 'text',
        body: 'مساء الخير يا أصدقاء',
        media: null,
        backgroundColor: 0xFF087F72,
        privacyLabel: 'كل الأصدقاء',
        onPublish: () async {
          publishCalls++;
          return null;
        },
      ),
      onResult: (value) => result = value,
    );

    expect(find.text('مساء الخير يا أصدقاء'), findsOneWidget);
    expect(find.text('كل الأصدقاء'), findsOneWidget);
    expect(publishCalls, 0);
    await tester.tap(find.widgetWithText(FilledButton, 'نشر الحالة'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));

    expect(publishCalls, 1);
    expect(result, isTrue);
  });

  testWidgets('editing returns to the draft without publishing', (
    tester,
  ) async {
    var publishCalls = 0;
    bool? result;
    await openPreview(
      tester,
      StatusDraftPreviewScreen(
        contentType: 'text',
        body: 'مسودة قابلة للتعديل',
        media: null,
        backgroundColor: 0xFF087F72,
        privacyLabel: 'كل الأصدقاء',
        onPublish: () async {
          publishCalls++;
          return null;
        },
      ),
      onResult: (value) => result = value,
    );

    await tester.tap(find.byTooltip('العودة للتعديل'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));

    expect(publishCalls, 0);
    expect(result, isFalse);
  });

  testWidgets('image status preview shows the selected image and caption', (
    tester,
  ) async {
    await openPreview(
      tester,
      StatusDraftPreviewScreen(
        contentType: 'image',
        body: 'تعليق على الصورة',
        media: XFile('/tmp/preview.png', name: 'preview.png'),
        backgroundColor: 0xFF087F72,
        privacyLabel: 'أصدقاء محددون (2)',
        onPublish: () async => null,
        imageProvider: MemoryImage(
          base64Decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/9N8AAAAASUVORK5CYII=',
          ),
        ),
      ),
    );

    expect(find.byType(Image), findsOneWidget);
    expect(find.text('تعليق على الصورة'), findsOneWidget);
    expect(find.text('أصدقاء محددون (2)'), findsOneWidget);
    expect(find.text('تعذر عرض الصورة'), findsNothing);
  });

  testWidgets('video status preview initializes a video player', (
    tester,
  ) async {
    final originalPlatform = VideoPlayerPlatform.instance;
    VideoPlayerPlatform.instance = _FakeVideoPlayerPlatform();
    addTearDown(() => VideoPlayerPlatform.instance = originalPlatform);

    await openPreview(
      tester,
      StatusDraftPreviewScreen(
        contentType: 'video',
        body: 'مقطع تجريبي',
        media: XFile('/tmp/wasla-preview.mp4', name: 'preview.mp4'),
        backgroundColor: 0xFF087F72,
        privacyLabel: 'كل الأصدقاء',
        onPublish: () async => null,
      ),
    );

    expect(find.byType(VideoPlayer), findsOneWidget);
    expect(find.text('مقطع تجريبي'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}

class _FakeVideoPlayerPlatform extends VideoPlayerPlatform {
  @override
  Future<void> init() async {}

  @override
  Future<int?> createWithOptions(VideoCreationOptions options) async => 1;

  @override
  Stream<VideoEvent> videoEventsFor(int playerId) => Stream<VideoEvent>.value(
    VideoEvent(
      eventType: VideoEventType.initialized,
      duration: const Duration(seconds: 8),
      size: const Size(1920, 1080),
    ),
  );

  @override
  Future<void> setLooping(int playerId, bool looping) async {}

  @override
  Future<void> setVolume(int playerId, double volume) async {}

  @override
  Future<void> play(int playerId) async {}

  @override
  Future<void> pause(int playerId) async {}

  @override
  Future<void> setPlaybackSpeed(int playerId, double speed) async {}

  @override
  Future<Duration> getPosition(int playerId) async => Duration.zero;

  @override
  Future<void> dispose(int playerId) async {}

  @override
  Widget buildViewWithOptions(VideoViewOptions options) =>
      const ColoredBox(color: Colors.black);
}
