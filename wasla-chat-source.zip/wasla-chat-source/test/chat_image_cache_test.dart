import 'dart:io';

import 'package:chat/chat_image_cache.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const pathProviderChannel = MethodChannel('plugins.flutter.io/path_provider');
  late Directory temporaryDirectory;
  late _FakeFileService fileService;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp(
      'wasla-image-cache-test-',
    );
    fileService = _FakeFileService();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(pathProviderChannel, (call) async {
          if (call.method == 'getTemporaryDirectory' ||
              call.method == 'getApplicationSupportDirectory') {
            return temporaryDirectory.path;
          }
          return null;
        });
    ChatImageCache.registerManagerForTesting(
      'user-a',
      CacheManager(
        Config(
          'test_wasla_images_user_a',
          stalePeriod: const Duration(days: 365),
          fileService: fileService,
        ),
      ),
    );
  });

  tearDown(() async {
    await ChatImageCache.disposeForTesting();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(pathProviderChannel, null);
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  test(
    'downloads an image once, restores it offline, and isolates accounts',
    () async {
      const mediaPath = 'conversation-1/photo.jpg';
      final first = await ChatImageCache.download(
        'user-a',
        mediaPath,
        'https://images.example/photo.jpg',
      );
      final restored = await ChatImageCache.findCachedFile('user-a', mediaPath);
      final second = await ChatImageCache.download(
        'user-a',
        mediaPath,
        'https://expired.example/old-signed-url',
      );
      final otherAccount = await ChatImageCache.findCachedFile(
        'user-b',
        mediaPath,
      );

      expect(await first.readAsBytes(), [10, 20, 30, 40]);
      expect(restored?.path, first.path);
      expect(second.path, first.path);
      expect(otherAccount, isNull);
      expect(fileService.requestCount, 1);
      expect(
        ChatImageCache.cacheKeyFor('user-a', mediaPath),
        isNot(ChatImageCache.cacheKeyFor('user-b', mediaPath)),
      );
    },
  );
}

class _FakeFileService extends FileService {
  int requestCount = 0;

  @override
  Future<FileServiceResponse> get(
    String url, {
    Map<String, String>? headers,
  }) async {
    requestCount++;
    return _FakeFileServiceResponse();
  }
}

class _FakeFileServiceResponse implements FileServiceResponse {
  @override
  Stream<List<int>> get content => Stream<List<int>>.value([10, 20, 30, 40]);

  @override
  int get contentLength => 4;

  @override
  String? get eTag => 'offline-cache-test';

  @override
  String get fileExtension => '.jpg';

  @override
  int get statusCode => HttpStatus.ok;

  @override
  DateTime get validTill => DateTime.now().add(const Duration(days: 365));
}
