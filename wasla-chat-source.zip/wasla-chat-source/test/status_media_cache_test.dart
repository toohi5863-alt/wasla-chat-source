import 'dart:io';
import 'dart:typed_data';

import 'package:chat/status_media_cache.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late Directory temporaryDirectory;
  late DateTime now;
  late StatusMediaCache cache;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp(
      'wasla-status-media-test-',
    );
    now = DateTime.utc(2026, 10, 9, 10);
    cache = StatusMediaCache(
      directoryProvider: () async => temporaryDirectory,
      clock: () => now,
    );
  });

  tearDown(() async {
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  test(
    'keeps a viewed status available offline without a second download',
    () async {
      var downloads = 0;
      final expiry = now.add(const Duration(hours: 24));
      final first = await cache.fileFor(
        accountId: 'account-a',
        statusId: 'status-1',
        storagePath: 'author/photo.jpg',
        expiresAt: expiry,
        download: () async {
          downloads++;
          return Uint8List.fromList([10, 20, 30]);
        },
      );
      final restored = await cache.fileFor(
        accountId: 'account-a',
        statusId: 'status-1',
        storagePath: 'author/photo.jpg',
        expiresAt: expiry,
        download: () async => throw StateError('should remain offline'),
      );

      expect(await first.readAsBytes(), [10, 20, 30]);
      expect(restored.path, first.path);
      expect(downloads, 1);
      expect(first.path, contains('wasla_status_media_'));
    },
  );

  test(
    'isolates the same status between different signed-in accounts',
    () async {
      var downloads = 0;
      final expiry = now.add(const Duration(hours: 24));
      Future<Uint8List> download() async {
        downloads++;
        return Uint8List.fromList([1, 2, 3]);
      }

      final accountA = await cache.fileFor(
        accountId: 'account-a',
        statusId: 'status-1',
        storagePath: 'author/video.mp4',
        expiresAt: expiry,
        download: download,
      );
      final accountB = await cache.fileFor(
        accountId: 'account-b',
        statusId: 'status-1',
        storagePath: 'author/video.mp4',
        expiresAt: expiry,
        download: download,
      );

      expect(accountA.path, isNot(accountB.path));
      expect(downloads, 2);
    },
  );

  test('removes cached media after expiry and refuses to serve it', () async {
    final expiry = now.add(const Duration(seconds: 1));
    final expiredFile = await cache.fileFor(
      accountId: 'account-a',
      statusId: 'expired-status',
      storagePath: 'author/image.webp',
      expiresAt: expiry,
      download: () async => Uint8List.fromList([4, 5, 6]),
    );

    now = expiry.add(const Duration(milliseconds: 1));
    await expectLater(
      cache.fileFor(
        accountId: 'account-a',
        statusId: 'expired-status',
        storagePath: 'author/image.webp',
        expiresAt: expiry,
        download: () async => throw StateError('expired status was fetched'),
      ),
      throwsA(isA<StatusMediaExpiredException>()),
    );

    // A subsequent valid status triggers the cache's expiry sweep.
    await cache.fileFor(
      accountId: 'account-a',
      statusId: 'active-status',
      storagePath: 'author/active.png',
      expiresAt: now.add(const Duration(hours: 1)),
      download: () async => Uint8List.fromList([7, 8, 9]),
    );
    expect(await expiredFile.exists(), isFalse);
  });

  test('coalesces simultaneous first views into one download', () async {
    var downloads = 0;
    final expiry = now.add(const Duration(hours: 24));
    Future<Uint8List> download() async {
      downloads++;
      await Future<void>.delayed(const Duration(milliseconds: 10));
      return Uint8List.fromList([9, 8, 7]);
    }

    final results = await Future.wait([
      cache.fileFor(
        accountId: 'account-a',
        statusId: 'status-concurrent',
        storagePath: 'author/photo.png',
        expiresAt: expiry,
        download: download,
      ),
      cache.fileFor(
        accountId: 'account-a',
        statusId: 'status-concurrent',
        storagePath: 'author/photo.png',
        expiresAt: expiry,
        download: download,
      ),
    ]);

    expect(results[0].path, results[1].path);
    expect(downloads, 1);
  });
}
