import 'package:chat/app_settings.dart';
import 'package:chat/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Wasla appearance options', () {
    test('high contrast strengthens the light theme outlines', () {
      final standard = buildWaslaTheme(
        option: appThemePresets.first,
        brightness: Brightness.light,
        highContrast: false,
        compactLayout: false,
      );
      final highContrast = buildWaslaTheme(
        option: appThemePresets.first,
        brightness: Brightness.light,
        highContrast: true,
        compactLayout: false,
      );
      final standardOutline =
          (standard.cardTheme.shape! as RoundedRectangleBorder).side.color;
      final highContrastOutline =
          (highContrast.cardTheme.shape! as RoundedRectangleBorder).side.color;

      expect(
        highContrastOutline.computeLuminance(),
        lessThan(standardOutline.computeLuminance()),
      );
      expect(
        highContrast.colorScheme.onSurfaceVariant.computeLuminance(),
        lessThan(standard.colorScheme.onSurfaceVariant.computeLuminance()),
      );
    });

    test('compact layout applies Material compact visual density', () {
      final standard = buildWaslaTheme(
        option: appThemePresets.first,
        brightness: Brightness.dark,
        highContrast: false,
        compactLayout: false,
      );
      final compact = buildWaslaTheme(
        option: appThemePresets.first,
        brightness: Brightness.dark,
        highContrast: false,
        compactLayout: true,
      );

      expect(standard.visualDensity, VisualDensity.standard);
      expect(compact.visualDensity, VisualDensity.compact);
    });
  });
}
