import 'package:flutter/material.dart';

/// Live connection state, separate from the user's selected presence status.
final ValueNotifier<Set<String>> onlineUserIds = ValueNotifier<Set<String>>({});

String connectionStatusLabel({
  required bool online,
  required DateTime? lastSeenAt,
  bool lastSeenLoaded = true,
  DateTime? now,
}) {
  if (online) return 'متصل الآن';
  if (!lastSeenLoaded) return 'جارٍ التحقق من الاتصال';
  return formatLastSeenLabel(lastSeenAt, now: now);
}

class ConnectionStatusDot extends StatelessWidget {
  const ConnectionStatusDot({
    required this.online,
    this.size = 8,
    this.borderColor = Colors.white,
    super.key,
  });

  final bool online;
  final double size;
  final Color borderColor;

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: online ? const Color(0xFF24A46D) : const Color(0xFF9AA7A3),
      shape: BoxShape.circle,
      border: Border.all(color: borderColor, width: size >= 10 ? 2 : 1),
    ),
  );
}

class ConnectionStatusLabel extends StatelessWidget {
  const ConnectionStatusLabel({
    required this.online,
    required this.lastSeenAt,
    this.lastSeenLoaded = true,
    this.fontSize = 11,
    super.key,
  });

  final bool online;
  final DateTime? lastSeenAt;
  final bool lastSeenLoaded;
  final double fontSize;

  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      ConnectionStatusDot(online: online, size: 7),
      const SizedBox(width: 4),
      Text(
        connectionStatusLabel(
          online: online,
          lastSeenAt: lastSeenAt,
          lastSeenLoaded: lastSeenLoaded,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: online ? const Color(0xFF087F72) : const Color(0xFF71827D),
          fontSize: fontSize,
        ),
      ),
    ],
  );
}

String formatLastSeenLabel(DateTime? lastSeenAt, {DateTime? now}) {
  if (lastSeenAt == null) return 'آخر ظهور غير متاح';

  final current = (now ?? DateTime.now()).toLocal();
  final seen = lastSeenAt.toLocal();
  final difference = current.difference(seen);
  if (difference.isNegative) return 'آخر ظهور الآن';
  if (difference < const Duration(minutes: 1)) return 'آخر ظهور منذ لحظات';

  if (difference < const Duration(hours: 1)) {
    final minutes = difference.inMinutes;
    final phrase = switch (minutes) {
      1 => 'دقيقة',
      2 => 'دقيقتين',
      >= 3 && <= 10 => '${_arabicDigits(minutes)} دقائق',
      _ => '${_arabicDigits(minutes)} دقيقة',
    };
    return 'آخر ظهور منذ $phrase';
  }

  if (difference < const Duration(days: 1)) {
    final hours = difference.inHours;
    final phrase = switch (hours) {
      1 => 'ساعة',
      2 => 'ساعتين',
      >= 3 && <= 10 => '${_arabicDigits(hours)} ساعات',
      _ => '${_arabicDigits(hours)} ساعة',
    };
    return 'آخر ظهور منذ $phrase';
  }

  final days = difference.inDays;
  if (days < 2) return 'آخر ظهور أمس';
  if (days <= 10) {
    final phrase = switch (days) {
      2 => 'يومين',
      >= 3 && <= 10 => '${_arabicDigits(days)} أيام',
      _ => '${_arabicDigits(days)} يوم',
    };
    return 'آخر ظهور منذ $phrase';
  }

  return 'آخر ظهور بتاريخ ${_arabicDigits(seen.day)}/${_arabicDigits(seen.month)}/${_arabicDigits(seen.year)}';
}

String _arabicDigits(int value) => value.toString().replaceAllMapped(
  RegExp(r'[0-9]'),
  (match) => '٠١٢٣٤٥٦٧٨٩'[int.parse(match.group(0)!)],
);
