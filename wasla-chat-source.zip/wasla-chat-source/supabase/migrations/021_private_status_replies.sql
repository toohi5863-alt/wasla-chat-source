-- Private, text-only replies to active Wasla status posts.
-- Each row is visible only to its author (the status owner) and the replying user.
create table if not exists public.status_replies (
  id uuid primary key default gen_random_uuid(),
  status_id uuid not null references public.status_posts(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (
    char_length(btrim(body)) between 1 and 1000
  ),
  created_at timestamptz not null default now()
);

create index if not exists status_replies_status_created_idx
  on public.status_replies (status_id, created_at desc);
create index if not exists status_replies_sender_created_idx
  on public.status_replies (sender_id, created_at desc);

alter table public.status_replies enable row level security;
revoke all on public.status_replies from public, anon, authenticated;
grant select, insert on public.status_replies to authenticated;

drop policy if exists status_replies_read_participants on public.status_replies;
create policy status_replies_read_participants on public.status_replies
  for select to authenticated
  using (
    sender_id = (select auth.uid())
    or exists (
      select 1 from public.status_posts sp
      where sp.id = status_id
        and sp.user_id = (select auth.uid())
    )
  );

drop policy if exists status_replies_insert_visible_status on public.status_replies;
create policy status_replies_insert_visible_status on public.status_replies
  for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and public.status_can_view_status(status_id, (select auth.uid()))
    and exists (
      select 1 from public.status_posts sp
      where sp.id = status_id
        and sp.user_id <> (select auth.uid())
        and sp.expires_at > now()
    )
  );

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'status_replies'
  ) then
    alter publication supabase_realtime add table public.status_replies;
  end if;
exception when undefined_object then
  raise notice 'Supabase Realtime publication unavailable; enable it for public.status_replies.';
end;
$$;
