# إعداد النسخة العامة بأمان

هذا المستودع لا يتضمن مفاتيح توقيع Android أو ملفات البناء أو ملفات APK أو إعدادات Firebase المحلية أو قيم الاتصال الخاصة بلوحة الإدارة. لا تُضف كلمات مرور أو مفاتيح خدمة أو ملفات keystore إلى Git.

## بناء تطبيق Flutter

1. انسخ `firebase.env.example.json` إلى `firebase.env.json` محليًا واملأ قيم مشروع Firebase المناسبة. الملف المحلي مستبعد من Git.
2. عرّف `SUPABASE_URL` و`SUPABASE_PUBLISHABLE_KEY` في بيئة البناء المحلية، ثم ابنِ التطبيق مثلًا باستخدام: `flutter build apk --release --split-per-abi --dart-define=SUPABASE_URL="$SUPABASE_URL" --dart-define=SUPABASE_PUBLISHABLE_KEY="$SUPABASE_PUBLISHABLE_KEY" --dart-define-from-file=firebase.env.json`.
3. توقيع إصدار Android يحتاج إعدادًا محليًا في `android/key.properties` وملف keystore خاصًا غير مرفوع.

## لوحة الإدارة

قبل نشر `admin_dashboard/index.html`، استبدل القيم التوضيحية `YOUR_SUPABASE_URL` و`YOUR_SUPABASE_PUBLISHABLE_KEY` و`YOUR_SUPABASE_ADMIN_USER_ID` بإعداد مشروعك في نسخة نشر محلية غير مضافة إلى Git. استخدم مفتاحًا عامًا محدود الصلاحيات فقط؛ لا تضع `service_role` أو أي سر إداري في JavaScript أو المتصفح. تُدار بيانات دخول المشرف عبر Supabase Auth ولا تُخزّن في المستودع.
