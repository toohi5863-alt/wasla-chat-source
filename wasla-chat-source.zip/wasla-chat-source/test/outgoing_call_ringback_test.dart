import 'dart:async';

import 'package:chat/notification_preferences.dart';
import 'package:chat/outgoing_call_ringback.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('OutgoingCallRingbackController', () {
    late int playCount;
    late int stopCount;
    late OutgoingCallRingbackController ringback;

    setUp(() {
      playCount = 0;
      stopCount = 0;
      ringback = OutgoingCallRingbackController(
        play: () async => playCount++,
        stop: () async => stopCount++,
      );
    });

    tearDown(() async => ringback.dispose());

    Future<bool> start({
      String callId = 'call-1',
      bool isOutgoing = true,
      String status = 'ringing',
      bool alertsEnabled = true,
      Duration timeout = const Duration(seconds: 90),
    }) => ringback.startForOutgoing(
      callId: callId,
      isOutgoing: isOutgoing,
      status: status,
      alertsEnabled: alertsEnabled,
      timeout: timeout,
    );

    test('starts one loop for a ringing outgoing call only once', () async {
      expect(await start(), isTrue);
      expect(ringback.activeCallId, 'call-1');
      expect(ringback.isRinging, isTrue);
      expect(await start(), isFalse);
      expect(playCount, 1);
      expect(stopCount, 0);
    });

    test(
      'does not start for inbound, answered, disabled, or expired calls',
      () async {
        final disabledPreferences = [
          const PushNotificationPreferences(callsEnabled: false),
          const PushNotificationPreferences(soundEnabled: false),
          const PushNotificationPreferences(doNotDisturb: true),
        ];
        for (final preferences in disabledPreferences) {
          expect(
            await start(
              callId: 'disabled-${disabledPreferences.indexOf(preferences)}',
              alertsEnabled: preferences.allowsChatSoundFor('calls'),
            ),
            isFalse,
          );
        }
        expect(await start(callId: 'incoming', isOutgoing: false), isFalse);
        expect(await start(callId: 'answered', status: 'accepted'), isFalse);
        expect(await start(callId: 'expired', timeout: Duration.zero), isFalse);
        expect(playCount, 0);
        expect(ringback.isRinging, isFalse);
      },
    );

    test('stops idempotently for every non-ringing state', () async {
      for (final status in [
        'accepted',
        'connecting',
        'active',
        'rejected',
        'cancelled',
        'missed',
        'ended',
        'failed',
      ]) {
        final callId = 'call-$status';
        expect(await start(callId: callId), isTrue);
        await ringback.updateCallStatus(callId: callId, status: status);
        await ringback.updateCallStatus(callId: callId, status: status);
        expect(ringback.isRinging, isFalse, reason: status);
      }
      expect(playCount, 8);
      expect(stopCount, 8);
    });

    test('stops when its original call timeout expires', () async {
      expect(await start(timeout: const Duration(milliseconds: 20)), isTrue);
      await Future<void>.delayed(const Duration(milliseconds: 60));
      expect(ringback.isRinging, isFalse);
      expect(stopCount, 1);
    });

    test(
      'serializes a pending start before stop and does not leak playback',
      () async {
        final firstPlay = Completer<void>();
        final order = <String>[];
        final serial = OutgoingCallRingbackController(
          play: () async {
            order.add('play-start');
            await firstPlay.future;
            order.add('play-end');
          },
          stop: () async => order.add('stop'),
        );
        final starting = serial.startForOutgoing(
          callId: 'call-pending',
          isOutgoing: true,
          status: 'ringing',
          alertsEnabled: true,
          timeout: const Duration(seconds: 5),
        );
        await Future<void>.delayed(Duration.zero);
        final stopping = serial.updateCallStatus(
          callId: 'call-pending',
          status: 'accepted',
        );
        firstPlay.complete();
        expect(await starting, isFalse);
        await stopping;
        expect(order, ['play-start', 'play-end', 'stop']);
        await serial.dispose();
      },
    );

    test('stops playback after a start failure', () async {
      final failed = OutgoingCallRingbackController(
        play: () async => throw StateError('audio failure'),
        stop: () async => stopCount++,
      );
      expect(
        await failed.startForOutgoing(
          callId: 'call-failed',
          isOutgoing: true,
          status: 'ringing',
          alertsEnabled: true,
          timeout: const Duration(seconds: 5),
        ),
        isFalse,
      );
      expect(failed.isRinging, isFalse);
      expect(stopCount, 1);
      await failed.dispose();
    });
  });
}
