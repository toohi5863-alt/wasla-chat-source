class PendingOutgoingMessage {
  const PendingOutgoingMessage({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.content,
    required this.createdAt,
    required this.messageType,
    this.mediaExtension,
    this.mediaDurationSeconds,
    this.replyTo,
    this.mediaUploaded = false,
    this.isEphemeral = false,
  });

  final String id;
  final String conversationId;
  final String senderId;
  final String content;
  final DateTime createdAt;
  final String messageType;
  final String? mediaExtension;
  final int? mediaDurationSeconds;
  final String? replyTo;
  final bool mediaUploaded;
  final bool isEphemeral;

  String? get mediaPath {
    final extension = mediaExtension;
    if (extension == null || extension.isEmpty) return null;
    return '$conversationId/$senderId/$id.$extension';
  }

  PendingOutgoingMessage copyWith({bool? mediaUploaded, bool? isEphemeral}) =>
      PendingOutgoingMessage(
        id: id,
        conversationId: conversationId,
        senderId: senderId,
        content: content,
        createdAt: createdAt,
        messageType: messageType,
        mediaExtension: mediaExtension,
        mediaDurationSeconds: mediaDurationSeconds,
        replyTo: replyTo,
        mediaUploaded: mediaUploaded ?? this.mediaUploaded,
        isEphemeral: isEphemeral ?? this.isEphemeral,
      );

  Map<String, dynamic> toMap() => {
    'id': id,
    'conversation_id': conversationId,
    'sender_id': senderId,
    'content': content,
    'created_at': createdAt.toUtc().toIso8601String(),
    'message_type': messageType,
    'media_extension': mediaExtension,
    'media_duration_seconds': mediaDurationSeconds,
    'reply_to': replyTo,
    'media_uploaded': mediaUploaded,
    'ephemeral': isEphemeral,
  };

  factory PendingOutgoingMessage.fromMap(Map<String, dynamic> map) =>
      PendingOutgoingMessage(
        id: map['id'].toString(),
        conversationId: map['conversation_id'].toString(),
        senderId: map['sender_id'].toString(),
        content: map['content']?.toString() ?? '',
        createdAt:
            DateTime.tryParse(map['created_at']?.toString() ?? '') ??
            DateTime.now(),
        messageType: map['message_type']?.toString() ?? 'text',
        mediaExtension: map['media_extension']?.toString(),
        mediaDurationSeconds: map['media_duration_seconds'] is num
            ? (map['media_duration_seconds'] as num).toInt()
            : int.tryParse(map['media_duration_seconds']?.toString() ?? ''),
        replyTo: map['reply_to']?.toString(),
        mediaUploaded:
            map['media_uploaded'] == true ||
            map['media_uploaded']?.toString() == 'true',
        isEphemeral:
            map['ephemeral'] == true || map['ephemeral']?.toString() == 'true',
      );
}
