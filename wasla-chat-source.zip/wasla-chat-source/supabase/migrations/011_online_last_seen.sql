-- Persist a server-timestamped last-seen value alongside existing Realtime presence.
-- Presence authorization remains governed by migration 004; this adds only a
-- nullable profile timestamp and a self-only heartbeat RPC.
alter table public.profiles
  add column if not exists last_seen_at timestamptz;

create or replace function public.heartbeat_presence()
returns timestamptz
language plpgsql
volatile
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_last_seen_at timestamptz;
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;

  update public.profiles
    set last_seen_at = now()
    where id = v_user_id
    returning last_seen_at into v_last_seen_at;

  if v_last_seen_at is null then
    raise exception 'Profile not found';
  end if;

  return v_last_seen_at;
end;
$$;

revoke all on function public.heartbeat_presence() from public, anon;
grant execute on function public.heartbeat_presence() to authenticated;
