import 'package:chat/typing_presence.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('hides the current user typing event', () {
    expect(
      isIncomingTypingSender(
        senderId: 'me',
        currentUserId: 'me',
        peerUserId: 'peer',
        isGroup: false,
      ),
      isFalse,
    );
  });

  test('accepts only the other participant in a direct conversation', () {
    expect(
      isIncomingTypingSender(
        senderId: 'peer',
        currentUserId: 'me',
        peerUserId: 'peer',
        isGroup: false,
      ),
      isTrue,
    );
    expect(
      isIncomingTypingSender(
        senderId: 'stranger',
        currentUserId: 'me',
        peerUserId: 'peer',
        isGroup: false,
      ),
      isFalse,
    );
  });

  test('accepts another member in a group conversation', () {
    expect(
      isIncomingTypingSender(
        senderId: 'member',
        currentUserId: 'me',
        peerUserId: null,
        isGroup: true,
      ),
      isTrue,
    );
  });
}
