-- Supporting indexes for call participant foreign keys and signal cleanup.
create index if not exists calls_conversation_caller_idx
  on public.calls(conversation_id, caller_id);
create index if not exists calls_conversation_callee_idx
  on public.calls(conversation_id, callee_id);
create index if not exists call_signals_sender_id_idx
  on public.call_signals(sender_id);
