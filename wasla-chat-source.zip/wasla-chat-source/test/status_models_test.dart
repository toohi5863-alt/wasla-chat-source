import 'package:flutter_test/flutter_test.dart';
import 'package:chat/status_models.dart';

void main() {
  test('parses text status with visibility and viewer metadata', () {
    final status = StatusItem.fromMap({
      'id': 'status-1',
      'user_id': 'user-1',
      'username': 'darwish',
      'display_name': 'درويش',
      'content_type': 'text',
      'body': 'مساء الخير',
      'background_color': 1428722,
      'privacy': 'selected',
      'created_at': '2026-10-08T02:00:00Z',
      'expires_at': '2026-10-09T02:00:00Z',
      'is_mine': false,
      'is_viewed': true,
      'views_count': 3,
    });

    expect(status.authorLabel, 'درويش');
    expect(status.body, 'مساء الخير');
    expect(status.privacy, 'selected');
    expect(status.isViewed, isTrue);
    expect(status.viewsCount, 3);
    expect(status.expiresAt.difference(status.createdAt).inHours, 24);
  });

  test('parses a video status and viewer identity', () {
    final status = StatusItem.fromMap({
      'id': 'status-2',
      'user_id': 'user-2',
      'username': 'friend',
      'content_type': 'video',
      'media_path': 'user-2/video.mp4',
      'background_color': '1428722',
      'created_at': '2026-10-08T02:00:00Z',
      'expires_at': '2026-10-09T02:00:00Z',
      'is_mine': true,
      'is_viewed': false,
      'views_count': '4',
    });
    final viewer = StatusViewer.fromMap({
      'viewer_id': 'viewer-1',
      'username': 'friend',
      'display_name': 'صديق',
      'viewed_at': '2026-10-08T02:03:00Z',
    });

    expect(status.contentType, 'video');
    expect(status.mediaPath, 'user-2/video.mp4');
    expect(status.isMine, isTrue);
    expect(viewer.label, 'صديق');
    expect(viewer.userId, 'viewer-1');
  });
}
