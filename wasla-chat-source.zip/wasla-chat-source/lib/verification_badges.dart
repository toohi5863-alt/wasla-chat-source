import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'admin_identity.dart';

/// Read-only client cache for server-controlled member verification badges.
/// The administrator badge is a separate, stable identity rule and is always
/// retained even when this public member-verification cache is refreshed.
class VerifiedMemberBadges {
  VerifiedMemberBadges._();

  static final ValueNotifier<Set<String>> userIds = ValueNotifier<Set<String>>(
    <String>{waslaAdminUserId},
  );

  static SupabaseClient? _client;
  static StreamSubscription<AuthState>? _authSubscription;
  static int _refreshGeneration = 0;

  static Future<void> initialize(SupabaseClient client) async {
    if (!identical(_client, client)) {
      await _authSubscription?.cancel();
      _client = client;
      _authSubscription = client.auth.onAuthStateChange.listen((state) {
        if (state.session == null) {
          updateVerifiedUserIds(const <String>{});
        } else {
          unawaited(refresh(client));
        }
      });
    }
    if (client.auth.currentSession != null) {
      await refresh(client);
    }
  }

  /// Reload only positively verified profile IDs. Errors are ignored so the
  /// app remains usable and no unverified account is accidentally badged.
  static Future<void> refresh(SupabaseClient client) async {
    if (client.auth.currentSession == null) {
      updateVerifiedUserIds(const <String>{});
      return;
    }

    final generation = ++_refreshGeneration;
    final verified = <String>{};
    const pageSize = 1000;
    var offset = 0;
    try {
      while (true) {
        final rows = await client
            .from('profiles')
            .select('id')
            .eq('is_verified', true)
            .order('id')
            .range(offset, offset + pageSize - 1);
        for (final row in rows) {
          final id = row['id']?.toString();
          if (id != null && id.isNotEmpty) verified.add(id);
        }
        if (rows.length < pageSize) break;
        offset += pageSize;
      }
      if (generation == _refreshGeneration) updateVerifiedUserIds(verified);
    } catch (_) {
      // Keep the last successful state; a failed read never grants a badge.
    }
  }

  @visibleForTesting
  static void updateVerifiedUserIds(Iterable<String> ids) {
    final next = <String>{waslaAdminUserId, ...ids};
    final current = userIds.value;
    if (setEquals(current, next)) return;
    userIds.value = Set<String>.unmodifiable(next);
  }

  static bool isVerified(String? userId) =>
      userId != null && userIds.value.contains(userId.trim());
}
