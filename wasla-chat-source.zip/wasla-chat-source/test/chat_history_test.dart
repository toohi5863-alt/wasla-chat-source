import 'package:chat/chat_history.dart';
import 'package:chat/chat_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('merges older pages chronologically without duplicating overlap', () {
    final cached = [
      _message('later', 'رسالة أحدث', DateTime.utc(2026, 10, 8, 12)),
      _message('shared', 'نسخة مخزنة', DateTime.utc(2026, 10, 8, 11)),
    ];
    final olderPage = [
      _message('oldest', 'رسالة أقدم', DateTime.utc(2026, 10, 8, 10)),
      _message('shared', 'نسخة الخادم', DateTime.utc(2026, 10, 8, 11)),
    ];

    final merged = mergeChatHistoryMessages(cached, olderPage);

    expect(merged.map((message) => message.id), ['oldest', 'shared', 'later']);
    expect(merged[1].content, 'نسخة الخادم');
  });

  test('uses stable ID ordering for messages with equal timestamps', () {
    final sameTime = DateTime.utc(2026, 10, 8, 12);

    final merged = mergeChatHistoryMessages(
      [_message('b', 'الثانية', sameTime)],
      [_message('a', 'الأولى', sameTime)],
    );

    expect(merged.map((message) => message.id), ['a', 'b']);
  });

  test('merges a Realtime row immediately and refreshes delivery metadata', () {
    final at = DateTime.utc(2026, 10, 8, 12);
    final optimistic = ChatMessage(
      id: 'message-1',
      senderId: 'user-1',
      content: 'مرحبًا',
      createdAt: at,
      isPending: true,
    );
    final realtime = ChatMessage(
      id: 'message-1',
      senderId: 'user-1',
      content: 'مرحبًا',
      createdAt: at,
      deliveredAt: at.add(const Duration(milliseconds: 40)),
    );

    final merged = mergeChatHistoryMessages([optimistic], [realtime]);

    expect(merged, hasLength(1));
    expect(merged.single.isPending, isFalse);
    expect(merged.single.deliveredAt, realtime.deliveredAt);
  });

  test(
    'keeps locally cached ephemeral content when the server has purged it',
    () {
      final at = DateTime.utc(2026, 10, 9, 12);
      final cachedImage = ChatMessage(
        id: 'image-1',
        senderId: 'sender',
        content: 'صورة العائلة',
        createdAt: at,
        messageType: 'image',
        mediaPath: 'conversation/sender/image.jpg',
        isEphemeral: true,
      );
      final serverTombstone = ChatMessage(
        id: 'image-1',
        senderId: 'sender',
        content: 'تم التسليم',
        createdAt: at,
        isEphemeral: true,
        payloadDeletedAt: at.add(const Duration(seconds: 1)),
        deliveredAt: at.add(const Duration(seconds: 1)),
      );

      final merged = mergeChatHistoryMessages([cachedImage], [serverTombstone]);

      expect(merged.single.content, 'صورة العائلة');
      expect(merged.single.messageType, 'image');
      expect(merged.single.mediaPath, 'conversation/sender/image.jpg');
      expect(merged.single.payloadDeletedAt, serverTombstone.payloadDeletedAt);
      expect(merged.single.deliveredAt, serverTombstone.deliveredAt);
      expect(merged.single.hasLocalPayload, isTrue);
    },
  );

  test('hides metadata-only tombstones from fresh and cached history', () {
    final tombstone = ChatMessage(
      id: 'text-1',
      senderId: 'sender',
      content: 'تم التسليم',
      createdAt: DateTime.utc(2026, 10, 9),
      isEphemeral: true,
      payloadDeletedAt: DateTime.utc(2026, 10, 9, 0, 1),
    );

    expect(mergeChatHistoryMessages([], [tombstone]), isEmpty);
    expect(mergeChatHistoryMessages([tombstone], []), isEmpty);
  });

  test(
    'keeps real non-ephemeral messages even when deletion metadata exists',
    () {
      final legacy = ChatMessage(
        id: 'legacy-1',
        senderId: 'sender',
        content: 'رسالة محفوظة',
        createdAt: DateTime.utc(2026, 10, 9),
        payloadDeletedAt: DateTime.utc(2026, 10, 9, 0, 1),
      );

      expect(mergeChatHistoryMessages([], [legacy]), [legacy]);
    },
  );
}

ChatMessage _message(String id, String content, DateTime createdAt) =>
    ChatMessage(
      id: id,
      senderId: 'user-1',
      content: content,
      createdAt: createdAt,
    );
