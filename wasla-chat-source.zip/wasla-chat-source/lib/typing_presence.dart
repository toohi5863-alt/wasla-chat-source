/// Returns whether a transient typing event belongs to someone else in this chat.
bool isIncomingTypingSender({
  required String? senderId,
  required String? currentUserId,
  required String? peerUserId,
  required bool isGroup,
}) {
  if (senderId == null || senderId.isEmpty || senderId == currentUserId) {
    return false;
  }
  return isGroup || (peerUserId != null && senderId == peerUserId);
}
