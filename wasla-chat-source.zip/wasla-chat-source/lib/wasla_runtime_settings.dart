import 'package:supabase_flutter/supabase_flutter.dart';

/// Public, non-secret operational flags returned by the Wasla admin function.
/// Defaults preserve the app's existing behavior if the endpoint is unavailable.
class WaslaRuntimeSettings {
  WaslaRuntimeSettings._();

  static bool announcementEnabled = false;
  static String announcementText = '';
  static bool messagesEnabled = true;
  static bool mediaUploadsEnabled = true;
  static int maxMediaUploadMb = 15;

  static DateTime? _lastRefreshAttempt;
  static int get maxMediaUploadBytes => maxMediaUploadMb * 1024 * 1024;

  static bool applyPublicSettings(Map<String, dynamic> values) {
    final previous = <Object?>[
      announcementEnabled,
      announcementText,
      messagesEnabled,
      mediaUploadsEnabled,
      maxMediaUploadMb,
    ];
    if (values['announcement_enabled'] is bool) {
      announcementEnabled = values['announcement_enabled'] as bool;
    }
    if (values['announcement_text'] is String) {
      announcementText = values['announcement_text'] as String;
    }
    if (values['messages_enabled'] is bool) {
      messagesEnabled = values['messages_enabled'] as bool;
    }
    if (values['media_uploads_enabled'] is bool) {
      mediaUploadsEnabled = values['media_uploads_enabled'] as bool;
    }
    final maxSize = int.tryParse(values['max_media_upload_mb']?.toString() ?? '');
    if (maxSize != null && maxSize >= 1 && maxSize <= 15) {
      maxMediaUploadMb = maxSize;
    }
    return previous[0] != announcementEnabled ||
        previous[1] != announcementText ||
        previous[2] != messagesEnabled ||
        previous[3] != mediaUploadsEnabled ||
        previous[4] != maxMediaUploadMb;
  }

  static Future<bool> refresh(
    SupabaseClient client, {
    bool force = false,
  }) async {
    final now = DateTime.now();
    final last = _lastRefreshAttempt;
    if (!force && last != null && now.difference(last) < const Duration(seconds: 30)) {
      return false;
    }
    _lastRefreshAttempt = now;
    try {
      final result = await client.functions
          .invoke('wasla-admin', body: const {'action': 'public_settings'})
          .timeout(const Duration(seconds: 3));
      if (result.data is Map) {
        return applyPublicSettings(Map<String, dynamic>.from(result.data as Map));
      }
    } catch (_) {
      // Backend enforcement remains authoritative when this UI refresh fails.
    }
    return false;
  }
}
