import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'notification_preferences.dart';
import 'verification_badges.dart';

const _firebaseApiKey = String.fromEnvironment('FIREBASE_API_KEY');
const _firebaseAppId = String.fromEnvironment('FIREBASE_APP_ID');
const _firebaseMessagingSenderId = String.fromEnvironment(
  'FIREBASE_MESSAGING_SENDER_ID',
);
const _firebaseProjectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
const _supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const _supabasePublishableKey = String.fromEnvironment(
  'SUPABASE_PUBLISHABLE_KEY',
);

bool get firebasePushConfigured =>
    _firebaseApiKey.isNotEmpty &&
    _firebaseAppId.isNotEmpty &&
    _firebaseMessagingSenderId.isNotEmpty &&
    _firebaseProjectId.isNotEmpty;

const _incomingCallNotificationId = 7401;
const _incomingCallNotificationTimeout = Duration(seconds: 90);

bool _isIncomingCallMessage(Map<String, dynamic> data) =>
    (data['type'] == 'incoming_call' || data['category'] == 'calls') &&
    (data['call_id']?.toString().isNotEmpty ?? false);

FirebaseOptions get _firebaseOptions => FirebaseOptions(
  apiKey: _firebaseApiKey,
  appId: _firebaseAppId,
  messagingSenderId: _firebaseMessagingSenderId,
  projectId: _firebaseProjectId,
);

@pragma('vm:entry-point')
Future<void> waslaFirebaseBackgroundHandler(RemoteMessage message) async {
  if (!firebasePushConfigured) return;
  if (Firebase.apps.isEmpty) {
    await Firebase.initializeApp(options: _firebaseOptions);
  }
  if (message.data['type'] == 'delivery_probe') {
    await _acknowledgeDeliveryProbe(message.data['message_id']?.toString());
    return;
  }
  // Data-only call pushes reach this handler and can request a full-screen
  // notification. FCM notification payloads are displayed directly by Android
  // and bypass this handler while the app is backgrounded.
  if (_isIncomingCallMessage(message.data)) {
    await _showBackgroundIncomingCallNotification(message);
  }
}

Future<void> _showBackgroundIncomingCallNotification(
  RemoteMessage message,
) async {
  final data = message.data;
  if (data['calls_enabled'] == 'false' || data['do_not_disturb'] == 'true') {
    return;
  }

  final soundEnabled = data['sound_enabled'] != 'false';
  final vibrationEnabled = data['vibration_enabled'] != 'false';
  final channelId = PushNotifications.channelIdFor(
    'calls',
    sound: soundEnabled,
    vibration: vibrationEnabled,
  );
  final channelName = PushNotifications._channelName(
    'calls',
    sound: soundEnabled,
    vibration: vibrationEnabled,
  );
  final local = FlutterLocalNotificationsPlugin();
  await local.initialize(
    const InitializationSettings(
      android: AndroidInitializationSettings('@drawable/ic_stat_wasla'),
    ),
  );
  final android = local
      .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin
      >();
  await android?.createNotificationChannel(
    AndroidNotificationChannel(
      channelId,
      channelName,
      description: 'إشعارات المكالمات الواردة في وصال',
      importance: Importance.max,
      playSound: soundEnabled,
      sound: soundEnabled
          ? const RawResourceAndroidNotificationSound('incoming_call_ringtone')
          : null,
      enableVibration: vibrationEnabled,
      audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
    ),
  );

  final title =
      message.notification?.title ??
      data['title']?.toString() ??
      'مكالمة واردة';
  final body =
      message.notification?.body ??
      data['body']?.toString() ??
      'لديك مكالمة واردة';
  await local.show(
    _incomingCallNotificationId,
    title,
    body,
    NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription: 'تنبيه المكالمة الواردة في وصال',
        icon: '@drawable/ic_stat_wasla',
        importance: Importance.max,
        priority: Priority.max,
        category: AndroidNotificationCategory.call,
        visibility: NotificationVisibility.private,
        playSound: soundEnabled,
        enableVibration: vibrationEnabled,
        audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
        fullScreenIntent: true,
        autoCancel: false,
        ongoing: true,
        onlyAlertOnce: true,
        timeoutAfter: _incomingCallNotificationTimeout.inMilliseconds,
        tag: 'call-${data['call_id']}',
        styleInformation: BigTextStyleInformation(body),
      ),
    ),
    payload: jsonEncode(data),
  );
}

Future<void> _acknowledgeDeliveryProbe(String? messageId) async {
  if (messageId == null ||
      messageId.isEmpty ||
      _supabaseUrl.isEmpty ||
      _supabasePublishableKey.isEmpty) {
    return;
  }
  HttpClient? http;
  try {
    final token = await FirebaseMessaging.instance.getToken();
    if (token == null || token.isEmpty) return;
    http = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    final baseUrl = _supabaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final request = await http
        .postUrl(Uri.parse('$baseUrl/functions/v1/send-message-push'))
        .timeout(const Duration(seconds: 8));
    request.headers
      ..set(HttpHeaders.contentTypeHeader, 'application/json')
      ..set('apikey', _supabasePublishableKey)
      ..set(HttpHeaders.authorizationHeader, 'Bearer $_supabasePublishableKey')
      ..set('x-wasla-device-token', token);
    request.write(
      jsonEncode({'type': 'DELIVERY_ACK', 'message_id': messageId}),
    );
    final response = await request.close().timeout(const Duration(seconds: 8));
    await response.drain<void>();
    if (response.statusCode < 200 || response.statusCode >= 300) {
      debugPrint('Wasla delivery receipt was not accepted by the server');
    }
  } catch (error) {
    debugPrint('Wasla background delivery receipt failed: $error');
  } finally {
    http?.close(force: true);
  }
}

class PushNotifications {
  PushNotifications._();

  static final PushNotifications instance = PushNotifications._();
  static const legacyChannelId = 'wasla_messages';
  static const defaultChannelId = 'wasla_messages_sound_vibrate';
  static const _categories = <String>[
    'messages',
    'groups',
    'channels',
    'statuses',
    'calls',
  ];

  static String accountChannelIdFor({
    required bool sound,
    required bool vibration,
  }) =>
      'wasla_account_${sound ? 'sound' : 'silent'}_${vibration ? 'vibrate' : 'no_vibrate'}';

  static String _accountChannelName({
    required bool sound,
    required bool vibration,
  }) =>
      'تنبيهات الحساب — ${sound ? 'صوت' : 'صامت'}${vibration ? ' واهتزاز' : ''}';

  static const _legacyChannel = AndroidNotificationChannel(
    legacyChannelId,
    'رسائل وصال',
    description: 'قناة احتياطية للإشعارات القديمة في وصال',
    importance: Importance.max,
    playSound: true,
  );

  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();
  SupabaseClient? _client;
  StreamSubscription<AuthState>? _authSubscription;
  StreamSubscription<String>? _tokenSubscription;
  StreamSubscription<RemoteMessage>? _foregroundSubscription;
  StreamSubscription<RemoteMessage>? _openedSubscription;
  void Function(Map<String, String>)? _tapHandler;
  Map<String, String>? _pendingTap;
  bool _initialized = false;
  bool _permissionGranted = false;
  String? activeConversationId;
  PushNotificationPreferences _preferences =
      const PushNotificationPreferences();

  PushNotificationPreferences get preferences => _preferences;

  static String channelIdFor(
    String category, {
    required bool sound,
    required bool vibration,
  }) {
    final safeCategory = _categories.contains(category) ? category : 'messages';
    final soundPart = sound ? 'sound' : 'silent';
    final vibrationPart = vibration ? 'vibrate' : 'no_vibrate';
    return 'wasla_${safeCategory}_${soundPart}_$vibrationPart';
  }

  static String _channelName(
    String category, {
    required bool sound,
    required bool vibration,
  }) {
    final base = switch (category) {
      'groups' => 'مجموعات وصال',
      'channels' => 'قنوات وصال',
      'statuses' => 'حالات وصال',
      'calls' => 'مكالمات وصال',
      _ => 'رسائل وصال',
    };
    final mode = [
      if (sound) 'صوت',
      if (vibration) 'اهتزاز',
      if (!sound && !vibration) 'صامت',
    ].join(' و');
    return '$base — $mode';
  }

  Future<bool> initialize(SupabaseClient client) async {
    _client = client;
    if (!Platform.isAndroid || !firebasePushConfigured) return false;
    if (_initialized) return true;

    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(options: _firebaseOptions);
      }
      FirebaseMessaging.onBackgroundMessage(waslaFirebaseBackgroundHandler);
      await _initializeLocalNotifications();
      await refreshPreferences();
      _foregroundSubscription = FirebaseMessaging.onMessage.listen((message) {
        if (message.data['type'] == 'delivery_probe') {
          unawaited(
            _acknowledgeDeliveryProbe(message.data['message_id']?.toString()),
          );
        } else {
          unawaited(_showForegroundNotification(message));
        }
      });
      _openedSubscription = FirebaseMessaging.onMessageOpenedApp.listen(
        (message) => _handleTap(message.data),
      );
      _tokenSubscription = FirebaseMessaging.instance.onTokenRefresh.listen(
        (token) => unawaited(_registerToken(token)),
        onError: (Object error) =>
            debugPrint('FCM token refresh failed: $error'),
      );
      _authSubscription = client.auth.onAuthStateChange.listen((state) {
        if (state.event == AuthChangeEvent.signedIn) {
          unawaited(refreshPreferences());
          if (_permissionGranted) unawaited(registerCurrentDevice());
        }
      });
      final initialMessage = await FirebaseMessaging.instance
          .getInitialMessage();
      if (initialMessage != null) _handleTap(initialMessage.data);
      final launchDetails = await _local.getNotificationAppLaunchDetails();
      final payload = launchDetails?.notificationResponse?.payload;
      if (launchDetails?.didNotificationLaunchApp == true && payload != null) {
        _handleLocalTap(payload);
      }
      _initialized = true;
      return true;
    } catch (error, stackTrace) {
      debugPrint('Wasla push initialization failed: $error\n$stackTrace');
      return false;
    }
  }

  Future<void> _initializeLocalNotifications() async {
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@drawable/ic_stat_wasla'),
    );
    await _local.initialize(
      settings,
      onDidReceiveNotificationResponse: (response) {
        final payload = response.payload;
        if (payload != null) _handleLocalTap(payload);
      },
    );
    final android = _local
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    await android?.createNotificationChannel(_legacyChannel);
    for (final category in _categories) {
      for (final sound in [false, true]) {
        for (final vibration in [false, true]) {
          final channelId = channelIdFor(
            category,
            sound: sound,
            vibration: vibration,
          );
          await android?.createNotificationChannel(
            AndroidNotificationChannel(
              channelId,
              _channelName(category, sound: sound, vibration: vibration),
              description: 'إشعارات $category في وصال',
              importance: Importance.max,
              playSound: sound,
              sound: category == 'calls' && sound
                  ? const RawResourceAndroidNotificationSound(
                      'incoming_call_ringtone',
                    )
                  : null,
              enableVibration: vibration,
              audioAttributesUsage: category == 'calls'
                  ? AudioAttributesUsage.notificationRingtone
                  : AudioAttributesUsage.notification,
            ),
          );
        }
      }
    }
    for (final sound in [false, true]) {
      for (final vibration in [false, true]) {
        await android?.createNotificationChannel(
          AndroidNotificationChannel(
            accountChannelIdFor(sound: sound, vibration: vibration),
            _accountChannelName(sound: sound, vibration: vibration),
            description: 'إشعارات توثيق الحساب في وصال',
            importance: Importance.max,
            playSound: sound,
            enableVibration: vibration,
            audioAttributesUsage: AudioAttributesUsage.notification,
          ),
        );
      }
    }
  }

  Future<void> refreshPreferences() async {
    final client = _client;
    final userId = client?.auth.currentUser?.id;
    if (client == null || userId == null) {
      _preferences = const PushNotificationPreferences();
      return;
    }
    try {
      final row = await client
          .from('notification_preferences')
          .select()
          .eq('user_id', userId)
          .maybeSingle();
      _preferences = PushNotificationPreferences.fromMap(
        row == null ? null : Map<String, dynamic>.from(row),
      );
    } catch (error) {
      // Retain the last known settings if offline; the server also enforces them.
      debugPrint('Wasla notification preferences refresh failed: $error');
    }
  }

  void updatePreferences(PushNotificationPreferences preferences) {
    _preferences = preferences;
  }

  Future<bool> shouldPlayConversationSound(
    String conversationId, {
    required String category,
  }) async {
    if (activeConversationId != conversationId) return false;
    await refreshPreferences();
    if (!_preferences.allowsChatSoundFor(category)) {
      return false;
    }
    final client = _client;
    final userId = client?.auth.currentUser?.id;
    if (client == null || userId == null) return false;
    try {
      final row = await client
          .from('conversation_notification_preferences')
          .select('notifications_enabled,muted_until')
          .eq('user_id', userId)
          .eq('conversation_id', conversationId)
          .maybeSingle();
      if (ConversationNotificationPreference.fromMap(
        row == null ? null : Map<String, dynamic>.from(row),
      ).isMuted) {
        return false;
      }
    } catch (_) {
      // Fail closed if the conversation mute preference cannot be verified.
      return false;
    }
    return activeConversationId == conversationId;
  }

  Future<bool> requestPermissionAndRegister() async {
    if (!_initialized || !Platform.isAndroid) return false;
    try {
      final settings = await FirebaseMessaging.instance.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );
      _permissionGranted =
          settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional;
      if (!_permissionGranted) return false;
      await refreshPreferences();
      await registerCurrentDevice();
      if (_preferences.callsEnabled) {
        try {
          final android = _local
              .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin
              >();
          final granted = await android?.requestFullScreenIntentPermission();
          if (granted != true) {
            debugPrint(
              'Wasla full-screen call alerts are not enabled; notifications remain available',
            );
          }
        } catch (error) {
          debugPrint('Wasla full-screen permission request failed: $error');
        }
      }
      return true;
    } catch (error) {
      debugPrint('Wasla notification permission failed: $error');
      return false;
    }
  }

  Future<void> registerCurrentDevice() async {
    if (!_initialized || !_permissionGranted) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null && token.isNotEmpty) await _registerToken(token);
    } catch (error) {
      debugPrint('Wasla push token registration failed: $error');
    }
  }

  Future<void> _registerToken(String token) async {
    final client = _client;
    if (client == null || client.auth.currentUser == null) return;
    try {
      await client.rpc(
        'register_push_device',
        params: {'p_token': token, 'p_platform': 'android'},
      );
    } catch (error) {
      debugPrint('Wasla push device registration is not ready: $error');
    }
  }

  Future<void> unregisterCurrentDevice() async {
    final client = _client;
    if (!_initialized || client?.auth.currentUser == null) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null || token.isEmpty) return;
      await client!.rpc('unregister_push_device', params: {'p_token': token});
    } catch (error) {
      debugPrint('Wasla push device removal failed: $error');
    }
  }

  void setNotificationTapHandler(void Function(Map<String, String>)? handler) {
    _tapHandler = handler;
    final pending = _pendingTap;
    if (handler != null && pending != null) {
      _pendingTap = null;
      scheduleMicrotask(() => handler(pending));
    }
  }

  String _categoryFor(Map<String, dynamic> data) {
    final declared = data['category']?.toString();
    if (_categories.contains(declared)) return declared!;
    return switch (data['type']?.toString()) {
      'incoming_call' || 'call' => 'calls',
      'status' => 'statuses',
      'group_message' => 'groups',
      'channel_message' => 'channels',
      _ => 'messages',
    };
  }

  Future<bool> _conversationMuted(String? conversationId) async {
    final client = _client;
    final userId = client?.auth.currentUser?.id;
    if (client == null || userId == null || conversationId == null) {
      return false;
    }
    try {
      final row = await client
          .from('conversation_notification_preferences')
          .select('notifications_enabled,muted_until')
          .eq('user_id', userId)
          .eq('conversation_id', conversationId)
          .maybeSingle();
      return ConversationNotificationPreference.fromMap(
        row == null ? null : Map<String, dynamic>.from(row),
      ).isMuted;
    } catch (_) {
      return false;
    }
  }

  Future<void> _showForegroundNotification(RemoteMessage message) async {
    final data = message.data;
    final verificationNotice = data['type'] == 'account_verification';
    if (verificationNotice && _client != null) {
      unawaited(VerifiedMemberBadges.refresh(_client!));
    }
    await refreshPreferences();
    final category = _categoryFor(data);
    // Realtime is authoritative for a live incoming call while the app is open.
    // Suppress the parallel FCM alert so it cannot stack over the call UI/ring.
    if (category == 'calls') return;
    if (!verificationNotice &&
        (_preferences.doNotDisturb || !_preferences.enabledFor(category))) {
      return;
    }

    final conversationId = data['conversation_id']?.toString();
    if (!verificationNotice &&
        category != 'calls' &&
        conversationId != null &&
        conversationId == activeConversationId) {
      return;
    }
    if (!verificationNotice && await _conversationMuted(conversationId)) return;

    final title = message.notification?.title ?? data['title']?.toString();
    var body = message.notification?.body ?? data['body']?.toString();
    if (title == null || title.isEmpty || body == null || body.isEmpty) return;
    if (!verificationNotice &&
        !_preferences.showMessagePreview &&
        const {'messages', 'groups', 'channels'}.contains(category)) {
      body = 'افتح وصال لعرض المحتوى';
    }

    final channelId = verificationNotice
        ? accountChannelIdFor(
            sound: _preferences.soundEnabled,
            vibration: _preferences.vibrationEnabled,
          )
        : channelIdFor(
            category,
            sound: _preferences.soundEnabled,
            vibration: _preferences.vibrationEnabled,
          );
    final channelName = verificationNotice
        ? _accountChannelName(
            sound: _preferences.soundEnabled,
            vibration: _preferences.vibrationEnabled,
          )
        : _channelName(
            category,
            sound: _preferences.soundEnabled,
            vibration: _preferences.vibrationEnabled,
          );
    final isCall = category == 'calls';
    final isStatus = category == 'statuses';
    await _local.show(
      message.hashCode,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          channelId,
          channelName,
          channelDescription: 'إشعارات وصال',
          icon: '@drawable/ic_stat_wasla',
          importance: Importance.max,
          priority: Priority.high,
          category: isCall
              ? AndroidNotificationCategory.call
              : isStatus
              ? AndroidNotificationCategory.social
              : AndroidNotificationCategory.message,
          visibility: !_preferences.showMessagePreview && !isCall && !isStatus
              ? NotificationVisibility.private
              : NotificationVisibility.public,
          playSound: _preferences.soundEnabled,
          enableVibration: _preferences.vibrationEnabled,
          styleInformation: BigTextStyleInformation(body),
          tag: (data['message_id'] ?? data['call_id'] ?? data['status_id'])
              ?.toString(),
        ),
      ),
      payload: jsonEncode(data),
    );
  }

  void _handleTap(Map<String, dynamic> data) {
    _deliverTap(_stringMap(data));
  }

  void _handleLocalTap(String payload) {
    try {
      final decoded = jsonDecode(payload);
      if (decoded is Map) {
        _deliverTap(_stringMap(Map<String, dynamic>.from(decoded)));
      }
    } on FormatException {
      // Ignore malformed notification payloads rather than interrupting startup.
    }
  }

  void _deliverTap(Map<String, String> data) {
    if ((data['conversation_id'] ?? '').isEmpty &&
        (data['call_id'] ?? '').isEmpty &&
        (data['status_id'] ?? '').isEmpty &&
        data['type'] != 'account_verification') {
      return;
    }
    final handler = _tapHandler;
    if (handler == null) {
      _pendingTap = data;
    } else {
      handler(data);
    }
  }

  Future<void> cancelIncomingCallNotification() async {
    if (!Platform.isAndroid) return;
    try {
      await _local.cancel(_incomingCallNotificationId);
    } catch (error) {
      debugPrint('Wasla incoming call notification cleanup failed: $error');
    }
  }

  static Map<String, String> _stringMap(Map<String, dynamic> data) => {
    for (final entry in data.entries)
      if (entry.value != null) entry.key: entry.value.toString(),
  };

  Future<void> dispose() async {
    await _authSubscription?.cancel();
    await _tokenSubscription?.cancel();
    await _foregroundSubscription?.cancel();
    await _openedSubscription?.cancel();
  }
}
