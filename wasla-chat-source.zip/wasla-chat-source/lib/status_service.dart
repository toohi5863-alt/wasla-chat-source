import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'friendship_models.dart';
import 'status_feed_cache.dart';
import 'status_models.dart';

class StatusService {
  StatusService(this.client, {StatusFeedCache? feedCache})
    : feedCache = feedCache ?? StatusFeedCache();

  final SupabaseClient client;
  final StatusFeedCache feedCache;

  Future<List<StatusItem>> loadFeed() async {
    final accountId = client.auth.currentUser?.id;
    try {
      final response = await client.rpc('list_status_feed');
      final statuses = (response as List)
          .map(
            (row) => StatusItem.fromMap(Map<String, dynamic>.from(row as Map)),
          )
          .toList(growable: false);
      if (accountId != null) {
        try {
          await feedCache.save(accountId, statuses);
        } catch (_) {
          // A cache write must not turn a successful server refresh into failure.
        }
      }
      return statuses;
    } catch (error, stackTrace) {
      if (accountId != null) {
        try {
          final cached = await feedCache.load(accountId);
          if (cached != null) return cached;
        } catch (_) {
          // Keep the original network error when no readable feed is cached.
        }
      }
      Error.throwWithStackTrace(error, stackTrace);
    }
  }

  Future<List<Friend>> loadFriends() async {
    final response = await client.rpc('list_friends');
    return (response as List)
        .map((row) => Friend.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList(growable: false);
  }

  Future<String> publish({
    required String contentType,
    required String? body,
    required Uint8List? mediaBytes,
    required String? fileName,
    required String? mediaContentType,
    required String privacy,
    required List<String> audienceUserIds,
    required int backgroundColor,
  }) async {
    final user = client.auth.currentUser;
    if (user == null) throw const AuthException('Authentication required');
    String? mediaPath;
    if (mediaBytes != null) {
      final extension = (fileName ?? '').contains('.')
          ? fileName!.split('.').last.toLowerCase()
          : (contentType == 'video' ? 'mp4' : 'jpg');
      mediaPath =
          '${user.id}/${DateTime.now().microsecondsSinceEpoch}.$extension';
      await client.storage
          .from('wasla-statuses')
          .uploadBinary(
            mediaPath,
            mediaBytes,
            fileOptions: FileOptions(contentType: mediaContentType),
          );
    }
    try {
      final row = await client
          .from('status_posts')
          .insert({
            'user_id': user.id,
            'content_type': contentType,
            'body': body,
            'media_path': mediaPath,
            'privacy': privacy,
            'audience_user_ids': privacy == 'selected'
                ? audienceUserIds
                : <String>[],
            'background_color': backgroundColor,
          })
          .select('id')
          .single();
      return row['id'].toString();
    } catch (_) {
      if (mediaPath != null) {
        try {
          await client.storage.from('wasla-statuses').remove([mediaPath]);
        } catch (_) {
          // Keep the original insert error; an orphan can be removed by storage cleanup.
        }
      }
      rethrow;
    }
  }

  Future<bool> markViewed(String statusId) async {
    return await client.rpc(
      'mark_status_viewed',
      params: {'p_status_id': statusId},
    ) as bool;
  }

  Future<List<StatusViewer>> loadViewers(String statusId) async {
    final response = await client.rpc(
      'list_status_viewers',
      params: {'p_status_id': statusId},
    );
    return (response as List)
        .map(
          (row) => StatusViewer.fromMap(Map<String, dynamic>.from(row as Map)),
        )
        .toList(growable: false);
  }

  Future<void> sendReply({
    required String statusId,
    required String body,
  }) async {
    final user = client.auth.currentUser;
    if (user == null) throw const AuthException('Authentication required');
    final text = body.trim();
    if (text.isEmpty || text.length > 1000) {
      throw ArgumentError.value(
        body,
        'body',
        'Reply must contain 1–1000 characters',
      );
    }
    await client.from('status_replies').insert({
      'status_id': statusId,
      'sender_id': user.id,
      'body': text,
    });
  }

  Future<List<StatusReply>> loadReplies(String statusId) async {
    final response = await client
        .from('status_replies')
        .select(
          'id,status_id,sender_id,body,created_at,'
          'sender:profiles!status_replies_sender_id_fkey('
          'username,display_name,avatar_path)',
        )
        .eq('status_id', statusId)
        .order('created_at', ascending: false)
        .limit(100);
    final replies = (response as List)
        .map(
          (row) => StatusReply.fromMap(Map<String, dynamic>.from(row as Map)),
        )
        .toList(growable: false);
    return replies.reversed.toList(growable: false);
  }

  Future<String> signedMediaUrl(String path) =>
      client.storage.from('wasla-statuses').createSignedUrl(path, 900);

  Future<Uint8List> downloadMedia(String path) =>
      client.storage.from('wasla-statuses').download(path);

  Future<void> delete(StatusItem status) async {
    await client.from('status_posts').delete().eq('id', status.id);
    final path = status.mediaPath;
    if (path != null && path.isNotEmpty) {
      await client.storage.from('wasla-statuses').remove([path]);
    }
  }
}
