import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';

/// Private, persistent on-device storage for media belonging to active statuses.
/// Files live in application support storage (not the public gallery), are
/// isolated by account, and are removed once their status expires.
class StatusMediaCache {
  StatusMediaCache({
    Future<Directory> Function()? directoryProvider,
    DateTime Function()? clock,
  }) : _directoryProvider = directoryProvider ?? getApplicationSupportDirectory,
       _clock = clock ?? DateTime.now;

  final Future<Directory> Function() _directoryProvider;
  final DateTime Function() _clock;
  final Map<String, Future<File>> _inFlight = <String, Future<File>>{};
  static final Set<String> _protectedFiles = <String>{};

  Future<File> fileFor({
    required String accountId,
    required String statusId,
    required String storagePath,
    required DateTime expiresAt,
    required Future<Uint8List> Function() download,
  }) async {
    if (!_clock().isBefore(expiresAt)) {
      throw const StatusMediaExpiredException();
    }

    final accountKey = _safeKey(accountId);
    final statusKey = _safeKey(statusId);
    final requestKey = '$accountKey:$statusKey';
    final active = _inFlight[requestKey];
    if (active != null) return active;

    final future = _fileForUnlocked(
      accountKey: accountKey,
      statusKey: statusKey,
      statusId: statusId,
      storagePath: storagePath,
      expiresAt: expiresAt,
      download: download,
    );
    _inFlight[requestKey] = future;
    try {
      return await future;
    } finally {
      if (identical(_inFlight[requestKey], future)) {
        _inFlight.remove(requestKey);
      }
    }
  }

  Future<void> removeStatus({
    required String accountId,
    required String statusId,
  }) async {
    final root = await _directoryProvider();
    final accountDirectory = Directory(
      '${root.path}${Platform.pathSeparator}wasla_status_media_${_safeKey(accountId)}',
    );
    if (!await accountDirectory.exists()) return;
    final statusKey = _safeKey(statusId);
    final prefix = 'status_$statusKey';
    await for (final entity in accountDirectory.list(followLinks: false)) {
      if (entity is File && entity.uri.pathSegments.last.startsWith(prefix)) {
        await _deleteIfPresent(entity);
      }
    }
  }

  Future<void> removeExpiredForAccount(String accountId) async {
    final root = await _directoryProvider();
    final directory = Directory(
      '${root.path}${Platform.pathSeparator}wasla_status_media_${_safeKey(accountId)}',
    );
    if (await directory.exists()) await _removeExpired(directory);
  }

  Future<File> _fileForUnlocked({
    required String accountKey,
    required String statusKey,
    required String statusId,
    required String storagePath,
    required DateTime expiresAt,
    required Future<Uint8List> Function() download,
  }) async {
    final root = await _directoryProvider();
    final accountDirectory = Directory(
      '${root.path}${Platform.pathSeparator}wasla_status_media_$accountKey',
    );
    await accountDirectory.create(recursive: true);
    await _removeExpired(accountDirectory);

    if (!_clock().isBefore(expiresAt)) {
      throw const StatusMediaExpiredException();
    }

    final extension = _safeExtension(storagePath);
    final file = File(
      '${accountDirectory.path}${Platform.pathSeparator}'
      'status_$statusKey.media.$extension',
    );
    final metadata = File(
      '${accountDirectory.path}${Platform.pathSeparator}status_$statusKey.json',
    );
    final cached = await _readMetadata(metadata);
    if (cached != null &&
        cached['statusId'] == statusId &&
        cached['storagePath'] == storagePath &&
        cached['expiresAt'] == expiresAt.toUtc().toIso8601String() &&
        cached['fileName'] == file.uri.pathSegments.last &&
        await _nonEmpty(file)) {
      return file;
    }
    await _deleteIfPresent(metadata);
    await _deleteIfPresent(file);

    final temporaryFile = File('${file.path}.part');
    final temporaryMetadata = File('${metadata.path}.part');
    _protectedFiles.add(file.path);
    try {
      final bytes = await download();
      if (!_clock().isBefore(expiresAt)) {
        throw const StatusMediaExpiredException();
      }
      if (bytes.isEmpty) {
        throw const FileSystemException('Downloaded status media is empty');
      }
      await temporaryFile.writeAsBytes(bytes, flush: true);
      if (await file.exists()) await file.delete();
      await temporaryFile.rename(file.path);
      final record = <String, Object?>{
        'statusId': statusId,
        'storagePath': storagePath,
        'expiresAt': expiresAt.toUtc().toIso8601String(),
        'fileName': file.uri.pathSegments.last,
      };
      await temporaryMetadata.writeAsString(jsonEncode(record), flush: true);
      if (await metadata.exists()) await metadata.delete();
      await temporaryMetadata.rename(metadata.path);
    } finally {
      await _deleteIfPresent(temporaryFile);
      await _deleteIfPresent(temporaryMetadata);
      _protectedFiles.remove(file.path);
    }
    return file;
  }

  Future<void> _removeExpired(Directory directory) async {
    final retainedFiles = <String>{};
    await for (final entity in directory.list(followLinks: false)) {
      if (entity is! File || !entity.path.endsWith('.json')) continue;
      final record = await _readMetadata(entity);
      final expiry = DateTime.tryParse(record?['expiresAt']?.toString() ?? '');
      final fileName = record?['fileName']?.toString();
      if (record != null &&
          expiry != null &&
          _clock().isBefore(expiry) &&
          fileName != null &&
          fileName == _safeLeaf(fileName)) {
        retainedFiles.add(fileName);
      } else {
        if (fileName != null && fileName == _safeLeaf(fileName)) {
          await _deleteIfPresent(
            File('${directory.path}${Platform.pathSeparator}$fileName'),
          );
        }
        await _deleteIfPresent(entity);
      }
    }

    // Remove files whose metadata was lost (for example after an interrupted
    // write), while leaving active downloads and their temporary files alone.
    await for (final entity in directory.list(followLinks: false)) {
      if (entity is! File || !entity.path.contains('.media.')) continue;
      final name = entity.uri.pathSegments.last;
      if (!retainedFiles.contains(name) &&
          !_protectedFiles.contains(entity.path) &&
          !entity.path.endsWith('.part')) {
        await _deleteIfPresent(entity);
      }
    }
  }

  Future<Map<String, dynamic>?> _readMetadata(File file) async {
    try {
      if (!await file.exists()) return null;
      final value = jsonDecode(await file.readAsString());
      return value is Map<String, dynamic> ? value : null;
    } on FileSystemException {
      return null;
    } on FormatException {
      return null;
    }
  }

  Future<bool> _nonEmpty(File file) async {
    try {
      return await file.exists() && await file.length() > 0;
    } on FileSystemException {
      return false;
    }
  }

  Future<void> _deleteIfPresent(File file) async {
    try {
      if (await file.exists()) await file.delete();
    } on FileSystemException {
      // A best-effort cleanup must not prevent opening a valid active status.
    }
  }
}

class StatusMediaExpiredException implements Exception {
  const StatusMediaExpiredException();

  @override
  String toString() => 'Status media has expired';
}

String _safeKey(String value) =>
    base64Url.encode(utf8.encode(value)).replaceAll('=', '');

String _safeExtension(String path) {
  final leaf = path.replaceAll('\\', '/').split('/').last;
  final dot = leaf.lastIndexOf('.');
  if (dot < 0 || dot == leaf.length - 1) return 'bin';
  final extension = leaf.substring(dot + 1).toLowerCase();
  return RegExp(r'^[a-z0-9]{1,10}$').hasMatch(extension) ? extension : 'bin';
}

String _safeLeaf(String value) {
  if (value.isEmpty || value == '.' || value == '..') return '';
  if (value.contains('/') || value.contains('\\') || value.contains('..')) {
    return '';
  }
  return value;
}
