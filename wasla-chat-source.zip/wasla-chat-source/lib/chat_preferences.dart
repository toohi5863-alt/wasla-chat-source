import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// Per-account, on-device inbox preferences; never changes server messages.
class ChatListPreferences {
  const ChatListPreferences({
    this.pinned = const <String>{},
    this.favorites = const <String>{},
    this.archived = const <String>{},
    this.muted = const <String>{},
    this.hidden = const <String>{},
    this.deleted = const <String>{},
  });

  final Set<String> pinned;
  final Set<String> favorites;
  final Set<String> archived;
  final Set<String> muted;
  final Set<String> hidden;
  final Set<String> deleted;

  factory ChatListPreferences.fromMap(Map<String, dynamic> map) {
    Set<String> readSet(String key) {
      final value = map[key];
      if (value is! List) return <String>{};
      return value
          .where((item) => item != null && item.toString().isNotEmpty)
          .map((item) => item.toString())
          .toSet();
    }

    return ChatListPreferences(
      pinned: readSet('pinned'),
      favorites: readSet('favorites'),
      archived: readSet('archived'),
      muted: readSet('muted'),
      hidden: readSet('hidden'),
      deleted: readSet('deleted'),
    );
  }

  Map<String, dynamic> toMap() => {
    'pinned': pinned.toList()..sort(),
    'favorites': favorites.toList()..sort(),
    'archived': archived.toList()..sort(),
    'muted': muted.toList()..sort(),
    'hidden': hidden.toList()..sort(),
    'deleted': deleted.toList()..sort(),
  };

  ChatListPreferences copyWith({
    Set<String>? pinned,
    Set<String>? favorites,
    Set<String>? archived,
    Set<String>? muted,
    Set<String>? hidden,
    Set<String>? deleted,
  }) => ChatListPreferences(
    pinned: pinned ?? this.pinned,
    favorites: favorites ?? this.favorites,
    archived: archived ?? this.archived,
    muted: muted ?? this.muted,
    hidden: hidden ?? this.hidden,
    deleted: deleted ?? this.deleted,
  );
}

class ChatListPreferencesStore {
  static const _fileName = 'wasla_chat_preferences.json';

  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}/$_fileName');
  }

  Future<ChatListPreferences> load(String userId) async {
    final file = await _file();
    if (!await file.exists()) return const ChatListPreferences();
    final decoded = jsonDecode(await file.readAsString());
    if (decoded is! Map) return const ChatListPreferences();
    final users = decoded['users'];
    if (users is! Map) return const ChatListPreferences();
    final value = users[userId];
    if (value is! Map) return const ChatListPreferences();
    return ChatListPreferences.fromMap(Map<String, dynamic>.from(value));
  }

  Future<void> save(String userId, ChatListPreferences preferences) async {
    final file = await _file();
    Map<String, dynamic> root = <String, dynamic>{'users': <String, dynamic>{}};
    if (await file.exists()) {
      try {
        final decoded = jsonDecode(await file.readAsString());
        if (decoded is Map) {
          root = Map<String, dynamic>.from(decoded);
        }
      } on FormatException {
        // Preserve normal app operation if an old preferences file is damaged.
      }
    }

    final usersValue = root['users'];
    final users = usersValue is Map
        ? Map<String, dynamic>.from(usersValue)
        : <String, dynamic>{};
    users[userId] = preferences.toMap();
    root['users'] = users;

    final temporary = File('${file.path}.tmp');
    await temporary.writeAsString(jsonEncode(root), flush: true);
    await temporary.rename(file.path);
  }
}
