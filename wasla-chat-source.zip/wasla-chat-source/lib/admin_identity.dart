import 'package:flutter/material.dart';

import 'verification_badges.dart';

/// Stable identity for the single Wasla application administrator.
const String waslaAdminUserId = '92262d97-f604-423e-bac7-8573eafffa65';

/// Returns true only for the configured administrator UUID; usernames are not used.
bool isWaslaAdmin(String? userId) =>
    userId != null && userId.trim().toLowerCase() == waslaAdminUserId;

/// Displays an account name normally, or with a verification badge for the
/// administrator and any server-verified member.
class AdminIdentityText extends StatelessWidget {
  const AdminIdentityText({
    required this.userId,
    required this.label,
    this.style,
    this.maxLines,
    this.overflow,
    this.textAlign,
    this.softWrap,
    super.key,
  });

  final String? userId;
  final String label;
  final TextStyle? style;
  final int? maxLines;
  final TextOverflow? overflow;
  final TextAlign? textAlign;
  final bool? softWrap;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Set<String>>(
    valueListenable: VerifiedMemberBadges.userIds,
    builder: (context, verifiedIds, _) {
      final administrator = isWaslaAdmin(userId);
      final verified =
          administrator ||
          (userId != null && verifiedIds.contains(userId!.trim()));
      if (!verified) {
        return Text(
          label,
          style: style,
          maxLines: maxLines,
          overflow: overflow,
          textAlign: textAlign,
          softWrap: softWrap,
        );
      }

      final dark = Theme.of(context).brightness == Brightness.dark;
      final adminAccent = dark
          ? const Color(0xFF78BDF5)
          : const Color(0xFF1769AA);
      final badgeColor = administrator
          ? adminAccent
          : Theme.of(context).colorScheme.primary;
      final fontSize =
          style?.fontSize ??
          Theme.of(context).textTheme.bodyMedium?.fontSize ??
          14;
      final badgeSize = (fontSize * .94).clamp(12.0, 18.0).toDouble();
      final effectiveStyle = administrator
          ? (style ?? const TextStyle()).copyWith(color: adminAccent)
          : style;
      final badgeLabel = administrator ? 'حساب الإدارة الموثّق' : 'عضو موثّق';

      return Text.rich(
        TextSpan(
          children: [
            TextSpan(text: label, style: effectiveStyle),
            WidgetSpan(
              alignment: PlaceholderAlignment.middle,
              child: Padding(
                padding: const EdgeInsetsDirectional.only(start: 3),
                child: Tooltip(
                  message: badgeLabel,
                  child: Semantics(
                    label: badgeLabel,
                    child: Icon(
                      Icons.verified_rounded,
                      size: badgeSize,
                      color: badgeColor,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        style: effectiveStyle,
        maxLines: maxLines,
        overflow: overflow,
        textAlign: textAlign,
        softWrap: softWrap,
        semanticsLabel: '$label، $badgeLabel',
      );
    },
  );
}

/// Explicit status shown on the signed-in member's own profile page.
class VerifiedAccountStatus extends StatelessWidget {
  const VerifiedAccountStatus({required this.userId, super.key});

  final String? userId;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Set<String>>(
    valueListenable: VerifiedMemberBadges.userIds,
    builder: (context, verifiedIds, _) {
      final id = userId?.trim();
      if (id == null || id.isEmpty || !verifiedIds.contains(id)) {
        return const SizedBox.shrink();
      }
      final label = isWaslaAdmin(id)
          ? 'حساب الإدارة موثّق'
          : 'حسابك موثّق';
      return DecoratedBox(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.verified_rounded,
                size: 17,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 6),
              Text(label),
            ],
          ),
        ),
      );
    },
  );
}
