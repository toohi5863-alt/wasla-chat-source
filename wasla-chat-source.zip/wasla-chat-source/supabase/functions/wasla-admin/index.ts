import { createClient } from 'npm:@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ADMIN_USER_ID = '92262d97-f604-423e-bac7-8573eafffa65';
const ADMIN_USERNAME = 'darwish71';
const APP_ORIGIN = /^https:\/\/(?:\d+-i6k6rayh1ru8avp1qz5f4-74423803\.us2\.manus\.computer|wasla-admin-dashboard-20261011\.(?:shy-eustoma|near-shock|righteous-koi)\.workers\.dev)$/;

const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

function headers(origin: string | null): HeadersInit {
  const out: Record<string, string> = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store, max-age=0',
    'Pragma': 'no-cache',
    'Vary': 'Origin',
  };
  if (origin && APP_ORIGIN.test(origin)) {
    out['Access-Control-Allow-Origin'] = origin;
    out['Access-Control-Allow-Methods'] = 'POST, OPTIONS';
    out['Access-Control-Allow-Headers'] = 'authorization, apikey, content-type, x-client-info';
    out['Access-Control-Max-Age'] = '600';
  }
  return out;
}

function response(data: unknown, origin: string | null, status = 200): Response {
  return new Response(JSON.stringify(data), { status, headers: headers(origin) });
}

function fail(message: string, origin: string | null, status: number): Response {
  return response({ error: message }, origin, status);
}

function cleanSearch(value: unknown): string {
  return String(value ?? '').replace(/[^\p{L}\p{N}_ -]/gu, '').trim().slice(0, 48);
}

function boundedInt(value: unknown, fallback: number, max: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.min(Math.floor(n), max)) : fallback;
}

async function login(body: Record<string, unknown>, origin: string | null): Promise<Response> {
  const username = String(body.username ?? '').trim().toLowerCase();
  const password = String(body.password ?? '');
  if (username !== ADMIN_USERNAME || password.length < 1 || password.length > 256) {
    return fail('اسم المستخدم أو كلمة المرور غير صحيحة.', origin, 401);
  }
  const { data: profile, error: profileError } = await admin
    .from('profiles').select('id,username,display_name').eq('id', ADMIN_USER_ID)
    .eq('username', ADMIN_USERNAME).maybeSingle();
  if (profileError || !profile) return fail('تعذر التحقق من حساب الإدارة.', origin, 401);
  const { data: userData, error: userError } = await admin.auth.admin.getUserById(ADMIN_USER_ID);
  const email = userData?.user?.email;
  if (userError || !email) return fail('تعذر التحقق من بيانات الدخول.', origin, 401);

  // The password is sent only over HTTPS to Supabase Auth and is never logged or stored here.
  const authResponse = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  if (!authResponse.ok) return fail('اسم المستخدم أو كلمة المرور غير صحيحة.', origin, 401);
  const session = await authResponse.json();
  if (session?.user?.id !== ADMIN_USER_ID || !session?.access_token || !session?.refresh_token) {
    return fail('هذا الحساب غير مخوّل للوحة الإدارة.', origin, 403);
  }
  return response({
    access_token: session.access_token,
    refresh_token: session.refresh_token,
    expires_in: session.expires_in,
    token_type: session.token_type,
    user: { id: profile.id, username: profile.username, display_name: profile.display_name },
  }, origin);
}

async function readPublicSettings(origin: string | null): Promise<Response> {
  const { data, error } = await admin.from('wasla_app_settings')
    .select('announcement_enabled,announcement_text,signups_enabled,group_creation_enabled,public_discovery_enabled,messages_enabled,media_uploads_enabled,max_media_upload_mb')
    .eq('id', 1).maybeSingle();
  if (error || !data) return fail('تعذر تحميل إعدادات التشغيل.', origin, 503);
  return response(data, origin);
}

async function requireAdmin(req: Request, origin: string | null) {
  const bearer = req.headers.get('Authorization') ?? '';
  const token = bearer.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return { error: fail('يلزم تسجيل الدخول.', origin, 401) };
  const userClient = createClient(SUPABASE_URL, ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data: authData, error: authError } = await userClient.auth.getUser(token);
  if (authError || authData.user?.id !== ADMIN_USER_ID) {
    return { error: fail('الحساب غير مخوّل للوصول إلى الإدارة.', origin, 403) };
  }
  const { data: profile, error: profileError } = await admin.from('profiles')
    .select('id,username,display_name').eq('id', ADMIN_USER_ID)
    .eq('username', ADMIN_USERNAME).maybeSingle();
  if (profileError || !profile) return { error: fail('تعذر التحقق من صلاحية الإدارة.', origin, 403) };
  return { profile };
}

async function overview(origin: string | null): Promise<Response> {
  const [users, groups, reports, conversations, messages] = await Promise.all([
    admin.from('profiles').select('id', { count: 'exact', head: true }),
    admin.from('groups').select('conversation_id', { count: 'exact', head: true }),
    admin.from('public_content_reports').select('id', { count: 'exact', head: true }).eq('status', 'open'),
    admin.from('conversations').select('id', { count: 'exact', head: true }),
    admin.from('messages').select('id', { count: 'exact', head: true }),
  ]);
  const errors = [users, groups, reports, conversations, messages].filter((r) => r.error);
  if (errors.length) return fail('تعذر تحميل ملخص الإدارة.', origin, 500);
  return response({
    users: users.count ?? 0,
    groups: groups.count ?? 0,
    open_reports: reports.count ?? 0,
    conversations: conversations.count ?? 0,
    messages: messages.count ?? 0,
  }, origin);
}

async function listUsers(body: Record<string, unknown>, origin: string | null): Promise<Response> {
  const q = cleanSearch(body.q);
  const limit = Math.max(1, Math.min(boundedInt(body.limit, 20, 50), 50));
  const offset = boundedInt(body.offset, 0, 100000);
  let query = admin.from('profiles')
    .select('id,username,display_name,bio,created_at,last_seen_at,is_verified', { count: 'exact' })
    .order('created_at', { ascending: false }).range(offset, offset + limit - 1);
  if (q) query = query.or(`username.ilike.%${q}%,display_name.ilike.%${q}%`);
  const { data, error, count } = await query;
  if (error) return fail('تعذر تحميل المستخدمين.', origin, 500);
  const { data: authUsers } = await admin.auth.admin.listUsers({ page: 1, perPage: 1000 });
  const authById = new Map((authUsers?.users ?? []).map((u) => [u.id, u]));
  const items = (data ?? []).map((p) => {
    const u = authById.get(p.id);
    return {
      id: p.id, username: p.username, display_name: p.display_name, bio: p.bio,
      is_verified: p.is_verified === true,
      created_at: p.created_at, last_seen_at: p.last_seen_at,
      suspended: Boolean(u?.banned_until && new Date(u.banned_until).getTime() > Date.now()),
      banned_until: u?.banned_until ?? null,
    };
  });
  return response({ items, total: count ?? 0, offset, limit }, origin);
}

async function listGroups(body: Record<string, unknown>, origin: string | null): Promise<Response> {
  const q = cleanSearch(body.q);
  const limit = Math.max(1, Math.min(boundedInt(body.limit, 20, 50), 50));
  const offset = boundedInt(body.offset, 0, 100000);
  let query = admin.from('groups').select(
    'conversation_id,name,description,owner_id,is_private,is_discoverable,listing_type,category,created_at,owner:profiles!groups_owner_id_fkey(username,display_name)',
    { count: 'exact' },
  ).order('created_at', { ascending: false }).range(offset, offset + limit - 1);
  if (q) query = query.ilike('name', `%${q}%`);
  const { data, error, count } = await query;
  if (error) return fail('تعذر تحميل المجموعات.', origin, 500);
  return response({ items: data ?? [], total: count ?? 0, offset, limit }, origin);
}

async function listReports(body: Record<string, unknown>, origin: string | null): Promise<Response> {
  const q = String(body.status ?? 'open');
  const status = ['open', 'actioned', 'dismissed', 'all'].includes(q) ? q : 'open';
  const limit = Math.max(1, Math.min(boundedInt(body.limit, 20, 50), 50));
  const offset = boundedInt(body.offset, 0, 100000);
  let query = admin.from('public_content_reports').select(
    'id,reporter_id,conversation_id,target_user_id,report_type,reason,details,status,created_at,reviewed_at',
    { count: 'exact' },
  ).order('created_at', { ascending: false }).range(offset, offset + limit - 1);
  if (status !== 'all') query = query.eq('status', status);
  const { data, error, count } = await query;
  if (error) return fail('تعذر تحميل البلاغات.', origin, 500);
  const reports = data ?? [];
  const profileIds = [...new Set(reports.flatMap((r) => [r.reporter_id, r.target_user_id].filter(Boolean)))];
  const groupIds = [...new Set(reports.map((r) => r.conversation_id))];
  const [profiles, groups] = await Promise.all([
    profileIds.length ? admin.from('profiles').select('id,username,display_name').in('id', profileIds) : Promise.resolve({ data: [], error: null }),
    groupIds.length ? admin.from('groups').select('conversation_id,name').in('conversation_id', groupIds) : Promise.resolve({ data: [], error: null }),
  ]);
  const pMap = new Map((profiles.data ?? []).map((p) => [p.id, p]));
  const gMap = new Map((groups.data ?? []).map((g) => [g.conversation_id, g]));
  const items = reports.map((r) => ({
    ...r,
    reporter: pMap.get(r.reporter_id) ?? null,
    target: r.target_user_id ? pMap.get(r.target_user_id) ?? null : null,
    group: gMap.get(r.conversation_id) ?? null,
  }));
  return response({ items, total: count ?? 0, offset, limit, status }, origin);
}

async function settings(origin: string | null): Promise<Response> {
  const { data, error } = await admin.from('wasla_app_settings').select(
    'announcement_enabled,announcement_text,signups_enabled,group_creation_enabled,public_discovery_enabled,messages_enabled,media_uploads_enabled,max_media_upload_mb,updated_at',
  ).eq('id', 1).maybeSingle();
  if (error || !data) return fail('تعذر تحميل الإعدادات.', origin, 500);
  return response(data, origin);
}

async function dispatchVerificationNotification(userId: string, wasVerified: boolean) {
  const secret = Deno.env.get('PUSH_EVENT_WEBHOOK_SECRET') ?? '';
  if (!secret) return { status: 'not_configured', sent: 0 };
  try {
    const pushResponse = await fetch(`${SUPABASE_URL}/functions/v1/send-message-push`, {
      method: 'POST',
      headers: {
        apikey: ANON_KEY,
        'Content-Type': 'application/json',
        'x-wasla-webhook-secret': secret,
      },
      body: JSON.stringify({
        schema: 'public',
        table: 'profiles',
        type: 'UPDATE',
        record: { id: userId, is_verified: true },
        old_record: { id: userId, is_verified: wasVerified },
      }),
    });
    if (!pushResponse.ok) return { status: 'delivery_failed', sent: 0 };
    const result = await pushResponse.json();
    const sent = Number.isFinite(Number(result?.sent)) ? Number(result.sent) : 0;
    return {
      status: sent > 0 ? 'sent' : 'no_device_or_delivery_failed',
      sent,
    };
  } catch (_) {
    return { status: 'delivery_failed', sent: 0 };
  }
}

async function performAction(body: Record<string, unknown>, origin: string | null, profile: { id: string; display_name: string }) {
  const action = String(body.action ?? '');
  switch (action) {
    case 'identity':
      return response({ id: profile.id, username: ADMIN_USERNAME, display_name: profile.display_name }, origin);
    case 'overview': return await overview(origin);
    case 'users': return await listUsers(body, origin);
    case 'groups': return await listGroups(body, origin);
    case 'reports': return await listReports(body, origin);
    case 'settings': return await settings(origin);
    case 'resolve_report': {
      const reportId = String(body.report_id ?? '');
      const status = String(body.status ?? '');
      if (!/^[0-9a-f-]{36}$/i.test(reportId) || !['actioned', 'dismissed'].includes(status)) {
        return fail('بيانات معالجة البلاغ غير صالحة.', origin, 400);
      }
      const { data, error } = await admin.from('public_content_reports').update({
        status, reviewed_at: new Date().toISOString(), reviewed_by: profile.id,
      }).eq('id', reportId).select('id,status').maybeSingle();
      if (error || !data) return fail('تعذر تحديث البلاغ.', origin, 500);
      return response({ ok: true, report: data }, origin);
    }
    case 'user_suspend':
    case 'user_activate': {
      const userId = String(body.user_id ?? '');
      if (!/^[0-9a-f-]{36}$/i.test(userId)) return fail('معرّف الحساب غير صالح.', origin, 400);
      if (userId === ADMIN_USER_ID) return fail('لا يمكن تعليق حساب الإدارة نفسه.', origin, 400);
      const { data: target } = await admin.from('profiles').select('id').eq('id', userId).maybeSingle();
      if (!target) return fail('المستخدم غير موجود.', origin, 404);
      const ban_duration = action === 'user_suspend' ? '8760h' : 'none';
      const { error } = await admin.auth.admin.updateUserById(userId, { ban_duration });
      if (error) return fail('تعذر تحديث حالة الحساب.', origin, 500);
      return response({ ok: true, suspended: action === 'user_suspend' }, origin);
    }
    case 'user_verification': {
      const userId = String(body.user_id ?? '');
      const verified = body.is_verified;
      if (!/^[0-9a-f-]{36}$/i.test(userId) || typeof verified !== 'boolean') {
        return fail('بيانات شارة التحقق غير صالحة.', origin, 400);
      }
      if (userId === ADMIN_USER_ID) {
        return fail('شارة حساب الإدارة محفوظة ولا تُدار من قائمة الأعضاء.', origin, 400);
      }
      const { data: target, error: targetError } = await admin.from('profiles')
        .select('id,is_verified').eq('id', userId).maybeSingle();
      if (targetError) return fail('تعذر التحقق من العضو.', origin, 500);
      if (!target) return fail('المستخدم غير موجود.', origin, 404);
      const { data, error } = await admin.from('profiles')
        .update({ is_verified: verified }).eq('id', userId)
        .select('id,is_verified').maybeSingle();
      if (error || !data) return fail('تعذر تحديث شارة التحقق.', origin, 500);
      const verificationNotification = verified && target.is_verified !== true
        ? await dispatchVerificationNotification(data.id, target.is_verified === true)
        : { status: 'not_applicable', sent: 0 };
      return response({
        ok: true,
        user_id: data.id,
        is_verified: data.is_verified,
        notification_status: verificationNotification.status,
        notification_devices_sent: verificationNotification.sent,
      }, origin);
    }
    case 'update_group': {
      const id = String(body.conversation_id ?? '');
      const name = String(body.name ?? '').trim();
      const description = String(body.description ?? '').trim();
      if (!/^[0-9a-f-]{36}$/i.test(id) || name.length < 2 || name.length > 80 || description.length > 500) {
        return fail('بيانات المجموعة غير صالحة.', origin, 400);
      }
      const is_private = body.is_private === true;
      const is_discoverable = !is_private && body.is_discoverable === true;
      const payload = {
        name, description, is_private, is_discoverable,
        members_can_message: Boolean(body.members_can_message),
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await admin.from('groups').update(payload)
        .eq('conversation_id', id)
        .select('conversation_id,name,description,is_private,is_discoverable,members_can_message')
        .maybeSingle();
      if (error || !data) return fail('تعذر حفظ تغييرات المجموعة.', origin, 500);
      return response({ ok: true, group: data }, origin);
    }
    case 'update_settings': {
      const announcement_text = String(body.announcement_text ?? '').trim();
      if (announcement_text.length > 300) return fail('نص الإعلان أطول من الحد المسموح.', origin, 400);
      const { data: current, error: currentError } = await admin.from('wasla_app_settings')
        .select('messages_enabled,media_uploads_enabled,max_media_upload_mb').eq('id', 1).maybeSingle();
      if (currentError || !current) return fail('تعذر تحميل إعدادات الرسائل والوسائط الحالية.', origin, 500);
      const messages_enabled = typeof body.messages_enabled === 'boolean'
        ? body.messages_enabled : current.messages_enabled === true;
      const media_uploads_enabled = typeof body.media_uploads_enabled === 'boolean'
        ? body.media_uploads_enabled : current.media_uploads_enabled === true;
      const max_media_upload_mb = body.max_media_upload_mb === undefined
        ? Number(current.max_media_upload_mb) : Number(body.max_media_upload_mb);
      if (!Number.isInteger(max_media_upload_mb) || max_media_upload_mb < 1 || max_media_upload_mb > 15) {
        return fail('حد حجم المرفق يجب أن يكون عددًا صحيحًا بين 1 و15 م.ب.', origin, 400);
      }
      const payload = {
        announcement_enabled: body.announcement_enabled === true,
        announcement_text,
        signups_enabled: body.signups_enabled === true,
        group_creation_enabled: body.group_creation_enabled === true,
        public_discovery_enabled: body.public_discovery_enabled === true,
        messages_enabled,
        media_uploads_enabled,
        max_media_upload_mb,
        updated_at: new Date().toISOString(),
        updated_by: profile.id,
      };
      const { data, error } = await admin.from('wasla_app_settings').update(payload)
        .eq('id', 1).select('announcement_enabled,announcement_text,signups_enabled,group_creation_enabled,public_discovery_enabled,messages_enabled,media_uploads_enabled,max_media_upload_mb,updated_at').single();
      if (error) return fail('تعذر حفظ إعدادات التطبيق.', origin, 500);
      return response({ ok: true, settings: data }, origin);
    }
    default: return fail('العملية غير معروفة.', origin, 400);
  }
}

Deno.serve(async (req: Request) => {
  const origin = req.headers.get('Origin');
  if (origin && !APP_ORIGIN.test(origin)) return fail('مصدر الطلب غير مسموح.', null, 403);
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: headers(origin) });
  if (req.method !== 'POST') return fail('طريقة الطلب غير مسموحة.', origin, 405);

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return fail('صيغة الطلب غير صالحة.', origin, 400); }
  const action = String(body.action ?? '');
  try {
    if (action === 'login') return await login(body, origin);
    if (action === 'public_settings') return await readPublicSettings(origin);
    const checked = await requireAdmin(req, origin);
    if (checked.error) return checked.error;
    return await performAction(body, origin, checked.profile!);
  } catch (_error) {
    return fail('تعذر إتمام الطلب. حاول مرة أخرى.', origin, 500);
  }
});
