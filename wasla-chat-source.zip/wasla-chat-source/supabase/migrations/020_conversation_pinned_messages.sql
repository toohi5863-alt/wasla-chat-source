-- Wasla: shared conversation pins retain metadata only (conversation/message IDs).
-- This migration never copies message text, media paths, or attachments.

create table if not exists public.conversation_pinned_messages (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  pinned_by uuid not null references public.profiles(id),
  pinned_at timestamptz not null default now(),
  primary key (conversation_id, message_id)
);

create index if not exists conversation_pins_recent_idx
  on public.conversation_pinned_messages (conversation_id, pinned_at desc);

alter table public.conversation_pinned_messages enable row level security;
drop policy if exists conversation_pins_select_member
  on public.conversation_pinned_messages;
create policy conversation_pins_select_member
  on public.conversation_pinned_messages
  for select to authenticated
  using (private.is_conversation_member(conversation_id));

revoke all on public.conversation_pinned_messages from public, anon, authenticated;
grant select on public.conversation_pinned_messages to authenticated;

-- Preserve pins created by versions that used the group-only table.
insert into public.conversation_pinned_messages
  (conversation_id, message_id, pinned_by, pinned_at)
select gp.conversation_id, gp.message_id, gp.pinned_by, gp.pinned_at
from public.group_pinned_messages gp
join public.messages m
  on m.id = gp.message_id and m.conversation_id = gp.conversation_id
on conflict (conversation_id, message_id) do nothing;

create or replace function public.set_conversation_message_pinned(
  p_conversation_id uuid,
  p_message_id uuid,
  p_pinned boolean
)
returns void
language plpgsql
volatile
security definer
set search_path = public, private, pg_temp
as $$
declare
  v_actor uuid := auth.uid();
  v_is_group boolean;
begin
  if v_actor is null then
    raise exception 'Authentication required';
  end if;
  if p_pinned is null then
    raise exception 'Pin state is required';
  end if;
  if not private.is_conversation_member(p_conversation_id) then
    raise exception 'Not a conversation member';
  end if;

  select exists (
    select 1 from public.groups g where g.conversation_id = p_conversation_id
  ) into v_is_group;

  if v_is_group and not private.can_pin_group_messages(p_conversation_id) then
    raise exception 'Only authorized group admins can pin messages';
  end if;
  if not exists (
    select 1 from public.messages m
    where m.id = p_message_id and m.conversation_id = p_conversation_id
  ) then
    raise exception 'Message does not belong to this conversation';
  end if;

  if p_pinned then
    insert into public.conversation_pinned_messages
      (conversation_id, message_id, pinned_by)
    values (p_conversation_id, p_message_id, v_actor)
    on conflict (conversation_id, message_id) do nothing;

    -- Keep the legacy group pin relation in sync for older clients.
    if v_is_group then
      insert into public.group_pinned_messages
        (conversation_id, message_id, pinned_by)
      values (p_conversation_id, p_message_id, v_actor)
      on conflict (conversation_id, message_id) do nothing;
      insert into public.group_activity (conversation_id, actor_id, action, details)
      values (
        p_conversation_id, v_actor, 'message_pinned',
        jsonb_build_object('message_id', p_message_id)
      );
    end if;
  else
    delete from public.conversation_pinned_messages
    where conversation_id = p_conversation_id and message_id = p_message_id;

    if v_is_group then
      delete from public.group_pinned_messages
      where conversation_id = p_conversation_id and message_id = p_message_id;
      insert into public.group_activity (conversation_id, actor_id, action, details)
      values (
        p_conversation_id, v_actor, 'message_unpinned',
        jsonb_build_object('message_id', p_message_id)
      );
    end if;
  end if;
end;
$$;
revoke all on function public.set_conversation_message_pinned(uuid, uuid, boolean)
  from public, anon;
grant execute on function public.set_conversation_message_pinned(uuid, uuid, boolean)
  to authenticated;

-- Keep legacy clients and the new unified pin table in sync through the old RPC.
create or replace function public.set_group_message_pinned(
  p_conversation_id uuid,
  p_message_id uuid,
  p_pinned boolean
)
returns void
language plpgsql
volatile
security definer
set search_path = public, private, pg_temp
as $$
begin
  perform public.set_conversation_message_pinned(
    p_conversation_id, p_message_id, p_pinned
  );
end;
$$;
revoke all on function public.set_group_message_pinned(uuid, uuid, boolean)
  from public, anon;
grant execute on function public.set_group_message_pinned(uuid, uuid, boolean)
  to authenticated;

do $$
begin
  if exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'conversation_pinned_messages'
  ) then
    null;
  else
    alter publication supabase_realtime
      add table public.conversation_pinned_messages;
  end if;
exception when undefined_object then
  raise notice 'Realtime publication unavailable; enable conversation_pinned_messages in Supabase.';
end;
$$;
