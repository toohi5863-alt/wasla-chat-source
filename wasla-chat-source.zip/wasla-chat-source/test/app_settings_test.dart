import 'dart:io';

import 'package:chat/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const pathProviderChannel = MethodChannel('plugins.flutter.io/path_provider');
  late Directory temporaryDirectory;

  setUp(() async {
    temporaryDirectory = await Directory.systemTemp.createTemp(
      'wasla-app-settings-test-',
    );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(pathProviderChannel, (call) async {
          if (call.method == 'getApplicationSupportDirectory') {
            return temporaryDirectory.path;
          }
          return null;
        });
  });

  tearDown(() async {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(pathProviderChannel, null);
    if (await temporaryDirectory.exists()) {
      await temporaryDirectory.delete(recursive: true);
    }
  });

  group('AppSettings', () {
    test('round-trips each supported theme mode', () {
      for (final mode in ThemeMode.values) {
        expect(
          AppSettings.fromMap(AppSettings(themeMode: mode).toMap()).themeMode,
          mode,
        );
      }
    });

    test('round-trips the selected theme and saved custom themes', () {
      const custom = AppThemeOption(
        id: 'custom_test',
        name: 'سماء',
        seedColor: 0xFF1769AA,
      );
      final settings = AppSettings(
        themeMode: ThemeMode.dark,
        themeId: custom.id,
        customThemes: const [custom],
      );
      final restored = AppSettings.fromMap(settings.toMap());
      expect(restored.themeMode, ThemeMode.dark);
      expect(restored.themeId, custom.id);
      expect(restored.customThemes.single.toMap(), custom.toMap());
      final selected = appThemeById(restored.themeId, restored.customThemes);
      expect(selected.id, custom.id);
      expect(selected.seedColor, custom.seedColor);
    });

    test('round-trips text size and reduced motion preferences', () {
      for (final size in AppTextSize.values) {
        final settings = AppSettings(
          textSize: size,
          reduceMotion: true,
          highContrast: true,
          compactLayout: true,
        );
        final restored = AppSettings.fromMap(settings.toMap());
        expect(restored.textSize, size);
        expect(restored.reduceMotion, isTrue);
        expect(restored.highContrast, isTrue);
        expect(restored.compactLayout, isTrue);
      }
    });

    test('round-trips each message bubble style and defaults safely', () {
      for (final style in MessageBubbleStyle.values) {
        expect(
          AppSettings.fromMap(AppSettings(bubbleStyle: style).toMap())
              .bubbleStyle,
          style,
        );
      }
      expect(AppSettings.fromMap({}).bubbleStyle, MessageBubbleStyle.classic);
      expect(
        AppSettings.fromMap({'bubble_style': 'unknown'}).bubbleStyle,
        MessageBubbleStyle.classic,
      );
    });

    test('defaults chat status highlights to visible and can hide them', () {
      const defaults = AppSettings();
      expect(defaults.showChatStatusHighlights, isTrue);
      expect(
        AppSettings.fromMap(defaults.toMap()).showChatStatusHighlights,
        isTrue,
      );
      expect(AppSettings.fromMap({}).showChatStatusHighlights, isTrue);
      expect(
        defaults
            .copyWith(showChatStatusHighlights: false)
            .showChatStatusHighlights,
        isFalse,
      );
    });

    test(
      'persists chat status visibility separately for each account',
      () async {
        final store = AppSettingsStore();
        await store.save(
          'account-a',
          const AppSettings(
            showChatStatusHighlights: false,
            bubbleStyle: MessageBubbleStyle.rounded,
          ),
        );

        final restartedStore = AppSettingsStore();
        expect(
          (await restartedStore.load('account-a')).showChatStatusHighlights,
          isFalse,
        );
        expect(
          (await restartedStore.load('account-a')).bubbleStyle,
          MessageBubbleStyle.rounded,
        );
        expect(
          (await restartedStore.load('account-b')).showChatStatusHighlights,
          isTrue,
        );
        expect(
          (await restartedStore.load('account-b')).bubbleStyle,
          MessageBubbleStyle.classic,
        );
      },
    );

    test('falls back to system mode for unknown settings', () {
      expect(
        AppSettings.fromMap({'theme_mode': 'sepia'}).themeMode,
        ThemeMode.system,
      );
      expect(const AppSettings().toMap(), {
        'theme_mode': 'system',
        'theme_id': 'wasla',
        'custom_themes': <Map<String, dynamic>>[],
        'text_size': 'standard',
        'bubble_style': 'classic',
        'reduce_motion': false,
        'high_contrast': false,
        'compact_layout': false,
        'show_chat_status_highlights': true,
      });
    });
  });
}
