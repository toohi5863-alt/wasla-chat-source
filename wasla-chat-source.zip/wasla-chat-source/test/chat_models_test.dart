import 'package:flutter_test/flutter_test.dart';
import 'package:chat/chat_models.dart';

void main() {
  test('parses audio message metadata and read receipt', () {
    final message = ChatMessage.fromMap({
      'id': 'm-1',
      'sender_id': 'u-1',
      'content': 'رسالة صوتية',
      'message_type': 'audio',
      'media_path': 'c-1/u-1/voice.m4a',
      'media_duration_seconds': 17,
      'created_at': '2026-10-07T10:00:00Z',
      'delivered_at': '2026-10-07T10:00:01Z',
      'read_at': '2026-10-07T10:00:03Z',
    });

    expect(message.messageType, 'audio');
    expect(message.mediaPath, 'c-1/u-1/voice.m4a');
    expect(message.mediaDurationSeconds, 17);
    expect(message.deliveredAt, DateTime.parse('2026-10-07T10:00:01Z'));
    expect(message.readAt, DateTime.parse('2026-10-07T10:00:03Z'));
  });

  test('parses inbox avatar, media preview, and receipt status', () {
    final preview = ChatPreview.fromMap({
      'conversation_id': 'c-1',
      'other_user_id': 'u-2',
      'username': 'friend',
      'display_name': 'صديق',
      'avatar_path': 'u-2/avatar.jpg',
      'last_message': 'صورة',
      'last_message_type': 'image',
      'last_message_at': '2026-10-07T10:00:00Z',
      'last_message_sender_id': 'u-1',
      'last_message_delivered_at': '2026-10-07T10:00:01Z',
      'last_message_read_at': null,
    });

    expect(preview.avatarPath, 'u-2/avatar.jpg');
    expect(preview.lastMessageType, 'image');
    expect(preview.lastMessageSenderId, 'u-1');
    expect(preview.lastMessageDeliveredAt, isNotNull);
    expect(preview.lastMessageReadAt, isNull);
  });

  test('restores a chat preview from its local JSON map', () {
    final timestamp = DateTime.utc(2026, 10, 8, 9, 30);
    final preview = ChatPreview(
      conversationId: 'conversation-1',
      otherUserId: 'user-2',
      username: 'friend',
      displayName: 'صديق',
      avatarPath: 'avatars/friend.jpg',
      lastMessage: 'أراك لاحقًا',
      lastMessageAt: timestamp,
      lastMessageSenderId: 'user-1',
    );

    final restored = ChatPreview.fromMap(preview.toMap());

    expect(restored.conversationId, preview.conversationId);
    expect(restored.otherUserId, preview.otherUserId);
    expect(restored.displayName, preview.displayName);
    expect(restored.lastMessage, preview.lastMessage);
    expect(restored.lastMessageAt, timestamp);
  });

  test('restores message text and local media references', () {
    final message = ChatMessage(
      id: 'message-1',
      senderId: 'user-1',
      content: 'صورة',
      createdAt: DateTime.utc(2026, 10, 8, 9, 30),
      messageType: 'image',
      mediaPath: 'conversation-1/user-1/image.jpg',
      mediaDurationSeconds: 8,
      deliveredAt: DateTime.utc(2026, 10, 8, 9, 31),
      replyTo: 'message-0',
      editedAt: DateTime.utc(2026, 10, 8, 9, 32),
    );

    final restored = ChatMessage.fromMap(message.toMap());

    expect(restored.id, message.id);
    expect(restored.senderId, message.senderId);
    expect(restored.content, message.content);
    expect(restored.createdAt, message.createdAt);
    expect(restored.messageType, 'image');
    expect(restored.mediaPath, message.mediaPath);
    expect(restored.mediaDurationSeconds, 8);
    expect(restored.deliveredAt, message.deliveredAt);
    expect(restored.replyTo, message.replyTo);
    expect(restored.editedAt, message.editedAt);
  });

  test('round-trips ephemeral delivery and local-payload markers', () {
    final deletedAt = DateTime.utc(2026, 10, 9, 11);
    final message = ChatMessage.fromMap({
      'id': 'ephemeral-1',
      'sender_id': 'user-1',
      'content': 'محتوى محلي',
      'message_type': 'text',
      'created_at': '2026-10-09T10:00:00Z',
      'ephemeral': true,
      'payload_deleted_at': deletedAt.toIso8601String(),
      'has_local_payload': true,
    });

    final restored = ChatMessage.fromMap(message.toMap());

    expect(restored.isEphemeral, isTrue);
    expect(restored.payloadDeletedAt, deletedAt);
    expect(restored.hasLocalPayload, isTrue);
  });
}
