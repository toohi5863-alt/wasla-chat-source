import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app_settings.dart';
import 'admin_identity.dart';
import 'friendship_models.dart';
import 'presence.dart';
import 'presence_status.dart';

class FriendsSection extends StatefulWidget {
  const FriendsSection({
    required this.friends,
    required this.friendsLoading,
    required this.friendsError,
    required this.onRefreshFriends,
    required this.onOpenFriend,
    required this.onRemoveFriend,
    required this.onSearchUsers,
    required this.onNearbyFriends,
    required this.onFriendRequests,
    required this.pendingFriendRequests,
    required this.onShowQr,
    required this.onInvite,
    required this.onOpenSettings,
    super.key,
  });

  final List<Friend> friends;
  final bool friendsLoading;
  final String? friendsError;
  final VoidCallback onRefreshFriends;
  final ValueChanged<Friend> onOpenFriend;
  final ValueChanged<Friend> onRemoveFriend;
  final VoidCallback onSearchUsers;
  final VoidCallback onNearbyFriends;
  final VoidCallback onFriendRequests;
  final int pendingFriendRequests;
  final VoidCallback onShowQr;
  final VoidCallback onInvite;
  final VoidCallback onOpenSettings;

  @override
  State<FriendsSection> createState() => _FriendsSectionState();
}

class _FriendsSectionState extends State<FriendsSection> {
  late final TextEditingController _searchController;
  late final FocusNode _searchFocusNode;
  String _query = '';
  bool _searchFocused = false;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _searchFocusNode = FocusNode()..addListener(_handleSearchFocusChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode
      ..removeListener(_handleSearchFocusChanged)
      ..dispose();
    super.dispose();
  }

  void _handleSearchFocusChanged() {
    if (_searchFocused != _searchFocusNode.hasFocus) {
      setState(() => _searchFocused = _searchFocusNode.hasFocus);
    }
  }

  List<Friend> get _visibleFriends {
    final query = _query.trim().toLowerCase();
    if (query.isEmpty) return widget.friends;
    return widget.friends.where((friend) {
      return friend.displayName.toLowerCase().contains(query) ||
          friend.username.toLowerCase().contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final visibleFriends = _visibleFriends;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        bottom: false,
        child: ColoredBox(
          color: colors.surface,
          child: ListView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: const EdgeInsetsDirectional.fromSTEB(20, 14, 20, 110),
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'إدارة الأصدقاء',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: colors.onSurface,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'الإعدادات',
                    onPressed: widget.onOpenSettings,
                    style: IconButton.styleFrom(
                      fixedSize: const Size(40, 40),
                      backgroundColor: colors.surfaceContainerHighest,
                      foregroundColor: colors.onSurfaceVariant,
                    ),
                    icon: const Icon(Icons.settings_outlined, size: 21),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                decoration: BoxDecoration(
                  color: _searchFocused
                      ? colors.surface
                      : colors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: _searchFocused
                        ? const Color(0xFF008F6B)
                        : Colors.transparent,
                    width: 1.4,
                  ),
                ),
                child: TextField(
                  controller: _searchController,
                  focusNode: _searchFocusNode,
                  textInputAction: TextInputAction.search,
                  onChanged: (value) => setState(() => _query = value),
                  decoration: InputDecoration(
                    hintText: 'ابحث عن صديق بالاسم أو اسم المستخدم...',
                    hintStyle: TextStyle(
                      color: colors.onSurfaceVariant.withValues(alpha: .82),
                      fontSize: 13,
                    ),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      color: colors.onSurfaceVariant,
                      size: 21,
                    ),
                    suffixIcon: _query.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'مسح البحث',
                            onPressed: () {
                              _searchController.clear();
                              setState(() => _query = '');
                            },
                            icon: const Icon(Icons.close_rounded, size: 19),
                          ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 15),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Text(
                'اختصارات سريعة',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: colors.onSurface,
                ),
              ),
              const SizedBox(height: 10),
              GridView.count(
                crossAxisCount: 4,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 9,
                mainAxisSpacing: 9,
                childAspectRatio: .82,
                children: [
                  _FriendQuickAction(
                    icon: Icons.person_add_alt_1_rounded,
                    label: 'إضافة صديق',
                    onTap: widget.onSearchUsers,
                  ),
                  _FriendQuickAction(
                    icon: Icons.group_add_rounded,
                    label: 'الطلبات',
                    badgeCount: widget.pendingFriendRequests,
                    onTap: widget.onFriendRequests,
                  ),
                  _FriendQuickAction(
                    icon: Icons.qr_code_2_rounded,
                    label: 'رمز QR',
                    onTap: widget.onShowQr,
                  ),
                  _FriendQuickAction(
                    icon: Icons.ios_share_rounded,
                    label: 'دعوة',
                    onTap: widget.onInvite,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Material(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(15),
                child: InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: widget.onNearbyFriends,
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(
                      13,
                      11,
                      11,
                      11,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: colors.surface,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.near_me_rounded,
                            color: colors.primary,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 11),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'اكتشف أصدقاء بالقرب منك',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: colors.onPrimaryContainer,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'تعرّف على أشخاص جدد في محيطك',
                                style: theme.textTheme.bodySmall?.copyWith(
                                  fontSize: 11,
                                  color: colors.onPrimaryContainer.withValues(
                                    alpha: .78,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.chevron_left_rounded, color: colors.primary),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'الأصدقاء (${widget.friends.length})',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'تحديث الأصدقاء',
                    onPressed: widget.onRefreshFriends,
                    icon: const Icon(Icons.sync_rounded),
                    visualDensity: VisualDensity.compact,
                    color: colors.onSurfaceVariant,
                  ),
                ],
              ),
              if (widget.friendsLoading)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 26),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (widget.friendsError != null)
                _FriendsMessageCard(
                  icon: Icons.cloud_off_rounded,
                  title: 'تعذّر تحميل الأصدقاء',
                  message: widget.friendsError!,
                  actionLabel: 'إعادة المحاولة',
                  onAction: widget.onRefreshFriends,
                )
              else if (widget.friends.isEmpty)
                _FriendsMessageCard(
                  icon: Icons.people_outline_rounded,
                  title: 'لا يوجد أصدقاء بعد',
                  message: 'ابدأ بإضافة أصدقاء لتجدهم هنا وتبدأ محادثة معهم.',
                  actionLabel: 'البحث عن أصدقاء',
                  onAction: widget.onSearchUsers,
                )
              else if (visibleFriends.isEmpty)
                _FriendsMessageCard(
                  icon: Icons.person_search_rounded,
                  title: 'لم نعثر على صديق بهذا الاسم',
                  message: 'جرّب اسمًا أو اسم مستخدم مختلفًا.',
                  actionLabel: 'مسح البحث',
                  onAction: () {
                    _searchController.clear();
                    setState(() => _query = '');
                  },
                )
              else
                ...visibleFriends.map(
                  (friend) => _FriendTile(
                    friend: friend,
                    onTap: () => widget.onOpenFriend(friend),
                    onRemove: () => widget.onRemoveFriend(friend),
                  ),
                ),
              const SizedBox(height: 16),
              const _InlineCapabilityNote(
                icon: Icons.info_outline_rounded,
                text: 'تُعرض الحسابات من دليل مستخدمي وصال؛ مزامنة دفتر عناوين الهاتف غير مفعّلة.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FriendQuickAction extends StatelessWidget {
  const _FriendQuickAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.badgeCount = 0,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final int badgeCount;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: colors.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        hoverColor: colors.primary.withValues(alpha: .1),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: colors.outlineVariant.withValues(alpha: .45),
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 9),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 37,
                    height: 37,
                    decoration: BoxDecoration(
                      color: colors.primaryContainer,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(icon, color: colors.primary, size: 20),
                  ),
                  if (badgeCount > 0)
                    PositionedDirectional(
                      top: -5,
                      end: -7,
                      child: Container(
                        constraints: const BoxConstraints(minWidth: 17),
                        height: 17,
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: colors.error,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: Colors.white, width: 1.5),
                        ),
                        child: Text(
                          badgeCount > 99 ? '99+' : '$badgeCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 7),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: colors.onSurface,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FriendsMessageCard extends StatelessWidget {
  const _FriendsMessageCard({
    required this.icon,
    required this.title,
    required this.message,
    required this.actionLabel,
    required this.onAction,
  });

  final IconData icon;
  final String title;
  final String message;
  final String actionLabel;
  final VoidCallback onAction;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .5)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 30, color: colors.primary),
          const SizedBox(height: 9),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 4),
          Text(
            message,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall
                ?.copyWith(color: colors.onSurfaceVariant, height: 1.45),
          ),
          const SizedBox(height: 10),
          TextButton(onPressed: onAction, child: Text(actionLabel)),
        ],
      ),
    );
  }
}

class UserQrDialog extends StatelessWidget {
  const UserQrDialog({required this.userId, required this.username, super.key});
  final String userId;
  final String username;

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('رمز QR الخاص بي'),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: QrImageView(
            data: userId.isEmpty ? '@$username' : 'wasla://user/$userId',
            version: QrVersions.auto,
            size: 220,
            backgroundColor: Colors.white,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'امسح الرمز لفتح ملفك مباشرة وإرسال طلب صداقة.',
          textAlign: TextAlign.center,
        ),
      ],
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إغلاق'),
      ),
    ],
  );
}

class _BubbleStylePreview extends StatelessWidget {
  const _BubbleStylePreview({required this.style});

  final MessageBubbleStyle style;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'معاينة مباشرة',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: colors.onSurfaceVariant,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: _BubbleStyleSample(
              style: style,
              mine: true,
              miniature: false,
            ),
          ),
          const SizedBox(height: 7),
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: _BubbleStyleSample(style: style, miniature: false),
          ),
        ],
      ),
    );
  }
}

class _BubbleStyleSample extends StatelessWidget {
  const _BubbleStyleSample({
    required this.style,
    this.mine = false,
    this.miniature = true,
  });

  final MessageBubbleStyle style;
  final bool mine;
  final bool miniature;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      constraints: BoxConstraints(maxWidth: miniature ? 76 : 150),
      padding: miniature
          ? const EdgeInsets.symmetric(horizontal: 9, vertical: 6)
          : const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
      decoration: BoxDecoration(
        color: mine ? colors.primaryContainer : colors.surface,
        borderRadius: style.borderRadiusFor(mine: mine),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .65)),
      ),
      child: Text(
        miniature
            ? 'رسالة'
            : mine
            ? 'مرحبًا، كيف حالك؟'
            : 'أهلًا بك!',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: colors.onSurface,
          fontWeight: mine ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
    );
  }
}

class SettingsSection extends StatelessWidget {
  const SettingsSection({
    required this.onProfile,
    required this.onInfo,
    required this.onNotifications,
    required this.onSaveMediaOptions,
    required this.onPresenceStatus,
    required this.presenceStatus,
    required this.onSignOut,
    required this.themeMode,
    required this.onThemeModeChanged,
    required this.themeId,
    required this.customThemes,
    required this.onThemeIdChanged,
    required this.onCustomThemeCreated,
    required this.onCustomThemesChanged,
    required this.textSize,
    required this.onTextSizeChanged,
    required this.bubbleStyle,
    required this.onBubbleStyleChanged,
    required this.reduceMotion,
    required this.onReduceMotionChanged,
    required this.highContrast,
    required this.onHighContrastChanged,
    required this.compactLayout,
    required this.onCompactLayoutChanged,
    required this.showChatStatusHighlights,
    required this.onShowChatStatusHighlightsChanged,
    required this.onExportData,
    this.onAbout,
    super.key,
  });

  final VoidCallback onProfile;
  final void Function(String title, String detail) onInfo;
  final VoidCallback onNotifications;
  final VoidCallback onSaveMediaOptions;
  final VoidCallback onPresenceStatus;
  final UserPresenceStatus presenceStatus;
  final VoidCallback onSignOut;
  final ThemeMode themeMode;
  final ValueChanged<ThemeMode> onThemeModeChanged;
  final String themeId;
  final List<AppThemeOption> customThemes;
  final ValueChanged<String> onThemeIdChanged;
  final ValueChanged<AppThemeOption> onCustomThemeCreated;
  final ValueChanged<List<AppThemeOption>> onCustomThemesChanged;
  final AppTextSize textSize;
  final ValueChanged<AppTextSize> onTextSizeChanged;
  final MessageBubbleStyle bubbleStyle;
  final ValueChanged<MessageBubbleStyle> onBubbleStyleChanged;
  final bool reduceMotion;
  final ValueChanged<bool> onReduceMotionChanged;
  final bool highContrast;
  final ValueChanged<bool> onHighContrastChanged;
  final bool compactLayout;
  final ValueChanged<bool> onCompactLayoutChanged;
  final bool showChatStatusHighlights;
  final ValueChanged<bool> onShowChatStatusHighlightsChanged;
  final VoidCallback onExportData;
  final VoidCallback? onAbout;

  String get _themeModeLabel => switch (themeMode) {
    ThemeMode.light => 'فاتح دائمًا',
    ThemeMode.dark => 'داكن دائمًا',
    ThemeMode.system => 'حسب إعداد الجهاز',
  };

  String get _selectedThemeName => appThemeById(themeId, customThemes).name;

  Future<void> _chooseTheme(BuildContext context) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(context).height * .82,
          ),
          child: Column(
            children: [
              const ListTile(
                title: Text(
                  'المظهر والثيمات',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text('اختر لوحة ألوان ووضع الإضاءة.'),
              ),
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                child: SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(
                      value: ThemeMode.system,
                      label: Text('الجهاز'),
                      icon: Icon(Icons.brightness_auto_rounded),
                    ),
                    ButtonSegment(
                      value: ThemeMode.light,
                      label: Text('فاتح'),
                      icon: Icon(Icons.light_mode_rounded),
                    ),
                    ButtonSegment(
                      value: ThemeMode.dark,
                      label: Text('داكن'),
                      icon: Icon(Icons.dark_mode_rounded),
                    ),
                  ],
                  selected: {themeMode},
                  onSelectionChanged: (values) =>
                      Navigator.pop(context, 'mode:${values.first.name}'),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    const Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(20, 8, 20, 4),
                      child: Text(
                        'ثيمات جاهزة',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                    for (final option in appThemePresets)
                      _themeOptionTile(context, option),
                    if (customThemes.isNotEmpty) ...[
                      const Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(20, 12, 20, 4),
                        child: Text(
                          'ثيماتي المخصصة',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                      for (final option in customThemes)
                        _themeOptionTile(context, option, deletable: true),
                    ],
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.pop(context, 'create'),
                        icon: const Icon(Icons.add_rounded),
                        label: const Text('إنشاء ثيم مخصص'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (action == null) return;
    if (action.startsWith('mode:')) {
      onThemeModeChanged(switch (action.substring(5)) {
        'light' => ThemeMode.light,
        'dark' => ThemeMode.dark,
        _ => ThemeMode.system,
      });
    } else if (action.startsWith('theme:')) {
      onThemeIdChanged(action.substring(6));
    } else if (action.startsWith('delete:')) {
      final deletedId = action.substring(7);
      onCustomThemesChanged(
        customThemes.where((theme) => theme.id != deletedId).toList(),
      );
    } else if (action == 'create') {
      if (!context.mounted) return;
      final created = await showDialog<AppThemeOption>(
        context: context,
        builder: (_) => const _CreateAppThemeDialog(),
      );
      if (created != null) onCustomThemeCreated(created);
    }
  }

  Widget _themeOptionTile(
    BuildContext context,
    AppThemeOption option, {
    bool deletable = false,
  }) => ListTile(
    leading: CircleAvatar(
      radius: 17,
      backgroundColor: option.color,
      child: themeId == option.id
          ? const Icon(Icons.check_rounded, color: Colors.white, size: 19)
          : null,
    ),
    title: Text(option.name),
    subtitle: option.isCustom
        ? const Text('ثيم محفوظ لهذا الحساب على الجهاز')
        : null,
    trailing: deletable
        ? IconButton(
            tooltip: 'حذف الثيم',
            onPressed: () => Navigator.pop(context, 'delete:${option.id}'),
            icon: const Icon(Icons.delete_outline_rounded),
          )
        : themeId == option.id
        ? Icon(Icons.radio_button_checked_rounded, color: option.color)
        : const Icon(Icons.radio_button_unchecked_rounded),
    onTap: () => Navigator.pop(context, 'theme:${option.id}'),
  );

  Future<void> _chooseTextSize(BuildContext context) async {
    final selected = await showModalBottomSheet<AppTextSize>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'حجم النص',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text('يُحفظ الاختيار لهذا الحساب على هذا الجهاز.'),
            ),
            for (final option in AppTextSize.values)
              ListTile(
                leading: Icon(
                  textSize == option
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded,
                  color: textSize == option
                      ? Theme.of(context).colorScheme.primary
                      : null,
                ),
                title: Text(option.label),
                onTap: () => Navigator.pop(context, option),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected != null) onTextSizeChanged(selected);
  }

  Future<void> _chooseBubbleStyle(BuildContext context) async {
    final selected = await showModalBottomSheet<MessageBubbleStyle>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.sizeOf(context).height * .72,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text(
                  'شكل فقاعات الرسائل',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text('اختر الشكل الذي يظهر في محادثاتك.'),
              ),
              Padding(
                padding: const EdgeInsetsDirectional.fromSTEB(20, 0, 20, 10),
                child: _BubbleStylePreview(style: bubbleStyle),
              ),
              const Divider(height: 1),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  children: [
                    for (final option in MessageBubbleStyle.values)
                      ListTile(
                        leading: Icon(
                          bubbleStyle == option
                              ? Icons.radio_button_checked_rounded
                              : Icons.radio_button_unchecked_rounded,
                          color: bubbleStyle == option
                              ? Theme.of(context).colorScheme.primary
                              : null,
                        ),
                        title: Text(option.label),
                        subtitle: Text(option.description),
                        trailing: _BubbleStyleSample(style: option),
                        onTap: () => Navigator.pop(context, option),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
    if (selected != null) onBubbleStyleChanged(selected);
  }

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 110),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primaryContainer,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface
                      .withValues(alpha: .82),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Icon(
                  Icons.tune_rounded,
                  color: Theme.of(context).colorScheme.primary,
                  size: 26,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'وصال على طريقتك',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'إعدادات مرتبة حسب ما تريد تخصيصه',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onPrimaryContainer
                            .withValues(alpha: .78),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        _SettingsGroup(
          icon: Icons.person_rounded,
          title: 'الحساب والتواجد',
          subtitle: 'ملفك الشخصي وحالة الاتصال',
          initiallyExpanded: true,
          children: [
            _SettingsTile(
              icon: Icons.person_rounded,
              title: 'الحساب',
              subtitle: 'الاسم الظاهر والصورة والنبذة',
              onTap: onProfile,
            ),
            _SettingsTile(
              icon: Icons.circle_rounded,
              title: 'حالة التواجد',
              subtitle: presenceStatus.label,
              onTap: onPresenceStatus,
            ),
          ],
        ),
        _SettingsGroup(
          icon: Icons.shield_rounded,
          title: 'الخصوصية والتنبيهات',
          subtitle: 'الأمان وإشعارات الرسائل والمجموعات',
          children: [
            _SettingsTile(
              icon: Icons.shield_rounded,
              title: 'الخصوصية والأمان',
              subtitle: 'معلومات عن حماية الحساب والرسائل',
              onTap: () => onInfo(
                'الخصوصية والأمان',
                'تُنقل الرسائل عبر اتصال TLS وتخزّن في مشروع وصال. التشفير بين الطرفين (E2EE) غير متوفر حاليًا.',
              ),
            ),
            _SettingsTile(
              icon: Icons.notifications_active_rounded,
              title: 'الإشعارات',
              subtitle: 'إدارة الرسائل والمجموعات والحالات والمكالمات',
              onTap: onNotifications,
            ),
          ],
        ),
        _SettingsGroup(
          icon: Icons.palette_rounded,
          title: 'المظهر والتخصيص',
          subtitle:
              '$_selectedThemeName · $_themeModeLabel · ${bubbleStyle.label}',
          children: [
            _SettingsTile(
              icon: Icons.palette_rounded,
              title: 'المظهر',
              subtitle: '$_selectedThemeName · $_themeModeLabel',
              onTap: () => _chooseTheme(context),
            ),
            _SettingsTile(
              icon: Icons.text_fields_rounded,
              title: 'حجم النص',
              subtitle: textSize.label,
              onTap: () => _chooseTextSize(context),
            ),
            _SettingsTile(
              icon: Icons.chat_bubble_rounded,
              title: 'شكل فقاعات الرسائل',
              subtitle: bubbleStyle.label,
              onTap: () => _chooseBubbleStyle(context),
            ),
            _SettingsToggle(
              icon: Icons.contrast_rounded,
              title: 'تباين عالٍ',
              subtitle: 'تقوية وضوح النصوص والحدود في الواجهة',
              value: highContrast,
              onChanged: onHighContrastChanged,
            ),
            _SettingsToggle(
              icon: Icons.view_compact_alt_rounded,
              title: 'واجهة مدمجة',
              subtitle: 'تقليل المسافات في القوائم وعناصر التحكم',
              value: compactLayout,
              onChanged: onCompactLayoutChanged,
            ),
            _SettingsToggle(
              icon: Icons.circle_outlined,
              title: 'إظهار الحالات أعلى الدردشات',
              subtitle: 'عرض شريط الحالات فوق قائمة المحادثات',
              value: showChatStatusHighlights,
              onChanged: onShowChatStatusHighlightsChanged,
            ),
            _SettingsToggle(
              icon: Icons.motion_photos_off_rounded,
              title: 'تقليل الحركة',
              subtitle: 'تقليل الحركات غير الضرورية في الواجهة',
              value: reduceMotion,
              onChanged: onReduceMotionChanged,
            ),
          ],
        ),
        _SettingsGroup(
          icon: Icons.storage_rounded,
          title: 'البيانات والوسائط',
          subtitle: 'التصدير وحفظ الوسائط وإدارة الأجهزة',
          children: [
            _SettingsTile(
              icon: Icons.storage_rounded,
              title: 'التخزين والبيانات',
              subtitle: 'تصدير JSON غير مشفر لنصوص الرسائل ومراجع الوسائط',
              onTap: onExportData,
            ),
            _SettingsTile(
              icon: Icons.download_for_offline_outlined,
              title: 'حفظ الوسائط والحالات',
              subtitle: 'اختر يدويًا ما تريد نسخه إلى مساحة الهاتف',
              onTap: onSaveMediaOptions,
            ),
            _SettingsTile(
              icon: Icons.devices_rounded,
              title: 'الأجهزة المتصلة',
              subtitle: 'إدارة الجلسات غير متاحة بعد',
              onTap: () => onInfo(
                'الأجهزة المتصلة',
                'لا تتوفر إدارة الأجهزة والجلسات النشطة في هذه النسخة.',
              ),
            ),
            _SettingsTile(
              icon: Icons.backup_rounded,
              title: 'النسخ الاحتياطي',
              subtitle: 'تصدير قابل للمشاركة، دون استعادة تلقائية',
              onTap: () => onInfo(
                'التصدير والاستعادة',
                'يمكنك إنشاء ملف JSON غير مشفر ومشاركته من خيار «التخزين والبيانات». يتضمن نصوص الرسائل ومراجع الوسائط، ولا يضمّن ملفات المرفقات. راجع الملف قبل مشاركته؛ الاستعادة التلقائية غير متاحة.',
              ),
            ),
          ],
        ),
        _SettingsGroup(
          icon: Icons.info_outline_rounded,
          title: 'التطبيق والدعم',
          subtitle: 'اللغة والمساعدة ومعلومات وصال',
          children: [
            _SettingsTile(
              icon: Icons.language_rounded,
              title: 'اللغة',
              subtitle: 'العربية',
              onTap: () =>
                  onInfo('اللغة', 'واجهة التطبيق مضبوطة على العربية حاليًا.'),
            ),
            _SettingsTile(
              icon: Icons.help_rounded,
              title: 'المساعدة',
              subtitle: 'معلومات عن الميزات المتاحة',
              onTap: () => onInfo(
                'المساعدة',
                'للاستفسارات أو الإبلاغ عن مشكلة، استخدم قناة الملاحظات المتاحة في التطبيق.',
              ),
            ),
            _SettingsTile(
              icon: Icons.info_rounded,
              title: 'حول التطبيق',
              subtitle: 'شركة الصرم للتطوير والبرمجيات',
              onTap:
                  onAbout ??
                  () => onInfo(
                    'حول وصال',
                    'شركة الصرم للتطوير والبرمجيات\nالبريد: darwishriad77@gmail.com\nواتساب: +967 774 655 282\nوصال: Darwish71',
                  ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        OutlinedButton.icon(
          onPressed: onSignOut,
          icon: const Icon(Icons.logout_rounded),
          label: const Text('تسجيل الخروج'),
        ),
      ],
    ),
  );
}

class _CreateAppThemeDialog extends StatefulWidget {
  const _CreateAppThemeDialog();

  @override
  State<_CreateAppThemeDialog> createState() => _CreateAppThemeDialogState();
}

class _CreateAppThemeDialogState extends State<_CreateAppThemeDialog> {
  static const _colors = <Color>[
    Color(0xFF087F72),
    Color(0xFF1769AA),
    Color(0xFF6750A4),
    Color(0xFFB33C68),
    Color(0xFFC45A28),
    Color(0xFF55723B),
    Color(0xFF52616B),
    Color(0xFF00838F),
    Color(0xFF7B5E00),
    Color(0xFF8C4A8B),
    Color(0xFFAD343E),
    Color(0xFF315C8C),
    Color(0xFF526D4E),
    Color(0xFF6D4C41),
    Color(0xFF3949AB),
    Color(0xFF008A70),
  ];

  final _nameController = TextEditingController();
  Color _selectedColor = _colors.first;

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;
    Navigator.pop(
      context,
      AppThemeOption(
        id: 'custom_${DateTime.now().microsecondsSinceEpoch}',
        name: name,
        seedColor: _selectedColor.toARGB32(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('إنشاء ثيم مخصص'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _nameController,
            autofocus: true,
            maxLength: 24,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(
              labelText: 'اسم الثيم',
              hintText: 'مثال: ألواني المفضلة',
            ),
            onChanged: (_) => setState(() {}),
            onSubmitted: (_) => _save(),
          ),
          const SizedBox(height: 8),
          const Text(
            'اللون الأساسي',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final color in _colors)
                Semantics(
                  button: true,
                  selected: color == _selectedColor,
                  label: 'لون ${color.toARGB32().toRadixString(16)}',
                  child: InkWell(
                    onTap: () => setState(() => _selectedColor = color),
                    customBorder: const CircleBorder(),
                    child: CircleAvatar(
                      radius: 18,
                      backgroundColor: color,
                      child: color == _selectedColor
                          ? const Icon(
                              Icons.check_rounded,
                              color: Colors.white,
                              size: 20,
                            )
                          : null,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'سيعمل الثيم مع وضع الإضاءة الذي تختاره، وسيُحفظ محليًا لهذا الحساب.',
            style: TextStyle(height: 1.4),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton.icon(
        onPressed: _nameController.text.trim().isEmpty ? null : _save,
        icon: const Icon(Icons.save_rounded),
        label: const Text('حفظ وتطبيق'),
      ),
    ],
  );
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        minVerticalPadding: 12,
        contentPadding: const EdgeInsetsDirectional.fromSTEB(14, 2, 10, 2),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: colors.primaryContainer,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(icon, color: colors.primary, size: 22),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: Icon(
          Icons.chevron_left_rounded,
          color: colors.onSurfaceVariant,
        ),
        onTap: onTap,
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  const _SettingsGroup({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.children,
    this.initiallyExpanded = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final List<Widget> children;
  final bool initiallyExpanded;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20),
      side: BorderSide(color: colors.outlineVariant.withValues(alpha: .55)),
    );
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      shape: shape,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          initiallyExpanded: initiallyExpanded,
          shape: shape,
          collapsedShape: shape,
          tilePadding: const EdgeInsetsDirectional.fromSTEB(14, 4, 12, 4),
          childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
          leading: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: colors.primaryContainer,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: colors.primary, size: 21),
          ),
          title: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          subtitle: Text(
            subtitle,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          children: children,
        ),
      ),
    );
  }
}

class _SettingsToggle extends StatelessWidget {
  const _SettingsToggle({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 8),
    child: SwitchListTile.adaptive(
      secondary: Icon(icon, color: Theme.of(context).colorScheme.primary),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
    ),
  );
}

class _FriendTile extends StatelessWidget {
  const _FriendTile({
    required this.friend,
    required this.onTap,
    required this.onRemove,
  });

  final Friend friend;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ValueListenableBuilder<Map<String, UserPresenceStatus>>(
      valueListenable: userPresenceStatuses,
      builder: (context, statuses, _) {
        final status = statuses[friend.userId];
        final avatarUrl = friend.avatarPath == null
            ? null
            : Supabase.instance.client.storage
                  .from('wasla-avatars')
                  .getPublicUrl(friend.avatarPath!);
        return ValueListenableBuilder<Set<String>>(
          valueListenable: onlineUserIds,
          builder: (context, onlineIds, _) {
            final isOnline = onlineIds.contains(friend.userId);
            return Column(
              children: [
                InkWell(
                  onTap: onTap,
                  borderRadius: BorderRadius.circular(14),
                  child: Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(2, 9, 2, 9),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFFBDE9DC),
                              width: 1.4,
                            ),
                          ),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Positioned.fill(
                                child: CircleAvatar(
                                  backgroundImage: avatarUrl == null
                                      ? null
                                      : NetworkImage(avatarUrl),
                                  child: avatarUrl == null
                                      ? const Icon(Icons.person_rounded)
                                      : null,
                                ),
                              ),
                              PositionedDirectional(
                                bottom: -1,
                                end: -1,
                                child: isOnline
                                    ? ConnectionStatusDot(
                                        online: true,
                                        size: 12,
                                        borderColor: colors.surface,
                                      )
                                    : ConnectionStatusDot(
                                        online: false,
                                        size: 12,
                                        borderColor: colors.surface,
                                      ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AdminIdentityText(
                                userId: friend.userId,
                                label: friend.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodyLarge
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                '@${friend.username}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(color: colors.onSurfaceVariant),
                              ),
                              if (status != null || isOnline) ...[
                                const SizedBox(height: 4),
                                if (isOnline)
                                  const ConnectionStatusLabel(
                                    online: true,
                                    lastSeenAt: null,
                                    fontSize: 10,
                                  )
                                else
                                  PresenceStatusLabel(
                                    status: status!,
                                    userId: friend.userId,
                                    fontSize: 10,
                                    dotSize: 7,
                                  ),
                              ],
                            ],
                          ),
                        ),
                        IconButton(
                          tooltip: 'إلغاء الصداقة',
                          onPressed: onRemove,
                          visualDensity: VisualDensity.compact,
                          color: colors.onSurfaceVariant,
                          icon: const Icon(Icons.more_horiz_rounded),
                        ),
                      ],
                    ),
                  ),
                ),
                Divider(
                  height: 1,
                  indent: 64,
                  color: colors.outlineVariant.withValues(alpha: .5),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class _InlineCapabilityNote extends StatelessWidget {
  const _InlineCapabilityNote({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .6)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: colors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: colors.onSurfaceVariant,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
