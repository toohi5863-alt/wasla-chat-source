import 'dart:io';
import 'dart:typed_data';

import 'package:chat/chat_local_cache.dart';
import 'package:chat/chat_models.dart';
import 'package:chat/message_delivery.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive_ce/hive_ce.dart';

void main() {
  late Directory supportDirectory;
  late ChatLocalCache cache;

  setUp(() async {
    supportDirectory = await Directory.systemTemp.createTemp(
      'wasla-delivery-flow-',
    );
    cache = ChatLocalCache(
      supportDirectoryProvider: () async => supportDirectory,
    );
  });

  tearDown(() async {
    await Hive.close();
    if (await supportDirectory.exists()) {
      await supportDirectory.delete(recursive: true);
    }
  });

  test(
    'saves image bytes and the message before acknowledgement and deletion',
    () async {
      final image = ChatMessage(
        id: 'image-new',
        senderId: 'sender',
        content: 'صورة',
        createdAt: DateTime.utc(2026, 10, 9),
        messageType: 'image',
        mediaPath: 'conversation/sender/image.jpg',
        isEphemeral: true,
      );
      final text = ChatMessage(
        id: 'text-new',
        senderId: 'sender',
        content: 'رسالة جديدة',
        createdAt: DateTime.utc(2026, 10, 9, 0, 1),
        isEphemeral: true,
      );
      final eventOrder = <String>[];
      final flow = LocalMessageDelivery(
        localCache: cache,
        downloadMedia: (_) async {
          eventOrder.add('download');
          return Uint8List.fromList([0xff, 0xd8, 0xff, 0xd9]);
        },
        acknowledge: (messageId) async {
          final localMessages = await cache.loadMessages(
            'recipient',
            'conversation',
          );
          expect(
            localMessages?.map((message) => message.id),
            contains(messageId),
          );
          if (messageId == image.id) {
            final localImage = await cache.findMedia(
              'recipient',
              image.mediaPath!,
            );
            expect(localImage, isNotNull);
            expect(await localImage!.readAsBytes(), [0xff, 0xd8, 0xff, 0xd9]);
          }
          eventOrder.add('ack:$messageId');
          return messageId == image.id ? image.mediaPath : null;
        },
        deleteRemoteMedia: (messageId, path) async {
          expect(messageId, image.id);
          expect(path, image.mediaPath);
          eventOrder.add('delete:$messageId');
        },
      );

      final acknowledged = await flow.cacheAndAcknowledge(
        userId: 'recipient',
        conversationId: 'conversation',
        conversationMessages: [image, text],
        incomingMessages: [image, text],
      );

      expect(acknowledged, {'image-new', 'text-new'});
      expect(eventOrder.first, 'download');
      expect(
        eventOrder.indexOf('ack:image-new'),
        greaterThan(eventOrder.indexOf('download')),
      );
      expect(
        eventOrder.indexOf('delete:image-new'),
        greaterThan(eventOrder.indexOf('ack:image-new')),
      );
      expect(
        eventOrder.indexOf('ack:text-new'),
        greaterThan(eventOrder.indexOf('download')),
      );
    },
  );

  test(
    'does not acknowledge when local media download fails; retries later',
    () async {
      final image = ChatMessage(
        id: 'retry-image',
        senderId: 'sender',
        content: 'صورة',
        createdAt: DateTime.utc(2026, 10, 9),
        messageType: 'image',
        mediaPath: 'conversation/sender/retry.jpg',
        isEphemeral: true,
      );
      var shouldFail = true;
      var acknowledgements = 0;
      final flow = LocalMessageDelivery(
        localCache: cache,
        downloadMedia: (_) async {
          if (shouldFail) throw const SocketException('offline');
          return Uint8List.fromList([1, 2, 3]);
        },
        acknowledge: (_) async {
          acknowledgements++;
          return null;
        },
        deleteRemoteMedia: (_, _) async {},
      );

      await flow.cacheAndAcknowledge(
        userId: 'recipient',
        conversationId: 'conversation',
        conversationMessages: [image],
        incomingMessages: [image],
      );
      expect(acknowledgements, 0);

      shouldFail = false;
      final retried = await flow.cacheAndAcknowledge(
        userId: 'recipient',
        conversationId: 'conversation',
        conversationMessages: [image],
        incomingMessages: [image],
      );
      expect(retried, {'retry-image'});
      expect(acknowledgements, 1);
    },
  );

  test(
    'legacy messages are cached but never sent to ephemeral acknowledgement',
    () async {
      final legacy = ChatMessage(
        id: 'historic',
        senderId: 'sender',
        content: 'رسالة تاريخية',
        createdAt: DateTime.utc(2025, 1, 1),
      );
      var acknowledgements = 0;
      final flow = LocalMessageDelivery(
        localCache: cache,
        downloadMedia: (_) async => Uint8List(0),
        acknowledge: (_) async {
          acknowledgements++;
          return null;
        },
        deleteRemoteMedia: (_, _) async {},
      );

      final result = await flow.cacheAndAcknowledge(
        userId: 'recipient',
        conversationId: 'conversation',
        conversationMessages: [legacy],
        incomingMessages: [legacy],
      );

      expect(result, isEmpty);
      expect(acknowledgements, 0);
      expect(
        (await cache.loadMessages('recipient', 'conversation'))!.single.content,
        'رسالة تاريخية',
      );
    },
  );

  test('does not acknowledge when local message persistence fails', () async {
    final message = ChatMessage(
      id: 'disk-failure',
      senderId: 'sender',
      content: 'رسالة جديدة',
      createdAt: DateTime.utc(2026, 10, 9),
      isEphemeral: true,
    );
    var acknowledgements = 0;
    final failingCache = ChatLocalCache(
      supportDirectoryProvider: () async => throw StateError('disk full'),
    );
    final flow = LocalMessageDelivery(
      localCache: failingCache,
      downloadMedia: (_) async => Uint8List(0),
      acknowledge: (_) async {
        acknowledgements++;
        return null;
      },
      deleteRemoteMedia: (_, _) async {},
    );

    await expectLater(
      flow.cacheAndAcknowledge(
        userId: 'recipient',
        conversationId: 'conversation',
        conversationMessages: [message],
        incomingMessages: [message],
      ),
      throwsA(isA<StateError>()),
    );
    expect(acknowledgements, 0);
  });

  test('group cleanup waits for server callback to report all recipients delivered', () async {
    final image = ChatMessage(
      id: 'group-image',
      senderId: 'sender',
      content: 'صورة المجموعة',
      createdAt: DateTime.utc(2026, 10, 9),
      messageType: 'image',
      mediaPath: 'group/sender/image.jpg',
      isEphemeral: true,
    );
    var recipientAcknowledgements = 0;
    var remoteDeletes = 0;
    Future<void> runFor(String recipient) async {
      final flow = LocalMessageDelivery(
        localCache: cache,
        downloadMedia: (_) async => Uint8List.fromList([1, 2, 3]),
        acknowledge: (_) async {
          recipientAcknowledgements++;
          return recipientAcknowledgements == 2 ? 'group/media.jpg' : null;
        },
        deleteRemoteMedia: (_, _) async => remoteDeletes++,
      );
      await flow.cacheAndAcknowledge(
        userId: recipient,
        conversationId: 'group',
        conversationMessages: [image],
        incomingMessages: [image],
      );
    }

    await runFor('recipient-a');
    expect(remoteDeletes, 0);
    await runFor('recipient-b');
    expect(remoteDeletes, 1);
  });
}
