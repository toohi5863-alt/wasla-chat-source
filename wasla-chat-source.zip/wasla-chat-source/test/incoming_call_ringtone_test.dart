import 'dart:async';

import 'package:chat/incoming_call_ringtone.dart';
import 'package:chat/notification_preferences.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('IncomingCallRingtoneController', () {
    late int playCount;
    late int stopCount;
    late IncomingCallRingtoneController ringtone;

    setUp(() {
      playCount = 0;
      stopCount = 0;
      ringtone = IncomingCallRingtoneController(
        play: () async => playCount++,
        stop: () async => stopCount++,
      );
    });

    tearDown(() async => ringtone.dispose());

    test(
      'starts one persistent ringtone for a new incoming call only once',
      () async {
        expect(
          await ringtone.startForIncoming(
            callId: 'call-1',
            isIncoming: true,
            alertsEnabled: true,
            callScreenOpen: false,
          ),
          isTrue,
        );
        expect(ringtone.activeCallId, 'call-1');
        expect(ringtone.isRinging, isTrue);
        expect(
          await ringtone.startForIncoming(
            callId: 'call-1',
            isIncoming: true,
            alertsEnabled: true,
            callScreenOpen: false,
          ),
          isFalse,
        );
        expect(playCount, 1);
      },
    );

    test(
      'stops immediately and idempotently for the active call only',
      () async {
        await ringtone.startForIncoming(
          callId: 'call-1',
          isIncoming: true,
          alertsEnabled: true,
          callScreenOpen: false,
        );

        await ringtone.stopForCall('another-call');
        expect(stopCount, 0);
        expect(ringtone.isRinging, isTrue);

        await ringtone.stopForCall('call-1');
        await ringtone.stopForCall('call-1');
        expect(stopCount, 1);
        expect(ringtone.isRinging, isFalse);
        expect(
          await ringtone.startForIncoming(
            callId: 'call-1',
            isIncoming: true,
            alertsEnabled: true,
            callScreenOpen: false,
          ),
          isFalse,
        );
        expect(playCount, 1);
      },
    );

    test(
      'does not ring for outgoing calls or while a call screen is open',
      () async {
        for (final values in [
          (incoming: false, screenOpen: false),
          (incoming: true, screenOpen: true),
        ]) {
          expect(
            await ringtone.startForIncoming(
              callId: 'call-${values.incoming}-${values.screenOpen}',
              isIncoming: values.incoming,
              alertsEnabled: true,
              callScreenOpen: values.screenOpen,
            ),
            isFalse,
          );
        }
        expect(playCount, 0);
      },
    );

    test('obeys call, sound, and do-not-disturb alert preferences', () async {
      final disabledPreferences = [
        const PushNotificationPreferences(callsEnabled: false),
        const PushNotificationPreferences(soundEnabled: false),
        const PushNotificationPreferences(doNotDisturb: true),
      ];
      for (var index = 0; index < disabledPreferences.length; index++) {
        expect(
          await ringtone.startForIncoming(
            callId: 'disabled-$index',
            isIncoming: true,
            alertsEnabled: disabledPreferences[index].allowsChatSoundFor(
              'calls',
            ),
            callScreenOpen: false,
          ),
          isFalse,
        );
      }
      expect(playCount, 0);
    });

    test('serializes a stop before the next call starts', () async {
      final firstPlay = Completer<void>();
      final order = <String>[];
      final serial = IncomingCallRingtoneController(
        play: () async {
          order.add('play-start');
          await firstPlay.future;
          order.add('play-end');
        },
        stop: () async => order.add('stop'),
      );
      final starting = serial.startForIncoming(
        callId: 'call-1',
        isIncoming: true,
        alertsEnabled: true,
        callScreenOpen: false,
      );
      await Future<void>.delayed(Duration.zero);
      final stopping = serial.stopForCall('call-1');
      firstPlay.complete();
      await starting;
      await stopping;
      expect(order, ['play-start', 'play-end', 'stop']);
      await serial.dispose();
    });

    test('stopAll stops the current ringtone once', () async {
      await ringtone.startForIncoming(
        callId: 'call-1',
        isIncoming: true,
        alertsEnabled: true,
        callScreenOpen: false,
      );
      await ringtone.stopAll();
      await ringtone.stopAll();
      expect(stopCount, 1);
      expect(ringtone.isRinging, isFalse);
    });
  });
}
