-- Wasla 1.8.1: expose accepted friends without exposing other users' relationships.
create or replace function public.list_friends()
returns table (
  friend_id uuid,
  username text,
  display_name text,
  avatar_path text
)
language sql stable security definer
set search_path = public, pg_temp
as $$
  select
    p.id,
    p.username,
    p.display_name,
    p.avatar_path
  from public.friend_requests fr
  join public.profiles p
    on p.id = case
      when fr.requester_id = auth.uid() then fr.addressee_id
      else fr.requester_id
    end
  where fr.status = 'accepted'
    and (fr.requester_id = auth.uid() or fr.addressee_id = auth.uid())
  order by lower(coalesce(nullif(p.display_name, ''), p.username)), p.username;
$$;

revoke all on function public.list_friends() from public, anon;
grant execute on function public.list_friends() to authenticated;
