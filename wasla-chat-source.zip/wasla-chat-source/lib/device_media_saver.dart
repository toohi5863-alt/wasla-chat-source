import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

typedef MediaDownloadToFile = Future<void> Function(
  Uri source,
  File destination,
);

class DeviceMediaSaveException implements Exception {
  const DeviceMediaSaveException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Saves a user-requested copy into the Android media library / Downloads.
/// On Android 10 and newer this uses MediaStore without broad storage access.
class DeviceMediaSaver {
  DeviceMediaSaver({
    MethodChannel? channel,
    bool? isAndroid,
    Future<Directory> Function()? temporaryDirectoryProvider,
    MediaDownloadToFile? downloadToFile,
  }) : _channel = channel ?? const MethodChannel(_channelName),
       _isAndroid = isAndroid ?? Platform.isAndroid,
       _temporaryDirectoryProvider =
           temporaryDirectoryProvider ?? getTemporaryDirectory,
       _downloadToFile = downloadToFile ?? _downloadUrlToFile;

  static const _channelName = 'app.wasla.chat/media_saver';

  final MethodChannel _channel;
  final bool _isAndroid;
  final Future<Directory> Function() _temporaryDirectoryProvider;
  final MediaDownloadToFile _downloadToFile;

  Future<String> saveFromUrl({
    required String url,
    required String fileName,
    String? mimeType,
  }) async {
    if (!_isAndroid) {
      throw const DeviceMediaSaveException(
        'حفظ الملفات في مساحة الهاتف متاح حاليًا على Android فقط.',
      );
    }

    final safeName = sanitizeDeviceMediaFileName(fileName);
    final tempDirectory = await _temporaryDirectoryProvider();
    final temporaryFile = File(
      '${tempDirectory.path}${Platform.pathSeparator}'
      'wasla_save_${DateTime.now().microsecondsSinceEpoch}_$safeName',
    );

    try {
      await _downloadToFile(Uri.parse(url), temporaryFile);
      if (!await temporaryFile.exists() || await temporaryFile.length() == 0) {
        throw const DeviceMediaSaveException('الملف فارغ أو غير متاح للحفظ.');
      }

      return await saveLocalFile(
        filePath: temporaryFile.path,
        fileName: safeName,
        mimeType: mimeType ?? mediaMimeTypeForFileName(safeName),
      );
    } on DeviceMediaSaveException {
      rethrow;
    } catch (_) {
      throw const DeviceMediaSaveException(
        'تعذر حفظ الملف على الهاتف. تحقق من الاتصال والمساحة المتاحة وحاول مجددًا.',
      );
    } finally {
      if (await temporaryFile.exists()) {
        try {
          await temporaryFile.delete();
        } catch (_) {}
      }
    }
  }

  Future<String> saveLocalFile({
    required String filePath,
    required String fileName,
    String? mimeType,
  }) async {
    if (!_isAndroid) {
      throw const DeviceMediaSaveException(
        'حفظ الملفات في مساحة الهاتف متاح حاليًا على Android فقط.',
      );
    }

    final androidSdk = await _channel.invokeMethod<int>('getAndroidSdk');
    if (androidSdk == null) {
      throw const DeviceMediaSaveException(
        'تعذر التحقق من دعم حفظ الملفات على هذا الجهاز.',
      );
    }
    if (androidSdk < 29) {
      final permission = await Permission.storage.request();
      if (!permission.isGranted) {
        throw const DeviceMediaSaveException(
          'يلزم السماح بالوصول إلى التخزين لحفظ الملف على هذا الإصدار من Android.',
        );
      }
    }

    try {
      final result = await _channel.invokeMapMethod<String, dynamic>(
        'saveFile',
        {
          'filePath': filePath,
          'fileName': sanitizeDeviceMediaFileName(fileName),
          'mimeType': mimeType ?? mediaMimeTypeForFileName(fileName),
        },
      );
      final location = result?['location']?.toString();
      if (location == null || location.isEmpty) {
        throw const DeviceMediaSaveException('لم يتمكن الهاتف من حفظ الملف.');
      }
      return location;
    } on DeviceMediaSaveException {
      rethrow;
    } on PlatformException catch (error) {
      if (error.code == 'permission_denied') {
        throw const DeviceMediaSaveException(
          'يلزم السماح بالوصول إلى التخزين لحفظ الملف على هذا الإصدار من Android.',
        );
      }
      throw const DeviceMediaSaveException(
        'تعذر حفظ الملف على الهاتف. تحقق من المساحة المتاحة وحاول مجددًا.',
      );
    } on MissingPluginException {
      throw const DeviceMediaSaveException(
        'ميزة الحفظ في مساحة الهاتف غير متاحة في هذا الإصدار من التطبيق.',
      );
    }
  }

  static Future<void> _downloadUrlToFile(Uri url, File destination) async {
    final httpClient = HttpClient()
      ..connectionTimeout = const Duration(seconds: 15)
      ..idleTimeout = const Duration(seconds: 30);
    try {
      final request = await httpClient
          .getUrl(url)
          .timeout(const Duration(seconds: 20));
      final response = await request.close().timeout(
        const Duration(seconds: 60),
      );
      if (response.statusCode != HttpStatus.ok) {
        await response.drain<void>();
        throw const DeviceMediaSaveException(
          'تعذر تنزيل الملف للحفظ. تحقق من الاتصال وحاول مجددًا.',
        );
      }
      final sink = destination.openWrite();
      try {
        await response.pipe(sink);
      } catch (_) {
        await sink.close();
        rethrow;
      }
    } finally {
      httpClient.close(force: true);
    }
  }
}

String sanitizeDeviceMediaFileName(String fileName) {
  final leaf = fileName.replaceAll('\\', '/').split('/').last;
  final safe = leaf.replaceAll(RegExp(r'[\u0000-\u001F\u007F]'), '').trim();
  if (safe.isEmpty || safe == '.' || safe == '..') return 'wasla_media.bin';
  return safe;
}

String mediaMimeTypeForFileName(String fileName) {
  final name = sanitizeDeviceMediaFileName(fileName).toLowerCase();
  final extension = name.contains('.') ? name.split('.').last : '';
  return switch (extension) {
    'jpg' || 'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
    'heic' || 'heif' => 'image/heic',
    'mp4' || 'm4v' => 'video/mp4',
    'mov' => 'video/quicktime',
    'webm' => 'video/webm',
    'mp3' => 'audio/mpeg',
    'm4a' => 'audio/mp4',
    'aac' => 'audio/aac',
    'wav' => 'audio/wav',
    'ogg' || 'opus' => 'audio/ogg',
    'pdf' => 'application/pdf',
    'txt' => 'text/plain',
    'doc' => 'application/msword',
    'docx' =>
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'zip' => 'application/zip',
    _ => 'application/octet-stream',
  };
}
