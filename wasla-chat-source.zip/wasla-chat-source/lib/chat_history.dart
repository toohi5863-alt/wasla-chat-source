import 'chat_models.dart';

/// Restores a locally cached payload for server rows that have become
/// metadata-only tombstones after every recipient persisted the message.
/// Other server rows remain authoritative and replace cached values.
List<ChatMessage> preserveCachedEphemeralPayloads(
  Iterable<ChatMessage> cachedMessages,
  Iterable<ChatMessage> serverMessages,
) {
  final cachedById = {
    for (final message in cachedMessages) message.id: message,
  };
  return serverMessages.map((server) {
    final cached = cachedById[server.id];
    if (cached == null ||
        server.payloadDeletedAt == null ||
        !server.isEphemeral ||
        !cached.isEphemeral ||
        (!cached.hasLocalPayload && cached.payloadDeletedAt != null)) {
      return server;
    }
    return ChatMessage(
      id: server.id,
      senderId: server.senderId,
      content: cached.content,
      createdAt: server.createdAt,
      messageType: cached.messageType,
      mediaPath: cached.mediaPath,
      mediaDurationSeconds: cached.mediaDurationSeconds,
      deliveredAt: server.deliveredAt ?? cached.deliveredAt,
      readAt: server.readAt ?? cached.readAt,
      replyTo: server.replyTo ?? cached.replyTo,
      editedAt: server.editedAt ?? cached.editedAt,
      isPending: cached.isPending,
      isEphemeral: true,
      payloadDeletedAt: server.payloadDeletedAt,
      hasLocalPayload: true,
    );
  }).toList();
}

/// Removes metadata-only ephemeral tombstones from the visible chat timeline.
/// Full locally cached messages are retained, including when the server has
/// already purged their payload.
List<ChatMessage> visibleChatHistoryMessages(Iterable<ChatMessage> messages) =>
    messages
        .where(
          (message) =>
              !message.isEphemeral ||
              message.payloadDeletedAt == null ||
              message.hasLocalPayload,
        )
        .toList();

/// Merges history pages by message ID and returns them in chronological order.
/// Incoming server rows replace matching cached rows so delivery/read metadata
/// stays fresh, except that a deleted server payload must not overwrite the
/// complete copy already persisted on this device. Metadata-only tombstones
/// remain server-side for delivery cleanup, but never appear in the timeline.
List<ChatMessage> mergeChatHistoryMessages(
  Iterable<ChatMessage> existing,
  Iterable<ChatMessage> incoming,
) {
  final messagesById = <String, ChatMessage>{
    for (final message in existing) message.id: message,
  };
  for (final message in incoming) {
    final cached = messagesById[message.id];
    if (cached == null) {
      messagesById[message.id] = message;
      continue;
    }
    messagesById[message.id] = preserveCachedEphemeralPayloads(
      [cached],
      [message],
    ).single;
  }
  return visibleChatHistoryMessages(messagesById.values)..sort((a, b) {
    final byCreatedAt = a.createdAt.compareTo(b.createdAt);
    return byCreatedAt != 0 ? byCreatedAt : a.id.compareTo(b.id);
  });
}
