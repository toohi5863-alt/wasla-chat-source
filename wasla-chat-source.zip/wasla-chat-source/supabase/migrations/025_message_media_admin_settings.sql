-- Wasla: reversible global controls for new chat messages and conversation media.
-- Existing messages and the cache-before-acknowledgement delivery policy are untouched.

alter table public.wasla_app_settings
  add column if not exists messages_enabled boolean not null default true,
  add column if not exists media_uploads_enabled boolean not null default true,
  add column if not exists max_media_upload_mb smallint not null default 15
    check (max_media_upload_mb between 1 and 15);

create or replace function private.wasla_feature_enabled(p_feature text)
returns boolean
language sql stable security definer
set search_path = public, private, pg_temp
as $$
  select coalesce(
    case p_feature
      when 'signups_enabled' then (select s.signups_enabled from public.wasla_app_settings s where s.id = 1)
      when 'group_creation_enabled' then (select s.group_creation_enabled from public.wasla_app_settings s where s.id = 1)
      when 'public_discovery_enabled' then (select s.public_discovery_enabled from public.wasla_app_settings s where s.id = 1)
      when 'messages_enabled' then (select s.messages_enabled from public.wasla_app_settings s where s.id = 1)
      when 'media_uploads_enabled' then (select s.media_uploads_enabled from public.wasla_app_settings s where s.id = 1)
      else false
    end,
    true
  );
$$;
revoke all on function private.wasla_feature_enabled(text) from public, anon, authenticated;

create or replace function private.wasla_guard_message_controls()
returns trigger
language plpgsql security definer
set search_path = public, private, pg_temp
as $$
begin
  if not private.wasla_feature_enabled('messages_enabled') then
    raise exception 'New message sending is temporarily disabled.' using errcode = 'P0001';
  end if;
  if new.media_path is not null
     and not private.wasla_feature_enabled('media_uploads_enabled') then
    raise exception 'Conversation media uploads are temporarily disabled.' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_guard_message_controls() from public, anon, authenticated;
drop trigger if exists wasla_guard_message_controls on public.messages;
create trigger wasla_guard_message_controls
before insert on public.messages
for each row execute function private.wasla_guard_message_controls();

-- This narrow helper is safe to call from the media-object RLS policy; it reveals
-- only whether conversation media uploads are enabled, not settings table data.
create or replace function private.wasla_media_upload_allowed()
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select coalesce((select s.media_uploads_enabled from public.wasla_app_settings s where s.id = 1), true);
$$;
revoke all on function private.wasla_media_upload_allowed() from public, anon, authenticated;
grant execute on function private.wasla_media_upload_allowed() to authenticated;

-- A restrictive policy composes with, rather than replaces, the existing member,
-- ownership, and per-group files/voice policies.
drop policy if exists wasla_media_global_settings on storage.objects;
create policy wasla_media_global_settings on storage.objects
  as restrictive for insert to authenticated
  with check (
    bucket_id <> 'wasla-media'
    or private.wasla_media_upload_allowed()
  );

-- Keep Supabase Storage's native upload-size enforcement synchronized with the
-- administrator's chosen limit (the existing default remains 15 MiB).
create or replace function private.wasla_sync_media_upload_limit()
returns trigger
language plpgsql security definer
set search_path = public, storage, pg_temp
as $$
begin
  update storage.buckets
    set file_size_limit = new.max_media_upload_mb::bigint * 1048576
    where id = 'wasla-media';
  if not found then
    raise exception 'Wasla media storage bucket is unavailable.';
  end if;
  return new;
end;
$$;
revoke all on function private.wasla_sync_media_upload_limit() from public, anon, authenticated;
drop trigger if exists wasla_sync_media_upload_limit on public.wasla_app_settings;
create trigger wasla_sync_media_upload_limit
after update of max_media_upload_mb on public.wasla_app_settings
for each row execute function private.wasla_sync_media_upload_limit();

-- Apply the default/recorded cap once without changing any existing media object.
update public.wasla_app_settings
set max_media_upload_mb = max_media_upload_mb
where id = 1;
