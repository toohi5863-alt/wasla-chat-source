import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

const _waslaGreen = Color(0xFF1FA463);
const _waslaGreenDark = Color(0xFF0E5A33);
const _waslaGreenLight = Color(0xFF2BC177);
const _email = 'darwishriad77@gmail.com';
const _whatsAppNumber = '967774655282';
const _waslaUsername = 'Darwish71';
const _appVersion = '1.19.8+48';

bool _isDark(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark;

Color _inkFor(BuildContext context) => Theme.of(context).colorScheme.onSurface;

Color _mutedFor(BuildContext context) =>
    Theme.of(context).colorScheme.onSurfaceVariant;

Color _borderFor(BuildContext context) =>
    Theme.of(context).colorScheme.outlineVariant;

Color _surfaceFor(BuildContext context) =>
    Theme.of(context).colorScheme.surface;

Color _surfaceAltFor(BuildContext context) => _isDark(context)
    ? Color.lerp(_surfaceFor(context), Colors.white, .035)!
    : Color.lerp(_surfaceFor(context), const Color(0xFFF0F7F3), .30)!;

Color _softFor(BuildContext context) =>
    Theme.of(context).colorScheme.primaryContainer;

Color _accentFor(BuildContext context) => Theme.of(context).colorScheme.primary;

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> with TickerProviderStateMixin {
  late final AnimationController _entryController;
  late final AnimationController _pulseController;
  bool _entryStarted = false;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.of(context).disableAnimations) {
      _entryController.value = 1;
      _pulseController.stop();
      _pulseController.value = 0;
      return;
    }
    if (!_entryStarted) {
      _entryStarted = true;
      _entryController.forward();
    }
    if (!_pulseController.isAnimating) {
      _pulseController.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _entryController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final baseTheme = Theme.of(context);
    final appTheme = baseTheme.copyWith(
      textTheme: baseTheme.textTheme.apply(fontFamily: 'IBMPlexSansArabic'),
      primaryTextTheme: baseTheme.primaryTextTheme.apply(
        fontFamily: 'IBMPlexSansArabic',
      ),
      scaffoldBackgroundColor: baseTheme.scaffoldBackgroundColor,
    );
    return Theme(
      data: appTheme,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: appTheme.scaffoldBackgroundColor,
          body: SafeArea(
            top: false,
            child: Stack(
              children: [
                const Positioned.fill(child: _SoftBackground()),
                CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverAppBar(
                      primary: true,
                      pinned: true,
                      toolbarHeight: 52,
                      elevation: 0,
                      scrolledUnderElevation: 0,
                      backgroundColor: Colors.transparent,
                      surfaceTintColor: Colors.transparent,
                      automaticallyImplyLeading: false,
                      leadingWidth: 56,
                      leading: IconButton(
                        tooltip: 'رجوع',
                        onPressed: () => Navigator.of(context).maybePop(),
                        icon: const Icon(Icons.arrow_forward_rounded),
                        color: _inkFor(context),
                      ),
                      title: Text(
                        'حول وصال',
                        style: TextStyle(
                          color: _inkFor(context),
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      flexibleSpace: ClipRect(
                        child: BackdropFilter(
                          filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _surfaceFor(
                                context,
                              ).withValues(alpha: _isDark(context) ? .88 : .84),
                              border: const Border(
                                bottom: BorderSide(color: Color(0xFFEFF2F0)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 560),
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(12, 14, 12, 26),
                            child: Column(
                              children: [
                                _StaggeredEntry(
                                  index: 0,
                                  controller: _entryController,
                                  child: _hero(context),
                                ),
                                const SizedBox(height: 10),
                                _StaggeredEntry(
                                  index: 1,
                                  controller: _entryController,
                                  child: _companyCard(),
                                ),
                                const SizedBox(height: 10),
                                _StaggeredEntry(
                                  index: 2,
                                  controller: _entryController,
                                  child: _aboutCard(),
                                ),
                                const SizedBox(height: 10),
                                _StaggeredEntry(
                                  index: 3,
                                  controller: _entryController,
                                  child: _contactCard(context),
                                ),
                                const SizedBox(height: 10),
                                _StaggeredEntry(
                                  index: 4,
                                  controller: _entryController,
                                  child: _linksCard(context),
                                ),
                                const SizedBox(height: 20),
                                _footer(),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _hero(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Container(
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [_waslaGreen, _waslaGreenDark],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: _waslaGreen.withValues(alpha: .22),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: -54,
            left: -38,
            child: Container(
              width: 155,
              height: 155,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: .055),
              ),
            ),
          ),
          Positioned(
            bottom: -75,
            right: 90,
            child: Container(
              width: 145,
              height: 145,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: .045),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .14),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .20),
                        ),
                      ),
                      child: const Icon(
                        Icons.forum_rounded,
                        color: Colors.white,
                        size: 33,
                      ),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'وصال',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 25,
                              fontWeight: FontWeight.w700,
                              height: 1.2,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'تواصل أقرب، أينما كنت',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: .82),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(
                      Icons.spa_rounded,
                      color: Colors.white.withValues(alpha: .24),
                      size: 28,
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Container(
                  height: 1,
                  color: Colors.white.withValues(alpha: .18),
                ),
                const SizedBox(height: 13),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsetsDirectional.fromSTEB(
                        11,
                        6,
                        10,
                        6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .13),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: .16),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              final pulse = _pulseController.value;
                              return Container(
                                width: 7 + pulse * 2,
                                height: 7 + pulse * 2,
                                margin: const EdgeInsetsDirectional.only(
                                  end: 7,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFA5F2C2),
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: const Color(0xFFA5F2C2)
                                          .withValues(alpha: .18 + pulse * .24),
                                      blurRadius: 3 + pulse * 5,
                                      spreadRadius: pulse,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                          const Text(
                            'الإصدار $_appVersion',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _companyCard() => _AboutCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader(
          icon: Icons.apartment_rounded,
          title: 'الشركة المطوّرة',
        ),
        const SizedBox(height: 12),
        Text(
          'شركة الصرم للتطوير والبرمجيات',
          style: TextStyle(
            color: _inkFor(context),
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'شركة متخصصة في تطوير البرمجيات والتطبيقات الرقمية.',
          style: TextStyle(
            color: _mutedFor(context),
            fontSize: 13,
            height: 1.55,
          ),
        ),
      ],
    ),
  );

  Widget _aboutCard() => _AboutCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader(icon: Icons.spa_outlined, title: 'عن وصال'),
        const SizedBox(height: 9),
        Text(
          'وصال مساحة عربية تجمعك بمن يهمّك؛ محادثاتك ومجتمعاتك ومكالماتك في تجربة واحدة بسيطة.',
          style: TextStyle(
            color: _mutedFor(context),
            fontSize: 13,
            height: 1.65,
          ),
        ),
        const SizedBox(height: 14),
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth >= 400 ? 3 : 2;
            return GridView.count(
              crossAxisCount: columns,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: columns == 3 ? 1.58 : 2.05,
              children: const [
                _FeatureTile(icon: Icons.chat_bubble_outline, label: 'محادثات'),
                _FeatureTile(icon: Icons.groups_2_outlined, label: 'مجموعات'),
                _FeatureTile(icon: Icons.campaign_outlined, label: 'قنوات'),
                _FeatureTile(icon: Icons.circle_outlined, label: 'حالات'),
                _FeatureTile(icon: Icons.call_outlined, label: 'مكالمات'),
                _FeatureTile(
                  icon: Icons.location_on_outlined,
                  label: 'القريبون',
                ),
              ],
            );
          },
        ),
      ],
    ),
  );

  Widget _contactCard(BuildContext context) => _AboutCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader(
          icon: Icons.headset_mic_outlined,
          title: 'تواصل معنا',
        ),
        const SizedBox(height: 13),
        Row(
          children: [
            Expanded(
              child: _ActionButton(
                compact: true,
                icon: Icons.mail_outline_rounded,
                title: 'البريد',
                color: const Color(0xFF365D9B),
                onTap: () => _confirmExternal(
                  context,
                  Uri(
                    scheme: 'mailto',
                    path: _email,
                    queryParameters: const {'subject': 'تواصل من تطبيق وصال'},
                  ),
                  title: 'فتح تطبيق البريد',
                  detail: 'سيتم فتح رسالة جديدة إلى البريد الرسمي لوصال.',
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _ActionButton(
                compact: true,
                icon: Icons.forum_outlined,
                title: 'عبر وصال',
                color: _waslaGreenDark,
                onTap: () async {
                  await Clipboard.setData(
                    const ClipboardData(text: _waslaUsername),
                  );
                  if (context.mounted) {
                    _showToast(context, 'تم نسخ حساب وصال: $_waslaUsername');
                  }
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _ActionButton(
                compact: true,
                icon: Icons.chat_rounded,
                title: 'واتساب',
                color: const Color(0xFF168C56),
                onTap: () => _confirmExternal(
                  context,
                  Uri.https('wa.me', '/$_whatsAppNumber'),
                  title: 'فتح واتساب',
                  detail: 'سيتم فتح محادثة واتساب مع فريق وصال.',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 9),
        Center(
          child: Text(
            _email,
            textDirection: TextDirection.ltr,
            style: TextStyle(color: _mutedFor(context), fontSize: 11),
          ),
        ),
      ],
    ),
  );

  Widget _linksCard(BuildContext context) => _AboutCard(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionHeader(icon: Icons.link_rounded, title: 'روابط ومعلومات'),
        const SizedBox(height: 13),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 9,
          mainAxisSpacing: 9,
          childAspectRatio: 2.35,
          children: [
            _ActionButton(
              icon: Icons.verified_user_outlined,
              title: 'الخصوصية',
              onTap: () => _showPolicySheet(
                context,
                title: 'الخصوصية',
                detail: 'رابط سياسة الخصوصية الرسمية غير مضاف في هذا الإصدار.',
                icon: Icons.verified_user_outlined,
              ),
            ),
            _ActionButton(
              icon: Icons.description_outlined,
              title: 'الشروط',
              onTap: () => _showPolicySheet(
                context,
                title: 'شروط الاستخدام',
                detail: 'رابط شروط الاستخدام الرسمية غير مضاف في هذا الإصدار.',
                icon: Icons.description_outlined,
              ),
            ),
            _ActionButton(
              icon: Icons.flag_outlined,
              title: 'الإبلاغ',
              onTap: () => _confirmExternal(
                context,
                Uri(
                  scheme: 'mailto',
                  path: _email,
                  queryParameters: const {'subject': 'بلاغ عن تطبيق وصال'},
                ),
                title: 'إرسال بلاغ',
                detail: 'سيتم فتح رسالة بريد إلى فريق وصال لوصف المشكلة.',
              ),
            ),
            _ActionButton(
              icon: Icons.help_outline_rounded,
              title: 'المساعدة',
              onTap: () => _confirmExternal(
                context,
                Uri(
                  scheme: 'mailto',
                  path: _email,
                  queryParameters: const {'subject': 'طلب مساعدة - وصال'},
                ),
                title: 'التواصل مع الدعم',
                detail: 'سيتم فتح رسالة بريد لفريق الدعم في وصال.',
              ),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _footer() => Column(
    children: [
      Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: _softFor(context),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(Icons.forum_rounded, color: _accentFor(context), size: 20),
      ),
      const SizedBox(height: 6),
      Text(
        'وصال',
        style: TextStyle(
          color: _inkFor(context),
          fontSize: 13,
          fontWeight: FontWeight.w700,
        ),
      ),
      const SizedBox(height: 2),
      Text(
        '© 2026 شركة الصرم للتطوير والبرمجيات — جميع الحقوق محفوظة',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: _mutedFor(context),
          fontSize: 10.5,
          height: 1.5,
        ),
      ),
    ],
  );

  Future<void> _confirmExternal(
    BuildContext context,
    Uri uri, {
    required String title,
    required String detail,
  }) async {
    final approved = await showModalBottomSheet<bool>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      backgroundColor: _surfaceFor(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 2, 20, 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: _inkFor(sheetContext),
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 7),
            Text(
              detail,
              style: TextStyle(color: _mutedFor(sheetContext), height: 1.55),
            ),
            const SizedBox(height: 8),
            Directionality(
              textDirection: TextDirection.ltr,
              child: SelectableText(
                uri.toString(),
                style: TextStyle(color: _mutedFor(sheetContext), fontSize: 12),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(sheetContext, false),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _inkFor(sheetContext),
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                    child: const Text('إلغاء'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => Navigator.pop(sheetContext, true),
                    style: FilledButton.styleFrom(
                      backgroundColor: _waslaGreenDark,
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                    icon: const Icon(Icons.open_in_new_rounded, size: 18),
                    label: const Text('متابعة'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    if (approved != true || !context.mounted) return;
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (context.mounted && !opened) {
        _showToast(context, 'تعذر فتح التطبيق المطلوب على هذا الجهاز.');
      }
    } catch (_) {
      if (context.mounted) {
        _showToast(context, 'تعذر فتح التطبيق المطلوب على هذا الجهاز.');
      }
    }
  }

  void _showPolicySheet(
    BuildContext context, {
    required String title,
    required String detail,
    required IconData icon,
  }) {
    showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      showDragHandle: true,
      backgroundColor: _surfaceFor(context),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => Padding(
        padding: const EdgeInsets.fromLTRB(22, 4, 22, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: _softFor(sheetContext),
                borderRadius: BorderRadius.circular(17),
              ),
              child: Icon(icon, color: _accentFor(sheetContext)),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                color: _inkFor(sheetContext),
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 7),
            Text(
              detail,
              textAlign: TextAlign.center,
              style: TextStyle(color: _mutedFor(sheetContext), height: 1.6),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(sheetContext),
                style: FilledButton.styleFrom(
                  backgroundColor: _waslaGreenDark,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(46),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13),
                  ),
                ),
                child: const Text('حسنًا'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showToast(BuildContext context, String message) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message, textAlign: TextAlign.center),
          behavior: SnackBarBehavior.floating,
          backgroundColor: const Color(0xFF163C2A),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          margin: const EdgeInsets.fromLTRB(24, 0, 24, 18),
          duration: const Duration(seconds: 3),
        ),
      );
  }
}

class _SoftBackground extends StatelessWidget {
  const _SoftBackground();

  @override
  Widget build(BuildContext context) => IgnorePointer(
    child: Stack(
      children: [
        Positioned(
          top: -90,
          right: -105,
          child: _Glow(
            size: 260,
            color: _waslaGreenLight.withValues(
              alpha: _isDark(context) ? .07 : .11,
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: -120,
          child: _Glow(
            size: 250,
            color: _waslaGreen.withValues(alpha: _isDark(context) ? .05 : .08),
          ),
        ),
      ],
    ),
  );
}

class _Glow extends StatelessWidget {
  const _Glow({required this.size, required this.color});
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) => ImageFiltered(
    imageFilter: ui.ImageFilter.blur(sigmaX: 45, sigmaY: 45),
    child: Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    ),
  );
}

class _AboutCard extends StatelessWidget {
  const _AboutCard({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [_surfaceFor(context), _surfaceAltFor(context)],
      ),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: _borderFor(context)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: _isDark(context) ? .12 : .035),
          blurRadius: 16,
          offset: Offset(0, 5),
        ),
      ],
    ),
    child: child,
  );
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: _softFor(context),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: _accentFor(context), size: 19),
      ),
      const SizedBox(width: 10),
      Text(
        title,
        style: TextStyle(
          color: _inkFor(context),
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
      ),
    ],
  );
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: _isDark(context)
          ? const Color(0xFF1D3029)
          : const Color(0xFFF5FAF7),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _borderFor(context)),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
    child: Row(
      children: [
        Icon(icon, size: 19, color: _accentFor(context)),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: _inkFor(context),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    ),
  );
}

class _ActionButton extends StatefulWidget {
  const _ActionButton({
    required this.icon,
    required this.title,
    required this.onTap,
    this.color = _waslaGreenDark,
    this.compact = false,
  });
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color color;
  final bool compact;

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(widget.compact ? 14 : 13);
    final dark = _isDark(context);
    final actionColor = dark
        ? Color.lerp(widget.color, Colors.white, .28)!
        : widget.color;
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        transform: Matrix4.translationValues(0, _hovered ? -1 : 0, 0),
        decoration: BoxDecoration(
          color: _surfaceFor(context),
          borderRadius: radius,
          border: Border.all(
            color: _hovered
                ? (dark ? const Color(0xFF4C8062) : const Color(0xFFB8E3CA))
                : _borderFor(context),
          ),
          boxShadow: _hovered
              ? [
                  BoxShadow(
                    color: _waslaGreen.withValues(alpha: .12),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : const [],
        ),
        child: Material(
          color: Colors.transparent,
          borderRadius: radius,
          child: InkWell(
            onTap: widget.onTap,
            borderRadius: radius,
            splashColor: _waslaGreen.withValues(alpha: .12),
            highlightColor: _waslaGreen.withValues(alpha: .05),
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: widget.compact ? 78 : 54),
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: widget.compact ? 5 : 11,
                  vertical: widget.compact ? 8 : 8,
                ),
                child: widget.compact
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(widget.icon, color: actionColor, size: 21),
                          const SizedBox(height: 5),
                          Text(
                            widget.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: _inkFor(context),
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        children: [
                          Icon(widget.icon, color: actionColor, size: 19),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              widget.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: _inkFor(context),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const Icon(
                            Icons.chevron_left_rounded,
                            color: Color(0xFF8A958E),
                            size: 18,
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _StaggeredEntry extends StatelessWidget {
  const _StaggeredEntry({
    required this.index,
    required this.controller,
    required this.child,
  });
  final int index;
  final AnimationController controller;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).disableAnimations) return child;
    final begin = index * .06;
    final animation = CurvedAnimation(
      parent: controller,
      curve: Interval(begin, begin + .46, curve: Curves.easeOutCubic),
    );
    return AnimatedBuilder(
      animation: animation,
      child: child,
      builder: (context, child) => Opacity(
        opacity: animation.value,
        child: Transform.translate(
          offset: Offset(0, 14 * (1 - animation.value)),
          child: child,
        ),
      ),
    );
  }
}
