export type AuthenticationTemplateInput = {
  phone: string;
  otp: string;
  templateName: string;
  language: string;
};

export type AuthenticationTemplatePayload = {
  messaging_product: "whatsapp";
  recipient_type: "individual";
  to: string;
  type: "template";
  template: {
    name: string;
    language: { code: string };
    components: Array<Record<string, unknown>>;
  };
};

export function buildAuthenticationTemplatePayload(
  input: AuthenticationTemplateInput,
): AuthenticationTemplatePayload {
  const { phone, otp, templateName, language } = input;
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) {
    throw new Error("Phone must be in E.164 format");
  }
  if (!/^\d{6}$/.test(otp)) {
    throw new Error("Supabase phone OTP must contain six digits");
  }
  if (!/^[a-z0-9_]{1,512}$/.test(templateName)) {
    throw new Error("Invalid WhatsApp authentication template name");
  }
  if (!/^[a-z]{2,3}(?:_[A-Z]{2})?$/.test(language)) {
    throw new Error("Invalid WhatsApp template language code");
  }

  return {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: phone.slice(1),
    type: "template",
    template: {
      name: templateName,
      language: { code: language },
      components: [
        {
          type: "body",
          parameters: [{ type: "text", text: otp }],
        },
        {
          type: "button",
          sub_type: "url",
          index: "0",
          parameters: [{ type: "text", text: otp }],
        },
      ],
    },
  };
}
