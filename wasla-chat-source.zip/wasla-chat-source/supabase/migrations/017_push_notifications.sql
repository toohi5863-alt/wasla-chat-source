-- Register Android FCM tokens without exposing device tokens to other users.
create table if not exists public.push_devices (
  token text primary key check (char_length(token) between 20 and 8192),
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null default 'android'
    check (platform in ('android', 'ios')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists push_devices_user_id_idx
  on public.push_devices(user_id);

alter table public.push_devices enable row level security;
revoke all on public.push_devices from public, anon, authenticated;

create or replace function public.register_push_device(
  p_token text,
  p_platform text default 'android'
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
begin
  if v_user_id is null then
    raise exception 'Authentication required';
  end if;
  if p_token is null or char_length(p_token) not between 20 and 8192 then
    raise exception 'Invalid push token';
  end if;
  if p_platform not in ('android', 'ios') then
    raise exception 'Unsupported push platform';
  end if;
  insert into public.push_devices(token, user_id, platform)
  values (p_token, v_user_id, p_platform)
  on conflict (token) do update set
    user_id = excluded.user_id,
    platform = excluded.platform,
    updated_at = now();
end;
$$;

create or replace function public.unregister_push_device(p_token text)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  delete from public.push_devices
  where token = p_token and user_id = auth.uid();
end;
$$;

revoke all on function public.register_push_device(text, text)
  from public, anon;
revoke all on function public.unregister_push_device(text)
  from public, anon;
grant execute on function public.register_push_device(text, text)
  to authenticated;
grant execute on function public.unregister_push_device(text)
  to authenticated;
